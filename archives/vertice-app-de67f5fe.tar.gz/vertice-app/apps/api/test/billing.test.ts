import assert from "node:assert/strict";
import { test } from "node:test";
import { createHmac } from "node:crypto";
import {
  isNewerThanLastEvent,
  normalizeAsaasEvent,
  statusForEffect,
  verifyHmacSignature,
  verifySharedToken,
  WebhookSignatureError,
} from "../src/domain/billing.js";

// ---------------------------------------------------------------------------
// Assinatura: a única coisa que impede alguém de marcar a conta como paga.
// ---------------------------------------------------------------------------

const SECRET = "segredo-de-webhook-de-teste";
const BODY = JSON.stringify({ id: "evt_1", event: "PAYMENT_CONFIRMED" });

function sign(body: string, secret = SECRET): string {
  return createHmac("sha256", secret).update(body).digest("hex");
}

test("assinatura correta passa", () => {
  assert.doesNotThrow(() => verifyHmacSignature(BODY, sign(BODY), SECRET));
});

test("assinatura de outro segredo é recusada", () => {
  assert.throws(
    () => verifyHmacSignature(BODY, sign(BODY, "outro-segredo"), SECRET),
    WebhookSignatureError,
  );
});

test("corpo alterado depois da assinatura é recusado", () => {
  const assinatura = sign(BODY);
  const adulterado = BODY.replace("PAYMENT_CONFIRMED", "PAYMENT_RECEIVED");
  assert.throws(() => verifyHmacSignature(adulterado, assinatura, SECRET), WebhookSignatureError);
});

test("assinatura ausente é recusada", () => {
  assert.throws(() => verifyHmacSignature(BODY, undefined, SECRET), WebhookSignatureError);
  assert.throws(() => verifyHmacSignature(BODY, "", SECRET), WebhookSignatureError);
});

test("segredo não configurado falha fechado em vez de aceitar tudo", () => {
  assert.throws(() => verifyHmacSignature(BODY, sign(BODY), ""), WebhookSignatureError);
});

test("assinatura de tamanho errado é recusada sem quebrar timingSafeEqual", () => {
  // timingSafeEqual lança se os buffers têm tamanhos diferentes; o código
  // compara tamanho antes, então o erro é o nosso, não um RangeError.
  assert.throws(() => verifyHmacSignature(BODY, "ab", SECRET), WebhookSignatureError);
});

test("aceita a assinatura em Buffer, como chega do provedor", () => {
  const raw = Buffer.from(BODY, "utf8");
  assert.doesNotThrow(() => verifyHmacSignature(raw, sign(BODY), SECRET));
});

test("segmento de token: valor errado é recusado", () => {
  assert.doesNotThrow(() => verifySharedToken("token-compartilhado", "token-compartilhado"));
  assert.throws(() => verifySharedToken("outro", "token-compartilhado"), WebhookSignatureError);
  assert.throws(() => verifySharedToken(undefined, "token-compartilhado"), WebhookSignatureError);
  assert.throws(() => verifySharedToken("x", ""), WebhookSignatureError);
});

// ---------------------------------------------------------------------------
// Tradução de evento
// ---------------------------------------------------------------------------

test("pagamento confirmado vira assinatura ativa", () => {
  const event = normalizeAsaasEvent({
    id: "evt_9",
    event: "PAYMENT_CONFIRMED",
    payment: { subscription: "sub_123" },
    dateCreated: "2026-03-15 10:00:00",
  });
  assert.equal(event.eventId, "evt_9");
  assert.equal(event.providerRef, "sub_123");
  assert.equal(event.effect.kind, "subscription_active");
  assert.ok(event.occurredAt instanceof Date);
});

test("pagamento em atraso vira past_due", () => {
  const event = normalizeAsaasEvent({
    id: "evt_10",
    event: "PAYMENT_OVERDUE",
    payment: { subscription: "sub_123" },
  });
  assert.equal(event.effect.kind, "subscription_past_due");
  assert.equal(statusForEffect(event.effect), "past_due");
});

test("exclusão de assinatura encerra a conta", () => {
  const event = normalizeAsaasEvent({
    id: "evt_11",
    event: "SUBSCRIPTION_DELETED",
    subscription: { id: "sub_123" },
  });
  assert.equal(event.effect.kind, "subscription_canceled");
  assert.equal(statusForEffect(event.effect), "churned");
});

test("evento sem efeito comercial é ignorado, não rejeitado", () => {
  const event = normalizeAsaasEvent({
    id: "evt_12",
    event: "PAYMENT_CREATED",
    payment: { subscription: "sub_123" },
  });
  assert.equal(event.effect.kind, "ignored");
  assert.equal(statusForEffect(event.effect), null);
});

test("evento sem id ou sem tipo é erro de formato", () => {
  assert.throws(() => normalizeAsaasEvent({ event: "PAYMENT_CONFIRMED" }), WebhookSignatureError);
  assert.throws(() => normalizeAsaasEvent({ id: "evt_1" }), WebhookSignatureError);
  assert.throws(() => normalizeAsaasEvent(null), WebhookSignatureError);
});

test("evento sem referência de assinatura é normalizado com providerRef nulo", () => {
  const event = normalizeAsaasEvent({ id: "evt_13", event: "PAYMENT_CONFIRMED" });
  assert.equal(event.providerRef, null);
});

// ---------------------------------------------------------------------------
// Ordem dos eventos
// ---------------------------------------------------------------------------

const t = (iso: string) => new Date(iso);

test("evento mais novo que o último aplicado passa", () => {
  assert.equal(isNewerThanLastEvent(t("2026-03-15T12:00:00Z"), t("2026-03-15T11:00:00Z")), true);
});

test("evento mais antigo que o último aplicado é descartado", () => {
  assert.equal(isNewerThanLastEvent(t("2026-03-15T10:00:00Z"), t("2026-03-15T11:00:00Z")), false);
});

test("evento no mesmo instante do último não reaplica", () => {
  assert.equal(isNewerThanLastEvent(t("2026-03-15T11:00:00Z"), t("2026-03-15T11:00:00Z")), false);
});

test("sem instante do provedor, aplica: a idempotência por id ainda protege", () => {
  assert.equal(isNewerThanLastEvent(null, t("2026-03-15T11:00:00Z")), true);
});

test("primeiro evento da assinatura sempre passa", () => {
  assert.equal(isNewerThanLastEvent(t("2020-01-01T00:00:00Z"), null), true);
});
