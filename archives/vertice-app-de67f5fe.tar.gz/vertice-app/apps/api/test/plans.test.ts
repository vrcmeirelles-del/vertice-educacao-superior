import assert from "node:assert/strict";
import { test } from "node:test";
import {
  blockReason,
  canRead,
  canWrite,
  checkQuota,
  effectiveStatus,
  quotaMessage,
  trialDaysLeft,
  type InstitutionState,
  type PlanLimits,
} from "../src/domain/plans.js";

// ---------------------------------------------------------------------------
// Ciclo de vida: as regras que a cobrança NÃO pode quebrar.
// ---------------------------------------------------------------------------

const NOW = new Date("2026-03-15T12:00:00Z");

const state = (over: Partial<InstitutionState> = {}): InstitutionState => ({
  status: "active",
  trialEndsAt: null,
  planCode: "piloto",
  ...over,
});

test("cliente ativo escreve", () => {
  assert.equal(canWrite(state({ status: "active" }), NOW), true);
});

test("trial dentro do prazo escreve", () => {
  const trial = state({ status: "trial", trialEndsAt: new Date("2026-04-01T00:00:00Z") });
  assert.equal(effectiveStatus(trial, NOW), "trial");
  assert.equal(canWrite(trial, NOW), true);
});

test("trial vencido bloqueia escrita sem depender de cron ter marcado o estado", () => {
  const expired = state({ status: "trial", trialEndsAt: new Date("2026-03-01T00:00:00Z") });
  assert.equal(effectiveStatus(expired, NOW), "trial_expired");
  assert.equal(canWrite(expired, NOW), false);
  // Mas o banco ainda diz "trial": nenhum job rodou.
  assert.equal(expired.status, "trial");
});

test("trial vencido continua legível", () => {
  const expired = state({ status: "trial", trialEndsAt: new Date("2026-03-01T00:00:00Z") });
  assert.equal(canRead(expired), true);
});

test("past_due escreve: inadimplência não derruba operação em curso", () => {
  assert.equal(canWrite(state({ status: "past_due" }), NOW), true);
});

test("suspended bloqueia escrita mas não leitura nem exportação", () => {
  const suspended = state({ status: "suspended" });
  assert.equal(canWrite(suspended, NOW), false);
  assert.equal(canRead(suspended), true);
});

test("churned não lê nada", () => {
  assert.equal(canRead(state({ status: "churned" })), false);
});

test("motivo do bloqueio é específico por estado", () => {
  const expired = blockReason(
    state({ status: "trial", trialEndsAt: new Date("2026-03-01T00:00:00Z") }),
    NOW,
  );
  assert.match(expired ?? "", /avaliação/);
  assert.match(expired ?? "", /leitura e exportação/);

  const suspended = blockReason(state({ status: "suspended" }), NOW);
  assert.match(suspended ?? "", /suspensa/);
  assert.match(suspended ?? "", /exportação/);

  assert.equal(blockReason(state({ status: "active" }), NOW), null);
  assert.equal(blockReason(state({ status: "past_due" }), NOW), null);
});

test("dias restantes de trial arredondam para cima e ficam negativos quando vence", () => {
  assert.equal(
    trialDaysLeft(state({ status: "trial", trialEndsAt: new Date("2026-03-16T12:00:00Z") }), NOW),
    1,
  );
  assert.equal(
    trialDaysLeft(state({ status: "trial", trialEndsAt: new Date("2026-03-10T00:00:00Z") }), NOW),
    -5,
  );
  assert.equal(trialDaysLeft(state({ status: "active" }), NOW), null);
});

// ---------------------------------------------------------------------------
// Cotas
// ---------------------------------------------------------------------------

const limits: PlanLimits = {
  planCode: "piloto",
  maxUsers: 10,
  maxAlertsMonth: 5000,
  maxStorageMb: 2048,
  maxBatchesDay: 20,
  maxCourses: 30,
  maxBatchRecords: 1000,
};

test("abaixo da cota passa", () => {
  assert.equal(checkQuota(limits, "maxUsers", 3), null);
});

test("no limite exato ainda passa", () => {
  assert.equal(checkQuota(limits, "maxUsers", 9, 1), null);
});

test("um acima do limite bloqueia", () => {
  const message = checkQuota(limits, "maxUsers", 10, 1);
  assert.ok(message, "deveria bloquear");
  assert.match(message!, /10 usuários ativos/);
});

test("cota nula significa sem limite, não zero", () => {
  const unlimited: PlanLimits = { ...limits, maxUsers: null, planCode: "contrato" };
  assert.equal(checkQuota(unlimited, "maxUsers", 10_000, 500), null);
});

test("mensagem de cota diz o limite e o uso, sem acusar o cliente", () => {
  const message = quotaMessage("maxStorageMb", 2048, 2048);
  assert.match(message, /2048/);
  assert.match(message, /armazenamento/);
  assert.match(message, /ampliar o plano/);
  assert.ok(!/excedido|bloqueado/i.test(message), "texto não deve soar punitivo");
});
