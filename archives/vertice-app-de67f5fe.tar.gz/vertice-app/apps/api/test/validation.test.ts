import assert from "node:assert/strict";
import { test } from "node:test";
import {
  detectForbiddenFields,
  retentionRecordSchema,
  validateBatch,
} from "../src/domain/validation.js";

const valid = {
  studentRef: "stu_001",
  courseRef: "course_admin",
  attendancePercent: 74,
  consecutiveAbsences: 3,
  observedAt: "2026-10-27T12:00:00-03:00",
  source: "portal-adapter-v1",
};

test("aceita registro mínimo válido", () => {
  assert.equal(retentionRecordSchema.safeParse(valid).success, true);
});

test("rejeita campo extra não previsto", () => {
  const result = retentionRecordSchema.safeParse({ ...valid, nome: "Fulano" });
  assert.equal(result.success, false);
});

test("rejeita percentual fora da faixa", () => {
  assert.equal(retentionRecordSchema.safeParse({ ...valid, attendancePercent: 140 }).success, false);
});

test("rejeita data sem offset", () => {
  assert.equal(retentionRecordSchema.safeParse({ ...valid, observedAt: "2026-10-27" }).success, false);
});

test("rejeita tipo de requerimento desconhecido", () => {
  assert.equal(retentionRecordSchema.safeParse({ ...valid, openRequests: ["FREE_TEXT"] }).success, false);
});

test("detecta CPF e e-mail aninhados", () => {
  const fields = detectForbiddenFields({
    records: [{ ...valid, cpf: "000", aluno: { email: "x@y.z" } }],
  });
  assert.ok(fields.includes("cpf"));
  assert.ok(fields.includes("email"));
});

test("lote separa aceitos e rejeitados sem abortar tudo", () => {
  const outcome = validateBatch([valid, { ...valid, attendancePercent: -1 }, valid], retentionRecordSchema);
  assert.equal(outcome.accepted.length, 2);
  assert.equal(outcome.rejected.length, 1);
  assert.equal(outcome.rejected[0]?.index, 1);
  assert.equal(outcome.rejected[0]?.field, "attendancePercent");
});
