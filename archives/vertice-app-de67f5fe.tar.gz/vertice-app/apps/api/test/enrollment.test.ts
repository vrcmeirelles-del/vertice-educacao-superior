import assert from "node:assert/strict";
import { test } from "node:test";
import {
  buildCoursePanelRow,
  classesWithStudents,
  compare,
  consolidate,
  decidePublish,
  findDivergences,
  previousSemester,
  sumClassEnrollment,
  sumStatuses,
  toEnrollmentRow,
  type EnrollmentRow,
} from "../src/domain/enrollment.js";
import {
  detectStudentLevelFields,
  enrollmentEnvelopeSchema,
  enrollmentRecordSchema,
  validateBatch,
} from "../src/domain/validation.js";

const base = {
  courseRef: "027",
  semester: "2026/02",
  observedAt: "2026-10-29T12:00:00-03:00",
  source: "eorbit-v1",
};

const row = (over: Partial<EnrollmentRow> = {}): EnrollmentRow => ({
  ...toEnrollmentRow(base),
  ...over,
});

// ---------------------------------------------------------------------------
// Contrato: agregado não aceita aluno.
// ---------------------------------------------------------------------------

test("aceita registro agregado mínimo", () => {
  assert.equal(enrollmentRecordSchema.safeParse(base).success, true);
});

test("rejeita campo por aluno no lote de matrícula", () => {
  const result = enrollmentRecordSchema.safeParse({ ...base, studentRef: "stu_1" });
  assert.equal(result.success, false);
});

test("rejeita nome de aluno mesmo em campo aninhado", () => {
  const fields = detectStudentLevelFields({
    records: [{ ...base, turmas: [{ serie: 1, turma: "A", matriculados: 3, aluno: "Fulano" }] }],
  });
  assert.deepEqual(fields, []);
  // `aluno` não é campo do contrato de retenção; quem barra é o .strict().
  assert.equal(
    enrollmentRecordSchema.safeParse({
      ...base,
      turmas: [{ serie: 1, turma: "A", matriculados: 3, aluno: "Fulano" }],
    }).success,
    false,
  );
});

test("detecta studentRef colado por engano na planilha de matrícula", () => {
  const fields = detectStudentLevelFields({ records: [{ ...base, studentRef: "x" }] });
  assert.deepEqual(fields, ["studentRef"]);
});

test("rejeita semestre fora do formato AAAA/01 ou AAAA/02", () => {
  for (const semester of ["2026-02", "2026/2", "26/02", "2026/00", "2026/03", "2026/13"]) {
    assert.equal(
      enrollmentRecordSchema.safeParse({ ...base, semester }).success,
      false,
      `deveria recusar ${semester}`,
    );
  }
});

test("aceita semestre 2026/01 e 2026/02", () => {
  for (const semester of ["2026/01", "2026/02", "2022/01"]) {
    assert.equal(enrollmentRecordSchema.safeParse({ ...base, semester }).success, true);
  }
});

test("rejeita contagem negativa e decimal", () => {
  assert.equal(enrollmentRecordSchema.safeParse({ ...base, matriculado: -1 }).success, false);
  assert.equal(enrollmentRecordSchema.safeParse({ ...base, matriculado: 2.5 }).success, false);
});

test("envelope aceita lote com registro ruim dentro", () => {
  // A rota valida só o envelope; o registro ruim é separado no serviço.
  const r = enrollmentEnvelopeSchema.safeParse({
    records: [base, { ...base, semester: "2026-02" }],
  });
  assert.equal(r.success, true);
});

test("um registro inválido não derruba o lote de 840 linhas", () => {
  const bom = base;
  const ruim = { ...base, semester: "2026-02" };
  const outcome = validateBatch([bom, ruim, bom, bom], enrollmentRecordSchema);
  assert.equal(outcome.accepted.length, 3);
  assert.equal(outcome.rejected.length, 1);
  assert.equal(outcome.rejected[0]?.field, "semester");
});

test("envelope recusa campo extra no topo do corpo", () => {
  assert.equal(enrollmentEnvelopeSchema.safeParse({ records: [base], extra: 1 }).success, false);
});

test("envelope recusa lote vazio", () => {
  assert.equal(enrollmentEnvelopeSchema.safeParse({ records: [] }).success, false);
});

test("rejeita turma com zero matriculado", () => {
  const result = enrollmentRecordSchema.safeParse({
    ...base,
    turmas: [{ serie: 1, turma: "ADM-1A", matriculados: 0 }],
  });
  assert.equal(result.success, false);
});

// ---------------------------------------------------------------------------
// Cálculos
// ---------------------------------------------------------------------------

test("soma dos status ignora ausentes e soma presentes", () => {
  assert.equal(sumStatuses(row({ matriculado: 245, trancado: 11, graduado: 0 })), 256);
  assert.equal(sumStatuses(row()), 0);
});

test("soma das turmas reflete o detalhe", () => {
  const r = row({
    turmas: [
      { serie: 1, turma: "DIR-1A", matriculados: 38 },
      { serie: 2, turma: "DIR-2A", matriculados: 36 },
      { serie: 2, turma: "DIR-2B", matriculados: 37 },
    ],
  });
  assert.equal(sumClassEnrollment(r), 111);
});

// ---------------------------------------------------------------------------
// Divergência: publicar como está, nunca "consertar"
// ---------------------------------------------------------------------------

test("detecta soma por turma diferente do subtotal", () => {
  const r = row({
    turmasSomadas: 220,
    turmas: [{ serie: 1, turma: "DIR-1A", matriculados: 218 }],
  });
  const d = findDivergences(r);
  assert.equal(d.length, 1);
  assert.equal(d[0]?.kind, "subtotal_vs_turmas");
  assert.equal(d[0]?.expected, 220);
  assert.equal(d[0]?.found, 218);
});

test("não acusa divergência quando turmasSomadas é zero (origem omitiu)", () => {
  const r = row({ turmasSomadas: 0, turmas: [{ serie: 1, turma: "A", matriculados: 5 }] });
  assert.deepEqual(findDivergences(r), []);
});

test("detecta total de registros incoerente com a soma dos status", () => {
  const r = row({ matriculado: 245, trancado: 11, totalRegistros: 300 });
  const d = findDivergences(r);
  assert.equal(d[0]?.kind, "total_vs_status");
});

test("matriculado sem nenhuma turma detalhada é extração incompleta", () => {
  const r = row({ matriculado: 245, turmas: [] });
  const d = findDivergences(r);
  assert.ok(d.some((x) => x.kind === "turmas_sem_detalhe"));
});

test("turma repetida na origem conta uma vez em Turmas com alunos", () => {
  // Caso real do acervo: 001/2025-02 tem ADM-1A com 12 e com 1.
  const r = row({
    turmas: [
      { serie: 1, turma: "ADM-1A", matriculados: 12 },
      { serie: 1, turma: "ADM-1A", matriculados: 1 },
      { serie: 2, turma: "ADM-2A", matriculados: 33 },
    ],
  });
  assert.equal(classesWithStudents(r), 2);
  assert.equal(sumClassEnrollment(r), 46);
});

// ---------------------------------------------------------------------------
// Variação entre semestres
// ---------------------------------------------------------------------------

test("semestre anterior respeita a virada de ano", () => {
  assert.equal(previousSemester("2026/02"), "2026/01");
  assert.equal(previousSemester("2026/01"), "2025/02");
  assert.equal(previousSemester("2022/01"), "2021/02");
  assert.equal(previousSemester("2026/13"), null, "só existe 01 e 02");
  assert.equal(previousSemester("2026/03"), null);
  assert.equal(previousSemester("lixo"), null);
});

test("variação do Direito reproduz a planilha: 245 sobre 220", () => {
  const c = compare(245, 220);
  assert.equal(c.label, "up");
  assert.equal(Math.round((c.change ?? 0) * 100), 11);
});

test("base zero não vira 100%", () => {
  const c = compare(50, 0);
  assert.equal(c.change, null, "sem base, a variação é indefinida");
  assert.equal(c.label, "up");
});

test("sem semestre anterior, variação é null e não zero", () => {
  const c = compare(50, null);
  assert.equal(c.change, null);
  assert.equal(c.label, "no_base");
});

test("curso zerado nos dois semestres é flat, não queda de 100%", () => {
  const c = compare(0, 0);
  assert.equal(c.label, "flat");
  assert.equal(c.change, null);
});

// ---------------------------------------------------------------------------
// Decisão de publicação
// ---------------------------------------------------------------------------

test("agregado coerente publica", () => {
  const r = row({
    matriculado: 245,
    trancado: 11,
    totalRegistros: 256,
    turmasSomadas: 245,
    turmas: [{ serie: 1, turma: "DIR-1A", matriculados: 245 }],
  });
  const d = decidePublish(r, findDivergences(r));
  assert.equal(d.verdict, "publish");
});

test("curso sem registro nenhum é pulado", () => {
  const d = decidePublish(row(), []);
  assert.equal(d.verdict, "skip");
});

test("matriculado sem turma vai para revisão, não para o painel", () => {
  const r = row({ matriculado: 245, totalRegistros: 245, turmas: [] });
  const d = decidePublish(r, findDivergences(r));
  assert.equal(d.verdict, "review");
  assert.match(d.reason, /Extração incompleta/);
});

test("divergência de total manda para revisão", () => {
  const r = row({
    matriculado: 245,
    totalRegistros: 999,
    turmas: [{ serie: 1, turma: "DIR-1A", matriculados: 245 }],
  });
  assert.equal(decidePublish(r, findDivergences(r)).verdict, "review");
});

// ---------------------------------------------------------------------------
// Consolidação
// ---------------------------------------------------------------------------

test("reimportação do mesmo semestre substitui pela observação mais nova", () => {
  const antigo = row({ matriculado: 200, observedAt: "2026-10-01T12:00:00-03:00" });
  const novo = row({ matriculado: 245, observedAt: "2026-10-29T12:00:00-03:00" });
  const out = consolidate([novo, antigo]);
  assert.equal(out.length, 1);
  assert.equal(out[0]?.matriculado, 245);
});

test("semestres diferentes do mesmo curso não se sobrescrevem", () => {
  const a = row({ semester: "2026/01", matriculado: 220 });
  const b = row({ semester: "2026/02", matriculado: 245 });
  const out = consolidate([a, b]);
  assert.equal(out.length, 2);
});

test("cursos diferentes no mesmo semestre são preservados", () => {
  const a = row({ courseRef: "027", matriculado: 245 });
  const b = row({ courseRef: "001", matriculado: 103 });
  assert.equal(consolidate([a, b]).length, 2);
});

// ---------------------------------------------------------------------------
// Linha do painel — o retrato que vai para a tela
// ---------------------------------------------------------------------------

test("linha do painel traz número, variação e turmas", () => {
  const atual = row({
    matriculado: 245,
    turmas: Array.from({ length: 10 }, (_, i) => ({
      serie: i + 1,
      turma: `DIR-${i + 1}A`,
      matriculados: 24,
    })),
  });
  const anterior = row({ semester: "2026/01", matriculado: 220 });
  const linha = buildCoursePanelRow(atual, anterior);

  assert.equal(linha.matriculado, 245);
  assert.equal(linha.previousMatriculado, 220);
  assert.equal(Math.round((linha.change.change ?? 0) * 100), 11);
  assert.equal(linha.classesWithStudents, 10);
  assert.equal(linha.decision.verdict, "publish");
});

test("curso novo sem semestre anterior não inventa variação", () => {
  const linha = buildCoursePanelRow(row({ matriculado: 10 }), null);
  assert.equal(linha.previousMatriculado, null);
  assert.equal(linha.change.change, null);
});
