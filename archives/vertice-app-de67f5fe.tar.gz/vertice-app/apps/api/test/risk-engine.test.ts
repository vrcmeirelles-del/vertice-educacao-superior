import assert from "node:assert/strict";
import { test } from "node:test";
import { evaluateRisk, DEFAULT_RULES, normalizeRules, levelFor } from "../src/domain/risk-engine.js";

const base = {
  attendancePercent: null,
  consecutiveAbsences: null,
  assessmentAverage: null,
  passingAverage: null,
  openRequests: [] as [],
};

test("soma os pesos e limita o escore a 100", () => {
  const result = evaluateRisk({
    attendancePercent: 50,
    consecutiveAbsences: 5,
    assessmentAverage: 3,
    passingAverage: 7,
    openRequests: ["TRANSFER_REQUEST"],
  });
  assert.equal(result.score, 100);
  assert.equal(result.level, "critical");
  assert.equal(result.factors.length, 4);
});

test("fatores explicam cada ponto somado", () => {
  const result = evaluateRisk({ ...base, attendancePercent: 70 });
  assert.equal(result.score, DEFAULT_RULES.attendanceWeight);
  assert.equal(result.factors[0]?.code, "LOW_ATTENDANCE");
  assert.equal(result.factors[0]?.observed, 70);
  assert.equal(result.factors[0]?.threshold, DEFAULT_RULES.attendanceThreshold);
});

test("remover um fator recalcula de forma determinística", () => {
  const full = evaluateRisk({ ...base, consecutiveAbsences: 4 });
  const without = evaluateRisk({ ...base, consecutiveAbsences: 1 });
  assert.equal(full.score - without.score, DEFAULT_RULES.consecutiveAbsenceWeight);
  assert.equal(without.score, 0);
});

test("requerimento de histórico NÃO pontua como saída", () => {
  const result = evaluateRisk({ ...base, openRequests: ["HISTORY_REQUEST", "SYLLABUS_REQUEST"] });
  assert.equal(result.score, 0);
  assert.equal(result.reviewRequired, false);
});

test("requerimento de trancamento pontua", () => {
  const result = evaluateRisk({ ...base, openRequests: ["WITHDRAWAL_REQUEST"] });
  assert.equal(result.score, DEFAULT_RULES.exitRequestWeight);
});

test("nunca emite decisão automatizada", () => {
  const result = evaluateRisk({ ...base, attendancePercent: 10, consecutiveAbsences: 9 });
  assert.equal(result.automatedDecision, null);
  assert.ok(result.recommendedAction.length > 0);
});

test("fronteiras de faixa", () => {
  assert.equal(levelFor(0), "low");
  assert.equal(levelFor(29), "low");
  assert.equal(levelFor(30), "medium");
  assert.equal(levelFor(49), "medium");
  assert.equal(levelFor(50), "high");
  assert.equal(levelFor(69), "high");
  assert.equal(levelFor(70), "critical");
  assert.equal(levelFor(100), "critical");
});

test("ruleset da IES sobrescreve limites", () => {
  const rules = normalizeRules({ attendanceThreshold: 90, attendanceWeight: 50 });
  const result = evaluateRisk({ ...base, attendancePercent: 85 }, rules);
  assert.equal(result.score, 50);
  assert.equal(result.factors[0]?.threshold, 90);
});

test("pesos inválidos são saneados", () => {
  const rules = normalizeRules({ attendanceWeight: 500, consecutiveAbsenceWeight: -20 });
  assert.equal(rules.attendanceWeight, 100);
  assert.equal(rules.consecutiveAbsenceWeight, 0);
});
