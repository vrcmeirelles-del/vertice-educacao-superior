import assert from "node:assert/strict";
import { test } from "node:test";
import { createServer, type Server } from "node:net";
import { AppError } from "../src/http/errors.js";
import { buildStorageKey, assertUploadAcceptable } from "../src/services/storage.js";
import { scanBuffer } from "../src/services/antivirus.js";

// ---------------------------------------------------------------------------
// Chave do objeto: nunca pode conter dado pessoal nem sair da raiz do bucket.
// ---------------------------------------------------------------------------

test("a chave não carrega nome de estudante e escapa caracteres perigosos", () => {
  const key = buildStorageKey({
    institutionId: "11111111-1111-1111-1111-111111111111",
    evidenceId: null,
    documentId: "22222222-2222-2222-2222-222222222222",
    fileName: "../../Relatório João da Silva (matrícula 2024).pdf",
  });

  assert.ok(!key.includes(".."), "não deve permitir travessia de caminho");
  assert.ok(!key.includes("/../"), "não deve permitir travessia de caminho");
  assert.ok(key.startsWith("11111111-1111-1111-1111-111111111111/avulso/"));
  assert.ok(!/[^\x20-\x7E]/.test(key), "chave deve ser ASCII imprimível");
});

test("sem evidência o arquivo vai para o prefixo avulso", () => {
  const key = buildStorageKey({
    institutionId: "abc",
    evidenceId: null,
    documentId: "doc",
    fileName: "ppc.pdf",
  });
  assert.equal(key, "abc/avulso/doc/ppc.pdf");
});

test("com evidência o arquivo fica sob o id da evidência", () => {
  const key = buildStorageKey({
    institutionId: "abc",
    evidenceId: "ev1",
    documentId: "doc",
    fileName: "ppc.pdf",
  });
  assert.equal(key, "abc/ev1/doc/ppc.pdf");
});

test("nome vazio resulta em nome padrão em vez de chave terminando em barra", () => {
  const key = buildStorageKey({
    institutionId: "abc",
    evidenceId: null,
    documentId: "doc",
    fileName: "...",
  });
  assert.ok(key.endsWith("/arquivo"));
});

// ---------------------------------------------------------------------------
// Validação de tipo e tamanho
// ---------------------------------------------------------------------------

test("aceita PDF dentro do limite", () => {
  assert.doesNotThrow(() => assertUploadAcceptable("application/pdf", 1024));
});

test("recusa tipo fora da lista fechada", () => {
  assert.throws(
    () => assertUploadAcceptable("application/x-msdownload", 1024),
    (error: unknown) => error instanceof AppError && error.statusCode === 415,
  );
});

test("recusa octet-stream, que burlaria a checagem de tipo", () => {
  assert.throws(
    () => assertUploadAcceptable("application/octet-stream", 1024),
    (error: unknown) => error instanceof AppError && error.statusCode === 415,
  );
});

test("recusa arquivo acima de 25 MB", () => {
  assert.throws(
    () => assertUploadAcceptable("application/pdf", 26 * 1024 * 1024),
    (error: unknown) => error instanceof AppError && error.statusCode === 413,
  );
});

test("recusa tamanho zero ou negativo", () => {
  for (const size of [0, -1]) {
    assert.throws(
      () => assertUploadAcceptable("application/pdf", size),
      (error: unknown) => error instanceof AppError && error.statusCode === 400,
    );
  }
});

test("recusa tamanho fracionário", () => {
  assert.throws(
    () => assertUploadAcceptable("application/pdf", 10.5),
    (error: unknown) => error instanceof AppError,
  );
});

// ---------------------------------------------------------------------------
// Antivírus: falha é sempre fechada
// ---------------------------------------------------------------------------

/** Sobe um ClamAV falso que responde com o texto dado. */
async function fakeClam(response: string | null): Promise<{ port: number; server: Server }> {
  const server = createServer((socket) => {
    let received = "";
    socket.on("data", (chunk) => {
      received += chunk.toString("latin1");
      // INSTREAM termina com 4 bytes zero; só então respondemos.
      if (received.includes("zINSTREAM\0") && received.endsWith("\0\0\0\0")) {
        if (response !== null) socket.end(response);
        // response null = nunca responde, para exercitar o timeout
      }
    });
    socket.on("error", () => undefined);
  });

  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  const port = typeof address === "object" && address ? address.port : 0;
  return { port, server };
}

async function withClam<T>(
  response: string | null,
  run: () => Promise<T>,
  extraEnv: Record<string, string> = {},
): Promise<T> {
  const { port, server } = await fakeClam(response);
  const savedPort = process.env.CLAMAV_PORT;
  const savedTimeout = process.env.CLAMAV_TIMEOUT_MS;
  const savedMode = process.env.ANTIVIRUS_MODE;

  process.env.CLAMAV_PORT = String(port);
  process.env.CLAMAV_HOST = "127.0.0.1";
  process.env.ANTIVIRUS_MODE = "required";
  for (const [k, v] of Object.entries(extraEnv)) process.env[k] = v;

  try {
    const { config } = await import("../src/config.js");
    (config.antivirus as { clamPort: number }).clamPort = port;
    (config.antivirus as { clamHost: string }).clamHost = "127.0.0.1";
    (config.antivirus as { mode: string }).mode = "required";
    (config.antivirus as { timeoutMs: number }).timeoutMs = 2000;
    return await run();
  } finally {
    server.close();
    if (savedPort === undefined) delete process.env.CLAMAV_PORT;
    else process.env.CLAMAV_PORT = savedPort;
    if (savedTimeout === undefined) delete process.env.CLAMAV_TIMEOUT_MS;
    else process.env.CLAMAV_TIMEOUT_MS = savedTimeout;
    if (savedMode === undefined) delete process.env.ANTIVIRUS_MODE;
    else process.env.ANTIVIRUS_MODE = savedMode;
  }
}

test("resposta OK do ClamAV resulta em clean", async () => {
  const result = await withClam("stream: OK\0", () => scanBuffer(Buffer.from("conteudo")));
  assert.equal(result.verdict, "clean");
  assert.equal(result.engine, "clamav");
});

test("resposta FOUND resulta em infected e preserva o nome da ameaça", async () => {
  const result = await withClam("stream: Eicar-Test-Signature FOUND\0", () =>
    scanBuffer(Buffer.from("X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR")),
  );
  assert.equal(result.verdict, "infected");
  assert.match(result.detail, /Eicar-Test-Signature/);
});

test("resposta inesperada resulta em failed, nunca clean", async () => {
  const result = await withClam("ERROR alguma coisa\0", () => scanBuffer(Buffer.from("x")));
  assert.equal(result.verdict, "failed");
});

test("servidor que não responde resulta em failed por timeout", async () => {
  const savedTimeout = process.env.CLAMAV_TIMEOUT_MS;
  process.env.CLAMAV_TIMEOUT_MS = "300";

  try {
    const result = await withClam(null, () => scanBuffer(Buffer.from("x")));
    assert.equal(result.verdict, "failed");
  } finally {
    if (savedTimeout === undefined) delete process.env.CLAMAV_TIMEOUT_MS;
    else process.env.CLAMAV_TIMEOUT_MS = savedTimeout;
  }
});

test("antivírus desligado nunca aprova arquivo", async () => {
  const { config } = await import("../src/config.js");
  const saved = config.antivirus.mode;
  (config.antivirus as { mode: string }).mode = "disabled";
  try {
    const result = await scanBuffer(Buffer.from("qualquer coisa"));
    assert.equal(result.verdict, "failed");
    assert.equal(result.engine, "disabled");
  } finally {
    (config.antivirus as { mode: string }).mode = saved;
  }
});
