import pg from "pg";
import { config } from "../config.js";

/**
 * Pool único por processo. Todas as consultas passam por aqui para que
 * o encerramento gracioso (SIGTERM) consiga drenar conexões.
 */
/**
 * Opções de TLS. `pg` não liga TLS sozinho: com banco gerenciado acessado pela
 * internet, sem isto os dados trafegam em claro. Quando `PG_SSL` já está na
 * própria URL (`?sslmode=...`), o driver resolve e não sobrescrevemos.
 */
function sslOptions(): pg.PoolConfig["ssl"] {
  const fromUrl = /[?&]sslmode=/.test(config.databaseUrl);
  if (fromUrl) return undefined;

  switch (config.pgSsl) {
    case "require":
      return { rejectUnauthorized: false };
    case "verify-full":
      return { rejectUnauthorized: true };
    default:
      return undefined;
  }
}

if (!/^[a-z_][a-z0-9_]*$/.test(config.databaseSchema)) {
  throw new Error("DATABASE_SCHEMA inválido");
}

export const pool = new pg.Pool({
  connectionString: config.databaseUrl,
  max: config.pgPoolMax,
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 10_000,
  application_name: "vertice-api",
  ssl: sslOptions(),
  options: `-c search_path=${config.databaseSchema},pg_catalog,extensions`,
});

pool.on("error", (error) => {
  console.error("[db] erro inesperado no pool de conexões", error);
});

export type Queryable = Pick<pg.PoolClient, "query">;

/** Executa uma consulta simples. */
export async function query<T extends pg.QueryResultRow = pg.QueryResultRow>(
  text: string,
  values: unknown[] = [],
): Promise<pg.QueryResult<T>> {
  return pool.query<T>(text, values as never[]);
}

/**
 * Executa trabalho dentro de uma transação, garantindo rollback em erro.
 * Usado em ingestão, que grava lote + alertas + eventos de forma atômica.
 */
export async function withTransaction<T>(fn: (client: pg.PoolClient) => Promise<T>): Promise<T> {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const result = await fn(client);
    await client.query("COMMIT");
    return result;
  } catch (error) {
    await client.query("ROLLBACK").catch(() => undefined);
    throw error;
  } finally {
    client.release();
  }
}

export async function closePool(): Promise<void> {
  await pool.end();
}
