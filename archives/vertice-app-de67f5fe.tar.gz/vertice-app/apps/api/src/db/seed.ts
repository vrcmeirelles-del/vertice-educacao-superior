import path from "node:path";
import { fileURLToPath } from "node:url";
import { config } from "../config.js";
import { hashPassword } from "../auth/password.js";
import { pool, query, withTransaction } from "./pool.js";
import { migrate } from "./migrate.js";

/**
 * Seed idempotente: cria uma instituição demo, cursos, catálogo de instrumento
 * e o usuário administrador. Não cria dados de aluno — dados sintéticos de
 * demonstração entram por `npm run seed:demo` (ver docs).
 */
/**
 * Em produção a senha de seed é obrigatória: cair no valor de demonstração
 * criaria um administrador com senha conhecida no ambiente publicado.
 * Roda antes de qualquer acesso ao banco, para falhar sem tocar em nada.
 */
function assertSeedPassword() {
  if (!config.isProduction) return;
  if (!config.seedAdminPassword) {
    throw new Error(
      "SEED_ADMIN_PASSWORD é obrigatória em produção (16+ caracteres). " +
        "Defina no .env antes de rodar o seed do primeiro administrador.",
    );
  }
  if (config.seedAdminPassword.length < 16) {
    throw new Error("SEED_ADMIN_PASSWORD deve ter ao menos 16 caracteres em produção.");
  }
}

async function seed() {
  assertSeedPassword();
  await migrate();

  const adminPassword = config.seedAdminPassword || "Vertice!Demo2026#";
  if (!config.seedAdminPassword) {
    console.warn(
      `[seed] SEED_ADMIN_PASSWORD não definida. Usando senha de demonstração. ` +
        `Troque antes de expor o ambiente.`,
    );
  }

  const passwordHash = await hashPassword(adminPassword);

  await withTransaction(async (client) => {
    const institution = await client.query<{ id: string }>(
      `INSERT INTO institutions
         (slug, name, status, activated_at, retention_alerts_days, retention_records_days, retention_audit_days)
       VALUES ('demo', 'Instituição Demonstração', 'active', now(), 730, 730, 1825)
       ON CONFLICT (slug) DO UPDATE SET name = EXCLUDED.name
       RETURNING id`,
    );
    const institutionId = institution.rows[0]!.id;

    const courses = [
      { code: "ADM", name: "Administração", campus: "Sede" },
      { code: "DIR", name: "Direito", campus: "Sede" },
      { code: "ENF", name: "Enfermagem", campus: "Sede" },
    ];
    for (const course of courses) {
      await client.query(
        `INSERT INTO courses (institution_id, code, name, campus)
         VALUES ($1,$2,$3,$4)
         ON CONFLICT (institution_id, code) DO UPDATE SET name = EXCLUDED.name`,
        [institutionId, course.code, course.name, course.campus],
      );
    }

    // Regras padrão da instituição (versionadas).
    await client.query(
      `INSERT INTO rulesets (institution_id, course_id, version, status, created_by)
       SELECT $1, NULL, 1, 'active', NULL
        WHERE NOT EXISTS (
          SELECT 1 FROM rulesets WHERE institution_id = $1 AND course_id IS NULL
        )`,
      [institutionId],
    );

    const user = await client.query<{ id: string }>(
      `INSERT INTO users (email, name, password_hash)
       VALUES (lower($1), 'Administrador Demo', $2)
       ON CONFLICT (email) DO UPDATE SET password_hash = EXCLUDED.password_hash
       RETURNING id`,
      [config.seedAdminEmail, passwordHash],
    );
    const userId = user.rows[0]!.id;

    await client.query(
      `INSERT INTO memberships (user_id, institution_id, role)
       VALUES ($1,$2,'institution_admin')
       ON CONFLICT (user_id, institution_id, role) DO UPDATE SET revoked_at = NULL`,
      [userId, institutionId],
    );

    // Instrumento regulatório de referência (estrutura, não promessa de nota).
    const instrument = await client.query<{ id: string }>(
      `INSERT INTO instruments (code, version, title, official_source, effective_from, status)
       VALUES ('INEP-REF', '2026.1',
               'Instrumento de referência (estrutura demonstrativa)',
               'Definir a portaria/instrumento oficial aplicável antes do uso real',
               '2026-01-01', 'draft')
       ON CONFLICT (code, version) DO UPDATE SET title = EXCLUDED.title
       RETURNING id`,
    );
    const instrumentId = instrument.rows[0]!.id;

    const requirements = [
      {
        code: "1.1",
        axis: "Organização Didático-Pedagógica",
        indicator: "Projeto Pedagógico de Curso",
        criterion: "PPC vigente, aprovado pelo colegiado, com perfil do egresso e matriz curricular.",
        evidence: "PPC aprovado, ata de aprovação, versão e vigência.",
      },
      {
        code: "1.2",
        axis: "Organização Didático-Pedagógica",
        indicator: "Monitoria",
        criterion: "Edital, seleção e acompanhamento documentados.",
        evidence: "Edital, termo de compromisso e relatórios.",
      },
      {
        code: "2.1",
        axis: "Corpo Docente e Tutorial",
        indicator: "Titulação e regime de trabalho",
        criterion: "Comprovação de titulação e regime conforme o instrumento vigente.",
        evidence: "Diplomas, contratos e quadro docente atualizado.",
      },
      {
        code: "3.1",
        axis: "Infraestrutura",
        indicator: "Biblioteca",
        criterion: "Acervo e serviços conforme parâmetros do instrumento aplicável.",
        evidence: "Inventário, contratos de base digital e relatórios de uso.",
      },
    ];

    for (const item of requirements) {
      await client.query(
        `INSERT INTO instrument_requirements
           (instrument_id, code, axis, indicator, criterion, expected_evidence)
         VALUES ($1,$2,$3,$4,$5,$6)
         ON CONFLICT (instrument_id, code) DO UPDATE SET criterion = EXCLUDED.criterion`,
        [instrumentId, item.code, item.axis, item.indicator, item.criterion, item.evidence],
      );
    }

    console.log(`[seed] instituição demo: ${institutionId}`);
    console.log(`[seed] administrador: ${config.seedAdminEmail}`);
  });
}

const invokedDirectly =
  process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);

if (invokedDirectly) {
  seed()
    .then(() => {
      console.log("[seed] concluído");
      return pool.end();
    })
    .catch((error) => {
      console.error("[seed] erro", error);
      process.exitCode = 1;
      return pool.end();
    });
}

export { seed };
