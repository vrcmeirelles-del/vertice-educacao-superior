import pg from "pg";
import { pool } from "./pool.js";
import { config } from "../config.js";

const quote = (value: string) => '"' + value.replaceAll('"', '""') + '"';

/** Copies existing records without replacing destination data or schema history. */
export async function transferRenderData(): Promise<void> {
  const sourceUrl = process.env.DATABASE_URL;
  if (!sourceUrl || !process.env.SUPABASE_DATABASE_URL || sourceUrl === config.databaseUrl) {
    throw new Error("Transferência exige bancos de origem e destino distintos");
  }
  const source = new pg.Client({ connectionString: sourceUrl, connectionTimeoutMillis: 10000 });
  const target = await pool.connect();
  try {
    await source.connect();
    await source.query("BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY");
    await target.query("BEGIN");
    const tables = (await source.query<{ table_name: string }>(
      "SELECT table_name FROM information_schema.tables WHERE table_schema='public' AND table_type='BASE TABLE' AND table_name <> 'schema_migrations' ORDER BY table_name",
    )).rows.map(row => row.table_name);
    const dependencies = (await source.query<{ child: string; parent: string }>(
      `SELECT child.relname child, parent.relname parent FROM pg_constraint c
       JOIN pg_class child ON child.oid=c.conrelid JOIN pg_namespace n ON n.oid=child.relnamespace
       JOIN pg_class parent ON parent.oid=c.confrelid
       WHERE c.contype='f' AND n.nspname='public' AND child.oid<>parent.oid`,
    )).rows;
    const remaining = new Set(tables);
    const ordered: string[] = [];
    while (remaining.size) {
      const ready = [...remaining].filter(table => !dependencies.some(d => d.child===table && remaining.has(d.parent)));
      if (!ready.length) throw new Error("Dependência circular na transferência");
      for (const table of ready) { ordered.push(table); remaining.delete(table); }
    }
    for (const table of ordered) {
      const destination = `${quote(config.databaseSchema)}.${quote(table)}`;
      const columns = (await source.query<{ column_name: string }>(
        "SELECT column_name FROM information_schema.columns WHERE table_schema='public' AND table_name=$1 AND is_generated='NEVER' ORDER BY ordinal_position", [table],
      )).rows.map(row => row.column_name);
      const keys = (await source.query<{ name: string }>(
        `SELECT a.attname name FROM pg_index i JOIN pg_attribute a ON a.attrelid=i.indrelid AND a.attnum=ANY(i.indkey)
         WHERE i.indrelid=$1::regclass AND i.indisprimary`, [`public.${quote(table)}`],
      )).rows.map(row => row.name);
      if (!keys.length) throw new Error(`Tabela sem chave: ${table}`);
      const records = (await source.query<{ record: Record<string, unknown> }>(`SELECT to_jsonb(t) record FROM public.${quote(table)} t`)).rows;
      for (const {record} of records) {
        await target.query(
          `INSERT INTO ${destination} (${columns.map(quote).join(',')}) SELECT ${columns.map(quote).join(',')} FROM jsonb_populate_record(NULL::${destination},$1::jsonb) ON CONFLICT DO NOTHING`,
          [JSON.stringify(record)],
        );
        const exists = await target.query(`SELECT 1 FROM ${destination} WHERE ${keys.map((key,i)=>`${quote(key)}=$${i+1}`).join(' AND ')}`,keys.map(key=>record[key]));
        if (!exists.rowCount) throw new Error(`Conflito de chave na transferência: ${table}`);
      }
      console.log(`[transfer] ${table}: ${records.length} registros conferidos`);
    }
    await target.query("COMMIT");
    await source.query("COMMIT");
    console.log("[transfer] concluída; origem preservada");
  } catch (error) {
    await target.query("ROLLBACK");
    await source.query("ROLLBACK").catch(() => undefined);
    throw error;
  } finally {
    target.release();
    await source.end();
  }
}
