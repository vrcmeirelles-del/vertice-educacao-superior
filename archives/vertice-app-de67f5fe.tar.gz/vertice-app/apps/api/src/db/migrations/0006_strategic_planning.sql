-- ============================================================================
-- 0006 — Planejamento Estratégico do Curso
--
-- Cobre o ciclo do PEC (Planejamento Estratégico de Curso) e o Planejamento
-- Semestral de Atividades.
--
-- Princípios: institution_id em toda tabela, course_id como agregador,
-- versão para histórico, auditoria via audit_log, nenhum dado pessoal de aluno.
-- ============================================================================

CREATE TABLE strategic_plans (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  institution_id        uuid NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  course_id             uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  version               integer NOT NULL DEFAULT 1,
  status                text NOT NULL DEFAULT 'draft'
                          CHECK (status IN ('draft', 'published', 'archived')),

  -- 1. Identificação
  coordinator_name      text,
  coordinator_since     text,
  enrolled_count        integer CHECK (enrolled_count IS NULL OR enrolled_count >= 0),
  first_semester        text,

  -- 2. Visão
  vision_text           text,
  vision_inspirations   jsonb NOT NULL DEFAULT '[]'::jsonb,
  vision_reflections    jsonb NOT NULL DEFAULT '[]'::jsonb,

  -- 3. Ciclo de vida
  lifecycle_stage       text,
  lifecycle_strategies  jsonb NOT NULL DEFAULT '[]'::jsonb,

  -- 4. Matriz BCG
  bcg_market_growth     text,
  bcg_market_share      text,
  bcg_quadrant          text,
  bcg_strategies        jsonb NOT NULL DEFAULT '[]'::jsonb,

  -- 5. Posicionamento estratégico (5 forças de Porter)
  porter_rivalry        text,
  porter_buyer_power    text,
  porter_supplier_power text,
  porter_substitutes    text,
  porter_new_entrants   text,

  -- 6-9. Fatores Críticos de Sucesso
  fcs_institutional     jsonb NOT NULL DEFAULT '[]'::jsonb,
  fcs_course            jsonb NOT NULL DEFAULT '[]'::jsonb,
  fcs_competitors       jsonb NOT NULL DEFAULT '[]'::jsonb,
  fcs_competitive_matrix jsonb NOT NULL DEFAULT '[]'::jsonb,

  -- 10. Matriz de atributos
  attributes_matrix     jsonb NOT NULL DEFAULT '[]'::jsonb,

  -- 11. Objetivos estratégicos (horizonte de 5 anos)
  strategic_objectives  jsonb NOT NULL DEFAULT '[]'::jsonb,

  -- 12. Objetivos operacionais / plano de ação
  operational_objectives jsonb NOT NULL DEFAULT '[]'::jsonb,

  created_by            uuid,
  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now(),
  UNIQUE (institution_id, course_id, version)
);

CREATE INDEX strategic_plans_inst_course_idx ON strategic_plans (institution_id, course_id);
CREATE INDEX strategic_plans_status_idx ON strategic_plans (institution_id, status);

CREATE TABLE semester_plannings (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  institution_id uuid NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  course_id      uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  semester       text NOT NULL CHECK (semester ~ '^[0-9]{4}/[12]$'),
  form_code      text,
  version        integer NOT NULL DEFAULT 1,
  status         text NOT NULL DEFAULT 'draft'
                   CHECK (status IN ('draft', 'published', 'archived')),
  activities     jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_by     uuid,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),
  UNIQUE (institution_id, course_id, semester, version)
);

CREATE INDEX semester_plannings_inst_course_idx
  ON semester_plannings (institution_id, course_id, semester);
