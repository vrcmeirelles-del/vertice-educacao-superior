-- ============================================================================
-- Vértice — esquema inicial
-- Princípios: tenant_id em toda tabela de cliente, auditoria imutável,
-- pseudonimização obrigatória, nenhuma coluna para dados proibidos no MVP.
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ---------------------------------------------------------------------------
-- Tenancy
-- ---------------------------------------------------------------------------

CREATE TABLE institutions (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug          text NOT NULL UNIQUE CHECK (slug ~ '^[a-z0-9][a-z0-9-]{1,62}$'),
  name          text NOT NULL,
  cnpj          text,
  timezone      text NOT NULL DEFAULT 'America/Sao_Paulo',
  -- Retenção configurável por cliente (dias). NULL = não expira automaticamente.
  retention_alerts_days    integer CHECK (retention_alerts_days IS NULL OR retention_alerts_days > 0),
  retention_records_days   integer CHECK (retention_records_days IS NULL OR retention_records_days > 0),
  retention_audit_days     integer CHECK (retention_audit_days IS NULL OR retention_audit_days > 0),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE courses (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  institution_id  uuid NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  code            text NOT NULL,
  name            text NOT NULL,
  campus          text,
  active          boolean NOT NULL DEFAULT true,
  created_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (institution_id, code)
);
CREATE INDEX courses_institution_idx ON courses (institution_id);

-- ---------------------------------------------------------------------------
-- Identidade e autorização
-- ---------------------------------------------------------------------------

CREATE TABLE users (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email          text NOT NULL UNIQUE,
  name           text NOT NULL,
  password_hash  text NOT NULL,
  is_active      boolean NOT NULL DEFAULT true,
  mfa_secret     text,                 -- reservado; MFA obrigatório só para admin
  last_login_at  timestamptz,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now()
);

-- platform_admin não tem instituição; os demais papéis têm.
CREATE TABLE memberships (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  institution_id  uuid REFERENCES institutions(id) ON DELETE CASCADE,
  role            text NOT NULL CHECK (role IN (
                    'platform_admin','institution_admin','regulatory_manager',
                    'coordinator','auditor_readonly','privacy_officer')),
  -- Escopo por curso; vazio = todos os cursos da instituição.
  course_scope    uuid[] NOT NULL DEFAULT '{}',
  expires_at      timestamptz,          -- obrigatório para auditor_readonly
  revoked_at      timestamptz,
  created_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, institution_id, role),
  CHECK (role = 'platform_admin' OR institution_id IS NOT NULL),
  CHECK (role <> 'auditor_readonly' OR expires_at IS NOT NULL)
);
CREATE INDEX memberships_user_idx ON memberships (user_id) WHERE revoked_at IS NULL;

-- Revogação de sessão imediata (jti do JWT).
CREATE TABLE revoked_sessions (
  jti         uuid PRIMARY KEY,
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  revoked_at  timestamptz NOT NULL DEFAULT now(),
  reason      text
);

-- ---------------------------------------------------------------------------
-- Catálogo regulatório versionado
-- ---------------------------------------------------------------------------

CREATE TABLE instruments (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code               text NOT NULL,           -- ex.: INEP-BACHARELADO
  version            text NOT NULL,           -- ex.: 2024.2
  title              text NOT NULL,
  official_source    text NOT NULL,           -- URL/portaria de origem
  effective_from     date NOT NULL,
  effective_to       date,
  status             text NOT NULL DEFAULT 'active'
                       CHECK (status IN ('draft','active','superseded')),
  created_at         timestamptz NOT NULL DEFAULT now(),
  UNIQUE (code, version)
);

CREATE TABLE instrument_requirements (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instrument_id   uuid NOT NULL REFERENCES instruments(id) ON DELETE CASCADE,
  code            text NOT NULL,
  axis            text NOT NULL,
  indicator       text NOT NULL,
  criterion       text NOT NULL,
  expected_evidence text NOT NULL,
  criticality     text NOT NULL DEFAULT 'normal'
                    CHECK (criticality IN ('low','normal','high','critical')),
  UNIQUE (instrument_id, code)
);

-- ---------------------------------------------------------------------------
-- Regras de risco (versionadas por instituição/curso)
-- ---------------------------------------------------------------------------

CREATE TABLE rulesets (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  institution_id      uuid NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  course_id           uuid REFERENCES courses(id) ON DELETE CASCADE,
  version             integer NOT NULL,
  attendance_threshold          numeric(5,2) NOT NULL DEFAULT 80,
  attendance_weight             integer NOT NULL DEFAULT 35,
  consecutive_absence_threshold integer NOT NULL DEFAULT 3,
  consecutive_absence_weight    integer NOT NULL DEFAULT 25,
  low_assessment_weight         integer NOT NULL DEFAULT 20,
  exit_request_weight           integer NOT NULL DEFAULT 30,
  status              text NOT NULL DEFAULT 'active'
                        CHECK (status IN ('draft','active','retired')),
  created_by          uuid REFERENCES users(id),
  created_at          timestamptz NOT NULL DEFAULT now(),
  CHECK (attendance_weight BETWEEN 0 AND 100),
  CHECK (consecutive_absence_weight BETWEEN 0 AND 100),
  CHECK (low_assessment_weight BETWEEN 0 AND 100),
  CHECK (exit_request_weight BETWEEN 0 AND 100),
  CHECK (attendance_threshold BETWEEN 0 AND 100),
  CHECK (consecutive_absence_threshold >= 0),
  UNIQUE (institution_id, course_id, version)
);
CREATE INDEX rulesets_active_idx ON rulesets (institution_id, course_id)
  WHERE status = 'active';

-- ---------------------------------------------------------------------------
-- Ingestão e retenção
-- ---------------------------------------------------------------------------

CREATE TABLE ingestion_batches (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  institution_id  uuid NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  status          text NOT NULL DEFAULT 'received'
                    CHECK (status IN ('received','validated','processed','rejected')),
  source          text NOT NULL,
  received_by     uuid REFERENCES users(id),
  total_records   integer NOT NULL DEFAULT 0,
  accepted_records integer NOT NULL DEFAULT 0,
  rejected_records integer NOT NULL DEFAULT 0,
  rejection_reason text,
  created_at      timestamptz NOT NULL DEFAULT now(),
  processed_at    timestamptz
);
CREATE INDEX ingestion_batches_tenant_idx ON ingestion_batches (institution_id, created_at DESC);

CREATE TABLE retention_records (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  institution_id       uuid NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  batch_id             uuid REFERENCES ingestion_batches(id) ON DELETE SET NULL,
  course_id            uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  -- HMAC do identificador enviado pela IES. O valor bruto nunca é persistido.
  student_ref_hash     text NOT NULL,
  attendance_percent   numeric(5,2),
  consecutive_absences integer,
  assessment_average   numeric(4,2),
  passing_average      numeric(4,2),
  open_requests        text[] NOT NULL DEFAULT '{}',
  observed_at          timestamptz NOT NULL,
  source               text NOT NULL,
  created_at           timestamptz NOT NULL DEFAULT now(),
  UNIQUE (institution_id, student_ref_hash, course_id, observed_at)
);
CREATE INDEX retention_records_tenant_course_idx
  ON retention_records (institution_id, course_id, observed_at DESC);

CREATE TABLE alerts (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  institution_id     uuid NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  course_id          uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  record_id          uuid NOT NULL REFERENCES retention_records(id) ON DELETE CASCADE,
  score              integer NOT NULL CHECK (score BETWEEN 0 AND 100),
  level              text NOT NULL CHECK (level IN ('low','medium','high','critical')),
  factors            jsonb NOT NULL,
  ruleset_id         uuid REFERENCES rulesets(id),
  rule_version       text NOT NULL,
  review_required    boolean NOT NULL DEFAULT false,
  recommended_action text NOT NULL,
  automated_decision jsonb,            -- sempre NULL no MVP; coluna existe para auditoria
  status             text NOT NULL DEFAULT 'open'
                       CHECK (status IN ('open','assigned','in_progress','resolved','dismissed','snoozed')),
  assigned_to        uuid REFERENCES users(id),
  snoozed_until      timestamptz,
  created_at         timestamptz NOT NULL DEFAULT now(),
  updated_at         timestamptz NOT NULL DEFAULT now(),
  UNIQUE (record_id)
);
CREATE INDEX alerts_tenant_status_idx ON alerts (institution_id, status, created_at DESC);
CREATE INDEX alerts_course_idx ON alerts (institution_id, course_id, status);

CREATE TABLE alert_events (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  institution_id uuid NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  alert_id     uuid NOT NULL REFERENCES alerts(id) ON DELETE CASCADE,
  actor_id     uuid REFERENCES users(id),
  type         text NOT NULL CHECK (type IN (
                 'created','assigned','contact_logged','action_taken',
                 'snoozed','resolved','dismissed','reopened','comment')),
  action_code  text,             -- ação institucional pré-aprovada
  note         text,             -- texto do coordenador (não do aluno)
  outcome      text,
  created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX alert_events_alert_idx ON alert_events (alert_id, created_at);

-- ---------------------------------------------------------------------------
-- Pasta de evidências regulatórias
-- ---------------------------------------------------------------------------

CREATE TABLE evidence_items (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  institution_id    uuid NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  course_id         uuid REFERENCES courses(id) ON DELETE CASCADE,
  instrument_id     uuid NOT NULL REFERENCES instruments(id),
  requirement_id    uuid NOT NULL REFERENCES instrument_requirements(id),
  status            text NOT NULL DEFAULT 'pending'
                      CHECK (status IN ('pending','in_review','validated','changes_requested','expired','not_applicable')),
  owner_id          uuid REFERENCES users(id),
  due_date          date,
  valid_until       date,
  reviewer_opinion  text,
  reviewed_by       uuid REFERENCES users(id),
  reviewed_at       timestamptz,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX evidence_tenant_idx ON evidence_items (institution_id, status, due_date);

CREATE TABLE documents (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  institution_id  uuid NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  storage_key     text NOT NULL,        -- objeto no bucket; nunca caminho local
  file_name       text NOT NULL,
  mime_type       text NOT NULL,
  size_bytes      bigint NOT NULL CHECK (size_bytes > 0),
  sha256          text NOT NULL,
  classification  text NOT NULL DEFAULT 'internal'
                    CHECK (classification IN ('public','internal','restricted')),
  created_by      uuid REFERENCES users(id),
  created_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (institution_id, sha256)
);

CREATE TABLE evidence_documents (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  institution_id uuid NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  evidence_id  uuid NOT NULL REFERENCES evidence_items(id) ON DELETE CASCADE,
  document_id  uuid NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  version      integer NOT NULL DEFAULT 1,
  created_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (evidence_id, document_id)
);

CREATE TABLE evidence_history (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  institution_id uuid NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  evidence_id   uuid NOT NULL REFERENCES evidence_items(id) ON DELETE CASCADE,
  from_status   text,
  to_status     text NOT NULL,
  actor_id      uuid REFERENCES users(id),
  note          text,
  created_at    timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- Integração (extensão) e LGPD
-- ---------------------------------------------------------------------------

-- Token curto de pareamento da extensão. Guardamos só o hash.
CREATE TABLE pairing_tokens (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  institution_id  uuid NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  token_hash      text NOT NULL UNIQUE,
  label           text NOT NULL,
  created_by      uuid REFERENCES users(id),
  expires_at      timestamptz NOT NULL,
  revoked_at      timestamptz,
  last_used_at    timestamptz,
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE data_subject_requests (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  institution_id  uuid NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  request_type    text NOT NULL CHECK (request_type IN ('access','correction','deletion','anonymization','export')),
  student_ref_hash text NOT NULL,
  status          text NOT NULL DEFAULT 'received'
                    CHECK (status IN ('received','in_progress','completed','rejected')),
  handled_by      uuid REFERENCES users(id),
  resolution_note text,
  created_at      timestamptz NOT NULL DEFAULT now(),
  completed_at    timestamptz
);

-- ---------------------------------------------------------------------------
-- Auditoria (append-only)
-- ---------------------------------------------------------------------------

CREATE TABLE audit_log (
  id              bigserial PRIMARY KEY,
  institution_id  uuid REFERENCES institutions(id) ON DELETE SET NULL,
  actor_id        uuid REFERENCES users(id) ON DELETE SET NULL,
  actor_kind      text NOT NULL DEFAULT 'user' CHECK (actor_kind IN ('user','system','extension')),
  action          text NOT NULL,
  resource_type   text NOT NULL,
  resource_id     uuid,
  outcome         text NOT NULL CHECK (outcome IN ('success','denied','error')),
  ip              inet,
  user_agent      text,
  -- Nunca gravar notas, textos de requerimento ou conteúdo de documento.
  metadata        jsonb NOT NULL DEFAULT '{}',
  created_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_log_tenant_idx ON audit_log (institution_id, created_at DESC);
CREATE INDEX audit_log_resource_idx ON audit_log (resource_type, resource_id);

CREATE OR REPLACE FUNCTION audit_log_immutable()
RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'audit_log é append-only';
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER audit_log_no_update BEFORE UPDATE ON audit_log
  FOR EACH ROW EXECUTE FUNCTION audit_log_immutable();
CREATE TRIGGER audit_log_no_delete BEFORE DELETE ON audit_log
  FOR EACH ROW EXECUTE FUNCTION audit_log_immutable();
