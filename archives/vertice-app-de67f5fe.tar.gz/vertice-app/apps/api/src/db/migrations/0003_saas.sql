-- ============================================================================
-- Plano de controle do SaaS
--
-- O que entra aqui NÃO é dado de cliente: é o estado comercial da instituição
-- (plano, ciclo de vida, assinatura) e o convite de acesso. Nada nesta migração
-- toca identificador de estudante, métrica acadêmica ou conteúdo de documento.
--
-- Regra que vale para o resto do sistema: plano é cota e estado, nunca papel.
-- Autorização continua sendo membership.role.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- Catálogo de planos
--
-- `price_brl_monthly` fica NULL de propósito: preço é decisão comercial,
-- registrada em contrato, não esquecida dentro de uma migração.
-- ---------------------------------------------------------------------------

CREATE TABLE plan_limits (
  plan_code            text PRIMARY KEY,
  label                text NOT NULL,
  -- NULL = sem limite. Prefira NULL a um número inventado.
  max_users            integer CHECK (max_users IS NULL OR max_users > 0),
  max_alerts_month     integer CHECK (max_alerts_month IS NULL OR max_alerts_month > 0),
  max_storage_mb       integer CHECK (max_storage_mb IS NULL OR max_storage_mb > 0),
  max_batches_day      integer CHECK (max_batches_day IS NULL OR max_batches_day > 0),
  max_courses          integer CHECK (max_courses IS NULL OR max_courses > 0),
  max_batch_records    integer CHECK (max_batch_records IS NULL OR max_batch_records > 0),
  trial_days           integer NOT NULL DEFAULT 30 CHECK (trial_days >= 0),
  price_brl_monthly    numeric(12,2),
  notes                text,
  created_at           timestamptz NOT NULL DEFAULT now()
);

INSERT INTO plan_limits
  (plan_code, label, max_users, max_alerts_month, max_storage_mb,
   max_batches_day, max_courses, max_batch_records, trial_days, notes)
VALUES
  ('piloto', 'Piloto',
   10,    5000,   2048,   20,   30,   1000, 30,
   'Um curso ou uma frente. Suficiente para validar o fluxo com dado real.'),
  ('essencial', 'Essencial',
   25,    25000,  10240,  60,   100,  1000, 30,
   'Operação contínua de uma IES de pequeno porte.'),
  ('institucional', 'Institucional',
   100,   100000, 51200,  240,  500,  1000, 30,
   'Todas as coordenações, retenção e evidências simultâneas.'),
  ('contrato', 'Contrato',
   NULL,  NULL,   NULL,   NULL, NULL, 1000, 0,
   'Sem cota. Usado só quando o contrato assinado diz isso por escrito.')
ON CONFLICT (plan_code) DO NOTHING;

-- ---------------------------------------------------------------------------
-- Ciclo de vida da instituição
--
-- Instituições que já existiam antes desta migração são clientes em operação:
-- viram `active`. Só instituições criadas depois nascem `trial`.
-- ---------------------------------------------------------------------------

ALTER TABLE institutions
  ADD COLUMN status        text NOT NULL DEFAULT 'trial'
                             CHECK (status IN ('trial','active','past_due','suspended','churned')),
  ADD COLUMN trial_ends_at timestamptz,
  ADD COLUMN activated_at  timestamptz,
  ADD COLUMN suspended_at  timestamptz,
  ADD COLUMN plan_code     text NOT NULL DEFAULT 'piloto';

ALTER TABLE institutions
  ADD CONSTRAINT institutions_plan_code_fkey
  FOREIGN KEY (plan_code) REFERENCES plan_limits(plan_code);

UPDATE institutions
   SET status       = 'active',
       activated_at = coalesce(activated_at, now())
 WHERE status = 'trial';

CREATE INDEX institutions_status_idx ON institutions (status);

-- ---------------------------------------------------------------------------
-- Assinatura
--
-- O estado comercial vive aqui, no banco da Vértice. Nenhuma requisição de
-- negócio pergunta ao provedor de pagamento se o cliente está em dia: se o
-- provedor cair, a plataforma continua operando com o último estado conhecido.
-- ---------------------------------------------------------------------------

CREATE TABLE subscriptions (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  institution_id        uuid NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  plan_code             text NOT NULL REFERENCES plan_limits(plan_code),
  status                text NOT NULL CHECK (status IN ('trialing','active','past_due','canceled')),
  current_period_start  timestamptz,
  current_period_end    timestamptz,
  cancel_at             timestamptz,
  provider              text,      -- 'asaas' | 'pagarme' | 'manual'
  provider_ref          text,      -- id da assinatura no provedor
  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now()
);

-- Uma assinatura aberta por instituição. Histórico fica nas linhas encerradas.
CREATE UNIQUE INDEX subscriptions_open_idx
  ON subscriptions (institution_id)
  WHERE status IN ('trialing','active','past_due');

CREATE INDEX subscriptions_provider_idx ON subscriptions (provider, provider_ref);

-- ---------------------------------------------------------------------------
-- Eventos de cobrança (idempotência do webhook)
--
-- O payload é guardado para reconciliação. Ele NUNCA deve conter dado de
-- estudante: o provedor não recebe nada além de instituição, plano e valor.
-- ---------------------------------------------------------------------------

CREATE TABLE billing_events (
  id             bigserial PRIMARY KEY,
  provider       text NOT NULL,
  event_id       text NOT NULL,
  event_type     text NOT NULL,
  institution_id uuid REFERENCES institutions(id) ON DELETE SET NULL,
  payload        jsonb NOT NULL DEFAULT '{}',
  processed_at   timestamptz,
  error          text,
  created_at     timestamptz NOT NULL DEFAULT now(),
  UNIQUE (provider, event_id)
);

CREATE INDEX billing_events_institution_idx ON billing_events (institution_id, created_at DESC);

-- ---------------------------------------------------------------------------
-- Convites de acesso
--
-- Substitui o desenho antigo em que o administrador digitava a senha do novo
-- usuário. Só o hash do token é persistido — mesmo desenho de pairing_tokens.
--
-- CHECK (role <> 'platform_admin') é uma fronteira de segurança, não um
-- detalhe: nenhuma instituição consegue emitir acesso de operador da Vértice.
-- ---------------------------------------------------------------------------

CREATE TABLE user_invites (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  institution_id   uuid NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  email            text NOT NULL,
  role             text NOT NULL CHECK (role IN (
                     'institution_admin','regulatory_manager','coordinator',
                     'auditor_readonly','privacy_officer')),
  course_scope     uuid[] NOT NULL DEFAULT '{}',
  token_hash       text NOT NULL UNIQUE,
  expires_at       timestamptz NOT NULL,
  invited_by       uuid REFERENCES users(id) ON DELETE SET NULL,
  accepted_at      timestamptz,
  accepted_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  revoked_at       timestamptz,
  created_at       timestamptz NOT NULL DEFAULT now(),
  CHECK (role <> 'auditor_readonly' OR expires_at IS NOT NULL)
);

-- Um convite pendente por e-mail por instituição. Reenviar revoga o anterior
-- em vez de deixar dois tokens válidos para a mesma pessoa.
CREATE UNIQUE INDEX user_invites_pending_idx
  ON user_invites (institution_id, lower(email))
  WHERE accepted_at IS NULL AND revoked_at IS NULL;

CREATE INDEX user_invites_expiry_idx ON user_invites (expires_at)
  WHERE accepted_at IS NULL AND revoked_at IS NULL;
