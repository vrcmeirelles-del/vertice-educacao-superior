-- ============================================================================
-- 0004 — Ordenação dos eventos de cobrança
--
-- Idempotência (0003) resolve evento repetido. NÃO resolve evento fora de
-- ordem, que é o erro caro: provedor reentrega `subscription.deleted` antes de
-- `payment.confirmed`, o cliente cancelou, e a conta continua escrevendo.
--
-- A solução aqui é comparar o instante do evento — declarado pelo provedor —
-- com o instante do último evento aplicado na assinatura. Evento mais antigo
-- que o já aplicado é registrado para auditoria e descartado.
--
-- `occurred_at` fica NULL quando o provedor não informa o instante: nesse caso
-- não há como ordenar, e o evento é aplicado (a idempotência ainda protege a
-- repetição). Preferimos assumir o risco de um estado velho sobre descartar
-- silenciosamente um evento que talvez fosse o mais novo.
-- ============================================================================

ALTER TABLE billing_events
  ADD COLUMN occurred_at timestamptz,
  -- Quando o evento chegou ordenado mas foi descartado por ser antigo, o
  -- motivo fica registrado: "por que a conta não mudou?" tem que ter resposta.
  ADD COLUMN skipped_reason text;

COMMENT ON COLUMN billing_events.occurred_at IS
  'Instante do fato segundo o provedor. NULL = provedor não informou.';
COMMENT ON COLUMN billing_events.skipped_reason IS
  'Motivo de o evento ter sido gravado sem alterar a assinatura.';

ALTER TABLE subscriptions
  ADD COLUMN last_event_at timestamptz;

COMMENT ON COLUMN subscriptions.last_event_at IS
  'occurred_at do último evento aplicado. Base da checagem de ordem.';

-- Busca do histórico de uma assinatura por ordem de acontecimento.
CREATE INDEX billing_events_institution_order_idx
  ON billing_events (institution_id, occurred_at DESC NULLS LAST);
