-- ============================================================================
-- 0002 — Upload de documentos com antivírus e integridade
-- ============================================================================

-- Estado do ciclo de vida do arquivo:
--   pending_upload → após criar a URL pré-assinada (arquivo ainda não existe)
--   pending_scan   → upload confirmado, aguardando antivírus
--   clean          → escaneado e aprovado, pode ser vinculado a evidência
--   infected       → bloqueado; nunca é servido
--   failed         → scan falhou ou excedeu prazo (falha fechada)
CREATE TYPE document_scan_status AS ENUM ('pending_upload','pending_scan','clean','infected','failed');

ALTER TABLE documents
  ADD COLUMN scan_status document_scan_status NOT NULL DEFAULT 'pending_upload',
  ADD COLUMN scan_engine text,
  ADD COLUMN scanned_at timestamptz,
  ADD COLUMN scan_detail text,
  ADD COLUMN uploaded_at timestamptz,
  ADD COLUMN deleted_at timestamptz;

-- Documento novo só existe com metadados completos; o status guia o fluxo.
CREATE INDEX documents_pending_idx
  ON documents (institution_id, scan_status)
  WHERE scan_status IN ('pending_upload','pending_scan');

-- Ninguém vincula documento não aprovado. O trigger é a última linha de defesa:
-- mesmo que uma rota futura esqueça a checagem, o banco recusa.
CREATE OR REPLACE FUNCTION evidence_document_requires_clean_document()
RETURNS trigger AS $$
DECLARE
  doc_status document_scan_status;
  doc_institution uuid;
BEGIN
  SELECT scan_status, institution_id INTO doc_status, doc_institution
    FROM documents WHERE id = NEW.document_id;

  IF doc_institution IS DISTINCT FROM NEW.institution_id THEN
    RAISE EXCEPTION 'documento pertence a outra instituição';
  END IF;

  IF doc_status <> 'clean' THEN
    RAISE EXCEPTION 'documento % não está aprovado (status=%)', NEW.document_id, doc_status;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER evidence_documents_require_clean
  BEFORE INSERT OR UPDATE ON evidence_documents
  FOR EACH ROW EXECUTE FUNCTION evidence_document_requires_clean_document();

-- Histórico de acessos a arquivo: quem baixou o quê e quando.
CREATE TABLE document_access_log (
  id             bigserial PRIMARY KEY,
  institution_id uuid NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  document_id    uuid NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  actor_id       uuid REFERENCES users(id) ON DELETE SET NULL,
  action         text NOT NULL CHECK (action IN ('upload_url_issued','upload_confirmed','download_url_issued','scan_completed')),
  result         text NOT NULL,
  ip             inet,
  created_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX document_access_log_doc_idx ON document_access_log (document_id, created_at DESC);

CREATE OR REPLACE FUNCTION document_access_log_immutable()
RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'document_access_log é append-only';
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER document_access_log_no_update BEFORE UPDATE ON document_access_log
  FOR EACH ROW EXECUTE FUNCTION document_access_log_immutable();
CREATE TRIGGER document_access_log_no_delete BEFORE DELETE ON document_access_log
  FOR EACH ROW EXECUTE FUNCTION document_access_log_immutable();
