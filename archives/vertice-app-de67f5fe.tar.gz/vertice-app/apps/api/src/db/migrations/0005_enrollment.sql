-- ============================================================================
-- 0005 — Matrícula agregada por curso
--
-- O sinal de retenção (por aluno) já existia em `retention_records`. O que
-- faltava era o número que a coordenação usa primeiro: quantas matrículas cada
-- curso tem no semestre, aberto por status, e como isso varia em relação ao
-- semestre anterior.
--
-- Decisões que não são óbvias:
--
--  * Agregado, nunca pessoa. Esta tabela não tem identificador de estudante,
--    nem coluna que permita derivá-lo. É contagem de vínculos (matrícula no
--    semestre), não de pessoas únicas — o comentário fica na coluna para que
--    ninguém leia o número como "alunos distintos".
--
--  * `source_ref` guarda o relatório de origem ("eORBIT — relatório
--    estatístico de alunos"), não um caminho de arquivo nem texto livre.
--
--  * Turmas ficam em JSONB, e não em tabela filha, por um motivo concreto: na
--    origem a mesma turma aparece repetida dentro do semestre (ex.: ADM-1A com
--    12 e com 1 matrícula em 001/2025-02). Uma UNIQUE por código de turma
--    obrigaria a inventar uma chave que o e-ORBIT não tem. O array preserva a
--    origem exatamente como ela é, que é o que o CLAUDE.md manda fazer com
--    divergência de acervo.
--
--  * `vagas` é a soma das vagas cadastradas nas turmas. NÃO é vaga autorizada
--    pelo MEC — o nome da coluna não pode sugerir isso.
-- ============================================================================

CREATE TABLE enrollments (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  institution_id    uuid NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  course_id         uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  batch_id          uuid REFERENCES ingestion_batches(id) ON DELETE SET NULL,

  -- Semestre letivo no formato AAAA/SS (ex.: 2026/02). Texto de propósito:
  -- é um rótulo acadêmico, não uma data, e ordena corretamente como string.
  semester          text NOT NULL CHECK (semester ~ '^[0-9]{4}/(0[12])$'),

  -- Vagas das turmas, não vagas autorizadas.
  vagas             integer NOT NULL DEFAULT 0 CHECK (vagas >= 0),

  -- Um contador por status do e-ORBIT. Todos existem sempre: zero é um dado,
  -- ausência é extração incompleta. A distinção importa na leitura.
  matriculado       integer NOT NULL DEFAULT 0 CHECK (matriculado >= 0),
  pre_matriculado   integer NOT NULL DEFAULT 0 CHECK (pre_matriculado >= 0),
  trancado          integer NOT NULL DEFAULT 0 CHECK (trancado >= 0),
  abandono          integer NOT NULL DEFAULT 0 CHECK (abandono >= 0),
  concluido         integer NOT NULL DEFAULT 0 CHECK (concluido >= 0),
  cancelado         integer NOT NULL DEFAULT 0 CHECK (cancelado >= 0),
  transferido       integer NOT NULL DEFAULT 0 CHECK (transferido >= 0),
  troca_curso       integer NOT NULL DEFAULT 0 CHECK (troca_curso >= 0),
  graduado          integer NOT NULL DEFAULT 0 CHECK (graduado >= 0),

  -- Total de registros do relatório e soma dos subtotais por turma. Podem
  -- divergir do somatório dos status na origem; guardamos os dois como vieram
  -- em vez de "consertar" o número.
  total_registros   integer NOT NULL DEFAULT 0 CHECK (total_registros >= 0),
  turmas_somadas    integer NOT NULL DEFAULT 0 CHECK (turmas_somadas >= 0),

  -- Turmas com 1 ou mais matriculados: [{serie, turma, matriculados}].
  -- Turma com zero aluno não entra, por definição do relatório.
  turmas            jsonb NOT NULL DEFAULT '[]'::jsonb,

  source            text NOT NULL,
  observed_at       timestamptz NOT NULL,
  created_at        timestamptz NOT NULL DEFAULT now(),

  -- Um agregado por curso e semestre. Reimportar o mesmo semestre corrige o
  -- valor em vez de duplicar a linha — o relatório é um retrato, não um fato
  -- que se acumula.
  UNIQUE (institution_id, course_id, semester)
);

CREATE INDEX enrollments_tenant_semester_idx
  ON enrollments (institution_id, semester DESC);

CREATE INDEX enrollments_course_semester_idx
  ON enrollments (institution_id, course_id, semester DESC);

-- O agregado alimenta painel; não é trilha de auditoria. Mas alteração de
-- número publicado merece registro, e por isso não há trigger de imutabilidade
-- aqui: a correção é a operação normal (relatório reemitido pela secretaria).
