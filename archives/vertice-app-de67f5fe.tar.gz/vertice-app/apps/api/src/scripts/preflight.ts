/**
 * Pré-voo da conexão com o Supabase.
 *
 * Valida os três caminhos que a API realmente usa — banco, bucket e antivírus —
 * antes de subir o painel. Não cria nem altera nada: só lê.
 *
 * Roda a partir da raiz do projeto, com o .env carregado:
 *   npx tsx apps/api/src/scripts/preflight.ts
 *
 * Cada verificação responde "isto vai funcionar quando o painel subir?", não
 * "o driver conectou?". É a diferença entre um teste verde e um usuário sem
 * acesso.
 */
import "dotenv/config";
import { config } from "../config.js";
import { pool } from "../db/pool.js";
import {
  buildStorageKey,
  headObject,
  storageConfigured,
} from "../services/storage.js";
import { pingAntivirus } from "../services/antivirus.js";

type Linha = { ok: boolean; nome: string; detalhe: string; fatal: boolean };

const linhas: Linha[] = [];

function registrar(ok: boolean, nome: string, detalhe: string, fatal = true) {
  linhas.push({ ok, nome, detalhe, fatal });
}

/** Primeira linha da mensagem de erro, sem stack. */
function erroMsg(e: unknown): string {
  // `pg` embrulha falhas de conexão num AggregateError com `message` vazio —
  // a causa real fica em `.errors[0]`. Sem descer nela, o relatório mostraria
  // um erro sem motivo, que é pior do que não mostrar nada.
  const alvo = e as { message?: string; errors?: unknown[]; code?: string };
  let texto = (alvo?.message ?? "").trim();

  if (!texto && Array.isArray(alvo?.errors) && alvo.errors.length > 0) {
    texto = erroMsg(alvo.errors[0]);
  }
  if (!texto && alvo?.code) texto = String(alvo.code);
  if (!texto) texto = String(e);

  const primeira = texto.split("\n")[0] ?? texto;
  return primeira.slice(0, 200);
}

function mascarar(url: string): string {
  try {
    const u = new URL(url);
    const senha = u.password ? "***" : "";
    const user = u.username ? u.username.slice(0, 12) : "";
    return `${u.protocol}//${user}${senha ? ":" + senha : ""}@${u.host}${u.pathname}`;
  } catch {
    return "(URL inválida)";
  }
}

async function checarBanco() {
  const url = config.databaseUrl;
  registrar(true, "DATABASE_URL definida", mascarar(url), false);

  const temSsl = /[?&]sslmode=/.test(url);
  const temPgSsl = Boolean(config.pgSsl);
  registrar(
    temSsl || temPgSsl,
    "TLS configurado no banco",
    temSsl
      ? `sslmode na URL`
      : temPgSsl
        ? `PG_SSL=${config.pgSsl}`
        : "NENHUM — a conexão sai em claro. Adicione ?sslmode=require à URL ou PG_SSL=require.",
    false, // avisa, mas o teste de conexão abaixo decide
  );

  // Conexão real pelo pool da aplicação.
  let versao = "";
  try {
    const r = await pool.query<{ v: string }>("SELECT version() AS v");
    versao = r.rows[0]?.v ?? "";
    registrar(true, "Conexão com o Postgres", versao.split(" ").slice(0, 2).join(" "));
  } catch (e) {
    registrar(false, "Conexão com o Postgres", erroMsg(e));
    return;
  }

  // TLS de fato negociado, não apenas solicitado.
  try {
    const r = await pool.query<{ ssl: boolean; cipher: string | null; versao: string | null }>(
      `SELECT ssl, cipher, version AS versao
         FROM pg_stat_ssl
        WHERE pid = pg_backend_pid()`,
    );
    const s = r.rows[0];
    if (!s) {
      registrar(false, "TLS negociado", "pg_stat_ssl não disponível", false);
    } else {
      registrar(
        Boolean(s.ssl),
        "TLS negociado na prática",
        s.ssl ? `${s.versao} / ${s.cipher}` : "conexão SEM TLS — corrija antes de seguir",
      );
    }
  } catch (e) {
    registrar(false, "TLS negociado", erroMsg(e), false);
  }

  // Extensão de UUID: sem ela nenhuma migração roda.
  try {
    const r = await pool.query<{ existe: boolean }>(
      `SELECT EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pgcrypto') AS existe`,
    );
    const existe = r.rows[0]?.existe ?? false;
    if (!existe) {
      // No Supabase, pgcrypto vive no schema extensions.
      const alt = await pool.query<{ existe: boolean }>(
        `SELECT EXISTS (
           SELECT 1 FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
            WHERE p.proname = 'gen_random_uuid'
         ) AS existe`,
      );
      const tem = alt.rows[0]?.existe ?? false;
      registrar(tem, "Extensão pgcrypto", tem ? "gen_random_uuid disponível" : "AUSENTE");
    } else {
      registrar(true, "Extensão pgcrypto", "instalada");
    }
  } catch (e) {
    registrar(false, "Extensão pgcrypto", erroMsg(e));
  }

  // Estado do schema: banco novo (esperado) ou já migrado.
  try {
    const r = await pool.query<{ existe: boolean }>(
      `SELECT EXISTS (
         SELECT 1 FROM information_schema.tables
          WHERE table_schema = 'public' AND table_name = 'schema_migrations'
       ) AS existe`,
    );
    if (!r.rows[0]?.existe) {
      registrar(true, "Migrações", "banco virgem — rode o migrate", false);
    } else {
      const m = await pool.query<{ name: string }>(
        "SELECT name FROM schema_migrations ORDER BY name",
      );
      registrar(
        true,
        "Migrações",
        m.rowCount === 0 ? "nenhuma aplicada" : `${m.rowCount} aplicadas: ${m.rows.map((x) => x.name).join(", ")}`,
        false,
      );
    }
  } catch (e) {
    registrar(false, "Migrações", erroMsg(e), false);
  }

  // Permissões de escrita: o pooler do Supabase pode conectar só em leitura se
  // a role estiver errada. Testa numa tabela temporária, sem tocar em dados.
  try {
    await pool.query("BEGIN");
    await pool.query("CREATE TEMP TABLE _preflight (x int)");
    await pool.query("INSERT INTO _preflight VALUES (1)");
    await pool.query("ROLLBACK");
    registrar(true, "Permissão de escrita", "CREATE/INSERT em transação descartada");
  } catch (e) {
    await pool.query("ROLLBACK").catch(() => undefined);
    registrar(false, "Permissão de escrita", erroMsg(e));
  }
}

async function checarStorage() {
  if (!storageConfigured()) {
    registrar(
      false,
      "Storage configurado",
      "faltam S3_BUCKET, S3_ACCESS_KEY_ID ou S3_SECRET_ACCESS_KEY",
    );
    return;
  }
  registrar(true, "Storage configurado", `bucket ${config.storage.bucket} @ ${config.storage.region}`, false);

  const endpoint = config.storage.endpoint ?? "(default AWS)";
  const hostCorreto =
    !config.storage.endpoint || /\.storage\.supabase\.co/.test(config.storage.endpoint);
  registrar(
    hostCorreto,
    "Endpoint S3 no formato do Supabase",
    hostCorreto
      ? endpoint
      : `${endpoint} — o correto é https://<ref>.storage.supabase.co/storage/v1/s3`,
    false,
  );

  // Leitura do bucket: HEAD num objeto que não existe. Um 404 prova duas coisas
  // — a chave autentica e o bucket existe. 403 é chave errada.
  const chave = buildStorageKey({
    institutionId: "00000000-0000-0000-0000-000000000000",
    evidenceId: null,
    documentId: "00000000-0000-0000-0000-000000000000",
    fileName: "preflight.txt",
  });
  try {
    // `null` = objeto não existe, mas a chamada autenticou e chegou ao bucket.
    const r = await headObject(chave);
    registrar(
      true,
      "Leitura do bucket",
      r === null ? "autenticou e chegou ao bucket (objeto de teste não existe)" : "objeto existe",
      false,
    );
  } catch (e) {
    const msg = erroMsg(e);
    const codigo = (e as { name?: string; $metadata?: { httpStatusCode?: number } });
    const http = codigo?.$metadata?.httpStatusCode;
    const ok = http === 404 || /NotFound|NoSuchKey/i.test(msg);
    registrar(
      ok,
      "Leitura do bucket",
      ok
        ? "autenticou e chegou ao bucket (404 do objeto de teste)"
        : `${http ?? ""} ${msg.slice(0, 140)}`,
      false,
    );
  }
}

async function checarAntivirus() {
  if (config.antivirus.mode === "disabled") {
    registrar(
      false,
      "Antivírus",
      "ANTIVIRUS_MODE=disabled — todo documento será reprovado (falha fechada)",
    );
    return;
  }
  const ok = await pingAntivirus();
  registrar(
    ok,
    "Antivírus (ClamAV)",
    ok
      ? `${config.antivirus.clamHost}:${config.antivirus.clamPort} respondeu`
      : `sem resposta em ${config.antivirus.clamHost}:${config.antivirus.clamPort}`,
  );
}

function imprimir() {
  console.log("");
  const largura = Math.max(...linhas.map((l) => l.nome.length));
  for (const l of linhas) {
    const marca = l.ok ? "OK  " : l.fatal ? "ERRO" : "AVISO";
    console.log(`${marca}  ${l.nome.padEnd(largura)}  ${l.detalhe}`);
  }
  const erros = linhas.filter((l) => !l.ok && l.fatal);
  const avisos = linhas.filter((l) => !l.ok && !l.fatal);
  console.log("");
  if (erros.length === 0) {
    console.log(
      avisos.length === 0
        ? "PRONTO — banco, bucket e antivírus respondendo."
        : `PRONTO com ${avisos.length} aviso(s). Nada impede subir.`,
    );
  } else {
    console.log(`${erros.length} erro(s) impedem o deploy. Corrija antes de subir.`);
  }
  return erros.length === 0 ? 0 : 1;
}

async function main() {
  console.log("Pré-voo Vértice — ambiente:", config.env);
  await checarBanco();
  await checarStorage();
  await checarAntivirus();
  const codigo = imprimir();
  await pool.end();
  process.exit(codigo);
}

main().catch(async (e) => {
  console.error("pré-voo falhou:", e);
  await pool.end().catch(() => undefined);
  process.exit(1);
});
