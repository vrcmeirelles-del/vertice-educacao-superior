/**
 * Ciclo de vida comercial da instituição.
 *
 * Regra central: **plano é cota e estado, nunca permissão**. Quem pode fazer o
 * quê continua sendo `membership.role`. Este módulo só responde a duas
 * perguntas: a instituição pode escrever agora? E ainda cabe esse recurso?
 *
 * Nenhuma função aqui toca o provedor de pagamento. O estado vem do banco
 * local, atualizado por webhook. Se o provedor cair, a plataforma continua
 * operando com o último estado conhecido.
 */

export type InstitutionStatus = "trial" | "active" | "past_due" | "suspended" | "churned";

export interface InstitutionState {
  status: InstitutionStatus;
  trialEndsAt: Date | null;
  /** Código do plano vigente. Sempre existe: `piloto` é o padrão. */
  planCode: string;
}

export interface PlanLimits {
  planCode: string;
  maxUsers: number | null;
  maxAlertsMonth: number | null;
  maxStorageMb: number | null;
  maxBatchesDay: number | null;
  maxCourses: number | null;
  maxBatchRecords: number | null;
}

export type QuotaKey =
  | "maxUsers"
  | "maxAlertsMonth"
  | "maxStorageMb"
  | "maxBatchesDay"
  | "maxCourses"
  | "maxBatchRecords";

const QUOTA_LABEL: Record<QuotaKey, string> = {
  maxUsers: "usuários ativos",
  maxAlertsMonth: "alertas por mês",
  maxStorageMb: "armazenamento",
  maxBatchesDay: "importações por dia",
  maxCourses: "cursos",
  maxBatchRecords: "registros por importação",
};

export function quotaLabel(key: QuotaKey): string {
  return QUOTA_LABEL[key];
}

/**
 * Texto que o cliente recebe ao bater a cota. Frases deste tipo acabam citadas
 * em conversa comercial, então precisam ser específicas e não acusatórias.
 */
export function quotaMessage(key: QuotaKey, limit: number, current: number): string {
  return (
    `O plano atual permite até ${limit} ${QUOTA_LABEL[key]} ` +
    `(uso atual: ${current}). Fale com a Vértice para ampliar o plano.`
  );
}

/**
 * Estado efetivo: um trial vencido é `trial_expired` mesmo que ninguém tenha
 * rodado um job para marcar `past_due`. Não depende de cron para ser correto.
 */
export type EffectiveStatus = InstitutionStatus | "trial_expired";

export function effectiveStatus(state: InstitutionState, now: Date = new Date()): EffectiveStatus {
  if (state.status === "trial" && state.trialEndsAt && state.trialEndsAt.getTime() <= now.getTime()) {
    return "trial_expired";
  }
  return state.status;
}

/**
 * Escrita = ingestão, upload, edição de regra, criação de usuário.
 *
 * `past_due` continua escrevendo de propósito: inadimplência não pode
 * derrubar a operação de um cliente que está no meio de uma renovação de
 * reconhecimento. Quem bloqueia é `suspended`, que é decisão humana.
 */
export function canWrite(state: InstitutionState, now: Date = new Date()): boolean {
  const status = effectiveStatus(state, now);
  return status === "trial" || status === "active" || status === "past_due";
}

/**
 * Leitura e exportação continuam liberadas na suspensão.
 *
 * Isso não é generosidade: suspender o acesso ao dado pessoal de um cliente
 * por causa de cobrança vira problema de LGPD (retenção de dado sem base) e
 * impede a IES de responder ao MEC. Suspensão bloqueia escrita, não saída.
 */
export function canRead(state: InstitutionState): boolean {
  return state.status !== "churned";
}

/** Só `trial` vencido e `suspended` bloqueiam; `churned` bloqueia tudo. */
export function blockReason(state: InstitutionState, now: Date = new Date()): string | null {
  const status = effectiveStatus(state, now);
  if (status === "trial_expired") {
    return "O período de avaliação terminou. Os dados continuam disponíveis para leitura e exportação.";
  }
  if (status === "suspended") {
    return "A conta está suspensa. Leitura e exportação continuam liberadas; a escrita está bloqueada.";
  }
  if (status === "churned") {
    return "A conta foi encerrada.";
  }
  return null;
}

/**
 * Compara uso com cota. `NULL` no limite significa "sem limite", não zero.
 * Retorna `null` quando cabe; caso contrário, a mensagem de bloqueio.
 */
export function checkQuota(
  limits: PlanLimits,
  key: QuotaKey,
  current: number,
  incoming = 1,
): string | null {
  const limit = limits[key];
  if (limit === null) return null;
  if (current + incoming <= limit) return null;
  return quotaMessage(key, limit, current);
}

/** Dias restantes de trial. Negativo = vencido. `null` = não é trial. */
export function trialDaysLeft(state: InstitutionState, now: Date = new Date()): number | null {
  if (state.status !== "trial" || !state.trialEndsAt) return null;
  const ms = state.trialEndsAt.getTime() - now.getTime();
  return Math.ceil(ms / 86_400_000);
}
