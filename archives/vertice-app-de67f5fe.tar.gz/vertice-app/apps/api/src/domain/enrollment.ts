import type { EnrollmentRecordInput } from "./validation.js";

/**
 * Regras do agregado de matrícula. Puras de propósito: nada aqui toca banco,
 * request ou configuração, então a parte que pode estar errada é a que dá para
 * testar.
 *
 * Duas leituras erradas que este arquivo existe para impedir:
 *
 *  1. Tratar o agregado como contagem de pessoas. É contagem de vínculos
 *     (matrícula no semestre). Um aluno com duas matrículas conta duas vezes.
 *  2. Tratar divergência da origem como erro a corrigir. O e-ORBIT tem casos em
 *     que a soma por turma não fecha com o subtotal do curso; o correto é
 *     publicar os dois números e sinalizar, não "acertar" um deles.
 */

export type SemesterStatus = keyof typeof STATUS_TO_COLUMN;

/** Ordem e rótulo do relatório do e-ORBIT. A chave é o nome no contrato. */
export const STATUS_TO_COLUMN = {
  matriculado: "matriculado",
  preMatriculado: "pre_matriculado",
  trancado: "trancado",
  abandono: "abandono",
  concluido: "concluido",
  cancelado: "cancelado",
  transferido: "transferido",
  trocaCurso: "troca_curso",
  graduado: "graduado",
} as const;

export interface EnrollmentRow {
  courseRef: string;
  semester: string;
  vagas: number;
  matriculado: number;
  preMatriculado: number;
  trancado: number;
  abandono: number;
  concluido: number;
  cancelado: number;
  transferido: number;
  trocaCurso: number;
  graduado: number;
  totalRegistros: number;
  turmasSomadas: number;
  turmas: { serie: number; turma: string; matriculados: number }[];
  source: string;
  observedAt: string;
}

/** Normaliza o registro validado: ausente vira zero, `turmas` vira array. */
export function toEnrollmentRow(input: EnrollmentRecordInput): EnrollmentRow {
  return {
    courseRef: input.courseRef,
    semester: input.semester,
    vagas: input.vagas ?? 0,
    matriculado: input.matriculado ?? 0,
    preMatriculado: input.preMatriculado ?? 0,
    trancado: input.trancado ?? 0,
    abandono: input.abandono ?? 0,
    concluido: input.concluido ?? 0,
    cancelado: input.cancelado ?? 0,
    transferido: input.transferido ?? 0,
    trocaCurso: input.trocaCurso ?? 0,
    graduado: input.graduado ?? 0,
    totalRegistros: input.totalRegistros ?? 0,
    turmasSomadas: input.turmasSomadas ?? 0,
    turmas: input.turmas ?? [],
    source: input.source,
    observedAt: input.observedAt,
  };
}

/** Soma dos nove status. É a coluna "Total de registros" quando a origem omite. */
export function sumStatuses(row: Pick<EnrollmentRow, SemesterStatus>): number {
  return Object.keys(STATUS_TO_COLUMN).reduce(
    (total, key) => total + (row[key as SemesterStatus] ?? 0),
    0,
  );
}

/** Soma dos matriculados das turmas — confere contra `turmasSomadas`. */
export function sumClassEnrollment(row: Pick<EnrollmentRow, "turmas">): number {
  return row.turmas.reduce((total, turma) => total + turma.matriculados, 0);
}

export type DivergenceKind =
  | "subtotal_vs_turmas"
  | "total_vs_status"
  | "turmas_sem_detalhe";

export interface Divergence {
  kind: DivergenceKind;
  expected: number;
  found: number;
  detail: string;
}

/**
 * Divergências que devem ser publicadas junto com o número, e não corrigidas.
 *
 * Só reportamos o que é inequivocamente incoerente. Diferença de 1 a 3 entre
 * subtotal e soma por turma é comum na origem e não invalida o dado; já
 * `matriculado > 0` sem nenhuma turma detalhada é sinal de extração pela metade
 * e precisa aparecer.
 */
export function findDivergences(row: EnrollmentRow): Divergence[] {
  const out: Divergence[] = [];
  const somaTurmas = sumClassEnrollment(row);
  const somaStatus = sumStatuses(row);

  // A origem pode não trazer `turmasSomadas`. Nesse caso não há o que comparar.
  if (row.turmasSomadas > 0 && somaTurmas !== row.turmasSomadas) {
    out.push({
      kind: "subtotal_vs_turmas",
      expected: row.turmasSomadas,
      found: somaTurmas,
      detail:
        `soma das turmas (${somaTurmas}) difere do subtotal informado ` +
        `(${row.turmasSomadas}). Publicar como está.`,
    });
  }

  if (row.totalRegistros > 0 && somaStatus !== row.totalRegistros) {
    out.push({
      kind: "total_vs_status",
      expected: row.totalRegistros,
      found: somaStatus,
      detail:
        `soma dos status (${somaStatus}) difere do total de registros ` +
        `(${row.totalRegistros}). Manter os dois valores.`,
    });
  }

  if (row.matriculado > 0 && row.turmas.length === 0) {
    out.push({
      kind: "turmas_sem_detalhe",
      expected: row.matriculado,
      found: 0,
      detail:
        `há ${row.matriculado} matriculado(s) sem nenhuma turma detalhada. ` +
        `Extração incompleta em 03_Turmas.`,
    });
  }

  return out;
}

/**
 * Quantas turmas têm aluno. É a coluna "Turmas com alunos" do painel e conta
 * entradas distintas na origem (a mesma turma pode aparecer repetida).
 */
export function classesWithStudents(row: Pick<EnrollmentRow, "turmas">): number {
  const chaves = new Set(row.turmas.map((t) => `${t.serie}|${t.turma}`));
  return chaves.size;
}

/** Semestre anterior: 2026/01 -> 2025/02, 2026/02 -> 2026/01. */
export function previousSemester(semester: string): string | null {
  const match = /^([0-9]{4})\/(0[12])$/.exec(semester);
  if (!match) return null;
  const year = Number(match[1]);
  // No primeiro semestre, o anterior é o segundo do ano passado. Não existe
  // "semestre zero": quem cair aqui precisa saber que é virada de ano.
  return match[2] === "01" ? `${year - 1}/02` : `${year}/01`;
}

export interface Comparison {
  current: number;
  previous: number | null;
  /** Fração pronta para formatar como %. `null` quando não há base. */
  change: number | null;
  label: "up" | "down" | "flat" | "no_base";
}

/**
 * Variação em relação ao semestre anterior.
 *
 * Divisão por zero não vira "100%": sem base, a variação é indefinida. O painel
 * mostra "—" em vez de um número que sugere crescimento explosivo.
 */
export function compare(current: number, previous: number | null): Comparison {
  if (previous === null) {
    return { current, previous: null, change: null, label: "no_base" };
  }
  if (previous === 0) {
    return { current, previous, change: null, label: current === 0 ? "flat" : "up" };
  }
  const change = (current - previous) / previous;
  const label = change > 0 ? "up" : change < 0 ? "down" : "flat";
  return { current, previous, change, label };
}

export type PublishVerdict = "publish" | "review" | "skip";

export interface PublishDecision {
  verdict: PublishVerdict;
  reason: string;
}

/**
 * Decide se o agregado vai para o painel da coordenação.
 *
 * Conservador de propósito: número sem turma detalhada ou incoerente com a
 * origem vai para revisão, não para o painel. Publicar errado é pior do que
 * publicar tarde — a mesma regra que a extensão já segue ao falhar fechada.
 */
export function decidePublish(row: EnrollmentRow, divergences: Divergence[]): PublishDecision {
  const bloqueante = divergences.find((d) => d.kind === "turmas_sem_detalhe");
  if (bloqueante) {
    return { verdict: "review", reason: bloqueante.detail };
  }

  if (row.matriculado === 0 && sumStatuses(row) === 0 && row.turmas.length === 0) {
    return { verdict: "skip", reason: "Sem nenhum registro no semestre." };
  }

  if (divergences.length > 0) {
    return {
      verdict: "review",
      reason: `${divergences.length} divergência(s) entre a origem e o somatório. Conferir antes de publicar.`,
    };
  }

  return { verdict: "publish", reason: "Agregado coerente com a origem." };
}

export interface CoursePanelRow {
  courseRef: string;
  semester: string;
  matriculado: number;
  previousMatriculado: number | null;
  change: Comparison;
  classesWithStudents: number;
  decision: PublishDecision;
  divergences: Divergence[];
}

/**
 * Monta a linha do painel por curso: o número do semestre, o do anterior, a
 * variação e quantas turmas têm aluno. É exatamente o retrato da aba
 * 04_Publicacao_Curso da planilha.
 */
export function buildCoursePanelRow(
  current: EnrollmentRow,
  previous: EnrollmentRow | null,
): CoursePanelRow {
  const divergences = findDivergences(current);
  return {
    courseRef: current.courseRef,
    semester: current.semester,
    matriculado: current.matriculado,
    previousMatriculado: previous?.matriculado ?? null,
    change: compare(current.matriculado, previous?.matriculado ?? null),
    classesWithStudents: classesWithStudents(current),
    decision: decidePublish(current, divergences),
    divergences,
  };
}

/**
 * Consolida um lote: uma linha por curso+semestre, a última observada vence.
 * Reimportar o mesmo semestre substitui, não soma — o relatório é um retrato.
 */
export function consolidate(rows: EnrollmentRow[]): EnrollmentRow[] {
  const mapa = new Map<string, EnrollmentRow>();
  for (const row of rows) {
    const chave = `${row.courseRef}|${row.semester}`;
    const existente = mapa.get(chave);
    if (!existente || Date.parse(row.observedAt) >= Date.parse(existente.observedAt)) {
      mapa.set(chave, row);
    }
  }
  return [...mapa.values()];
}
