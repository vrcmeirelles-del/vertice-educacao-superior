import { z } from "zod";
import { REQUEST_TYPES } from "./risk-engine.js";

/**
 * Contrato de ingestão. `strict()` é essencial: qualquer campo não previsto
 * — sobretudo nome, CPF, e-mail, telefone — rejeita o registro inteiro em vez
 * de ser silenciosamente descartado.
 */

const ref = (max: number) =>
  z
    .string()
    .min(2)
    .max(max)
    .regex(/^[A-Za-z0-9._:-]+$/, "deve ser um identificador pseudonimizado");

export const retentionRecordSchema = z
  .object({
    studentRef: ref(128),
    courseRef: ref(128),
    attendancePercent: z.number().min(0).max(100).nullable().optional(),
    consecutiveAbsences: z.number().int().min(0).max(365).nullable().optional(),
    assessmentAverage: z.number().min(0).max(10).nullable().optional(),
    passingAverage: z.number().min(0).max(10).nullable().optional(),
    openRequests: z.array(z.enum(REQUEST_TYPES)).max(20).optional(),
    observedAt: z.string().datetime({ offset: true }),
    source: ref(80),
  })
  .strict();

export type RetentionRecordInput = z.infer<typeof retentionRecordSchema>;

export const ingestionBatchSchema = z
  .object({
    records: z.array(retentionRecordSchema).min(1).max(1000),
  })
  .strict();

// ---------------------------------------------------------------------------
// Matrícula agregada por curso
//
// Contrato diferente do de retenção, de propósito: aqui não existe aluno, e
// `studentRef` não é aceito. O `.strict()` impede que uma planilha mais larga
// que a esperada entre silenciosamente carregando nome de estudante.
// ---------------------------------------------------------------------------

/**
 * Semestre letivo AAAA/SS. Guardado como texto: é rótulo, não data.
 * Só 01 e 02 — o calendário desta operação é semestral. Aceitar 03 abriria
 * espaço para trimestre colado por engano e quebraria a comparação com o
 * semestre anterior.
 */
const semester = z
  .string()
  .regex(/^[0-9]{4}\/(0[12])$/, "semestre deve ser AAAA/01 ou AAAA/02 (ex.: 2026/02)");

const contagem = z.number().int().min(0).max(100_000);

export const enrollmentClassSchema = z
  .object({
    serie: z.number().int().min(0).max(99),
    /** Código da turma como está na origem, sem o sufixo do semestre. */
    turma: z.string().min(1).max(60),
    matriculados: z.number().int().min(1).max(100_000),
  })
  .strict();

export const enrollmentRecordSchema = z
  .object({
    courseRef: ref(128),
    semester,
    vagas: contagem.optional(),
    matriculado: contagem.optional(),
    preMatriculado: contagem.optional(),
    trancado: contagem.optional(),
    abandono: contagem.optional(),
    concluido: contagem.optional(),
    cancelado: contagem.optional(),
    transferido: contagem.optional(),
    trocaCurso: contagem.optional(),
    graduado: contagem.optional(),
    totalRegistros: contagem.optional(),
    turmasSomadas: contagem.optional(),
    /** Turmas com 1+ matriculados. Turma zerada não entra. */
    turmas: z.array(enrollmentClassSchema).max(500).optional(),
    observedAt: z.string().datetime({ offset: true }),
    source: ref(80),
  })
  .strict();

export type EnrollmentRecordInput = z.infer<typeof enrollmentRecordSchema>;

export const enrollmentBatchSchema = z
  .object({
    records: z.array(enrollmentRecordSchema).min(1).max(2000),
  })
  .strict();

/**
 * Envelope do lote, validado na rota antes de olhar cada registro.
 *
 * A separação é deliberada: se a rota validasse o lote com o schema completo,
 * uma célula mal formatada nas 840 linhas da planilha derrubaria o lote
 * inteiro. O envelope garante que veio um array de tamanho razoável; a
 * conferência de cada registro fica no serviço, que aceita os bons e devolve o
 * motivo dos ruins.
 */
export const enrollmentEnvelopeSchema = z
  .object({
    records: z.array(z.unknown()).min(1).max(2000),
  })
  .strict();

/**
 * Campos que só existem no contrato de retenção. Se aparecerem num lote de
 * matrícula, é sinal de que alguém colou a planilha errada — recusamos o lote
 * inteiro em vez de ignorar as colunas sobrando.
 */
export const STUDENT_LEVEL_FIELDS = [
  "studentRef",
  "attendancePercent",
  "consecutiveAbsences",
  "assessmentAverage",
  "passingAverage",
  "openRequests",
] as const;

export function detectStudentLevelFields(payload: unknown): string[] {
  if (!payload || typeof payload !== "object") return [];
  const keys = new Set<string>();
  const walk = (value: unknown) => {
    if (Array.isArray(value)) {
      value.forEach(walk);
      return;
    }
    if (value && typeof value === "object") {
      for (const [key, child] of Object.entries(value)) {
        keys.add(key);
        walk(child);
      }
    }
  };
  walk(payload);
  return STUDENT_LEVEL_FIELDS.filter((field) => keys.has(field));
}

/**
 * Nomes que, se aparecerem, indicam vazamento de dado pessoal. A checagem é
 * redundante com `.strict()` de propósito: queremos uma mensagem explícita
 * e auditável quando alguém tenta enviar CPF.
 */
export const FORBIDDEN_FIELDS = [
  "name",
  "fullName",
  "nome",
  "cpf",
  "rg",
  "email",
  "phone",
  "telefone",
  "whatsapp",
  "address",
  "endereco",
  "password",
  "senha",
  "token",
  "healthData",
  "biometric",
  "biometria",
  "rawHtml",
  "freeText",
] as const;

export function detectForbiddenFields(payload: unknown): string[] {
  if (!payload || typeof payload !== "object") return [];
  const keys = new Set<string>();
  const walk = (value: unknown) => {
    if (Array.isArray(value)) {
      value.forEach(walk);
      return;
    }
    if (value && typeof value === "object") {
      for (const [key, child] of Object.entries(value)) {
        keys.add(key);
        walk(child);
      }
    }
  };
  walk(payload);
  return FORBIDDEN_FIELDS.filter((field) => keys.has(field));
}

/** Resultado por registro em lotes: aceitos e rejeitados com motivo. */
export interface BatchOutcome<T> {
  accepted: { index: number; value: T }[];
  rejected: { index: number; reason: string; field?: string }[];
}

export function validateBatch<T>(
  records: unknown[],
  schema: z.ZodType<T>,
): BatchOutcome<T> {
  const outcome: BatchOutcome<T> = { accepted: [], rejected: [] };
  records.forEach((record, index) => {
    const parsed = schema.safeParse(record);
    if (parsed.success) {
      outcome.accepted.push({ index, value: parsed.data });
    } else {
      const issue = parsed.error.issues[0];
      outcome.rejected.push({
        index,
        reason: issue?.message ?? "registro inválido",
        field: issue?.path.join(".") || undefined,
      });
    }
  });
  return outcome;
}
