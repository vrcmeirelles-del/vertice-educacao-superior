/**
 * Motor de risco determinístico e explicável.
 *
 * Decisões de projeto (ver docs/CORRECOES-E-FUROS.md):
 *  - nenhuma ação automática contra o estudante;
 *  - pesos e limites vêm de um ruleset versionado por IES/curso;
 *  - todo fator que compõe o escore é devolvido com valor observado e limite;
 *  - recalcular sem um fator produz resultado determinístico e menor.
 *
 * Este módulo não importa nada do banco: é testável isoladamente.
 */

export interface RiskRules {
  attendanceThreshold: number;
  attendanceWeight: number;
  consecutiveAbsenceThreshold: number;
  consecutiveAbsenceWeight: number;
  lowAssessmentWeight: number;
  exitRequestWeight: number;
}

export const DEFAULT_RULES: Readonly<RiskRules> = Object.freeze({
  attendanceThreshold: 80,
  attendanceWeight: 35,
  consecutiveAbsenceThreshold: 3,
  consecutiveAbsenceWeight: 25,
  lowAssessmentWeight: 20,
  exitRequestWeight: 30,
});

export const EXIT_REQUESTS = ["TRANSFER_REQUEST", "WITHDRAWAL_REQUEST"] as const;

export const REQUEST_TYPES = [
  "TRANSFER_REQUEST",
  "WITHDRAWAL_REQUEST",
  "HISTORY_REQUEST",
  "SYLLABUS_REQUEST",
  "OTHER",
] as const;

export type RequestType = (typeof REQUEST_TYPES)[number];
export type RiskLevel = "low" | "medium" | "high" | "critical";

export interface RiskInput {
  attendancePercent: number | null;
  consecutiveAbsences: number | null;
  assessmentAverage: number | null;
  passingAverage: number | null;
  openRequests: RequestType[];
}

export interface RiskFactor {
  code: "LOW_ATTENDANCE" | "CONSECUTIVE_ABSENCES" | "LOW_ASSESSMENT" | "EXIT_REQUEST_SIGNAL";
  points: number;
  observed: number | string;
  threshold: number | string;
  explanation: string;
}

export interface RiskResult {
  score: number;
  level: RiskLevel;
  factors: RiskFactor[];
  reviewRequired: boolean;
  recommendedAction: string;
  automatedDecision: null;
  ruleVersion: string;
}

const clamp = (value: number, min: number, max: number) => Math.min(Math.max(value, min), max);

export function levelFor(score: number): RiskLevel {
  if (score >= 70) return "critical";
  if (score >= 50) return "high";
  if (score >= 30) return "medium";
  return "low";
}

/** Valida e normaliza um ruleset vindo do banco/UI. */
export function normalizeRules(input: Partial<RiskRules> | null | undefined): RiskRules {
  const merged = { ...DEFAULT_RULES, ...(input ?? {}) };
  const int = (value: unknown, fallback: number) => {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? Math.round(clamp(parsed, 0, 100)) : fallback;
  };
  return {
    attendanceThreshold: clamp(Number(merged.attendanceThreshold), 0, 100),
    attendanceWeight: int(merged.attendanceWeight, DEFAULT_RULES.attendanceWeight),
    consecutiveAbsenceThreshold: Math.max(0, Math.round(Number(merged.consecutiveAbsenceThreshold))),
    consecutiveAbsenceWeight: int(merged.consecutiveAbsenceWeight, DEFAULT_RULES.consecutiveAbsenceWeight),
    lowAssessmentWeight: int(merged.lowAssessmentWeight, DEFAULT_RULES.lowAssessmentWeight),
    exitRequestWeight: int(merged.exitRequestWeight, DEFAULT_RULES.exitRequestWeight),
  };
}

/**
 * Calcula o alerta de acompanhamento. O nome importa: isto NÃO é diagnóstico
 * de evasão nem decisão sobre o estudante.
 */
export function evaluateRisk(
  input: RiskInput,
  rules: RiskRules = DEFAULT_RULES,
  ruleVersion = "retention-v1",
): RiskResult {
  const safeRules = normalizeRules(rules);
  const factors: RiskFactor[] = [];
  let score = 0;

  if (input.attendancePercent != null && input.attendancePercent < safeRules.attendanceThreshold) {
    score += safeRules.attendanceWeight;
    factors.push({
      code: "LOW_ATTENDANCE",
      points: safeRules.attendanceWeight,
      observed: input.attendancePercent,
      threshold: safeRules.attendanceThreshold,
      explanation: `Frequência de ${input.attendancePercent}% abaixo do limite de ${safeRules.attendanceThreshold}%`,
    });
  }

  if (
    input.consecutiveAbsences != null &&
    input.consecutiveAbsences >= safeRules.consecutiveAbsenceThreshold &&
    safeRules.consecutiveAbsenceThreshold > 0
  ) {
    score += safeRules.consecutiveAbsenceWeight;
    factors.push({
      code: "CONSECUTIVE_ABSENCES",
      points: safeRules.consecutiveAbsenceWeight,
      observed: input.consecutiveAbsences,
      threshold: safeRules.consecutiveAbsenceThreshold,
      explanation: `${input.consecutiveAbsences} faltas consecutivas (limite: ${safeRules.consecutiveAbsenceThreshold})`,
    });
  }

  if (
    input.assessmentAverage != null &&
    input.passingAverage != null &&
    input.assessmentAverage < input.passingAverage
  ) {
    score += safeRules.lowAssessmentWeight;
    factors.push({
      code: "LOW_ASSESSMENT",
      points: safeRules.lowAssessmentWeight,
      observed: input.assessmentAverage,
      threshold: input.passingAverage,
      explanation: "Média parcial abaixo da referência configurada pela IES",
    });
  }

  const exitRequest = input.openRequests.find((request) =>
    (EXIT_REQUESTS as readonly string[]).includes(request),
  );
  if (exitRequest) {
    score += safeRules.exitRequestWeight;
    factors.push({
      code: "EXIT_REQUEST_SIGNAL",
      points: safeRules.exitRequestWeight,
      observed: exitRequest,
      threshold: "TRANSFER_REQUEST | WITHDRAWAL_REQUEST",
      explanation: "Requerimento que exige acompanhamento humano prioritário",
    });
  }

  const boundedScore = clamp(score, 0, 100);
  const level = levelFor(boundedScore);

  return {
    score: boundedScore,
    level,
    factors,
    reviewRequired: factors.length > 0,
    recommendedAction:
      level === "critical" || level === "high"
        ? "Encaminhar para revisão humana conforme a política da IES. Não bloquear serviços acadêmicos."
        : factors.length > 0
          ? "Registrar acolhimento e reavaliar conforme a política da IES."
          : "Nenhuma ação de acompanhamento necessária com os dados recebidos.",
    automatedDecision: null,
    ruleVersion,
  };
}

/** Extrai o ruleset aplicável a um curso a partir das linhas do banco. */
export function pickRuleset<T extends { courseId: string | null }>(
  rulesets: T[],
  courseId: string,
): T | undefined {
  return rulesets.find((r) => r.courseId === courseId) ?? rulesets.find((r) => r.courseId === null);
}
