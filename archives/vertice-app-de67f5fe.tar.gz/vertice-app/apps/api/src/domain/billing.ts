import { createHmac, timingSafeEqual } from "node:crypto";

/**
 * Regras de cobrança que não dependem de banco nem de I/O.
 *
 * Separadas de propósito: assinatura de webhook e transição de estado são as
 * duas coisas que erram silenciosamente em produção. Assim ficam testáveis
 * sem subir Postgres.
 */

export type BillingProvider = "asaas" | "pagarme" | "manual";

/** O que o webhook precisa para decidir o novo estado da conta. */
export type BillingEffect =
  | { kind: "subscription_active"; periodStart: Date | null; periodEnd: Date | null }
  | { kind: "subscription_past_due" }
  | { kind: "subscription_canceled"; cancelAt: Date | null }
  | { kind: "ignored"; why: string };

export interface NormalizedEvent {
  /** Id do evento no provedor. Chave de idempotência. */
  eventId: string;
  type: string;
  /** Instituição-alvo, resolvida a partir do identificador do provedor. */
  providerRef: string | null;
  occurredAt: Date | null;
  effect: BillingEffect;
}

export class WebhookSignatureError extends Error {
  readonly statusCode = 401;
  readonly code = "invalid_signature";
  constructor(message = "Assinatura do webhook inválida") {
    super(message);
    this.name = "WebhookSignatureError";
  }
}

/**
 * Verifica HMAC-SHA256 do corpo bruto.
 *
 * O corpo tem que ser o byte exato recebido — reserializar o JSON muda espaços
 * e a assinatura nunca confere. É por isso que a rota registra um parser de
 * corpo bruto em vez de usar `request.body`.
 *
 * `timingSafeEqual` exige buffers do mesmo tamanho, então o tamanho é
 * comparado antes; um comprimento diferente já é assinatura inválida e não
 * vaza nada que o atacante não soubesse.
 */
export function verifyHmacSignature(
  rawBody: Buffer | string,
  signatureHex: string | undefined,
  secret: string,
): void {
  if (!secret) throw new WebhookSignatureError("Webhook sem segredo configurado");
  if (!signatureHex) throw new WebhookSignatureError("Webhook sem cabeçalho de assinatura");

  const expected = createHmac("sha256", secret).update(rawBody).digest();
  const provided = Buffer.from(signatureHex.trim(), "hex");

  if (provided.length !== expected.length || !timingSafeEqual(provided, expected)) {
    throw new WebhookSignatureError();
  }
}

/**
 * Comparação de token enviado em cabeçalho (Asaas usa `asaas-access-token`,
 * um segredo compartilhado, não HMAC). Mesmo cuidado de tempo constante.
 */
export function verifySharedToken(provided: string | undefined, expected: string): void {
  if (!expected) throw new WebhookSignatureError("Webhook sem token configurado");
  if (!provided) throw new WebhookSignatureError("Webhook sem token no cabeçalho");

  const a = Buffer.from(provided);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) {
    throw new WebhookSignatureError("Token do webhook inválido");
  }
}

/**
 * Traduz o evento do provedor para o efeito sobre a conta.
 *
 * `ignored` não é erro: provedores mandam dezenas de tipos que não mudam nada
 * aqui (boleto gerado, nota fiscal emitida). Registrar e ignorar é o
 * comportamento certo — devolver 400 faria o provedor reentregar para sempre.
 */
export function normalizeAsaasEvent(payload: unknown): NormalizedEvent {
  const body = payload as {
    id?: string;
    event?: string;
    payment?: { subscription?: string; dueDate?: string };
    subscription?: { id?: string; nextDueDate?: string };
    dateCreated?: string;
  };

  const eventId = typeof body?.id === "string" ? body.id : "";
  const type = typeof body?.event === "string" ? body.event : "";
  if (!eventId || !type) {
    throw new WebhookSignatureError("Evento sem identificador ou tipo");
  }

  const providerRef = body.subscription?.id ?? body.payment?.subscription ?? null;
  const occurredAt = body.dateCreated ? new Date(body.dateCreated) : null;

  const effect = ((): BillingEffect => {
    switch (type) {
      case "PAYMENT_CONFIRMED":
      case "PAYMENT_RECEIVED":
        return { kind: "subscription_active", periodStart: null, periodEnd: null };
      case "PAYMENT_OVERDUE":
        return { kind: "subscription_past_due" };
      case "SUBSCRIPTION_DELETED":
        return { kind: "subscription_canceled", cancelAt: null };
      default:
        return { kind: "ignored", why: `evento ${type} não altera a conta` };
    }
  })();

  return { eventId, type, providerRef, occurredAt, effect };
}

/**
 * Estado-alvo da conta para um efeito. Centralizado para que a regra
 * `past_due` continua escrevendo (só `suspended` bloqueia) fique em um lugar.
 */
export function statusForEffect(
  effect: BillingEffect,
): "active" | "past_due" | "churned" | null {
  switch (effect.kind) {
    case "subscription_active":
      return "active";
    case "subscription_past_due":
      return "past_due";
    case "subscription_canceled":
      return "churned";
    default:
      return null;
  }
}

/**
 * Um evento pode ser aplicado?
 *
 * Regra: só se for mais novo que o último aplicado. Sem `occurred_at` do
 * provedor, aplica — a idempotência por `event_id` ainda impede repetição.
 */
export function isNewerThanLastEvent(
  occurredAt: Date | null,
  lastEventAt: Date | null,
): boolean {
  if (!occurredAt || !lastEventAt) return true;
  return occurredAt.getTime() > lastEventAt.getTime();
}
