import { createHmac, timingSafeEqual } from "node:crypto";
import { config } from "../config.js";

/**
 * A IES envia um identificador pseudonimizado (studentRef). Mesmo esse valor
 * não é guardado em claro: persistimos apenas um HMAC-SHA256 com pepper de
 * servidor. Isso impede correlação entre tenants e reduz o impacto de um
 * dump do banco.
 */
export function hashStudentRef(studentRef: string): string {
  return createHmac("sha256", config.pseudonymPepper).update(studentRef.trim().toLowerCase()).digest("hex");
}

/** Comparação em tempo constante para hashes de referência. */
export function sameRefHash(a: string, b: string): boolean {
  const bufA = Buffer.from(a, "hex");
  const bufB = Buffer.from(b, "hex");
  if (bufA.length !== bufB.length) return false;
  return timingSafeEqual(bufA, bufB);
}
