import type { FastifyRequest } from "fastify";
import { createHash } from "node:crypto";
import { query } from "../db/pool.js";
import { forbidden, unauthorized } from "../http/errors.js";
import { verifySession, type Role, type SessionClaims } from "./tokens.js";

declare module "fastify" {
  interface FastifyRequest {
    auth?: SessionClaims;
    tenantId?: string;
  }
}

/**
 * Resolve a sessão do usuário. O tenant NUNCA vem do corpo da requisição:
 * é derivado da membership gravada no token e reconferido no banco a cada
 * chamada (revogação imediata e expiração de auditor).
 */
export async function requireUser(request: FastifyRequest): Promise<SessionClaims> {
  const header = request.headers.authorization ?? "";
  const [scheme, token] = header.split(" ");
  if (scheme !== "Bearer" || !token) throw unauthorized();

  let claims: SessionClaims;
  try {
    claims = await verifySession(token);
  } catch {
    throw unauthorized("Sessão inválida ou expirada");
  }

  const revoked = await query("SELECT 1 FROM revoked_sessions WHERE jti = $1", [claims.jti]);
  if (revoked.rowCount) throw unauthorized("Sessão revogada");

  const membership = await query<{ expires_at: Date | null; revoked_at: Date | null }>(
    `SELECT m.expires_at, m.revoked_at
       FROM memberships m
      WHERE m.user_id = $1
        AND m.role = $2
        AND ($3::uuid IS NULL AND m.institution_id IS NULL OR m.institution_id = $3::uuid)`,
    [claims.sub, claims.role, claims.institutionId],
  );

  const row = membership.rows[0];
  if (!row || row.revoked_at) throw unauthorized("Acesso revogado");
  if (row.expires_at && row.expires_at.getTime() < Date.now()) {
    throw forbidden("Acesso temporário expirado");
  }

  request.auth = claims;
  request.tenantId = claims.institutionId ?? undefined;
  return claims;
}

const READ_ROLES: Role[] = [
  "platform_admin",
  "institution_admin",
  "regulatory_manager",
  "coordinator",
  "auditor_readonly",
  "privacy_officer",
];

/** Exige um dos papéis informados. */
export async function requireRole(request: FastifyRequest, ...allowed: Role[]): Promise<SessionClaims> {
  const claims = await requireUser(request);
  if (!allowed.includes(claims.role)) {
    throw forbidden(`Papel ${claims.role} não autorizado para esta operação`);
  }
  return claims;
}

/**
 * Toda consulta de dados de cliente passa por aqui. Centralizar evita o
 * esquecimento de um `WHERE institution_id` em uma rota nova.
 */
export function requireTenant(request: FastifyRequest): string {
  const claims = request.auth;
  if (!claims) throw unauthorized();
  if (!claims.institutionId) throw forbidden("Usuário sem instituição vinculada");
  return claims.institutionId;
}

/**
 * Operador da Vértice.
 *
 * `platform_admin` não tem instituição, então nunca passa por `requireTenant` —
 * todas as rotas de cliente o recusam com 403. As rotas `/v1/platform/*` usam
 * este guard e escolhem a instituição-alvo explicitamente na URL, registrando
 * a ação na auditoria da instituição afetada.
 */
export async function requirePlatformAdmin(request: FastifyRequest): Promise<SessionClaims> {
  const claims = await requireRole(request, "platform_admin");
  return claims;
}

/**
 * Instituição-alvo de uma rota de plataforma. Sempre vem do caminho, nunca do
 * corpo, e o formato é validado antes de virar consulta.
 */
export function platformTargetId(id: string | undefined): string {
  const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  if (!id || !uuid.test(id)) throw forbidden("Instituição inválida");
  return id;
}

/** Coordenador só enxerga os cursos do seu escopo. */
export function assertCourseAccess(request: FastifyRequest, courseId: string): void {
  const claims = request.auth;
  if (!claims) throw unauthorized();
  if (claims.role === "coordinator" && claims.courseScope.length > 0) {
    if (!claims.courseScope.includes(courseId)) {
      throw forbidden("Curso fora do escopo autorizado");
    }
  }
}

export function canWrite(role: Role): boolean {
  return role !== "auditor_readonly" && role !== "privacy_officer";
}

export function sha256(value: string): string {
  return createHash("sha256").update(value).digest("hex");
}

export { READ_ROLES };
