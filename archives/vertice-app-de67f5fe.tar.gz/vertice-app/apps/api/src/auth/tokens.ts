import { randomBytes } from "node:crypto";
import { SignJWT, jwtVerify } from "jose";
import { config } from "../config.js";

export type Role =
  | "platform_admin"
  | "institution_admin"
  | "regulatory_manager"
  | "coordinator"
  | "auditor_readonly"
  | "privacy_officer";

export interface SessionClaims {
  sub: string;             // users.id
  jti: string;             // permite revogação
  email: string;
  name: string;
  institutionId: string | null;
  role: Role;
  courseScope: string[];
}

const secret = new TextEncoder().encode(config.jwtSecret);

export async function signSession(claims: SessionClaims): Promise<string> {
  return new SignJWT({ ...claims })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setIssuer(config.jwtIssuer)
    .setAudience(config.jwtAudience)
    .setExpirationTime(`${config.sessionTtlSeconds}s`)
    .setJti(claims.jti)
    .sign(secret);
}

export async function verifySession(token: string): Promise<SessionClaims> {
  const { payload } = await jwtVerify(token, secret, {
    issuer: config.jwtIssuer,
    audience: config.jwtAudience,
    algorithms: ["HS256"],
  });
  return payload as unknown as SessionClaims;
}

/** Token opaco de pareamento da extensão. Só o hash é persistido. */
export function newPairingToken(): string {
  return `vtc_${randomBytes(32).toString("base64url")}`;
}

export function newSessionId(): string {
  return randomBytes(16).toString("hex");
}
