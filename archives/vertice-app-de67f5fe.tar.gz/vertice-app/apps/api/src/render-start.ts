import { migrate } from "./db/migrate.js";
import { seed } from "./db/seed.js";
import { pool, closePool } from "./db/pool.js";
import { buildServer } from "./server.js";
import { config } from "./config.js";
import { transferRenderData } from "./db/transfer-render.js";

// The first deployment initializes access; later starts preserve user passwords.
if (process.env.DATABASE_AUTO_MIGRATE !== "false") await migrate();
if (process.env.MIGRATE_RENDER_DATA === "true") await transferRenderData();
const users = await pool.query("SELECT 1 FROM users LIMIT 1");
if (!users.rowCount && process.env.DATABASE_AUTO_MIGRATE !== "false") await seed();

const app = await buildServer();
await app.listen({ host: config.host, port: config.port });
for (const signal of ["SIGTERM", "SIGINT"] as const) {
  process.once(signal, async () => {
    await app.close();
    await closePool();
  });
}
