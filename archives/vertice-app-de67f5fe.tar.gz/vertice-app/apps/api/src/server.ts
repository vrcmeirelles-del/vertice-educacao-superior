import Fastify from "fastify";
import cors from "@fastify/cors";
import helmet from "@fastify/helmet";
import rateLimit from "@fastify/rate-limit";
import staticFiles from "@fastify/static";
import { fileURLToPath } from "node:url";
import { config } from "./config.js";
import { AppError } from "./http/errors.js";
import { closePool, pool } from "./db/pool.js";
import { authRoutes } from "./routes/auth.js";
import { ingestionRoutes } from "./routes/ingestion.js";
import { enrollmentRoutes } from "./routes/enrollment.js";
import { alertRoutes } from "./routes/alerts.js";
import { evidenceRoutes } from "./routes/evidence.js";
import { adminRoutes } from "./routes/admin.js";
import { documentRoutes } from "./routes/documents.js";
import { platformRoutes } from "./routes/platform.js";
import { billingRoutes } from "./routes/billing.js";
import { strategicRoutes } from "./routes/strategic.js";
import { SubscriptionBlockedError } from "./services/plans.js";
import { WebhookSignatureError } from "./domain/billing.js";

export async function buildServer() {
  const app = Fastify({
    logger: {
      level: process.env.LOG_LEVEL ?? "info",
      // Nunca logar corpo de requisição: pode conter dados acadêmicos.
      redact: ["req.headers.authorization", "req.headers.cookie"],
    },
    bodyLimit: config.bodyLimitBytes,
    trustProxy: true,
    disableRequestLogging: false,
  });

  await app.register(helmet, {
    contentSecurityPolicy: false, // a UI é servida separadamente
    crossOriginResourcePolicy: { policy: "same-site" },
  });

  await app.register(cors, {
    origin: (origin, callback) => {
      if (!origin) return callback(null, true); // curl/servidor
      callback(null, config.allowedOrigins.includes(origin));
    },
    methods: ["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["content-type", "authorization"],
    maxAge: 600,
  });

  await app.register(rateLimit, {
    max: Number(process.env.RATE_LIMIT_MAX ?? 300),
    timeWindow: "1 minute",
    // Ingestão em lote tem seu próprio limite, por rota.
    allowList: [],
  });

  app.setErrorHandler((error, request, reply) => {
    if (error instanceof AppError) {
      return reply.status(error.statusCode).send({
        error: error.code,
        message: error.message,
        details: error.details,
      });
    }
    // Webhook com assinatura inválida: 401 e nada mais. Não devolver detalhe
    // nem ecoar o que veio — a resposta é para o provedor, não para quem
    // estiver tentando descobrir o segredo.
    if (error instanceof WebhookSignatureError) {
      return reply.status(401).send({ error: error.code, message: error.message });
    }
    // Conta bloqueada por plano/assinatura: a UI usa `status` e `planCode`
    // para trocar o erro genérico pelo aviso de cobrança certo.
    if (error instanceof SubscriptionBlockedError) {
      return reply.status(402).send({
        error: error.code,
        message: error.message,
        details: { status: error.state.status, planCode: error.state.planCode },
      });
    }
    if ((error as { statusCode?: number }).statusCode === 429) {
      return reply.status(429).send({ error: "rate_limited", message: "Muitas requisições" });
    }
    if ((error as { validation?: unknown }).validation) {
      return reply.status(400).send({
        error: "invalid_request",
        message: (error as Error).message,
      });
    }

    request.log.error({ err: error }, "erro não tratado");
    return reply.status(500).send({
      error: "internal_error",
      message: "Erro interno. Tente novamente ou contate o suporte.",
    });
  });

  app.get("/health", async (_request, reply) => {
    try {
      await pool.query("SELECT 1");
      return { status: "ok", version: "1.0.0", database: process.env.SUPABASE_DATABASE_URL ? "supabase" : "postgres" };
    } catch {
      return reply.code(503).send({ status: "unavailable" });
    }
  });

  app.get("/v1/meta", async () => ({
    name: "Vértice Retention API",
    version: "1.0.0",
    disclaimer:
      "Alertas de acompanhamento. Não substitui decisão humana, e-MEC ou ERP acadêmico.",
    requestTypes: ["TRANSFER_REQUEST", "WITHDRAWAL_REQUEST", "HISTORY_REQUEST", "SYLLABUS_REQUEST", "OTHER"],
    enrollmentStatuses: [
      "matriculado",
      "preMatriculado",
      "trancado",
      "abandono",
      "concluido",
      "cancelado",
      "transferido",
      "trocaCurso",
      "graduado",
    ],
    semesterFormat: "AAAA/01 ou AAAA/02",
  }));

  await app.register(authRoutes);
  await app.register(ingestionRoutes);
  await app.register(enrollmentRoutes);
  await app.register(alertRoutes);
  await app.register(evidenceRoutes);
  await app.register(adminRoutes);
  await app.register(documentRoutes);
  await app.register(platformRoutes);
  await app.register(billingRoutes);
  await app.register(strategicRoutes);

  if (process.env.SERVE_WEB === "true") {
    await app.register(staticFiles, {
      root: fileURLToPath(new URL("../../web/dist/", import.meta.url)),
      index: "index.html",
    });
  }

  return app;
}

const isMain = process.argv[1]?.replace(/\\/g, "/").endsWith("/server.ts")
  || process.argv[1]?.replace(/\\/g, "/").endsWith("/dist/server.js");

if (isMain) {
  const app = await buildServer();
  try {
    await app.listen({ port: config.port, host: config.host });
    console.log(`[api] ouvindo em http://${config.host}:${config.port}`);
  } catch (error) {
    app.log.error(error);
    process.exit(1);
  }

  const shutdown = async (signal: string) => {
    console.log(`[api] ${signal} recebido, encerrando...`);
    await app.close();
    await closePool();
    process.exit(0);
  };
  process.on("SIGTERM", () => void shutdown("SIGTERM"));
  process.on("SIGINT", () => void shutdown("SIGINT"));
}

export { AppError };

