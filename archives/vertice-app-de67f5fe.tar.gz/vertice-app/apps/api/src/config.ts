import "dotenv/config";

/**
 * Configuração central da API. Falha rápido no boot quando falta segredo
 * obrigatório em produção — melhor derrubar o processo do que subir aberto.
 */
const isProduction = process.env.NODE_ENV === "production";

function required(name: string, fallback?: string): string {
  const value = process.env[name] ?? fallback;
  if (!value) {
    throw new Error(`Variável de ambiente obrigatória ausente: ${name}`);
  }
  if (isProduction && value.length < 32) {
    throw new Error(`Variável ${name} deve ter ao menos 32 caracteres em produção`);
  }
  return value;
}

export const config = {
  env: process.env.NODE_ENV ?? "development",
  isProduction,
  port: Number(process.env.PORT ?? 8787),
  host: process.env.HOST ?? "0.0.0.0",

  databaseUrl: process.env.SUPABASE_DATABASE_URL || required("DATABASE_URL", "postgresql://vertice:vertice@localhost:5432/vertice"),
  databaseSchema: process.env.DATABASE_SCHEMA ?? "public",

  /**
   * TLS na conexão com o banco. O driver `pg` NÃO liga TLS por padrão: sem
   * `sslmode=require` na URL, a conexão com um Postgres gerenciado (Supabase,
   * RDS, Magalu) sai em claro pela internet.
   *   - `PG_SSL=require` força TLS;
   *   - `PG_SSL=verify-full` força TLS e valida o certificado do servidor;
   *   - ausente = comportamento do driver (só TCP local, dev).
   */
  pgSsl: process.env.PG_SSL ?? "",

  /** Conexões simultâneas no pool. Ver docs/SUPABASE-MIGRACAO.md (pooler). */
  pgPoolMax: Number(process.env.PG_POOL_MAX ?? 10),

  /** Chave de assinatura dos JWT de sessão. */
  jwtSecret: required("JWT_SECRET", "dev-only-jwt-secret-change-me-please-32"),
  jwtIssuer: "vertice-api",
  jwtAudience: "vertice-app",
  sessionTtlSeconds: Number(process.env.SESSION_TTL_SECONDS ?? 60 * 60 * 8),

  /** Pepper usado no HMAC dos identificadores de estudante. */
  pseudonymPepper: required("PSEUDONYM_PEPPER", "dev-only-pseudonym-pepper-change-me-32"),

  /** Hash (scrypt) da senha de administrador criada no seed. */
  seedAdminEmail: process.env.SEED_ADMIN_EMAIL ?? "admin@vertice.local",
  seedAdminPassword: process.env.SEED_ADMIN_PASSWORD ?? "",

  allowedOrigins: (process.env.ALLOWED_ORIGINS ?? "http://localhost:5173,http://localhost:3000")
    .split(",")
    .map((value) => value.trim())
    .filter(Boolean),

  /** Tamanho máximo de corpo JSON aceito pela API. */
  bodyLimitBytes: Number(process.env.BODY_LIMIT_BYTES ?? 2 * 1024 * 1024),
  maxBatchRecords: 1000,

  /**
   * Storage de documentos. S3-compatível (AWS, Magalu Cloud, Cloudflare R2,
   * MinIO). O bucket é SEMPRE privado: toda leitura sai por URL pré-assinada.
   */
  storage: {
    endpoint: process.env.S3_ENDPOINT ?? undefined,
    region: process.env.S3_REGION ?? "sa-east-1",
    bucket: process.env.S3_BUCKET ?? "",
    accessKeyId: process.env.S3_ACCESS_KEY_ID ?? "",
    secretAccessKey: process.env.S3_SECRET_ACCESS_KEY ?? "",
    forcePathStyle: process.env.S3_FORCE_PATH_STYLE === "true",
    /** Validade da URL pré-assinada de upload (segundos). */
    uploadTtlSeconds: Number(process.env.S3_UPLOAD_TTL_SECONDS ?? 600),
    /** Validade da URL pré-assinada de download (segundos). Curta por padrão. */
    downloadTtlSeconds: Number(process.env.S3_DOWNLOAD_TTL_SECONDS ?? 300),
    /** Limite por arquivo. 25 MB cobre PDF de PPC e planilhas com folga. */
    maxFileBytes: Number(process.env.MAX_UPLOAD_BYTES ?? 25 * 1024 * 1024),
    /** Tipos aceitos. Lista fechada — nada de "application/octet-stream". */
    allowedMimeTypes: (
      process.env.ALLOWED_UPLOAD_MIME ??
      "application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,image/png,image/jpeg"
    )
      .split(",")
      .map((value) => value.trim())
      .filter(Boolean),
  },

  /**
   * Antivírus. `required` bloqueia a validação da evidência enquanto o arquivo
   * não for escaneado; `disabled` só é aceitável em desenvolvimento.
   */
  antivirus: {
    mode: (process.env.ANTIVIRUS_MODE ?? "required") as "required" | "disabled",
    clamHost: process.env.CLAMAV_HOST ?? "clamav",
    clamPort: Number(process.env.CLAMAV_PORT ?? 3310),
    timeoutMs: Number(process.env.CLAMAV_TIMEOUT_MS ?? 30_000),
  },

  /**
   * Webhook de cobrança. O provedor envia eventos de assinatura; a API valida
   * a assinatura HMAC-SHA256 e grava em `billing_events` antes de qualquer
   * processamento — idempotência garantida no banco.
   *
   * `provider` aceita 'asaas' | 'pagarme' | 'manual'. 'manual' desativa a
   * verificação de assinatura (só para testes locais). Em produção, use um
   * provedor real e defina o segredo.
   */
  billing: {
    provider: (process.env.BILLING_PROVIDER ?? "manual") as "asaas" | "pagarme" | "manual",
    webhookSecret: process.env.BILLING_WEBHOOK_SECRET ?? "",
  },
} as const;

/** Exportado para os guards: produção não sobe sem bucket configurado. */
export function assertStorageConfigured(): void {
  const { bucket, accessKeyId, secretAccessKey } = config.storage;
  if (!bucket || !accessKeyId || !secretAccessKey) {
    throw new Error(
      "Storage não configurado: defina S3_BUCKET, S3_ACCESS_KEY_ID e S3_SECRET_ACCESS_KEY",
    );
  }
}
