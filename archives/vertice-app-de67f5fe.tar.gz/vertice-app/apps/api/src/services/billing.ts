import { query, withTransaction } from "../db/pool.js";
import {
  isNewerThanLastEvent,
  statusForEffect,
  type NormalizedEvent,
} from "../domain/billing.js";

/**
 * Aplicação de evento de cobrança.
 *
 * Ordem das coisas, e por quê:
 *
 *  1. `INSERT ... ON CONFLICT DO NOTHING` no evento. Se não inseriu, já foi
 *     processado — responder 200 e sair. A chave é (provider, event_id), do
 *     banco: dois processos da API não conseguem aplicar o mesmo evento, mesmo
 *     com o provedor reentregando em paralelo.
 *  2. `SELECT ... FOR UPDATE` na assinatura. Serializa dois eventos distintos
 *     da mesma assinatura que chegam juntos.
 *  3. Compara `occurred_at` com `subscriptions.last_event_at`. Evento antigo
 *     não regride a conta; fica gravado com `skipped_reason` para que "por que
 *     a conta não mudou?" tenha resposta depois.
 *  4. Só então atualiza assinatura e instituição.
 *
 * Nada aqui chama o provedor. O webhook é a única entrada de estado comercial.
 */

export interface ApplyOutcome {
  /** false quando o evento já tinha sido processado antes. */
  processed: boolean;
  /** true quando o evento foi gravado mas não alterou nada. */
  skipped: boolean;
  reason?: string;
  /** Instituição afetada, quando identificada. Usada pela auditoria. */
  institutionId: string | null;
  /**
   * `subscriptions.id` — NÃO o `provider_ref`. A coluna `audit_log.resource_id`
   * é uuid; o id do provedor é texto livre (`sub_abc`) e faria o INSERT da
   * auditoria falhar, perdendo o registro em silêncio.
   */
  subscriptionId: string | null;
}

interface EventRow {
  id: string;
  occurred_at: Date | null;
}

export async function applyBillingEvent(
  provider: string,
  event: NormalizedEvent,
  payload: unknown,
): Promise<ApplyOutcome> {
  return withTransaction(async (client) => {
    // 1. Idempotência. A constraint UNIQUE (provider, event_id) decide.
    const inserted = await client.query<{ id: string }>(
      `INSERT INTO billing_events
         (provider, event_id, event_type, occurred_at, payload)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (provider, event_id) DO NOTHING
       RETURNING id`,
      [provider, event.eventId, event.type, event.occurredAt, JSON.stringify(payload)],
    );

    if (!inserted.rowCount) {
      return {
        processed: false,
        skipped: true,
        reason: "evento já processado",
        institutionId: null,
        subscriptionId: null,
      };
    }
    const eventRowId = inserted.rows[0]!.id;

    const finish = async (
      institutionId: string | null,
      outcome: Omit<ApplyOutcome, "institutionId" | "subscriptionId">,
      subscriptionId: string | null = null,
    ): Promise<ApplyOutcome> => {
      await client.query(
        `UPDATE billing_events
            SET processed_at = now(), institution_id = $2, skipped_reason = $3
          WHERE id = $1`,
        [eventRowId, institutionId, outcome.reason ?? null],
      );
      return { ...outcome, institutionId, subscriptionId };
    };

    // Evento sem assinatura identificável: gravado, não aplicado. Não é erro do
    // provedor, é evento que não nos diz respeito — devolver erro faria
    // reentrega infinita.
    if (!event.providerRef) {
      return finish(null, {
        processed: true,
        skipped: true,
        reason: "evento sem referência de assinatura",
      });
    }

    // 2. Serializa eventos concorrentes da mesma assinatura.
    const sub = await client.query<{
      id: string;
      institution_id: string;
      last_event_at: Date | null;
    }>(
      `SELECT id, institution_id, last_event_at
         FROM subscriptions
        WHERE provider = $1 AND provider_ref = $2
        ORDER BY created_at DESC
        LIMIT 1
        FOR UPDATE`,
      [provider, event.providerRef],
    );

    const subscription = sub.rows[0];
    if (!subscription) {
      // Assinatura desconhecida: instituição pode ter sido apagada, ou o
      // provedor está apontando para outro ambiente. Registrar e sinalizar é
      // melhor que criar estado a partir de um id que não reconhecemos.
      return finish(null, {
        processed: true,
        skipped: true,
        reason: `assinatura ${event.providerRef} não encontrada`,
      });
    }

    // 3. Ordem.
    if (!isNewerThanLastEvent(event.occurredAt, subscription.last_event_at)) {
      return finish(
        subscription.institution_id,
        {
          processed: true,
          skipped: true,
          reason: "evento mais antigo que o último aplicado",
        },
        subscription.id,
      );
    }

    // 4. Aplica.
    const targetStatus = statusForEffect(event.effect);

    if (event.effect.kind === "ignored" || targetStatus === null) {
      return finish(
        subscription.institution_id,
        {
          processed: true,
          skipped: true,
          reason: event.effect.kind === "ignored" ? event.effect.why : "evento sem efeito",
        },
        subscription.id,
      );
    }

    if (event.effect.kind === "subscription_canceled") {
      await client.query(
        `UPDATE subscriptions
            SET status = 'canceled',
                cancel_at = coalesce($2, now()),
                last_event_at = $3,
                updated_at = now()
          WHERE id = $1`,
        [subscription.id, event.effect.cancelAt, event.occurredAt],
      );
    } else if (event.effect.kind === "subscription_active") {
      await client.query(
        `UPDATE subscriptions
            SET status = 'active',
                current_period_start = coalesce($2, current_period_start),
                current_period_end = coalesce($3, current_period_end),
                last_event_at = $4,
                updated_at = now()
          WHERE id = $1`,
        [
          subscription.id,
          event.effect.periodStart,
          event.effect.periodEnd,
          event.occurredAt,
        ],
      );
    } else {
      await client.query(
        `UPDATE subscriptions
            SET status = 'past_due', last_event_at = $2, updated_at = now()
          WHERE id = $1`,
        [subscription.id, event.occurredAt],
      );
    }

    // A instituição acompanha a assinatura. `churned` implica encerramento;
    // `past_due` continua escrevendo — quem bloqueia é `suspended`, decisão
    // humana, não efeito de cobrança.
    await client.query(
      `UPDATE institutions
          SET status = $2,
              activated_at = CASE WHEN $2 = 'active' THEN coalesce(activated_at, now()) ELSE activated_at END,
              suspended_at = NULL,
              updated_at = now()
        WHERE id = $1`,
      [subscription.institution_id, targetStatus],
    );

    return finish(
      subscription.institution_id,
      { processed: true, skipped: false },
      subscription.id,
    );
  });
}

/**
 * Desfecho de um evento. `pending` = gravado sem `processed_at`: a transação
 * não completou.
 */
export type BillingEventOutcome = "applied" | "ignored" | "duplicate" | "pending";

/**
 * Eventos gravados, para a tela de operação.
 *
 * `institutionId` é obrigatório e sempre aplicado como filtro. Sem ele, a tela
 * de uma IES listaria o estado de cobrança das outras — e `billing_events`
 * guarda o payload inteiro do provedor, que traz nome e valor pago.
 * `null` (só `platform_admin`) vê tudo, porque a Vértice é quem opera as
 * contas.
 *
 * `outcome` traduz três colunas em um rótulo só, decidido aqui e não na UI:
 * a UI não deve reimplementar a regra de o que é "ignorado".
 */
export async function listBillingEvents(opts: {
  institutionId: string | null;
  limit?: number;
  eventType?: string | null;
  outcome?: BillingEventOutcome | null;
}) {
  const limit = Math.min(opts.limit ?? 100, 500);

  const result = await query(
    `SELECT be.id, be.provider, be.event_id, be.event_type, be.institution_id,
            i.name AS institution_name, i.slug AS institution_slug,
            be.occurred_at, be.processed_at, be.skipped_reason, be.error,
            be.created_at,
            CASE
              WHEN be.processed_at IS NULL THEN 'pending'
              WHEN be.skipped_reason = 'evento já processado' THEN 'duplicate'
              WHEN be.skipped_reason IS NOT NULL THEN 'ignored'
              ELSE 'applied'
            END AS outcome
       FROM billing_events be
       LEFT JOIN institutions i ON i.id = be.institution_id
      WHERE ($1::uuid IS NULL OR be.institution_id = $1)
        AND ($2::text IS NULL OR be.event_type = $2)
        AND ($3::text IS NULL OR
             CASE
               WHEN be.processed_at IS NULL THEN 'pending'
               WHEN be.skipped_reason = 'evento já processado' THEN 'duplicate'
               WHEN be.skipped_reason IS NOT NULL THEN 'ignored'
               ELSE 'applied'
             END = $3)
      ORDER BY be.created_at DESC
      LIMIT $4`,
    [opts.institutionId, opts.eventType ?? null, opts.outcome ?? null, limit],
  );

  return result.rows;
}

/**
 * Contagem por desfecho no escopo visível.
 *
 * Existe para o cabeçalho da tela responder "está tudo processando?" sem
 * carregar a lista inteira — o número de eventos cresce com o tempo e a lista
 * é paginada.
 */
export async function billingEventCounts(institutionId: string | null) {
  const result = await query<{
    outcome: string;
    count: string;
    last_at: Date | null;
  }>(
    `SELECT CASE
              WHEN processed_at IS NULL THEN 'pending'
              WHEN skipped_reason = 'evento já processado' THEN 'duplicate'
              WHEN skipped_reason IS NOT NULL THEN 'ignored'
              ELSE 'applied'
            END AS outcome,
            count(*)::text AS count,
            max(created_at) AS last_at
       FROM billing_events
      WHERE ($1::uuid IS NULL OR institution_id = $1)
      GROUP BY 1`,
    [institutionId],
  );

  const counts: Record<string, number> = {
    applied: 0,
    ignored: 0,
    duplicate: 0,
    pending: 0,
  };
  let lastAt: Date | null = null;
  for (const row of result.rows) {
    counts[row.outcome] = Number(row.count);
    if (row.last_at && (!lastAt || row.last_at > lastAt)) lastAt = row.last_at;
  }
  return { counts, lastAt };
}
