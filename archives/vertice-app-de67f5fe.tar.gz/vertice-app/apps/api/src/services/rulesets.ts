import { query } from "../db/pool.js";
import { normalizeRules, pickRuleset, type RiskRules } from "../domain/risk-engine.js";

export interface ResolvedRuleset {
  id: string | null;
  version: number;
  ruleVersion: string;
  rules: RiskRules;
}

interface RulesetRow {
  id: string;
  course_id: string | null;
  version: number;
  attendance_threshold: string;
  attendance_weight: number;
  consecutive_absence_threshold: number;
  consecutive_absence_weight: number;
  low_assessment_weight: number;
  exit_request_weight: number;
}

/**
 * Carrega o ruleset ativo do curso (ou o da instituição, quando não houver
 * regra específica) e devolve já normalizado. Sem linha = defaults de produto.
 */
export async function resolveRuleset(institutionId: string, courseId: string): Promise<ResolvedRuleset> {
  const result = await query<RulesetRow>(
    `SELECT id, course_id, version, attendance_threshold, attendance_weight,
            consecutive_absence_threshold, consecutive_absence_weight,
            low_assessment_weight, exit_request_weight
       FROM rulesets
      WHERE institution_id = $1
        AND status = 'active'
        AND (course_id = $2 OR course_id IS NULL)
      ORDER BY course_id NULLS LAST, version DESC`,
    [institutionId, courseId],
  );

  const rows = result.rows.map((row) => ({ ...row, courseId: row.course_id }));
  const chosen = pickRuleset(rows, courseId);

  if (!chosen) {
    return { id: null, version: 1, ruleVersion: "retention-v1", rules: normalizeRules(null) };
  }

  return {
    id: chosen.id,
    version: chosen.version,
    ruleVersion: `retention-v${chosen.version}`,
    rules: normalizeRules({
      attendanceThreshold: Number(chosen.attendance_threshold),
      attendanceWeight: chosen.attendance_weight,
      consecutiveAbsenceThreshold: chosen.consecutive_absence_threshold,
      consecutiveAbsenceWeight: chosen.consecutive_absence_weight,
      lowAssessmentWeight: chosen.low_assessment_weight,
      exitRequestWeight: chosen.exit_request_weight,
    }),
  };
}

/** Lista o histórico de versões visível ao administrador da IES. */
export async function listRulesets(institutionId: string) {
  const result = await query(
    `SELECT r.*, c.name AS course_name
       FROM rulesets r
       LEFT JOIN courses c ON c.id = r.course_id AND c.institution_id = r.institution_id
      WHERE r.institution_id = $1
      ORDER BY r.created_at DESC`,
    [institutionId],
  );
  return result.rows;
}

/**
 * Publica uma nova versão. Regras nunca são editadas no lugar: uma avaliação
 * já emitida precisa continuar explicável pela versão que a produziu.
 */
export async function createRulesetVersion(
  institutionId: string,
  input: {
    courseId: string | null;
    rules: Partial<RiskRules>;
    createdBy: string;
  },
) {
  const rules = normalizeRules(input.rules);

  const next = await query<{ version: number }>(
    `SELECT COALESCE(MAX(version), 0) + 1 AS version
       FROM rulesets
      WHERE institution_id = $1 AND course_id IS NOT DISTINCT FROM $2`,
    [institutionId, input.courseId],
  );
  const version = next.rows[0]?.version ?? 1;

  // Aposenta a versão anterior e insere a nova na mesma transação lógica.
  await query(
    `UPDATE rulesets SET status = 'retired'
      WHERE institution_id = $1 AND course_id IS NOT DISTINCT FROM $2 AND status = 'active'`,
    [institutionId, input.courseId],
  );

  const inserted = await query(
    `INSERT INTO rulesets (
        institution_id, course_id, version, attendance_threshold, attendance_weight,
        consecutive_absence_threshold, consecutive_absence_weight,
        low_assessment_weight, exit_request_weight, status, created_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'active',$10)
     RETURNING *`,
    [
      institutionId,
      input.courseId,
      version,
      rules.attendanceThreshold,
      rules.attendanceWeight,
      rules.consecutiveAbsenceThreshold,
      rules.consecutiveAbsenceWeight,
      rules.lowAssessmentWeight,
      rules.exitRequestWeight,
      input.createdBy,
    ],
  );

  return inserted.rows[0];
}
