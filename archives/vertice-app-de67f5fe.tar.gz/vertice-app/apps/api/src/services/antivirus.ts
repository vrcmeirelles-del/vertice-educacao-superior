import { createConnection, type Socket } from "node:net";
import { config } from "../config.js";

/**
 * Cliente ClamAV (protocolo INSTREAM).
 *
 * A escolha do ClamAV é por ser auto-hospedável: o arquivo de uma IES não sai
 * para o serviço de terceiro só para ser escaneado. Para volume maior, troque
 * o `scanBuffer` por uma API gerenciada — o contrato de retorno deve continuar
 * o mesmo.
 *
 * Falha é sempre FECHADA: erro de rede, timeout ou resposta inesperada resultam
 * em `failed`, nunca em `clean`.
 */

export type ScanVerdict = "clean" | "infected" | "failed";

export interface ScanResult {
  verdict: ScanVerdict;
  engine: string;
  detail: string;
}

const CHUNK = 64 * 1024;

function scanViaClam(buffer: Buffer): Promise<ScanResult> {
  return new Promise((resolve) => {
    let settled = false;
    let response = "";
    let socket: Socket | null = null;

    const finish = (result: ScanResult) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      socket?.destroy();
      resolve(result);
    };

    const timer = setTimeout(() => {
      finish({
        verdict: "failed",
        engine: "clamav",
        detail: "tempo esgotado ao escanear o arquivo",
      });
    }, config.antivirus.timeoutMs);

    socket = createConnection({
      host: config.antivirus.clamHost,
      port: config.antivirus.clamPort,
    });

    socket.on("error", (error) => {
      finish({ verdict: "failed", engine: "clamav", detail: `conexão falhou: ${error.message}` });
    });

    socket.on("data", (data) => {
      response += data.toString("utf8");
    });

    socket.on("end", () => {
      // O clamd termina a resposta com NUL; `trim()` não remove NUL, então
      // limpamos explicitamente antes de casar o padrão.
      const text = response.replace(/\0/g, "").trim();
      const engine = "clamav";

      if (/\bFOUND$/.test(text)) {
        finish({ verdict: "infected", engine, detail: text.slice(0, 300) });
      } else if (/^stream: OK$/.test(text)) {
        finish({ verdict: "clean", engine, detail: "nenhuma ameaça encontrada" });
      } else {
        finish({
          verdict: "failed",
          engine,
          detail: `resposta inesperada: ${text.slice(0, 200) || "(vazia)"}`,
        });
      }
    });

    socket.on("connect", () => {
      socket!.write("zINSTREAM\0");

      // INSTREAM: cada bloco precedido do tamanho em big-endian, terminado por zero.
      let offset = 0;
      while (offset < buffer.length) {
        const slice = buffer.subarray(offset, offset + CHUNK);
        const size = Buffer.alloc(4);
        size.writeUInt32BE(slice.length, 0);
        socket!.write(size);
        socket!.write(slice);
        offset += slice.length;
      }
      socket!.write(Buffer.alloc(4)); // terminador
    });
  });
}

/**
 * Escaneia um buffer. Quando o antivírus está desligado (só desenvolvimento),
 * devolve `failed` — nunca `clean` — para que a evidência não seja validada
 * sem verificação real.
 */
export async function scanBuffer(buffer: Buffer): Promise<ScanResult> {
  if (config.antivirus.mode === "disabled") {
    return {
      verdict: "failed",
      engine: "disabled",
      detail: "antivírus desabilitado; arquivo não pode ser aprovado",
    };
  }
  return scanViaClam(buffer);
}

/**
 * Health do antivírus: abre e fecha uma conexão. Usado no boot e em /health.
 */
export async function pingAntivirus(): Promise<boolean> {
  if (config.antivirus.mode === "disabled") return false;

  return new Promise((resolve) => {
    const socket = createConnection({
      host: config.antivirus.clamHost,
      port: config.antivirus.clamPort,
    });
    const done = (ok: boolean) => {
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(3000, () => done(false));
    socket.on("connect", () => {
      socket.write("zPING\0");
    });
    socket.on("data", (data) => done(data.toString().includes("PONG")));
    socket.on("error", () => done(false));
  });
}
