import { randomBytes } from "node:crypto";
import type pg from "pg";
import { query, withTransaction, type Queryable } from "../db/pool.js";
import { hashPassword } from "../auth/password.js";
import { sha256 } from "../auth/middleware.js";
import { conflict, forbidden, notFound } from "../http/errors.js";

/**
 * Convite de acesso.
 *
 * O desenho anterior pedia que o administrador digitasse a senha do novo
 * usuário — o que significa que ele a conhecia. Aqui o administrador emite um
 * convite; a pessoa define a própria senha. Só o hash do token é gravado,
 * mesmo padrão de `pairing_tokens`.
 *
 * Não há envio de e-mail neste módulo: a Vértice ainda não tem provedor
 * configurado. O link é devolvido para quem emitiu, que o entrega por canal
 * seguro. Quando o envio entrar, ele pluga em `createInvite` sem mudar o
 * contrato das rotas.
 */

export const INVITE_TTL_HOURS = 72;

export interface InviteInput {
  institutionId: string;
  email: string;
  role: "institution_admin" | "regulatory_manager" | "coordinator" | "auditor_readonly" | "privacy_officer";
  courseScope?: string[];
  expiresAt?: string | null;
  invitedBy: string | null;
}

export interface InviteResult {
  id: string;
  /** Token em claro. Devolvido uma única vez; não é recuperável depois. */
  token: string;
  expiresAt: Date;
}

/**
 * Emite convite e revoga o pendente do mesmo e-mail na mesma instituição.
 *
 * Qualquer administrador — da Vértice ou da IES — pode emitir outro
 * `institution_admin`: uma IES costuma ter mais de um. O que não existe é
 * convite para `platform_admin`, e essa barreira é do banco (CHECK em
 * `user_invites`), não deste código.
 */
export async function createInvite(input: InviteInput, client?: pg.PoolClient): Promise<InviteResult> {
  if (input.role === "auditor_readonly" && !input.expiresAt) {
    throw forbidden("Auditor temporário exige data de expiração de acesso");
  }

  const token = `vtc_inv_${randomBytes(32).toString("base64url")}`;
  const tokenHash = sha256(token);
  const ttlHours = INVITE_TTL_HOURS;

  const run = async (db: Queryable) => {
    await db.query(
      `UPDATE user_invites
          SET revoked_at = now()
        WHERE institution_id = $1
          AND lower(email) = lower($2)
          AND accepted_at IS NULL
          AND revoked_at IS NULL`,
      [input.institutionId, input.email],
    );

    return db.query<{ id: string; expires_at: Date }>(
      `INSERT INTO user_invites
         (institution_id, email, role, course_scope, token_hash, expires_at, invited_by)
       VALUES ($1, lower($2), $3, $4::uuid[], $5, now() + ($6 || ' hours')::interval, $7)
       RETURNING id, expires_at`,
      [
        input.institutionId,
        input.email,
        input.role,
        input.courseScope ?? [],
        tokenHash,
        String(ttlHours),
        input.invitedBy,
      ],
    );
  };

  const result = client ? await run(client) : await withTransaction(run);
  const row = result.rows[0]!;
  return { id: row.id, token, expiresAt: row.expires_at };
}

export interface InvitePreview {
  email: string;
  role: string;
  institutionName: string;
  expiresAt: Date;
}

/** Leitura pública do convite pelo token — só o necessário para a tela. */
export async function previewInvite(token: string): Promise<InvitePreview> {
  const result = await query<{
    email: string;
    role: string;
    institution_name: string;
    expires_at: Date;
  }>(
    `SELECT i.email, i.role, inst.name AS institution_name, i.expires_at
       FROM user_invites i
       JOIN institutions inst ON inst.id = i.institution_id
      WHERE i.token_hash = $1
        AND i.accepted_at IS NULL
        AND i.revoked_at IS NULL
        AND i.expires_at > now()`,
    [sha256(token)],
  );
  const row = result.rows[0];
  if (!row) throw notFound("Convite inválido, expirado ou já utilizado");
  return {
    email: row.email,
    role: row.role,
    institutionName: row.institution_name,
    expiresAt: row.expires_at,
  };
}

/**
 * Aceite: cria (ou reaproveita) o usuário e a membership.
 *
 * Roda em transação com `SELECT ... FOR UPDATE` no convite. Sem o lock, dois
 * cliques no botão criam duas memberships a partir do mesmo token.
 */
export async function acceptInvite(
  token: string,
  password: string,
  name: string,
): Promise<{ userId: string; institutionId: string; role: string }> {
  const passwordHash = await hashPassword(password);
  const tokenHash = sha256(token);

  return withTransaction(async (client) => {
    const found = await client.query<{
      id: string;
      institution_id: string;
      email: string;
      role: string;
      course_scope: string[];
      expires_at: Date;
    }>(
      `SELECT id, institution_id, email, role, course_scope, expires_at
         FROM user_invites
        WHERE token_hash = $1
          AND accepted_at IS NULL
          AND revoked_at IS NULL
        FOR UPDATE`,
      [tokenHash],
    );
    const invite = found.rows[0];
    if (!invite) throw notFound("Convite inválido, expirado ou já utilizado");
    if (invite.expires_at.getTime() <= Date.now()) {
      throw conflict("Convite expirado. Peça um novo ao administrador.");
    }

    const user = await client.query<{ id: string }>(
      `INSERT INTO users (email, name, password_hash)
       VALUES (lower($1), $2, $3)
       ON CONFLICT (email) DO UPDATE SET name = EXCLUDED.name, updated_at = now()
       RETURNING id`,
      [invite.email, name, passwordHash],
    );
    const userId = user.rows[0]!.id;

    // Se o usuário já tinha membership nesta instituição com outro papel,
    // o convite acrescenta a nova — não substitui. Revogar acesso é ação
    // separada, registrada na auditoria.
    await client.query(
      `INSERT INTO memberships (user_id, institution_id, role, course_scope)
       VALUES ($1, $2, $3, $4::uuid[])
       ON CONFLICT (user_id, institution_id, role)
       DO UPDATE SET course_scope = EXCLUDED.course_scope, revoked_at = NULL`,
      [userId, invite.institution_id, invite.role, invite.course_scope],
    );

    await client.query(
      `UPDATE user_invites
          SET accepted_at = now(), accepted_user_id = $2
        WHERE id = $1`,
      [invite.id, userId],
    );

    return { userId, institutionId: invite.institution_id, role: invite.role };
  });
}

/** Lista de convites pendentes — a UI mostra para não emitir duplicado. */
export async function listPendingInvites(institutionId: string) {
  const result = await query(
    `SELECT id, email, role, expires_at, created_at
       FROM user_invites
      WHERE institution_id = $1
        AND accepted_at IS NULL
        AND revoked_at IS NULL
        AND expires_at > now()
      ORDER BY created_at DESC
      LIMIT 100`,
    [institutionId],
  );
  return result.rows;
}

export async function revokeInvite(institutionId: string, inviteId: string): Promise<void> {
  const result = await query(
    `UPDATE user_invites
        SET revoked_at = now()
      WHERE id = $1 AND institution_id = $2
        AND accepted_at IS NULL AND revoked_at IS NULL`,
    [inviteId, institutionId],
  );
  if (!result.rowCount) throw notFound("Convite não encontrado ou já utilizado");
}
