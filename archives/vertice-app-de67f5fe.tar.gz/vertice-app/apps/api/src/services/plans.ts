import { query } from "../db/pool.js";
import { notFound } from "../http/errors.js";
import {
  blockReason,
  canWrite,
  checkQuota,
  effectiveStatus,
  type InstitutionState,
  type PlanLimits,
  type QuotaKey,
} from "../domain/plans.js";

/**
 * Acesso ao estado comercial. Uma instituição pequena gera poucas linhas; a
 * consulta é barata o bastante para rodar por requisição, e é isso que mantém
 * suspensão e cota valendo no mesmo instante em que o webhook chega — sem
 * cache para invalidar e sem esperar expirar.
 */

interface InstitutionRow {
  status: InstitutionState["status"];
  trial_ends_at: Date | null;
  plan_code: string;
}

export async function loadInstitutionState(institutionId: string): Promise<InstitutionState> {
  const result = await query<InstitutionRow>(
    `SELECT status, trial_ends_at, plan_code FROM institutions WHERE id = $1`,
    [institutionId],
  );
  const row = result.rows[0];
  if (!row) throw notFound("Instituição não encontrada");
  return { status: row.status, trialEndsAt: row.trial_ends_at, planCode: row.plan_code };
}

interface PlanRow {
  plan_code: string;
  max_users: number | null;
  max_alerts_month: number | null;
  max_storage_mb: number | null;
  max_batches_day: number | null;
  max_courses: number | null;
  max_batch_records: number | null;
}

export async function loadPlanLimits(planCode: string): Promise<PlanLimits> {
  const result = await query<PlanRow>(
    `SELECT plan_code, max_users, max_alerts_month, max_storage_mb,
            max_batches_day, max_courses, max_batch_records
       FROM plan_limits WHERE plan_code = $1`,
    [planCode],
  );
  const row = result.rows[0];
  if (!row) throw notFound(`Plano desconhecido: ${planCode}`);
  return {
    planCode: row.plan_code,
    maxUsers: row.max_users,
    maxAlertsMonth: row.max_alerts_month,
    maxStorageMb: row.max_storage_mb,
    maxBatchesDay: row.max_batches_day,
    maxCourses: row.max_courses,
    maxBatchRecords: row.max_batch_records,
  };
}

/**
 * Uso corrente de cada cota. Uma consulta só: são contagens por índice, e
 * cinco idas ao banco para desenhar uma tela de plano não se justifica.
 */
export interface Usage {
  users: number;
  alertsMonth: number;
  storageMb: number;
  batchesDay: number;
  courses: number;
}

export async function loadUsage(institutionId: string): Promise<Usage> {
  const result = await query<{
    users: string;
    alerts_month: string;
    storage_bytes: string;
    batches_day: string;
    courses: string;
  }>(
    `SELECT
       -- Assento = pessoa ativa ou convite pendente. Contar só memberships
       -- deixaria convidar ilimitado, porque o assento só passaria a existir
       -- depois do aceite. A UNION por e-mail evita contar duas vezes quem já
       -- tem acesso e recebeu convite para outro papel.
       (SELECT count(*) FROM (
          SELECT lower(u.email) AS email
            FROM memberships m
            JOIN users u ON u.id = m.user_id
           WHERE m.institution_id = $1
             AND m.revoked_at IS NULL
             AND (m.expires_at IS NULL OR m.expires_at > now())
          UNION
          SELECT lower(i.email)
            FROM user_invites i
           WHERE i.institution_id = $1
             AND i.accepted_at IS NULL
             AND i.revoked_at IS NULL
             AND i.expires_at > now()
        ) seats)                                                             AS users,
       (SELECT count(*) FROM alerts a
         WHERE a.institution_id = $1
           AND a.created_at >= date_trunc('month', now()))                   AS alerts_month,
       (SELECT coalesce(sum(d.size_bytes), 0) FROM documents d
         WHERE d.institution_id = $1 AND d.deleted_at IS NULL)               AS storage_bytes,
       (SELECT count(*) FROM ingestion_batches b
         WHERE b.institution_id = $1
           AND b.created_at >= date_trunc('day', now()))                     AS batches_day,
       (SELECT count(*) FROM courses c
         WHERE c.institution_id = $1 AND c.active)                           AS courses`,
    [institutionId],
  );
  const row = result.rows[0]!;
  return {
    users: Number(row.users),
    alertsMonth: Number(row.alerts_month),
    // Arredonda para cima: 1 byte de 1 MB usado já conta como 1 MB.
    storageMb: Math.ceil(Number(row.storage_bytes) / (1024 * 1024)),
    batchesDay: Number(row.batches_day),
    courses: Number(row.courses),
  };
}

const USAGE_KEY: Record<Exclude<QuotaKey, "maxBatchRecords">, keyof Usage> = {
  maxUsers: "users",
  maxAlertsMonth: "alertsMonth",
  maxStorageMb: "storageMb",
  maxBatchesDay: "batchesDay",
  maxCourses: "courses",
};

/**
 * Erro de conta bloqueada. O status 402 e o código `subscription_blocked` são
 * estáveis: a UI troca a tela de erro por um aviso de cobrança quando os vê.
 */
export class SubscriptionBlockedError extends Error {
  readonly statusCode = 402;
  readonly code = "subscription_blocked";
  constructor(
    message: string,
    readonly state: InstitutionState,
  ) {
    super(message);
    this.name = "SubscriptionBlockedError";
  }
}

/**
 * Barreira de escrita: chamada por toda rota que grava dado de cliente.
 *
 * Duas decisões que não são óbvias:
 *  - `platform_admin` passa direto. Ele opera a conta do cliente; suspender a
 *    conta não pode impedir a Vértice de corrigi-la.
 *  - `past_due` escreve. Só `suspended` e trial vencido bloqueiam.
 */
export async function assertInstitutionCanWrite(
  institutionId: string,
  role: string,
): Promise<InstitutionState> {
  const state = await loadInstitutionState(institutionId);
  if (role === "platform_admin") return state;
  if (!canWrite(state)) {
    throw new SubscriptionBlockedError(blockReason(state) ?? "Conta sem permissão de escrita", state);
  }
  return state;
}

/** Verifica uma cota específica contra o uso corrente. */
export async function assertQuota(
  institutionId: string,
  key: QuotaKey,
  incoming = 1,
): Promise<void> {
  const state = await loadInstitutionState(institutionId);
  const limits = await loadPlanLimits(state.planCode);
  if (limits[key] === null) return;

  // `maxBatchRecords` não é contagem acumulada: o uso corrente é zero e o que
  // se compara é o tamanho do lote que está entrando.
  const current = key === "maxBatchRecords" ? 0 : (await loadUsage(institutionId))[USAGE_KEY[key]];
  const problem = checkQuota(limits, key, current, incoming);
  if (problem) throw new SubscriptionBlockedError(problem, state);
}

/** Limite de lotes por dia do plano. Aplicado na rota de ingestão. */
export async function assertBatchQuota(institutionId: string): Promise<void> {
  await assertQuota(institutionId, "maxBatchesDay", 1);
}

/** Resumo para a tela de plano: estado efetivo, limites e uso. */
export async function institutionSummary(institutionId: string) {
  const state = await loadInstitutionState(institutionId);
  const [limits, usage] = await Promise.all([
    loadPlanLimits(state.planCode),
    loadUsage(institutionId),
  ]);
  return {
    status: effectiveStatus(state),
    planCode: state.planCode,
    trialEndsAt: state.trialEndsAt,
    limits,
    usage,
  };
}
