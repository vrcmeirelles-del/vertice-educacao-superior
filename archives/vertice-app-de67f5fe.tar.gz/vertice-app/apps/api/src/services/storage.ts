import {
  DeleteObjectCommand,
  GetObjectCommand,
  HeadObjectCommand,
  PutObjectCommand,
  S3Client,
} from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { config, assertStorageConfigured } from "../config.js";
import { AppError } from "../http/errors.js";

/**
 * Storage de documentos.
 *
 * Decisões:
 *  - bucket privado; nenhuma leitura pública;
 *  - upload e download só por URL pré-assinada de vida curta;
 *  - a chave do objeto não carrega dado pessoal (sem nome, matrícula, CPF);
 *  - o cliente envia o SHA-256 e o servidor confere no HEAD após o upload.
 */

let client: S3Client | null = null;

export function storageConfigured(): boolean {
  const { bucket, accessKeyId, secretAccessKey } = config.storage;
  return Boolean(bucket && accessKeyId && secretAccessKey);
}

function getClient(): S3Client {
  if (client) return client;
  assertStorageConfigured();

  client = new S3Client({
    region: config.storage.region,
    ...(config.storage.endpoint ? { endpoint: config.storage.endpoint } : {}),
    forcePathStyle: config.storage.forcePathStyle,
    credentials: {
      accessKeyId: config.storage.accessKeyId,
      secretAccessKey: config.storage.secretAccessKey,
    },
  });
  return client;
}

/**
 * Chave do objeto: {instituição}/{evidência ou "avulso"}/{uuid}/{nome saneado}.
 * O uuid garante unicidade e o nome só ajuda o humano a reconhecer o arquivo —
 * nunca inclua identificador de estudante aqui.
 */
export function buildStorageKey(params: {
  institutionId: string;
  evidenceId: string | null;
  documentId: string;
  fileName: string;
}): string {
  const safeName = params.fileName
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^A-Za-z0-9._-]/g, "_")
    .slice(-120)
    .replace(/^[._]+/, "");

  return [
    params.institutionId,
    params.evidenceId ?? "avulso",
    params.documentId,
    safeName || "arquivo",
  ].join("/");
}

/** URL pré-assinada de PUT. O corpo vai direto para o bucket. */
export async function presignUpload(params: {
  key: string;
  contentType: string;
  contentLength: number;
  sha256: string;
}): Promise<string> {
  // Removidos ChecksumSHA256 e ChecksumAlgorithm para compatibilidade com
  // Supabase Storage e outros provedores S3 que não exigem esses headers
  // no momento da assinatura. A integridade é verificada no HEAD/complete.
  const command = new PutObjectCommand({
    Bucket: config.storage.bucket,
    Key: params.key,
    ContentType: params.contentType,
    ContentLength: params.contentLength,
  });

  return getSignedUrl(getClient(), command, { expiresIn: config.storage.uploadTtlSeconds });
}

/** URL pré-assinada de GET, sempre curta. */
export async function presignDownload(params: {
  key: string;
  fileName: string;
}): Promise<string> {
  const command = new GetObjectCommand({
    Bucket: config.storage.bucket,
    Key: params.key,
    ResponseContentDisposition: `attachment; filename="${sanitizeForHeader(params.fileName)}"`,
  });

  return getSignedUrl(getClient(), command, { expiresIn: config.storage.downloadTtlSeconds });
}

/**
 * Lê o objeto após o upload. Retorna tamanho e checksum reais do bucket —
 * é assim que sabemos que o cliente enviou o que declarou.
 */
export async function headObject(key: string): Promise<{
  size: number;
  checksumSha256: string | null;
  contentType: string | null;
} | null> {
  try {
    const result = await getClient().send(
      new HeadObjectCommand({ Bucket: config.storage.bucket, Key: key }),
    );
    return {
      size: Number(result.ContentLength ?? 0),
      checksumSha256: result.Metadata?.sha256 ?? result.ChecksumSHA256 ?? null,
      contentType: result.ContentType ?? null,
    };
  } catch (error) {
    const name = (error as { name?: string }).name;
    if (name === "NotFound" || name === "NoSuchKey") return null;
    throw error;
  }
}

/** Remove o objeto. Usado quando o antivírus reprova o arquivo. */
export async function deleteObject(key: string): Promise<void> {
  try {
    await getClient().send(new DeleteObjectCommand({ Bucket: config.storage.bucket, Key: key }));
  } catch (error) {
    console.error("[storage] falha ao remover objeto", { key, error });
  }
}

/** Rejeita nomes com caracteres que quebram o cabeçalho HTTP. */
function sanitizeForHeader(fileName: string): string {
  return fileName.replace(/["\r\n\\]/g, "_").slice(0, 180);
}

/** Valida tipo e tamanho declarados antes de emitir qualquer URL. */
export function assertUploadAcceptable(contentType: string, sizeBytes: number): void {
  if (!config.storage.allowedMimeTypes.includes(contentType)) {
    throw new AppError(
      `Tipo de arquivo não permitido: ${contentType}`,
      415,
      "unsupported_media_type",
      { allowed: config.storage.allowedMimeTypes },
    );
  }
  if (!Number.isInteger(sizeBytes) || sizeBytes <= 0) {
    throw new AppError("Tamanho do arquivo inválido", 400, "invalid_request");
  }
  if (sizeBytes > config.storage.maxFileBytes) {
    throw new AppError(
      `Arquivo excede o limite de ${Math.floor(config.storage.maxFileBytes / 1024 / 1024)} MB`,
      413,
      "payload_too_large",
    );
  }
}
