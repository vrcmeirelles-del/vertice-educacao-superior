import { query, withTransaction } from "../db/pool.js";
import {
  buildCoursePanelRow,
  consolidate,
  findDivergences,
  previousSemester,
  toEnrollmentRow,
  type CoursePanelRow,
  type EnrollmentRow,
} from "../domain/enrollment.js";
import {
  enrollmentRecordSchema,
  validateBatch,
  type BatchOutcome,
  type EnrollmentRecordInput,
} from "../domain/validation.js";

export interface EnrollmentIngestOptions {
  institutionId: string;
  batchId: string;
  receivedBy: string | null;
  actorKind: "user" | "extension";
}

export interface EnrollmentIngestSummary {
  batchId: string;
  total: number;
  accepted: number;
  rejected: number;
  /** Cursos enviados que não existem na instituição. */
  unknownCourses: string[];
  /** Pares curso+semestre gravados. Menor que `accepted` quando há repetição. */
  upserted: number;
  rejections: { index: number; reason: string; field?: string }[];
}

async function loadCourses(institutionId: string, codes: string[]): Promise<Map<string, string>> {
  if (codes.length === 0) return new Map();
  const result = await query<{ id: string; code: string }>(
    `SELECT id, code FROM courses
      WHERE institution_id = $1 AND code = ANY($2::text[])`,
    [institutionId, codes],
  );
  return new Map(result.rows.map((row) => [row.code, row.id]));
}

async function upsertEnrollment(
  client: { query: typeof query },
  institutionId: string,
  batchId: string,
  courseId: string,
  row: EnrollmentRow,
): Promise<void> {
  await client.query(
    `INSERT INTO enrollments (
        institution_id, course_id, batch_id, semester, vagas,
        matriculado, pre_matriculado, trancado, abandono, concluido,
        cancelado, transferido, troca_curso, graduado,
        total_registros, turmas_somadas, turmas, source, observed_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17::jsonb,$18,$19)
     ON CONFLICT (institution_id, course_id, semester) DO UPDATE SET
        batch_id        = EXCLUDED.batch_id,
        vagas           = EXCLUDED.vagas,
        matriculado     = EXCLUDED.matriculado,
        pre_matriculado = EXCLUDED.pre_matriculado,
        trancado        = EXCLUDED.trancado,
        abandono        = EXCLUDED.abandono,
        concluido       = EXCLUDED.concluido,
        cancelado       = EXCLUDED.cancelado,
        transferido     = EXCLUDED.transferido,
        troca_curso     = EXCLUDED.troca_curso,
        graduado        = EXCLUDED.graduado,
        total_registros = EXCLUDED.total_registros,
        turmas_somadas  = EXCLUDED.turmas_somadas,
        turmas          = EXCLUDED.turmas,
        source          = EXCLUDED.source,
        observed_at     = EXCLUDED.observed_at`,
    [
      institutionId,
      courseId,
      batchId,
      row.semester,
      row.vagas,
      row.matriculado,
      row.preMatriculado,
      row.trancado,
      row.abandono,
      row.concluido,
      row.cancelado,
      row.transferido,
      row.trocaCurso,
      row.graduado,
      row.totalRegistros,
      row.turmasSomadas,
      JSON.stringify(row.turmas),
      row.source,
      row.observedAt,
    ],
  );
}

/**
 * Grava um lote de matrícula agregada.
 *
 * Diferente de `ingestBatch`, aqui não existe aluno: nenhuma pseudonimização,
 * nenhum alerta, nenhum ruleset. É contagem por curso e semestre.
 *
 * O lote inteiro vai em uma transação. Um registro com curso desconhecido é
 * descartado e reportado; os demais entram. Não revertemos tudo por causa de um
 * código digitado errado na planilha.
 */
export async function ingestEnrollmentBatch(
  records: unknown[],
  options: EnrollmentIngestOptions,
): Promise<EnrollmentIngestSummary> {
  const outcome: BatchOutcome<EnrollmentRecordInput> = validateBatch(
    records,
    enrollmentRecordSchema,
  );

  const courseCodes = [...new Set(outcome.accepted.map((item) => item.value.courseRef))];
  const courseMap = await loadCourses(options.institutionId, courseCodes);
  const unknownCourses = courseCodes.filter((code) => !courseMap.has(code));

  const resolvidos = outcome.accepted
    .filter((item) => courseMap.has(item.value.courseRef))
    .map((item) => toEnrollmentRow(item.value));

  // Reimportação do mesmo semestre dentro do mesmo lote: a última observação vence.
  const consolidadas = consolidate(resolvidos);

  await withTransaction(async (client) => {
    for (const row of consolidadas) {
      const courseId = courseMap.get(row.courseRef)!;
      await upsertEnrollment(client, options.institutionId, options.batchId, courseId, row);
    }
  });

  return {
    batchId: options.batchId,
    total: records.length,
    accepted: consolidadas.length,
    rejected: outcome.rejected.length + (outcome.accepted.length - resolvidos.length),
    unknownCourses,
    upserted: consolidadas.length,
    rejections: outcome.rejected.slice(0, 50),
  };
}

interface EnrollmentDbRow {
  course_code: string;
  course_name: string;
  campus: string | null;
  semester: string;
  vagas: number;
  matriculado: number;
  pre_matriculado: number;
  trancado: number;
  abandono: number;
  concluido: number;
  cancelado: number;
  transferido: number;
  troca_curso: number;
  graduado: number;
  total_registros: number;
  turmas_somadas: number;
  turmas: { serie: number; turma: string; matriculados: number }[];
  source: string;
  observed_at: Date;
}

function toRow(db: EnrollmentDbRow): EnrollmentRow {
  return {
    courseRef: db.course_code,
    semester: db.semester,
    vagas: db.vagas,
    matriculado: db.matriculado,
    preMatriculado: db.pre_matriculado,
    trancado: db.trancado,
    abandono: db.abandono,
    concluido: db.concluido,
    cancelado: db.cancelado,
    transferido: db.transferido,
    trocaCurso: db.troca_curso,
    graduado: db.graduado,
    totalRegistros: db.total_registros,
    turmasSomadas: db.turmas_somadas,
    turmas: db.turmas ?? [],
    source: db.source,
    observedAt: db.observed_at.toISOString(),
  };
}

export interface CoursePanelResult extends CoursePanelRow {
  courseName: string;
  campus: string | null;
}

/**
 * Painel por curso no semestre pedido, com a comparação contra o anterior.
 *
 * O filtro de instituição é o primeiro argumento da consulta e vem do token,
 * nunca do corpo. Coordenador com escopo restrito recebe `courseIds`.
 */
export async function loadCoursePanel(
  institutionId: string,
  semester: string,
  courseIds?: string[],
): Promise<CoursePanelResult[]> {
  const anterior = previousSemester(semester);
  const parametros: unknown[] = [institutionId, semester, anterior];
  let filtroCurso = "";
  if (courseIds && courseIds.length > 0) {
    parametros.push(courseIds);
    filtroCurso = ` AND c.id = ANY($4::uuid[])`;
  }

  const result = await query<EnrollmentDbRow & { campus: string | null; course_name: string }>(
    `SELECT c.code AS course_code, c.name AS course_name, c.campus,
            e.semester, e.vagas, e.matriculado, e.pre_matriculado, e.trancado,
            e.abandono, e.concluido, e.cancelado, e.transferido, e.troca_curso,
            e.graduado, e.total_registros, e.turmas_somadas, e.turmas,
            e.source, e.observed_at
       FROM enrollments e
       JOIN courses c ON c.id = e.course_id
      WHERE e.institution_id = $1
        AND e.semester = ANY(ARRAY[$2::text, COALESCE($3::text, $2::text)])
        ${filtroCurso}
      ORDER BY c.name`,
    parametros,
  );

  // Agrupa por curso para parear o semestre pedido com o anterior.
  const porCurso = new Map<string, { atual?: EnrollmentRow; anterior?: EnrollmentRow; nome: string; campus: string | null }>();
  for (const db of result.rows) {
    const atual = porCurso.get(db.course_code) ?? {
      nome: db.course_name,
      campus: db.campus,
    };
    if (db.semester === semester) atual.atual = toRow(db);
    else atual.anterior = toRow(db);
    porCurso.set(db.course_code, atual);
  }

  const painel: CoursePanelResult[] = [];
  for (const [code, dados] of porCurso) {
    if (!dados.atual) continue; // sem dado no semestre pedido
    painel.push({
      ...buildCoursePanelRow(dados.atual, dados.anterior ?? null),
      courseName: dados.nome,
      campus: dados.campus,
    });
  }
  return painel;
}

/**
 * Série histórica de um curso. Alimenta o gráfico de tendência sem expor nada
 * além de contagem por semestre.
 */
export async function loadCourseHistory(
  institutionId: string,
  courseCode: string,
  limit = 20,
): Promise<{ semester: string; matriculado: number; turmasComAlunos: number; observedAt: string }[]> {
  const result = await query<{
    semester: string;
    matriculado: number;
    turmas: unknown;
    observed_at: Date;
  }>(
    `SELECT e.semester, e.matriculado, e.turmas, e.observed_at
       FROM enrollments e
       JOIN courses c ON c.id = e.course_id
      WHERE e.institution_id = $1 AND c.code = $2
      ORDER BY e.semester DESC
      LIMIT $3`,
    [institutionId, courseCode, limit],
  );

  return result.rows.map((row) => {
    const turmas = Array.isArray(row.turmas) ? (row.turmas as { serie: number; turma: string }[]) : [];
    return {
      semester: row.semester,
      matriculado: row.matriculado,
      turmasComAlunos: new Set(turmas.map((t) => `${t.serie}|${t.turma}`)).size,
      observedAt: row.observed_at.toISOString(),
    };
  });
}

/** Divergências registradas no último lote do semestre. Usado pelo painel. */
export function divergencesFor(row: EnrollmentRow) {
  return findDivergences(row);
}
