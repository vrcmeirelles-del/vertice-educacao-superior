import type { PoolClient } from "pg";
import { withTransaction } from "../db/pool.js";
import { hashStudentRef } from "../domain/pseudonymize.js";
import { evaluateRisk } from "../domain/risk-engine.js";
import { validateBatch, type BatchOutcome, type RetentionRecordInput } from "../domain/validation.js";
import { retentionRecordSchema } from "../domain/validation.js";
import { resolveRuleset } from "./rulesets.js";

export interface IngestOptions {
  institutionId: string;
  source: string;
  batchId: string;
  receivedBy: string | null;
  actorKind: "user" | "extension";
}

export interface IngestSummary {
  batchId: string;
  total: number;
  accepted: number;
  rejected: number;
  alertsCreated: number;
  rejections: { index: number; reason: string; field?: string }[];
  /** Cursos enviados no lote que não existem na instituição. */
  unknownCourses: string[];
}

/**
 * Processa um lote de ingestão: valida, resolve o curso, aplica o ruleset
 * vigente, grava o registro e cria/atualiza o alerta — tudo em uma transação
 * por lote. Um registro inválido não derruba os demais.
 */
export async function ingestBatch(
  records: unknown[],
  options: IngestOptions,
): Promise<IngestSummary> {
  const outcome: BatchOutcome<RetentionRecordInput> = validateBatch(records, retentionRecordSchema);

  const courseCodes = [...new Set(outcome.accepted.map((item) => item.value.courseRef))];
  const courseMap = await loadCourses(options.institutionId, courseCodes);
  const unknownCourses = courseCodes.filter((code) => !courseMap.has(code));

  let alertsCreated = 0;
  const acceptedForCourse = outcome.accepted.filter((item) => courseMap.has(item.value.courseRef));

  await withTransaction(async (client) => {
    // Rulesets são lidos uma vez por curso dentro da transação.
    const rulesByCourse = new Map<string, Awaited<ReturnType<typeof resolveRuleset>>>();

    for (const { value } of acceptedForCourse) {
      const course = courseMap.get(value.courseRef)!;

      let resolved = rulesByCourse.get(course.id);
      if (!resolved) {
        resolved = await resolveRuleset(options.institutionId, course.id);
        rulesByCourse.set(course.id, resolved);
      }

      const recordId = await insertRecord(client, options, course.id, value);
      if (!recordId) continue; // duplicata exata (mesmo observedAt)

      const risk = evaluateRisk(
        {
          attendancePercent: value.attendancePercent ?? null,
          consecutiveAbsences: value.consecutiveAbsences ?? null,
          assessmentAverage: value.assessmentAverage ?? null,
          passingAverage: value.passingAverage ?? null,
          openRequests: value.openRequests ?? [],
        },
        resolved.rules,
        resolved.ruleVersion,
      );

      const created = await upsertAlert(client, {
        institutionId: options.institutionId,
        courseId: course.id,
        recordId,
        rulesetId: resolved.id,
        risk,
        actorId: options.receivedBy,
      });
      if (created) alertsCreated += 1;
    }

    await client.query(
      `UPDATE ingestion_batches
          SET status = $2,
              accepted_records = $3,
              rejected_records = $4,
              rejection_reason = $5,
              processed_at = now()
        WHERE id = $1 AND institution_id = $6`,
      [
        options.batchId,
        acceptedForCourse.length > 0 ? "processed" : "rejected",
        acceptedForCourse.length,
        records.length - acceptedForCourse.length,
        outcome.rejected.length
          ? outcome.rejected.slice(0, 50).map((r) => `[${r.index}] ${r.reason}`).join("; ")
          : null,
        options.institutionId,
      ],
    );
  });

  return {
    batchId: options.batchId,
    total: records.length,
    accepted: acceptedForCourse.length,
    rejected: records.length - acceptedForCourse.length,
    alertsCreated,
    rejections: outcome.rejected,
    unknownCourses,
  };
}

async function loadCourses(institutionId: string, codes: string[]) {
  const map = new Map<string, { id: string; code: string }>();
  if (codes.length === 0) return map;

  const { query } = await import("../db/pool.js");
  const result = await query<{ id: string; code: string }>(
    `SELECT id, code FROM courses
      WHERE institution_id = $1 AND code = ANY($2::text[])`,
    [institutionId, codes],
  );
  for (const row of result.rows) map.set(row.code, row);
  return map;
}

async function insertRecord(
  client: PoolClient,
  options: IngestOptions,
  courseId: string,
  value: RetentionRecordInput,
): Promise<string | null> {
  const result = await client.query<{ id: string }>(
    `INSERT INTO retention_records (
        institution_id, batch_id, course_id, student_ref_hash,
        attendance_percent, consecutive_absences, assessment_average,
        passing_average, open_requests, observed_at, source)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
     ON CONFLICT (institution_id, student_ref_hash, course_id, observed_at) DO NOTHING
     RETURNING id`,
    [
      options.institutionId,
      options.batchId,
      courseId,
      hashStudentRef(value.studentRef),
      value.attendancePercent ?? null,
      value.consecutiveAbsences ?? null,
      value.assessmentAverage ?? null,
      value.passingAverage ?? null,
      value.openRequests ?? [],
      value.observedAt,
      value.source,
    ],
  );
  return result.rows[0]?.id ?? null;
}

async function upsertAlert(
  client: PoolClient,
  input: {
    institutionId: string;
    courseId: string;
    recordId: string;
    rulesetId: string | null;
    risk: ReturnType<typeof evaluateRisk>;
    actorId: string | null;
  },
): Promise<boolean> {
  const { risk } = input;

  // Alerta de escore zero não polui a fila do coordenador.
  if (risk.score === 0) return false;

  const inserted = await client.query<{ id: string }>(
    `INSERT INTO alerts (
        institution_id, course_id, record_id, score, level, factors,
        ruleset_id, rule_version, review_required, recommended_action, automated_decision)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,NULL)
     ON CONFLICT (record_id) DO NOTHING
     RETURNING id`,
    [
      input.institutionId,
      input.courseId,
      input.recordId,
      risk.score,
      risk.level,
      JSON.stringify(risk.factors),
      input.rulesetId,
      risk.ruleVersion,
      risk.reviewRequired,
      risk.recommendedAction,
    ],
  );

  const alertId = inserted.rows[0]?.id;
  if (!alertId) return false;

  await client.query(
    `INSERT INTO alert_events (institution_id, alert_id, actor_id, type, outcome)
     VALUES ($1,$2,$3,'created',$4)`,
    [input.institutionId, alertId, input.actorId, risk.level],
  );

  return true;
}
