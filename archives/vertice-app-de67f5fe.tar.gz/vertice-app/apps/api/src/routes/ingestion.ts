import type { FastifyInstance } from "fastify";
import { createHash } from "node:crypto";
import { query } from "../db/pool.js";
import { config } from "../config.js";
import { requireRole, requireTenant, canWrite } from "../auth/middleware.js";
import { audit } from "../http/audit.js";
import { badRequest, forbidden } from "../http/errors.js";
import { detectForbiddenFields, ingestionBatchSchema, retentionRecordSchema } from "../domain/validation.js";
import { evaluateRisk, normalizeRules } from "../domain/risk-engine.js";
import { ingestBatch } from "../services/ingestion.js";
import { resolveRuleset } from "../services/rulesets.js";
import { assertBatchQuota, assertInstitutionCanWrite, assertQuota } from "../services/plans.js";

const WRITE_ROLES = ["platform_admin", "institution_admin", "regulatory_manager", "coordinator"] as const;

export async function ingestionRoutes(app: FastifyInstance): Promise<void> {
  /**
   * Avaliação avulsa, sem persistência. Serve para o desenvolvedor validar o
   * contrato e para a extensão testar um adaptador antes de importar.
   */
  app.post("/v1/risk/evaluate", async (request, reply) => {
    const claims = await requireRole(request, ...WRITE_ROLES);
    const institutionId = requireTenant(request);

    const forbiddenFields = detectForbiddenFields(request.body);
    if (forbiddenFields.length) {
      await audit(request, {
        institutionId,
        actorId: claims.sub,
        action: "risk.evaluate",
        resourceType: "retention_record",
        outcome: "denied",
        metadata: { forbiddenFields },
      });
      throw badRequest(
        `A requisição contém campos proibidos: ${forbiddenFields.join(", ")}`,
        { forbiddenFields },
      );
    }

    const parsed = retentionRecordSchema.safeParse(request.body);
    if (!parsed.success) {
      const issue = parsed.error.issues[0];
      throw badRequest(issue?.message ?? "Registro inválido", {
        field: issue?.path.join("."),
      });
    }

    const course = await query<{ id: string }>(
      "SELECT id FROM courses WHERE institution_id = $1 AND code = $2",
      [institutionId, parsed.data.courseRef],
    );
    const courseId = course.rows[0]?.id;
    if (!courseId) throw badRequest(`Curso não encontrado: ${parsed.data.courseRef}`);

    const resolved = await resolveRuleset(institutionId, courseId);
    const risk = evaluateRisk(
      {
        attendancePercent: parsed.data.attendancePercent ?? null,
        consecutiveAbsences: parsed.data.consecutiveAbsences ?? null,
        assessmentAverage: parsed.data.assessmentAverage ?? null,
        passingAverage: parsed.data.passingAverage ?? null,
        openRequests: parsed.data.openRequests ?? [],
      },
      resolved.rules,
      resolved.ruleVersion,
    );

    return reply.send({
      recordRef: parsed.data.studentRef,
      courseRef: parsed.data.courseRef,
      observedAt: parsed.data.observedAt,
      source: parsed.data.source,
      risk,
    });
  });

  /** Importação de lote (CSV→JSON feito pelo cliente ou pela extensão). */
  app.post("/v1/ingestions", async (request, reply) => {
    const claims = await requireRole(request, ...WRITE_ROLES);
    const institutionId = requireTenant(request);

    if (!canWrite(claims.role)) throw forbidden();
    await assertInstitutionCanWrite(institutionId, claims.role);

    const forbiddenFields = detectForbiddenFields(request.body);
    if (forbiddenFields.length) {
      await audit(request, {
        institutionId,
        actorId: claims.sub,
        action: "ingestion.create",
        resourceType: "ingestion_batch",
        outcome: "denied",
        metadata: { forbiddenFields },
      });
      throw badRequest(
        `A requisição contém campos proibidos: ${forbiddenFields.join(", ")}`,
        { forbiddenFields },
      );
    }

    const parsed = ingestionBatchSchema.safeParse(request.body);
    if (!parsed.success) {
      const issue = parsed.error.issues[0];
      throw badRequest(issue?.message ?? "Lote inválido", { field: issue?.path.join(".") });
    }
    // Teto absoluto do processo: protege a API de um lote que derrubaria memória,
    // independente do plano. Vale antes de qualquer consulta ao banco.
    if (parsed.data.records.length > config.maxBatchRecords) {
      throw badRequest(`Lote excede ${config.maxBatchRecords} registros`);
    }

    // Depois, a cota do plano: quantos registros por lote e quantos lotes por dia.
    await assertQuota(institutionId, "maxBatchRecords", parsed.data.records.length);
    await assertBatchQuota(institutionId);

    const batch = await query<{ id: string }>(
      `INSERT INTO ingestion_batches (institution_id, status, source, received_by, total_records)
       VALUES ($1,'received',$2,$3,$4) RETURNING id`,
      [institutionId, "panel", claims.sub, parsed.data.records.length],
    );
    const batchId = batch.rows[0]!.id;

    const summary = await ingestBatch(parsed.data.records, {
      institutionId,
      source: "panel",
      batchId,
      receivedBy: claims.sub,
      actorKind: "user",
    });

    await audit(request, {
      institutionId,
      actorId: claims.sub,
      action: "ingestion.create",
      resourceType: "ingestion_batch",
      resourceId: batchId,
      metadata: {
        total: summary.total,
        accepted: summary.accepted,
        rejected: summary.rejected,
        alertsCreated: summary.alertsCreated,
      },
    });

    return reply.status(202).send(summary);
  });

  /** Ingestão pela extensão, autenticada por token de pareamento. */
  app.post("/v1/ingestions/extension", async (request, reply) => {
    const header = request.headers.authorization ?? "";
    const [scheme, token] = header.split(" ");
    if (scheme !== "Bearer" || !token) throw forbidden("Token de pareamento ausente");

    const tokenHash = createHash("sha256").update(token).digest("hex");
    const pairing = await query<{ id: string; institution_id: string }>(
      `SELECT id, institution_id FROM pairing_tokens
        WHERE token_hash = $1
          AND revoked_at IS NULL
          AND expires_at > now()`,
      [tokenHash],
    );
    const row = pairing.rows[0];
    if (!row) throw forbidden("Token de pareamento inválido ou expirado");

    const forbiddenFields = detectForbiddenFields(request.body);
    if (forbiddenFields.length) {
      throw badRequest(`A requisição contém campos proibidos: ${forbiddenFields.join(", ")}`, {
        forbiddenFields,
      });
    }

    const parsed = ingestionBatchSchema.safeParse(request.body);
    if (!parsed.success) {
      throw badRequest(parsed.error.issues[0]?.message ?? "Lote inválido");
    }

    const institutionId = row.institution_id;
    const batch = await query<{ id: string }>(
      `INSERT INTO ingestion_batches (institution_id, status, source, received_by, total_records)
       VALUES ($1,'received',$2,NULL,$3) RETURNING id`,
      [institutionId, `extension:${request.ip}`, parsed.data.records.length],
    );
    const batchId = batch.rows[0]!.id;

    const summary = await ingestBatch(parsed.data.records, {
      institutionId,
      source: "extension",
      batchId,
      receivedBy: null,
      actorKind: "extension",
    });

    await query("UPDATE pairing_tokens SET last_used_at = now() WHERE id = $1", [row.id]);
    await audit(request, {
      institutionId,
      actorId: null,
      actorKind: "extension",
      action: "ingestion.create",
      resourceType: "ingestion_batch",
      resourceId: batchId,
      metadata: { accepted: summary.accepted, rejected: summary.rejected },
    });

    return reply.status(202).send({
      accepted: summary.accepted,
      processed: summary.accepted,
      rejected: summary.rejected,
      alertsCreated: summary.alertsCreated,
      rejections: summary.rejections.slice(0, 20),
      unknownCourses: summary.unknownCourses,
    });
  });

  app.get("/v1/ingestions", async (request, reply) => {
    const claims = await requireRole(request, ...WRITE_ROLES);
    const institutionId = requireTenant(request);
    const limit = Math.min(Number((request.query as Record<string, string>).limit ?? 50), 200);

    const batches = await query(
      `SELECT id, status, source, total_records, accepted_records, rejected_records,
              rejection_reason, created_at, processed_at
         FROM ingestion_batches
        WHERE institution_id = $1
        ORDER BY created_at DESC
        LIMIT $2`,
      [institutionId, limit],
    );

    return reply.send({ batches: batches.rows, requestedBy: claims.email });
  });
}
