import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { query } from "../db/pool.js";
import { verifyPassword } from "../auth/password.js";
import { newSessionId, signSession, type Role } from "../auth/tokens.js";
import { requireUser } from "../auth/middleware.js";
import { audit } from "../http/audit.js";
import { AppError, badRequest, unauthorized } from "../http/errors.js";
import { acceptInvite, previewInvite } from "../services/invites.js";

const loginSchema = z
  .object({
    email: z.string().email().max(320),
    password: z.string().min(8).max(200),
    institutionSlug: z.string().min(2).max(63).optional(),
  })
  .strict();

interface LoginRow {
  user_id: string;
  email: string;
  name: string;
  password_hash: string;
  institution_id: string | null;
  role: Role;
  course_scope: string[];
  expires_at: Date | null;
}

export async function authRoutes(app: FastifyInstance): Promise<void> {
  app.post(
    "/v1/auth/login",
    {
      config: { rateLimit: { max: 10, timeWindow: "1 minute" } },
    },
    async (request, reply) => {
      const parsed = loginSchema.safeParse(request.body);
      if (!parsed.success) throw badRequest("Credenciais em formato inválido");
      const { email, password, institutionSlug } = parsed.data;

      const result = await query<LoginRow>(
        `SELECT u.id AS user_id, u.email, u.name, u.password_hash,
                m.institution_id, m.role, m.course_scope, m.expires_at
           FROM users u
           JOIN memberships m ON m.user_id = u.id
           LEFT JOIN institutions i ON i.id = m.institution_id
          WHERE lower(u.email) = lower($1)
            AND u.is_active
            AND m.revoked_at IS NULL
            AND ($2::text IS NULL OR m.institution_id IS NULL OR i.slug = $2)
          ORDER BY m.institution_id NULLS LAST
          LIMIT 1`,
        [email, institutionSlug ?? null],
      );

      const row = result.rows[0];

      // Verificação sempre executada para não revelar existência de e-mail.
      const dummyHash =
        "scrypt$32768$8$1$AAAAAAAAAAAAAAAAAAAAAA==$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==";
      const valid = await verifyPassword(password, row?.password_hash ?? dummyHash);

      if (!row || !valid) {
        await audit(request, {
          institutionId: null,
          actorId: null,
          action: "auth.login",
          resourceType: "session",
          outcome: "denied",
          metadata: { emailDomain: email.split("@")[1] ?? "unknown" },
        });
        throw unauthorized("Credenciais inválidas");
      }

      if (row.expires_at && row.expires_at.getTime() < Date.now()) {
        throw new AppError("Acesso temporário expirado", 403, "forbidden");
      }

      const claims = {
        sub: row.user_id,
        jti: newSessionId(),
        email: row.email,
        name: row.name,
        institutionId: row.institution_id,
        role: row.role,
        courseScope: row.course_scope ?? [],
      };

      const token = await signSession(claims);
      await query("UPDATE users SET last_login_at = now() WHERE id = $1", [row.user_id]);
      await audit(request, {
        institutionId: row.institution_id,
        actorId: row.user_id,
        action: "auth.login",
        resourceType: "session",
        metadata: { role: row.role },
      });

      return reply.send({
        token,
        user: {
          id: row.user_id,
          name: row.name,
          email: row.email,
          institutionId: row.institution_id,
          role: row.role,
          courseScope: claims.courseScope,
        },
      });
    },
  );

  // -------------------------------------------------------------------------
  // Convite — rotas públicas, autenticadas pelo próprio token do convite.
  // -------------------------------------------------------------------------

  app.get("/v1/auth/invite", async (request, reply) => {
    const token = (request.query as Record<string, string>).token ?? "";
    if (!token) throw badRequest("Token do convite ausente");
    return reply.send(await previewInvite(token));
  });

  app.post(
    "/v1/auth/invite/accept",
    { config: { rateLimit: { max: 10, timeWindow: "1 minute" } } },
    async (request, reply) => {
      const parsed = z
        .object({
          token: z.string().min(20).max(200),
          name: z.string().min(3).max(200),
          // Mesma regra do cadastro administrativo: 12 caracteres no mínimo.
          password: z.string().min(12).max(200),
        })
        .strict()
        .safeParse(request.body);
      if (!parsed.success) throw badRequest(parsed.error.issues[0]?.message ?? "Corpo inválido");

      const accepted = await acceptInvite(parsed.data.token, parsed.data.password, parsed.data.name);

      await audit(request, {
        institutionId: accepted.institutionId,
        actorId: accepted.userId,
        action: "user.invite_accepted",
        resourceType: "user",
        resourceId: accepted.userId,
        metadata: { role: accepted.role },
      });

      // Não devolve e-mail nem nome: o cliente acabou de informá-los e
      // repetir identificador na resposta só aumenta onde ele aparece.
      return reply.status(201).send({
        institutionId: accepted.institutionId,
        role: accepted.role,
      });
    },
  );

  app.get("/v1/auth/me", async (request, reply) => {
    const claims = await requireUser(request);
    return reply.send({
      id: claims.sub,
      email: claims.email,
      name: claims.name,
      institutionId: claims.institutionId,
      role: claims.role,
      courseScope: claims.courseScope,
    });
  });

  app.post("/v1/auth/logout", async (request, reply) => {
    const claims = await requireUser(request);
    await query(
      `INSERT INTO revoked_sessions (jti, user_id, reason)
       VALUES ($1,$2,'logout') ON CONFLICT (jti) DO NOTHING`,
      [claims.jti, claims.sub],
    );
    await audit(request, {
      institutionId: claims.institutionId,
      actorId: claims.sub,
      action: "auth.logout",
      resourceType: "session",
    });
    return reply.send({ ok: true });
  });
}
