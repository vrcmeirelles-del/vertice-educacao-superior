import type { FastifyInstance } from "fastify";
import { createHash } from "node:crypto";
import { query } from "../db/pool.js";
import { requireRole, requireTenant, requireUser, canWrite } from "../auth/middleware.js";
import { audit } from "../http/audit.js";
import { badRequest, forbidden, notFound } from "../http/errors.js";
import {
  detectForbiddenFields,
  detectStudentLevelFields,
  enrollmentEnvelopeSchema,
} from "../domain/validation.js";
import { ingestEnrollmentBatch, loadCourseHistory, loadCoursePanel } from "../services/enrollment.js";
import { assertBatchQuota, assertInstitutionCanWrite, assertQuota } from "../services/plans.js";

const WRITE_ROLES = ["platform_admin", "institution_admin", "regulatory_manager", "coordinator"] as const;
const READ_ROLES = [
  "platform_admin",
  "institution_admin",
  "regulatory_manager",
  "coordinator",
  "auditor_readonly",
  "privacy_officer",
] as const;

const SEMESTER = /^[0-9]{4}\/(0[12])$/;

function semesterParam(raw: unknown): string {
  const value = String(raw ?? "");
  if (!SEMESTER.test(value)) throw badRequest("semestre deve ser AAAA/01 ou AAAA/02 (ex.: 2026/02)");
  return value;
}

/**
 * Matrícula agregada por curso.
 *
 * Contrato separado do de retenção de propósito. Aqui não trafega identificador
 * de estudante; se trafegar, o lote é recusado inteiro — quem colou a planilha
 * de aluno na tela de matrícula precisa saber que errou, não receber um sucesso
 * com 90% de dado descartado.
 */
export async function enrollmentRoutes(app: FastifyInstance): Promise<void> {
  /** Importação de lote (CSV→JSON feito pelo painel ou pela extensão). */
  app.post("/v1/enrollments", async (request, reply) => {
    const claims = await requireRole(request, ...WRITE_ROLES);
    const institutionId = requireTenant(request);

    if (!canWrite(claims.role)) throw forbidden();
    await assertInstitutionCanWrite(institutionId, claims.role);

    const forbiddenFields = detectForbiddenFields(request.body);
    if (forbiddenFields.length) {
      await audit(request, {
        institutionId,
        actorId: claims.sub,
        action: "enrollment.create",
        resourceType: "enrollment_batch",
        outcome: "denied",
        metadata: { forbiddenFields },
      });
      throw badRequest(
        `A requisição contém campos proibidos: ${forbiddenFields.join(", ")}`,
        { forbiddenFields },
      );
    }

    const studentFields = detectStudentLevelFields(request.body);
    if (studentFields.length) {
      throw badRequest(
        "Este lote é de matrícula agregada e não aceita campo por aluno. " +
          "Campos recusados: " +
          studentFields.join(", ") +
          ". Use /v1/ingestions para dados de aluno.",
        { studentFields },
      );
    }

    // Envelope só: a conferência de cada registro acontece no serviço, que
    // aceita os válidos e devolve o motivo dos rejeitados. Assim uma célula mal
    // formatada nas 840 linhas da planilha não derruba o lote inteiro.
    const parsed = enrollmentEnvelopeSchema.safeParse(request.body);
    if (!parsed.success) {
      const issue = parsed.error.issues[0];
      throw badRequest(issue?.message ?? "Lote inválido", { field: issue?.path.join(".") });
    }

    await assertQuota(institutionId, "maxBatchRecords", parsed.data.records.length);
    await assertBatchQuota(institutionId);

    const batch = await query<{ id: string }>(
      `INSERT INTO ingestion_batches (institution_id, status, source, received_by, total_records)
       VALUES ($1,'received','enrollment',$2,$3) RETURNING id`,
      [institutionId, claims.sub, parsed.data.records.length],
    );
    const batchId = batch.rows[0]!.id;

    const summary = await ingestEnrollmentBatch(parsed.data.records, {
      institutionId,
      batchId,
      receivedBy: claims.sub,
      actorKind: "user",
    });

    await query(
      `UPDATE ingestion_batches
          SET status = 'processed',
              accepted_records = $2,
              rejected_records = $3,
              processed_at = now()
        WHERE id = $1`,
      [batchId, summary.accepted, summary.rejected],
    );

    await audit(request, {
      institutionId,
      actorId: claims.sub,
      action: "enrollment.create",
      resourceType: "enrollment_batch",
      resourceId: batchId,
      metadata: {
        total: summary.total,
        accepted: summary.accepted,
        rejected: summary.rejected,
        upserted: summary.upserted,
        unknownCourses: summary.unknownCourses.slice(0, 20),
      },
    });

    return reply.status(202).send(summary);
  });

  /**
   * Ingestão pela extensão. Token de pareamento, como em `/v1/ingestions/extension`.
   * A extensão lê a tela do e-ORBIT e manda o agregado; nada de aluno passa por aqui.
   */
  app.post("/v1/enrollments/extension", async (request, reply) => {
    const header = request.headers.authorization ?? "";
    const [scheme, token] = header.split(" ");
    if (scheme !== "Bearer" || !token) throw forbidden("Token de pareamento ausente");

    const tokenHash = createHash("sha256").update(token).digest("hex");
    const pairing = await query<{ id: string; institution_id: string }>(
      `SELECT id, institution_id FROM pairing_tokens
        WHERE token_hash = $1 AND revoked_at IS NULL AND expires_at > now()`,
      [tokenHash],
    );
    const row = pairing.rows[0];
    if (!row) throw forbidden("Token de pareamento inválido ou expirado");

    const forbiddenFields = detectForbiddenFields(request.body);
    if (forbiddenFields.length) {
      throw badRequest(`A requisição contém campos proibidos: ${forbiddenFields.join(", ")}`, {
        forbiddenFields,
      });
    }

    const studentFields = detectStudentLevelFields(request.body);
    if (studentFields.length) {
      throw badRequest(
        "Lote de matrícula agregada não aceita campo por aluno: " + studentFields.join(", "),
        { studentFields },
      );
    }

    const parsed = enrollmentEnvelopeSchema.safeParse(request.body);
    if (!parsed.success) {
      throw badRequest(parsed.error.issues[0]?.message ?? "Lote inválido");
    }

    const institutionId = row.institution_id;
    const batch = await query<{ id: string }>(
      `INSERT INTO ingestion_batches (institution_id, status, source, received_by, total_records)
       VALUES ($1,'received','extension',$2,$3) RETURNING id`,
      [institutionId, `extension:enrollment:${request.ip}`, parsed.data.records.length],
    );
    const batchId = batch.rows[0]!.id;

    const summary = await ingestEnrollmentBatch(parsed.data.records, {
      institutionId,
      batchId,
      receivedBy: null,
      actorKind: "extension",
    });

    await query(
      `UPDATE ingestion_batches
          SET status = 'processed', accepted_records = $2, rejected_records = $3, processed_at = now()
        WHERE id = $1`,
      [batchId, summary.accepted, summary.rejected],
    );
    await query("UPDATE pairing_tokens SET last_used_at = now() WHERE id = $1", [row.id]);
    await audit(request, {
      institutionId,
      actorId: null,
      actorKind: "extension",
      action: "enrollment.create",
      resourceType: "enrollment_batch",
      resourceId: batchId,
      metadata: { accepted: summary.accepted, rejected: summary.rejected },
    });

    return reply.status(202).send({
      accepted: summary.accepted,
      upserted: summary.upserted,
      rejected: summary.rejected,
      rejections: summary.rejections.slice(0, 20),
      unknownCourses: summary.unknownCourses,
    });
  });

  /**
   * Painel: matrícula por curso no semestre, com variação contra o anterior e
   * quantas turmas têm aluno. É a tela que a planilha alimenta.
   *
   * Sem parâmetro de semestre, devolve o mais recente que a instituição tem.
   */
  app.get("/v1/enrollments/panel", async (request, reply) => {
    const claims = await requireRole(request, ...READ_ROLES);
    const institutionId = requireTenant(request);
    const q = request.query as Record<string, string>;

    let semester = q.semester;
    if (!semester) {
      const latest = await query<{ semester: string }>(
        "SELECT semester FROM enrollments WHERE institution_id = $1 ORDER BY semester DESC LIMIT 1",
        [institutionId],
      );
      semester = latest.rows[0]?.semester;
      if (!semester) return reply.send({ semester: null, courses: [], totals: null });
    } else {
      semester = semesterParam(semester);
    }

    // Coordenador com escopo restrito só vê os próprios cursos — filtro no SQL.
    let courseIds: string[] | undefined;
    if (claims.role === "coordinator" && claims.courseScope.length > 0) {
      courseIds = claims.courseScope;
    }

    const courses = await loadCoursePanel(institutionId, semester, courseIds);

    const totals = courses.reduce(
      (acc, c) => ({
        matriculado: acc.matriculado + c.matriculado,
        previous: acc.previous + (c.previousMatriculado ?? 0),
        classes: acc.classes + c.classesWithStudents,
      }),
      { matriculado: 0, previous: 0, classes: 0 },
    );

    return reply.send({
      semester,
      previousSemester: courses[0]?.change.previous ?? null,
      courses,
      totals: {
        ...totals,
        change:
          totals.previous === 0 ? null : (totals.matriculado - totals.previous) / totals.previous,
        coursesWithStudents: courses.filter((c) => c.matriculado > 0).length,
        pendingReview: courses.filter((c) => c.decision.verdict === "review").length,
      },
    });
  });

  /** Série histórica de um curso. */
  app.get("/v1/enrollments/history", async (request, reply) => {
    await requireUser(request);
    await requireRole(request, ...READ_ROLES);
    const institutionId = requireTenant(request);
    const q = request.query as Record<string, string>;

    const courseRef = String(q.courseRef ?? "").trim();
    if (!courseRef) throw badRequest("courseRef é obrigatório");

    const exists = await query("SELECT 1 FROM courses WHERE institution_id = $1 AND code = $2", [
      institutionId,
      courseRef,
    ]);
    if (!exists.rowCount) throw notFound(`Curso não encontrado: ${courseRef}`);

    const limit = Math.min(Number(q.limit ?? 20), 40);
    return reply.send({
      courseRef,
      semesters: await loadCourseHistory(institutionId, courseRef, limit),
    });
  });

  /** Lotes de matrícula, para a aba de importação. */
  app.get("/v1/enrollments/batches", async (request, reply) => {
    await requireRole(request, ...READ_ROLES);
    const institutionId = requireTenant(request);
    const limit = Math.min(Number((request.query as Record<string, string>).limit ?? 50), 200);

    const batches = await query(
      `SELECT id, status, source, total_records, accepted_records, rejected_records,
              created_at, processed_at
         FROM ingestion_batches
        WHERE institution_id = $1 AND source = 'enrollment'
        ORDER BY created_at DESC
        LIMIT $2`,
      [institutionId, limit],
    );

    return reply.send({ batches: batches.rows });
  });
}
