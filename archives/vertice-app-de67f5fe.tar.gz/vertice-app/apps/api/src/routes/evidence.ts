import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { withTransaction, query } from "../db/pool.js";
import { canWrite, requireRole, requireTenant } from "../auth/middleware.js";
import { audit } from "../http/audit.js";
import { badRequest, conflict, forbidden, notFound } from "../http/errors.js";

const READ_ROLES = ["platform_admin", "institution_admin", "regulatory_manager", "coordinator", "auditor_readonly"] as const;
const WRITE_ROLES = ["platform_admin", "institution_admin", "regulatory_manager"] as const;

const createSchema = z
  .object({
    courseId: z.string().uuid().nullable().optional(),
    instrumentId: z.string().uuid(),
    requirementId: z.string().uuid(),
    ownerId: z.string().uuid().nullable().optional(),
    dueDate: z.string().date().optional(),
    validUntil: z.string().date().optional(),
  })
  .strict();

const transitionSchema = z
  .object({
    status: z.enum(["pending", "in_review", "validated", "changes_requested", "expired", "not_applicable"]),
    opinion: z.string().max(4000).optional(),
  })
  .strict();

const ALLOWED: Record<string, string[]> = {
  pending: ["in_review", "not_applicable"],
  in_review: ["validated", "changes_requested", "not_applicable"],
  changes_requested: ["in_review", "pending"],
  validated: ["expired", "in_review"],
  expired: ["in_review"],
  not_applicable: ["pending"],
};

export async function evidenceRoutes(app: FastifyInstance): Promise<void> {
  /** Catálogo de instrumentos com suas exigências, versionado. */
  app.get("/v1/instruments", async (request, reply) => {
    await requireRole(request, ...READ_ROLES);

    const instruments = await query(
      `SELECT i.id, i.code, i.version, i.title, i.official_source,
              i.effective_from, i.effective_to, i.status,
              count(r.id)::int AS requirement_count
         FROM instruments i
         LEFT JOIN instrument_requirements r ON r.instrument_id = i.id
        WHERE i.status IN ('active','draft')
        GROUP BY i.id
        ORDER BY i.code, i.effective_from DESC`,
    );

    return reply.send({ instruments: instruments.rows });
  });

  app.get<{ Params: { id: string } }>("/v1/instruments/:id/requirements", async (request, reply) => {
    await requireRole(request, ...READ_ROLES);

    const requirements = await query(
      `SELECT id, code, axis, indicator, criterion, expected_evidence, criticality
         FROM instrument_requirements
        WHERE instrument_id = $1
        ORDER BY axis, code`,
      [request.params.id],
    );

    return reply.send({ requirements: requirements.rows });
  });

  app.get("/v1/evidence", async (request, reply) => {
    await requireRole(request, ...READ_ROLES);
    const institutionId = requireTenant(request);
    const q = request.query as Record<string, string>;

    const result = await query(
      `SELECT e.id, e.status, e.due_date, e.valid_until, e.updated_at,
              e.course_id, c.name AS course_name,
              r.code AS requirement_code, r.axis, r.indicator, r.criterion,
              r.expected_evidence, r.criticality,
              i.code AS instrument_code, i.version AS instrument_version,
              i.official_source AS instrument_source,
              u.name AS owner_name,
              (SELECT count(*)::int FROM evidence_documents ed WHERE ed.evidence_id = e.id) AS document_count
         FROM evidence_items e
         JOIN instrument_requirements r ON r.id = e.requirement_id
         JOIN instruments i ON i.id = e.instrument_id
         LEFT JOIN courses c ON c.id = e.course_id
         LEFT JOIN users u ON u.id = e.owner_id
        WHERE e.institution_id = $1
          AND ($2::text IS NULL OR e.status = $2)
          AND ($3::uuid IS NULL OR e.course_id = $3)
        ORDER BY
          CASE e.status WHEN 'expired' THEN 0 WHEN 'changes_requested' THEN 1
                        WHEN 'in_review' THEN 2 WHEN 'pending' THEN 3 ELSE 4 END,
          e.due_date NULLS LAST`,
      [institutionId, q.status ?? null, q.courseId ?? null],
    );

    const readiness = await query<{ status: string; total: string }>(
      `SELECT status, count(*)::text AS total
         FROM evidence_items WHERE institution_id = $1 GROUP BY status`,
      [institutionId],
    );

    return reply.send({
      evidence: result.rows,
      countsByStatus: Object.fromEntries(readiness.rows.map((r) => [r.status, Number(r.total)])),
    });
  });

  app.post("/v1/evidence", async (request, reply) => {
    const claims = await requireRole(request, ...WRITE_ROLES);
    const institutionId = requireTenant(request);

    const parsed = createSchema.safeParse(request.body);
    if (!parsed.success) throw badRequest(parsed.error.issues[0]?.message ?? "Corpo inválido");

    // A exigência precisa pertencer ao instrumento informado.
    const check = await query(
      "SELECT 1 FROM instrument_requirements WHERE id = $1 AND instrument_id = $2",
      [parsed.data.requirementId, parsed.data.instrumentId],
    );
    if (!check.rowCount) throw badRequest("A exigência não pertence ao instrumento informado");

    const inserted = await query<{ id: string }>(
      `INSERT INTO evidence_items
         (institution_id, course_id, instrument_id, requirement_id, owner_id, due_date, valid_until)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
      [
        institutionId,
        parsed.data.courseId ?? null,
        parsed.data.instrumentId,
        parsed.data.requirementId,
        parsed.data.ownerId ?? null,
        parsed.data.dueDate ?? null,
        parsed.data.validUntil ?? null,
      ],
    );

    const evidenceId = inserted.rows[0]!.id;
    await query(
      `INSERT INTO evidence_history (institution_id, evidence_id, from_status, to_status, actor_id, note)
       VALUES ($1,$2,NULL,'pending',$3,'Evidência criada')`,
      [institutionId, evidenceId, claims.sub],
    );
    await audit(request, {
      institutionId,
      actorId: claims.sub,
      action: "evidence.create",
      resourceType: "evidence_item",
      resourceId: evidenceId,
    });

    return reply.status(201).send({ id: evidenceId });
  });

  app.patch<{ Params: { id: string } }>("/v1/evidence/:id/status", async (request, reply) => {
    const claims = await requireRole(request, ...WRITE_ROLES);
    const institutionId = requireTenant(request);

    const parsed = transitionSchema.safeParse(request.body);
    if (!parsed.success) throw badRequest(parsed.error.issues[0]?.message ?? "Corpo inválido");

    const current = await query<{ status: string }>(
      "SELECT status FROM evidence_items WHERE id = $1 AND institution_id = $2",
      [request.params.id, institutionId],
    );
    const evidence = current.rows[0];
    if (!evidence) throw notFound("Evidência não encontrada");

    if (!(ALLOWED[evidence.status] ?? []).includes(parsed.data.status)) {
      throw conflict(`Transição não permitida: ${evidence.status} → ${parsed.data.status}`);
    }

    await withTransaction(async (client) => {
      await client.query(
        `UPDATE evidence_items
            SET status = $2, reviewer_opinion = COALESCE($3, reviewer_opinion),
                reviewed_by = $4, reviewed_at = now(), updated_at = now()
          WHERE id = $1 AND institution_id = $5`,
        [request.params.id, parsed.data.status, parsed.data.opinion ?? null, claims.sub, institutionId],
      );
      await client.query(
        `INSERT INTO evidence_history
           (institution_id, evidence_id, from_status, to_status, actor_id, note)
         VALUES ($1,$2,$3,$4,$5,$6)`,
        [institutionId, request.params.id, evidence.status, parsed.data.status, claims.sub, parsed.data.opinion ?? null],
      );
    });

    await audit(request, {
      institutionId,
      actorId: claims.sub,
      action: "evidence.transition",
      resourceType: "evidence_item",
      resourceId: request.params.id,
      metadata: { from: evidence.status, to: parsed.data.status },
    });

    return reply.send({ ok: true, status: parsed.data.status });
  });

  app.get<{ Params: { id: string } }>("/v1/evidence/:id", async (request, reply) => {
    await requireRole(request, ...READ_ROLES);
    const institutionId = requireTenant(request);

    const evidence = await query(
      `SELECT e.*, r.code AS requirement_code, r.axis, r.indicator, r.criterion,
              r.expected_evidence, i.code AS instrument_code, i.version AS instrument_version,
              i.official_source
         FROM evidence_items e
         JOIN instrument_requirements r ON r.id = e.requirement_id
         JOIN instruments i ON i.id = e.instrument_id
        WHERE e.id = $1 AND e.institution_id = $2`,
      [request.params.id, institutionId],
    );
    if (!evidence.rows[0]) throw notFound("Evidência não encontrada");

    const history = await query(
      `SELECT h.from_status, h.to_status, h.note, h.created_at, u.name AS actor_name
         FROM evidence_history h
         LEFT JOIN users u ON u.id = h.actor_id
        WHERE h.evidence_id = $1 AND h.institution_id = $2
        ORDER BY h.created_at ASC`,
      [request.params.id, institutionId],
    );

    const documents = await query(
      `SELECT d.file_name, d.mime_type, d.sha256, d.created_at, ed.version
         FROM evidence_documents ed
         JOIN documents d ON d.id = ed.document_id
        WHERE ed.evidence_id = $1 AND ed.institution_id = $2
        ORDER BY ed.version DESC`,
      [request.params.id, institutionId],
    );

    return reply.send({
      evidence: evidence.rows[0],
      history: history.rows,
      documents: documents.rows,
    });
  });

  /** Vínculo lógico: aponta para um documento existente, sem duplicar arquivo. */
  app.post<{ Params: { id: string } }>("/v1/evidence/:id/documents", async (request, reply) => {
    const claims = await requireRole(request, ...WRITE_ROLES);
    const institutionId = requireTenant(request);
    const parsed = z
      .object({ documentId: z.string().uuid(), version: z.number().int().min(1).optional() })
      .strict()
      .safeParse(request.body);
    if (!parsed.success) throw badRequest("documentId é obrigatório");

    const owns = await query(
      "SELECT 1 FROM documents WHERE id = $1 AND institution_id = $2",
      [parsed.data.documentId, institutionId],
    );
    if (!owns.rowCount) throw notFound("Documento não encontrado");

    if (!canWrite(claims.role)) throw forbidden();

    await query(
      `INSERT INTO evidence_documents (institution_id, evidence_id, document_id, version)
       VALUES ($1,$2,$3,$4)
       ON CONFLICT (evidence_id, document_id) DO NOTHING`,
      [institutionId, request.params.id, parsed.data.documentId, parsed.data.version ?? 1],
    );

    await audit(request, {
      institutionId,
      actorId: claims.sub,
      action: "evidence.link_document",
      resourceType: "evidence_item",
      resourceId: request.params.id,
      metadata: { documentId: parsed.data.documentId },
    });

    return reply.status(201).send({ ok: true });
  });
}
