import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { randomUUID } from "node:crypto";
import { query } from "../db/pool.js";
import { canWrite, requireRole, requireTenant } from "../auth/middleware.js";
import { audit } from "../http/audit.js";
import { AppError, badRequest, conflict, forbidden, notFound } from "../http/errors.js";
import { config } from "../config.js";
import {
  assertUploadAcceptable,
  buildStorageKey,
  deleteObject,
  headObject,
  presignDownload,
  presignUpload,
  storageConfigured,
} from "../services/storage.js";
import { scanBuffer } from "../services/antivirus.js";
import { assertInstitutionCanWrite, assertQuota } from "../services/plans.js";

/**
 * Documentos.
 *
 * Fluxo:
 *   1. POST /v1/documents            → cria registro + URL pré-assinada de PUT
 *   2. cliente faz PUT direto no bucket
 *   3. POST /v1/documents/:id/complete → confere tamanho/checksum, escaneia
 *   4. POST /v1/evidence/:id/documents → vincula (só se scan_status = clean)
 *
 * O servidor nunca recebe o corpo do arquivo: menos memória, menos superfície.
 */

const READ_ROLES = [
  "platform_admin",
  "institution_admin",
  "regulatory_manager",
  "coordinator",
  "auditor_readonly",
] as const;
const WRITE_ROLES = ["platform_admin", "institution_admin", "regulatory_manager"] as const;

const createSchema = z
  .object({
    fileName: z.string().min(1).max(255),
    mimeType: z.string().min(3).max(150),
    sizeBytes: z.number().int().positive(),
    /** SHA-256 em base64 (formato exigido pelo S3 para o cabeçalho de checksum). */
    sha256Base64: z.string().min(44).max(44),
    classification: z.enum(["public", "internal", "restricted"]).default("internal"),
    evidenceId: z.string().uuid().nullable().optional(),
  })
  .strict();

export async function documentRoutes(app: FastifyInstance): Promise<void> {
  app.get("/v1/documents", async (request, reply) => {
    await requireRole(request, ...READ_ROLES);
    const institutionId = requireTenant(request);

    const rows = await query(
      `SELECT id, file_name, mime_type, size_bytes, classification,
              scan_status, scan_detail, scanned_at, created_at
         FROM documents
        WHERE institution_id = $1 AND deleted_at IS NULL
        ORDER BY created_at DESC
        LIMIT 200`,
      [institutionId],
    );

    return reply.send({ documents: rows.rows });
  });

  /** Passo 1: registra a intenção e devolve a URL de PUT. */
  app.post("/v1/documents", async (request, reply) => {
    const claims = await requireRole(request, ...WRITE_ROLES);
    const institutionId = requireTenant(request);
    if (!canWrite(claims.role)) throw forbidden("Papel sem permissão de escrita");
    await assertInstitutionCanWrite(institutionId, claims.role);

    const parsed = createSchema.safeParse(request.body);
    if (!parsed.success) {
      throw badRequest("Dados do documento inválidos", parsed.error.flatten());
    }
    const input = parsed.data;

    if (!storageConfigured()) {
      throw new AppError(
        "Storage de documentos não configurado neste ambiente",
        503,
        "storage_unavailable",
      );
    }

    assertUploadAcceptable(input.mimeType, input.sizeBytes);

    // Cota de armazenamento do plano, em MB. A conta é feita sobre o total
    // atual mais o arquivo que está entrando — não sobre a contagem de linhas.
    await assertQuota(
      institutionId,
      "maxStorageMb",
      Math.ceil(input.sizeBytes / (1024 * 1024)),
    );

    // Evidência, se informada, precisa ser da mesma instituição.
    if (input.evidenceId) {
      const owns = await query(
        "SELECT 1 FROM evidence_items WHERE id = $1 AND institution_id = $2",
        [input.evidenceId, institutionId],
      );
      if (!owns.rowCount) throw notFound("Evidência não encontrada");
    }

    // sha256 em hexadecimal para deduplicação (o UNIQUE usa hex).
    const sha256Hex = Buffer.from(input.sha256Base64, "base64").toString("hex");

    const duplicate = await query<{ id: string; scan_status: string }>(
      `SELECT id, scan_status FROM documents
        WHERE institution_id = $1 AND sha256 = $2 AND deleted_at IS NULL`,
      [institutionId, sha256Hex],
    );
    if (duplicate.rowCount) {
      throw conflict("Este arquivo já foi enviado (mesmo SHA-256)");
    }

    const documentId = randomUUID();
    const storageKey = buildStorageKey({
      institutionId,
      evidenceId: input.evidenceId ?? null,
      documentId,
      fileName: input.fileName,
    });

    await query(
      `INSERT INTO documents
         (id, institution_id, storage_key, file_name, mime_type, size_bytes,
          sha256, classification, created_by, scan_status)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'pending_upload')`,
      [
        documentId,
        institutionId,
        storageKey,
        input.fileName,
        input.mimeType,
        input.sizeBytes,
        sha256Hex,
        input.classification,
        claims.sub,
      ],
    );

    const uploadUrl = await presignUpload({
      key: storageKey,
      contentType: input.mimeType,
      contentLength: input.sizeBytes,
      sha256: input.sha256Base64,
    });

    await logAccess(request, institutionId, documentId, claims.sub, "upload_url_issued", "issued");
    await audit(request, {
      institutionId,
      actorId: claims.sub,
      action: "document.upload_url_issued",
      resourceType: "document",
      resourceId: documentId,
      metadata: { mimeType: input.mimeType, sizeBytes: input.sizeBytes },
    });

    return reply.status(201).send({
      documentId,
      uploadUrl,
      method: "PUT",
      headers: {
        "Content-Type": input.mimeType,
        "x-amz-checksum-sha256": input.sha256Base64,
        "x-amz-sdk-checksum-algorithm": "SHA256",
      },
      expiresInSeconds: config.storage.uploadTtlSeconds,
    });
  });

  /**
   * Passo 3: o cliente confirma o upload. O servidor confere o objeto no bucket
   * e roda o antivírus antes de liberar o documento para vínculo.
   */
  app.post<{ Params: { id: string } }>(
    "/v1/documents/:id/complete",
    { bodyLimit: config.storage.maxFileBytes + 1024 },
    async (request, reply) => {
      const claims = await requireRole(request, ...WRITE_ROLES);
      const institutionId = requireTenant(request);

      const found = await query<{
        id: string;
        storage_key: string;
        mime_type: string;
        size_bytes: string;
        scan_status: string;
      }>(
        `SELECT id, storage_key, mime_type, size_bytes, scan_status
           FROM documents
          WHERE id = $1 AND institution_id = $2 AND deleted_at IS NULL`,
        [request.params.id, institutionId],
      );

      const doc = found.rows[0];
      if (!doc) throw notFound("Documento não encontrado");
      if (doc.scan_status === "clean") {
        return reply.send({ documentId: doc.id, scanStatus: "clean", alreadyDone: true });
      }
      if (doc.scan_status === "infected") {
        throw new AppError("Arquivo reprovado no antivírus", 422, "document_blocked");
      }

      const head = await headObject(doc.storage_key);
      if (!head) {
        throw badRequest("Arquivo não encontrado no bucket; envie novamente", {
          documentId: doc.id,
        });
      }

      // Divergência de tamanho indica upload incompleto ou adulterado.
      if (head.size !== Number(doc.size_bytes)) {
        await markFailed(doc.id, `tamanho divergente: bucket=${head.size} esperado=${doc.size_bytes}`);
        throw badRequest("O arquivo enviado não corresponde ao tamanho declarado");
      }

      // O scanner precisa dos bytes. Em produção com volumes grandes, troque
      // por scan no próprio bucket (S3 Object Lambda) e mantenha este contrato.
      const scanTarget = await readUploadedBytes(doc.storage_key);
      const scan = scanTarget
        ? await scanBuffer(scanTarget)
        : {
            verdict: "failed" as const,
            engine: "clamav",
            detail: "corpo do arquivo indisponível para verificação",
          };

      if (scan.verdict === "infected") {
        await query(
          `UPDATE documents
              SET scan_status = 'infected', scan_engine = $2, scan_detail = $3,
                  scanned_at = now(), uploaded_at = now()
            WHERE id = $1`,
          [doc.id, scan.engine, scan.detail],
        );
        await deleteObject(doc.storage_key);
        await logAccess(request, institutionId, doc.id, claims.sub, "scan_completed", "infected");
        await audit(request, {
          institutionId,
          actorId: claims.sub,
          action: "document.infected",
          resourceType: "document",
          resourceId: doc.id,
          outcome: "denied",
          metadata: { detail: scan.detail },
        });
        throw new AppError("Arquivo reprovado no antivírus e removido", 422, "document_blocked");
      }

      if (scan.verdict === "failed") {
        await markFailed(doc.id, scan.detail);
        await logAccess(request, institutionId, doc.id, claims.sub, "scan_completed", "failed");
        throw new AppError(
          "Não foi possível verificar o arquivo. Ele permanece bloqueado até novo envio.",
          503,
          "scan_unavailable",
        );
      }

      await query(
        `UPDATE documents
            SET scan_status = 'clean', scan_engine = $2, scan_detail = $3,
                scanned_at = now(), uploaded_at = now()
          WHERE id = $1`,
        [doc.id, scan.engine, scan.detail],
      );

      await logAccess(request, institutionId, doc.id, claims.sub, "scan_completed", "clean");
      await audit(request, {
        institutionId,
        actorId: claims.sub,
        action: "document.approved",
        resourceType: "document",
        resourceId: doc.id,
        metadata: { engine: scan.engine },
      });

      return reply.send({ documentId: doc.id, scanStatus: "clean", scanDetail: scan.detail });
    },
  );

  /** URL de download, curta e auditada. Documento reprovado nunca é servido. */
  app.get<{ Params: { id: string } }>("/v1/documents/:id/download", async (request, reply) => {
    const claims = await requireRole(request, ...READ_ROLES);
    const institutionId = requireTenant(request);

    const found = await query<{
      id: string;
      storage_key: string;
      file_name: string;
      scan_status: string;
    }>(
      `SELECT id, storage_key, file_name, scan_status
         FROM documents
        WHERE id = $1 AND institution_id = $2 AND deleted_at IS NULL`,
      [request.params.id, institutionId],
    );

    const doc = found.rows[0];
    if (!doc) throw notFound("Documento não encontrado");
    if (doc.scan_status !== "clean") {
      throw new AppError("Documento não liberado (antivírus pendente ou reprovado)", 403, "document_not_clean");
    }

    const url = await presignDownload({ key: doc.storage_key, fileName: doc.file_name });

    await logAccess(request, institutionId, doc.id, claims.sub, "download_url_issued", "issued");
    await audit(request, {
      institutionId,
      actorId: claims.sub,
      action: "document.download_url_issued",
      resourceType: "document",
      resourceId: doc.id,
    });

    return reply.send({ url, expiresInSeconds: config.storage.downloadTtlSeconds });
  });

  /** Remoção lógica + remoção do objeto. Exigida para atender exclusão a pedido. */
  app.delete<{ Params: { id: string } }>("/v1/documents/:id", async (request, reply) => {
    const claims = await requireRole(request, ...WRITE_ROLES);
    const institutionId = requireTenant(request);

    const found = await query<{ storage_key: string }>(
      "SELECT storage_key FROM documents WHERE id = $1 AND institution_id = $2 AND deleted_at IS NULL",
      [request.params.id, institutionId],
    );
    if (!found.rowCount) throw notFound("Documento não encontrado");

    await query("UPDATE documents SET deleted_at = now() WHERE id = $1", [request.params.id]);
    await deleteObject(found.rows[0]!.storage_key);

    await audit(request, {
      institutionId,
      actorId: claims.sub,
      action: "document.deleted",
      resourceType: "document",
      resourceId: request.params.id,
    });

    return reply.send({ ok: true });
  });
}

async function markFailed(documentId: string, detail: string): Promise<void> {
  await query(
    `UPDATE documents
        SET scan_status = 'failed', scan_engine = 'clamav', scan_detail = $2, scanned_at = now()
      WHERE id = $1`,
    [documentId, detail.slice(0, 500)],
  );
}

async function logAccess(
  request: { ip: string },
  institutionId: string,
  documentId: string,
  actorId: string | null,
  action: string,
  result: string,
): Promise<void> {
  try {
    await query(
      `INSERT INTO document_access_log
         (institution_id, document_id, actor_id, action, result, ip)
       VALUES ($1,$2,$3,$4,$5,$6)`,
      [institutionId, documentId, actorId, action, result, request.ip],
    );
  } catch (error) {
    console.error("[documents] falha ao registrar acesso", error);
  }
}

/**
 * Baixa o objeto para o scanner.
 *
 * Nota de implementação: em deployment com muitos arquivos grandes, mova o
 * antivírus para um worker que consome uma fila, e o endpoint `/complete`
 * apenas enfileira. O contrato de `scan_status` continua idêntico.
 */
async function readUploadedBytes(key: string): Promise<Buffer | null> {
  const { GetObjectCommand, S3Client } = await import("@aws-sdk/client-s3");
  try {
    const client = new S3Client({
      region: config.storage.region,
      ...(config.storage.endpoint ? { endpoint: config.storage.endpoint } : {}),
      forcePathStyle: config.storage.forcePathStyle,
      credentials: {
        accessKeyId: config.storage.accessKeyId,
        secretAccessKey: config.storage.secretAccessKey,
      },
    });
    const object = await client.send(
      new GetObjectCommand({ Bucket: config.storage.bucket, Key: key }),
    );
    const bytes = await object.Body?.transformToByteArray();
    return bytes ? Buffer.from(bytes) : null;
  } catch (error) {
    console.error("[documents] falha ao ler objeto para scan", error);
    return null;
  }
}
