import type { FastifyInstance } from "fastify";
import { config } from "../config.js";
import {
  normalizeAsaasEvent,
  verifyHmacSignature,
  verifySharedToken,
  WebhookSignatureError,
  type NormalizedEvent,
} from "../domain/billing.js";
import { billingEventCounts, applyBillingEvent, listBillingEvents } from "../services/billing.js";
import { audit } from "../http/audit.js";
import { requireRole, requireTenant } from "../auth/middleware.js";

/**
 * Webhook de cobrança.
 *
 * Rota pública por natureza — o provedor não tem sessão. A autenticação é a
 * assinatura do corpo, não um Bearer.
 *
 * Três detalhes que costumam ser feitos errado e causam incidente:
 *
 *  - **Corpo bruto.** A assinatura HMAC cobre os bytes originais. Reserializar
 *    o JSON muda espaço e ordem de chave, e a verificação falha sempre. Por
 *    isso o parser abaixo guarda o Buffer e a rota nunca usa `request.body`.
 *  - **Sempre 200 em evento conhecido.** Provedor reentrega qualquer resposta
 *    fora da faixa 2xx. Devolver 400 para evento que não altera nada gera
 *    fila de reentrega infinita. 4xx só para assinatura inválida.
 *  - **Trabalho assíncrono é tentação, não aqui.** O processamento é uma
 *    transação curta; enfileirar exigiria uma fila que ainda não existe e
 *    abriria a janela em que o provedor acha que entregou mas nada foi gravado.
 */

declare module "fastify" {
  interface FastifyRequest {
    rawBody?: Buffer;
  }
}

export async function billingRoutes(app: FastifyInstance): Promise<void> {
  // Parser dedicado: só este tipo de conteúdo, e só nesta rota, precisa do
  // corpo bruto. Manter global aumentaria memória de toda requisição.
  app.addContentTypeParser(
    "application/json",
    { parseAs: "buffer", bodyLimit: 1024 * 1024 },
    (request, body, done) => {
      const buffer = body as Buffer;
      // O Fastify já tentaria parsear; guardamos os bytes antes de qualquer
      // transformação.
      if (request.url.startsWith("/v1/billing/webhook")) {
        request.rawBody = buffer;
      }
      try {
        done(null, buffer.length ? JSON.parse(buffer.toString("utf8")) : {});
      } catch (error) {
        done(error as Error, undefined);
      }
    },
  );

  app.post(
    "/v1/billing/webhook",
    {
      // Provedor pode reentregar em rajada; o limite global de 300/min é
      // apertado demais para um lote de eventos atrasados.
      config: { rateLimit: { max: 600, timeWindow: "1 minute" } },
    },
    async (request, reply) => {
      const provider = config.billing.provider;
      const rawBody = request.rawBody;

      if (!rawBody) {
        throw new WebhookSignatureError("Corpo bruto indisponível para verificação");
      }

      // ---------------------------------------------------------------------
      // Autenticidade
      // ---------------------------------------------------------------------
      if (provider !== "manual") {
        if (!config.billing.webhookSecret) {
          // Falha fechada: webhook sem segredo em produção é porta aberta para
          // qualquer um mudar o estado de cobrança de um cliente.
          request.log.error("[billing] webhook recebido sem BILLING_WEBHOOK_SECRET configurado");
          return reply.status(503).send({ error: "webhook_not_configured" });
        }

        if (provider === "asaas") {
          // Asaas usa segredo compartilhado em cabeçalho, não HMAC.
          verifySharedToken(
            request.headers["asaas-access-token"] as string | undefined,
            config.billing.webhookSecret,
          );
        } else {
          verifyHmacSignature(
            rawBody,
            request.headers["x-signature"] as string | undefined,
            config.billing.webhookSecret,
          );
        }
      }

      // ---------------------------------------------------------------------
      // Tradução
      // ---------------------------------------------------------------------
      let event: NormalizedEvent;
      try {
        event = normalizeAsaasEvent(request.body);
      } catch (error) {
        // Evento malformado do provedor: 400 para que ele reentregue e a gente
        // investigue, em vez de engolir silenciosamente.
        request.log.warn({ err: error }, "[billing] evento malformado");
        return reply.status(400).send({ error: "malformed_event" });
      }

      // ---------------------------------------------------------------------
      // Aplicação idempotente
      // ---------------------------------------------------------------------
      const outcome = await applyBillingEvent(provider, event, request.body);

      // Auditoria só quando o estado mudou: evento ignorado não é ação da
      // plataforma sobre a conta do cliente, e encher o log de auditoria com
      // "nada aconteceu" esconde o que importa.
      if (outcome.processed && !outcome.skipped && outcome.institutionId) {
        await audit(request, {
          institutionId: outcome.institutionId,
          actorId: null,
          actorKind: "system",
          action: `billing.${event.type.toLowerCase()}`,
          resourceType: "subscription",
          // `subscriptions.id` (uuid). O id do provedor vai em metadata, onde
          // texto livre é permitido.
          resourceId: outcome.subscriptionId,
          metadata: {
            provider,
            eventId: event.eventId,
            providerRef: event.providerRef,
            effect: event.effect.kind,
          },
        });
      }

      request.log.info(
        {
          provider,
          eventId: event.eventId,
          type: event.type,
          processed: outcome.processed,
          skipped: outcome.skipped,
          reason: outcome.reason,
        },
        "[billing] evento de webhook",
      );

      // 200 mesmo quando já processado: reentrega é esperada e não é erro.
      return reply.status(200).send({
        ok: true,
        duplicate: !outcome.processed,
        applied: outcome.processed && !outcome.skipped,
      });
    },
  );

  /**
   * Eventos de cobrança para a tela de operação.
   *
   * Escopo: `platform_admin` vê todas as instituições (é quem opera a
   * cobrança); qualquer outro papel vê só a própria, e o filtro vem do token,
   * nunca da URL — um `?institutionId=` no query string deixaria qualquer
   * administrador ler o faturamento do cliente vizinho.
   */
  const READ_ROLES = [
    "platform_admin",
    "institution_admin",
    "auditor_readonly",
    "privacy_officer",
  ] as const;

  app.get("/v1/billing/events", async (request, reply) => {
    const claims = await requireRole(request, ...READ_ROLES);

    const scope =
      claims.role === "platform_admin" ? null : requireTenant(request);

    const q = request.query as Record<string, string | undefined>;
    const limit = Number(q.limit ?? 100);
    const outcome =
      q.outcome === "applied" ||
      q.outcome === "ignored" ||
      q.outcome === "duplicate" ||
      q.outcome === "pending"
        ? q.outcome
        : null;

    const [events, stats] = await Promise.all([
      listBillingEvents({
        institutionId: scope,
        limit: Number.isFinite(limit) ? limit : 100,
        eventType: q.type ?? null,
        outcome,
      }),
      billingEventCounts(scope),
    ]);

    return reply.send({
      events,
      counts: stats.counts,
      lastEventAt: stats.lastAt,
      /** Mostra na tela que o operador está vendo além da própria conta. */
      scopeInstitutionId: scope,
    });
  });
}
