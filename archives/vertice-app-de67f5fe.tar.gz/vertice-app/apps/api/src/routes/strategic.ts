import type { FastifyInstance, FastifyRequest } from "fastify";
import { z } from "zod";
import { query, withTransaction } from "../db/pool.js";
import { requireRole, requireTenant, canWrite } from "../auth/middleware.js";
import { audit } from "../http/audit.js";
import { badRequest, forbidden, notFound } from "../http/errors.js";

const READ_ROLES = [
  "platform_admin",
  "institution_admin",
  "regulatory_manager",
  "coordinator",
  "auditor_readonly",
  "privacy_officer",
] as const;

const WRITE_ROLES = [
  "platform_admin",
  "institution_admin",
  "regulatory_manager",
  "coordinator",
] as const;

// ---------------------------------------------------------------------------
// Zod schemas
// ---------------------------------------------------------------------------

const strategicPlanSchema = z
  .object({
    courseId: z.string().uuid(),
    version: z.number().int().positive().optional(),
    status: z.enum(["draft", "published", "archived"]).optional(),

    // 1. Identificação
    coordinator_name: z.string().max(200).optional().nullable(),
    coordinator_since: z.string().max(100).optional().nullable(),
    enrolled_count: z.number().int().min(0).optional().nullable(),
    first_semester: z.string().regex(/^[0-9]{4}\/[12]$/).optional().nullable(),

    // 2. Visão
    vision_text: z.string().max(10000).optional().nullable(),
    vision_inspirations: z.array(z.object({ text: z.string().max(2000) })).optional(),
    vision_reflections: z.array(
      z.object({
        item: z.string().max(200),
        current_state: z.string().max(2000),
        desired_state: z.string().max(2000),
      })
    ).optional(),

    // 3. Ciclo de vida
    lifecycle_stage: z.string().max(200).optional().nullable(),
    lifecycle_strategies: z.array(z.object({ text: z.string().max(2000) })).optional(),

    // 4. Matriz BCG
    bcg_market_growth: z.string().max(200).optional().nullable(),
    bcg_market_share: z.string().max(200).optional().nullable(),
    bcg_quadrant: z.string().max(200).optional().nullable(),
    bcg_strategies: z.array(z.object({ quadrant: z.string().max(100), strategy: z.string().max(2000) })).optional(),

    // 5. Porter
    porter_rivalry: z.string().max(4000).optional().nullable(),
    porter_buyer_power: z.string().max(4000).optional().nullable(),
    porter_supplier_power: z.string().max(4000).optional().nullable(),
    porter_substitutes: z.string().max(4000).optional().nullable(),
    porter_new_entrants: z.string().max(4000).optional().nullable(),

    // 6-9. FCS
    fcs_institutional: z.array(
      z.object({ name: z.string().max(200), description: z.string().max(4000), differentiator: z.string().max(4000) })
    ).optional(),
    fcs_course: z.array(
      z.object({ name: z.string().max(200), maturity: z.string().max(100), differentiator: z.string().max(4000) })
    ).optional(),
    fcs_competitors: z.array(
      z.object({ fcs_name: z.string().max(200), competitors: z.array(z.object({ name: z.string().max(200), rating: z.string().max(100) })) })
    ).optional(),
    fcs_competitive_matrix: z.array(
      z.object({ fcs_name: z.string().max(200), institution_code: z.string().max(10), rating: z.string().max(100) })
    ).optional(),

    // 10. Matriz de atributos
    attributes_matrix: z.array(
      z.object({
        attribute: z.string().max(200),
        importance: z.string().max(100),
        satisfaction: z.string().max(100),
        gap: z.string().max(100),
      })
    ).optional(),

    // 11. Objetivos estratégicos
    strategic_objectives: z.array(
      z.object({
        theme: z.string().max(200),
        indicator: z.string().max(200),
        description: z.string().max(4000),
        targets: z.object({
          year1: z.string().max(200).optional(),
          year2: z.string().max(200).optional(),
          year3: z.string().max(200).optional(),
          year4: z.string().max(200).optional(),
          year5: z.string().max(200).optional(),
        }),
      })
    ).optional(),

    // 12. Objetivos operacionais / plano de ação
    operational_objectives: z.array(
      z.object({
        strategic_objective_id: z.string().uuid().optional().nullable(),
        description: z.string().max(4000),
        responsible: z.string().max(200).optional().nullable(),
        deadline: z.string().date().optional().nullable(),
        resources: z.string().max(4000).optional().nullable(),
        status: z.enum(["planned", "in_progress", "completed", "cancelled"]).optional(),
        year_targets: z.record(z.string().max(200)).optional(),
      })
    ).optional(),
  })
  .strict();

const semesterPlanSchema = z
  .object({
    courseId: z.string().uuid(),
    semester: z.string().regex(/^[0-9]{4}\/[12]$/),
    form_code: z.string().max(50).optional().nullable(),
    version: z.number().int().positive().optional(),
    status: z.enum(["draft", "published", "archived"]).optional(),
    activities: z.array(
      z.object({
        month: z.string().max(100),
        date: z.string().max(100),
        event: z.string().max(500),
        event_type: z.string().max(200).optional().nullable(),
        action: z.string().max(2000).optional().nullable(),
        student_count: z.string().max(100).optional().nullable(),
        location: z.string().max(200).optional().nullable(),
        status: z.enum(["planned", "in_progress", "completed", "cancelled"]).optional(),
      })
    ).optional(),
  })
  .strict();

const readGuard = async (request: FastifyRequest): Promise<void> => {
  await requireRole(request, ...READ_ROLES);
};

const writeGuard = async (request: FastifyRequest): Promise<void> => {
  await requireRole(request, ...WRITE_ROLES);
};

export async function strategicRoutes(app: FastifyInstance): Promise<void> {
  // -------------------------------------------------------------------------
  // Listar planejamentos da instituição
  // -------------------------------------------------------------------------
  app.get(
    "/v1/strategic-plans",
    { preHandler: readGuard },
    async (request, reply) => {
      const institutionId = requireTenant(request);
      const { courseId, status, limit = "50", offset = "0" } = request.query as Record<string, string>;

      const params: unknown[] = [institutionId];
      let where = "WHERE sp.institution_id = $1";
      let idx = 1;

      if (courseId) {
        idx++;
        where += ` AND sp.course_id = $${idx}`;
        params.push(courseId);
      }
      if (status) {
        idx++;
        where += ` AND sp.status = $${idx}`;
        params.push(status);
      }

      const lim = Math.min(Math.max(parseInt(limit, 10) || 50, 1), 200);
      const off = Math.max(parseInt(offset, 10) || 0, 0);

      const res = await query(
        `SELECT sp.*, c.code as course_code, c.name as course_name
           FROM strategic_plans sp
           JOIN courses c ON c.id = sp.course_id
           ${where}
           ORDER BY sp.created_at DESC
           LIMIT ${lim} OFFSET ${off}`,
        params,
      );

      return { plans: res.rows };
    }
  );

  // -------------------------------------------------------------------------
  // Obter planejamento por ID
  // -------------------------------------------------------------------------
  app.get(
    "/v1/strategic-plans/:id",
    { preHandler: readGuard },
    async (request, reply) => {
      const institutionId = requireTenant(request);
      const { id } = request.params as { id: string };

      const res = await query(
        `SELECT sp.*, c.code as course_code, c.name as course_name
           FROM strategic_plans sp
           JOIN courses c ON c.id = sp.course_id
          WHERE sp.id = $1 AND sp.institution_id = $2`,
        [id, institutionId],
      );

      if (!res.rowCount) throw notFound("Planejamento estratégico");
      return { plan: res.rows[0] };
    }
  );

  // -------------------------------------------------------------------------
  // Criar novo planejamento (versão 1)
  // -------------------------------------------------------------------------
  app.post(
    "/v1/strategic-plans",
    { preHandler: writeGuard },
    async (request, reply) => {
      const institutionId = requireTenant(request);
      const claims = request.auth!;
      const parsed = strategicPlanSchema.safeParse(request.body);
      if (!parsed.success) throw badRequest("Dados inválidos", { issues: parsed.error.flatten() });

      const data = parsed.data;
      const res = await withTransaction(async (client) => {
        // Verifica curso pertence à instituição
        const crs = await client.query(
          "SELECT id FROM courses WHERE id = $1 AND institution_id = $2",
          [data.courseId, institutionId],
        );
        if (!crs.rowCount) throw badRequest("Curso não pertence a esta instituição");

        // Próxima versão
        const ver = await client.query(
          `SELECT COALESCE(MAX(version), 0) + 1 as next_ver FROM strategic_plans
             WHERE institution_id = $1 AND course_id = $2`,
          [institutionId, data.courseId],
        );
        const version = data.version ?? ver.rows[0].next_ver;

        const ins = await client.query(
          `INSERT INTO strategic_plans (
             institution_id, course_id, version, status,
             coordinator_name, coordinator_since, enrolled_count, first_semester,
             vision_text, vision_inspirations, vision_reflections,
             lifecycle_stage, lifecycle_strategies,
             bcg_market_growth, bcg_market_share, bcg_quadrant, bcg_strategies,
             porter_rivalry, porter_buyer_power, porter_supplier_power, porter_substitutes, porter_new_entrants,
             fcs_institutional, fcs_course, fcs_competitors, fcs_competitive_matrix,
             attributes_matrix,
             strategic_objectives,
             operational_objectives,
             created_by
           ) VALUES (
             $1,$2,$3,$4,
             $5,$6,$7,$8,
             $9,$10,$11,
             $12,$13,
             $14,$15,$16,$17,
             $18,$19,$20,$21,$22,
             $23,$24,$25,$26,
             $27,
             $28,
             $29,
             $30
           ) RETURNING *`,
          [
            institutionId,
            data.courseId,
            version,
            data.status ?? "draft",
            data.coordinator_name,
            data.coordinator_since,
            data.enrolled_count,
            data.first_semester,
            data.vision_text,
            JSON.stringify(data.vision_inspirations ?? []),
            JSON.stringify(data.vision_reflections ?? []),
            data.lifecycle_stage,
            JSON.stringify(data.lifecycle_strategies ?? []),
            data.bcg_market_growth,
            data.bcg_market_share,
            data.bcg_quadrant,
            JSON.stringify(data.bcg_strategies ?? []),
            data.porter_rivalry,
            data.porter_buyer_power,
            data.porter_supplier_power,
            data.porter_substitutes,
            data.porter_new_entrants,
            JSON.stringify(data.fcs_institutional ?? []),
            JSON.stringify(data.fcs_course ?? []),
            JSON.stringify(data.fcs_competitors ?? []),
            JSON.stringify(data.fcs_competitive_matrix ?? []),
            JSON.stringify(data.attributes_matrix ?? []),
            JSON.stringify(data.strategic_objectives ?? []),
            JSON.stringify(data.operational_objectives ?? []),
            claims.sub,
          ],
        );

        await audit(request, {
          institutionId,
          actorId: claims.sub,
          action: "strategic_plan.create",
          resourceType: "strategic_plan",
          resourceId: ins.rows[0].id,
          metadata: { courseId: data.courseId, version },
        });

        return ins.rows[0];
      });

      return reply.status(201).send({ plan: res });
    }
  );

  // -------------------------------------------------------------------------
  // Atualizar planejamento (nova versão ou edição da mesma versão)
  // -------------------------------------------------------------------------
  app.patch(
    "/v1/strategic-plans/:id",
    { preHandler: writeGuard },
    async (request, reply) => {
      const institutionId = requireTenant(request);
      const claims = request.auth!;
      const { id } = request.params as { id: string };
      const parsed = strategicPlanSchema.partial().safeParse(request.body);
      if (!parsed.success) throw badRequest("Dados inválidos", { issues: parsed.error.flatten() });

      const data = parsed.data;

      // Verifica propriedade
      const cur = await query(
        "SELECT * FROM strategic_plans WHERE id = $1 AND institution_id = $2",
        [id, institutionId],
      );
      if (!cur.rowCount) throw notFound("Planejamento estratégico");

      // Se version mudou, cria nova versão; senão atualiza
      const newVersion = data.version ?? cur.rows[0]!.version;
      const isNewVersion = newVersion !== cur.rows[0]!.version;

      let res;
      if (isNewVersion) {
        // Cria nova versão copiando campos não informados
        const base = cur.rows[0]!;
        res = await withTransaction(async (client) => {
          const ins = await client.query(
            `INSERT INTO strategic_plans (
               institution_id, course_id, version, status,
               coordinator_name, coordinator_since, enrolled_count, first_semester,
               vision_text, vision_inspirations, vision_reflections,
               lifecycle_stage, lifecycle_strategies,
               bcg_market_growth, bcg_market_share, bcg_quadrant, bcg_strategies,
               porter_rivalry, porter_buyer_power, porter_supplier_power, porter_substitutes, porter_new_entrants,
               fcs_institutional, fcs_course, fcs_competitors, fcs_competitive_matrix,
               attributes_matrix,
               strategic_objectives,
               operational_objectives,
               created_by
             ) VALUES (
               $1,$2,$3,$4,
               $5,$6,$7,$8,
               $9,$10,$11,
               $12,$13,
               $14,$15,$16,$17,
               $18,$19,$20,$21,$22,
               $23,$24,$25,$26,
               $27,
               $28,
               $29,
               $30
             ) RETURNING *`,
            [
              institutionId,
              base.course_id,
              newVersion,
              data.status ?? base.status,
              data.coordinator_name ?? base.coordinator_name,
              data.coordinator_since ?? base.coordinator_since,
              data.enrolled_count ?? base.enrolled_count,
              data.first_semester ?? base.first_semester,
              data.vision_text ?? base.vision_text,
              JSON.stringify(data.vision_inspirations ?? base.vision_inspirations),
              JSON.stringify(data.vision_reflections ?? base.vision_reflections),
              data.lifecycle_stage ?? base.lifecycle_stage,
              JSON.stringify(data.lifecycle_strategies ?? base.lifecycle_strategies),
              data.bcg_market_growth ?? base.bcg_market_growth,
              data.bcg_market_share ?? base.bcg_market_share,
              data.bcg_quadrant ?? base.bcg_quadrant,
              JSON.stringify(data.bcg_strategies ?? base.bcg_strategies),
              data.porter_rivalry ?? base.porter_rivalry,
              data.porter_buyer_power ?? base.porter_buyer_power,
              data.porter_supplier_power ?? base.porter_supplier_power,
              data.porter_substitutes ?? base.porter_substitutes,
              data.porter_new_entrants ?? base.porter_new_entrants,
              JSON.stringify(data.fcs_institutional ?? base.fcs_institutional),
              JSON.stringify(data.fcs_course ?? base.fcs_course),
              JSON.stringify(data.fcs_competitors ?? base.fcs_competitors),
              JSON.stringify(data.fcs_competitive_matrix ?? base.fcs_competitive_matrix),
              JSON.stringify(data.attributes_matrix ?? base.attributes_matrix),
              JSON.stringify(data.strategic_objectives ?? base.strategic_objectives),
              JSON.stringify(data.operational_objectives ?? base.operational_objectives),
              claims.sub,
            ],
          );

          await audit(request, {
            institutionId,
            actorId: claims.sub,
            action: "strategic_plan.create_version",
            resourceType: "strategic_plan",
            resourceId: ins.rows[0].id,
            metadata: { courseId: base.course_id, version: newVersion, fromId: id },
          });

          return ins.rows[0];
        });
      } else {
        // Atualiza a mesma versão
        const base = cur.rows[0]!;
        res = await withTransaction(async (client) => {
          const upd = await client.query(
            `UPDATE strategic_plans SET
               status = COALESCE($1, status),
               coordinator_name = COALESCE($2, coordinator_name),
               coordinator_since = COALESCE($3, coordinator_since),
               enrolled_count = COALESCE($4, enrolled_count),
               first_semester = COALESCE($5, first_semester),
               vision_text = COALESCE($6, vision_text),
               vision_inspirations = COALESCE($7, vision_inspirations),
               vision_reflections = COALESCE($8, vision_reflections),
               lifecycle_stage = COALESCE($9, lifecycle_stage),
               lifecycle_strategies = COALESCE($10, lifecycle_strategies),
               bcg_market_growth = COALESCE($11, bcg_market_growth),
               bcg_market_share = COALESCE($12, bcg_market_share),
               bcg_quadrant = COALESCE($13, bcg_quadrant),
               bcg_strategies = COALESCE($14, bcg_strategies),
               porter_rivalry = COALESCE($15, porter_rivalry),
               porter_buyer_power = COALESCE($16, porter_buyer_power),
               porter_supplier_power = COALESCE($17, porter_supplier_power),
               porter_substitutes = COALESCE($18, porter_substitutes),
               porter_new_entrants = COALESCE($19, porter_new_entrants),
               fcs_institutional = COALESCE($20, fcs_institutional),
               fcs_course = COALESCE($21, fcs_course),
               fcs_competitors = COALESCE($22, fcs_competitors),
               fcs_competitive_matrix = COALESCE($23, fcs_competitive_matrix),
               attributes_matrix = COALESCE($24, attributes_matrix),
               strategic_objectives = COALESCE($25, strategic_objectives),
               operational_objectives = COALESCE($26, operational_objectives),
               updated_at = now()
             WHERE id = $27 AND institution_id = $28
             RETURNING *`,
            [
              data.status,
              data.coordinator_name,
              data.coordinator_since,
              data.enrolled_count,
              data.first_semester,
              data.vision_text,
              data.vision_inspirations ? JSON.stringify(data.vision_inspirations) : null,
              data.vision_reflections ? JSON.stringify(data.vision_reflections) : null,
              data.lifecycle_stage,
              data.lifecycle_strategies ? JSON.stringify(data.lifecycle_strategies) : null,
              data.bcg_market_growth,
              data.bcg_market_share,
              data.bcg_quadrant,
              data.bcg_strategies ? JSON.stringify(data.bcg_strategies) : null,
              data.porter_rivalry,
              data.porter_buyer_power,
              data.porter_supplier_power,
              data.porter_substitutes,
              data.porter_new_entrants,
              data.fcs_institutional ? JSON.stringify(data.fcs_institutional) : null,
              data.fcs_course ? JSON.stringify(data.fcs_course) : null,
              data.fcs_competitors ? JSON.stringify(data.fcs_competitors) : null,
              data.fcs_competitive_matrix ? JSON.stringify(data.fcs_competitive_matrix) : null,
              data.attributes_matrix ? JSON.stringify(data.attributes_matrix) : null,
              data.strategic_objectives ? JSON.stringify(data.strategic_objectives) : null,
              data.operational_objectives ? JSON.stringify(data.operational_objectives) : null,
              id,
              institutionId,
            ],
          );

          await audit(request, {
            institutionId,
            actorId: claims.sub,
            action: "strategic_plan.update",
            resourceType: "strategic_plan",
            resourceId: id,
            metadata: { version: newVersion },
          });

          return upd.rows[0];
        });
      }

      return { plan: res };
    }
  );

  // -------------------------------------------------------------------------
  // Publicar/arquivar
  // -------------------------------------------------------------------------
  app.patch(
    "/v1/strategic-plans/:id/status",
    { preHandler: writeGuard },
    async (request, reply) => {
      const institutionId = requireTenant(request);
      const claims = request.auth!;
      const { id } = request.params as { id: string };
      const { status } = z.object({ status: z.enum(["draft", "published", "archived"]) }).parse(request.body);

      const res = await query(
        `UPDATE strategic_plans SET status = $1, updated_at = now()
           WHERE id = $2 AND institution_id = $3
           RETURNING *`,
        [status, id, institutionId],
      );
      if (!res.rowCount) throw notFound("Planejamento estratégico");

      await audit(request, {
        institutionId,
        actorId: claims.sub,
        action: "strategic_plan.status",
        resourceType: "strategic_plan",
        resourceId: id,
        metadata: { status },
      });

      return { plan: res.rows[0] };
    }
  );

  // -------------------------------------------------------------------------
  // =========================================================================
  // PLANEJAMENTO SEMESTRAL
  // =========================================================================
  // -------------------------------------------------------------------------

  app.get(
    "/v1/semester-plannings",
    { preHandler: readGuard },
    async (request, reply) => {
      const institutionId = requireTenant(request);
      const { courseId, semester, status, limit = "50", offset = "0" } = request.query as Record<string, string>;

      const params: unknown[] = [institutionId];
      let where = "WHERE sp.institution_id = $1";
      let idx = 1;

      if (courseId) {
        idx++;
        where += ` AND sp.course_id = $${idx}`;
        params.push(courseId);
      }
      if (semester) {
        idx++;
        where += ` AND sp.semester = $${idx}`;
        params.push(semester);
      }
      if (status) {
        idx++;
        where += ` AND sp.status = $${idx}`;
        params.push(status);
      }

      const lim = Math.min(Math.max(parseInt(limit, 10) || 50, 1), 200);
      const off = Math.max(parseInt(offset, 10) || 0, 0);

      const res = await query(
        `SELECT sp.*, c.code as course_code, c.name as course_name
           FROM semester_plannings sp
           JOIN courses c ON c.id = sp.course_id
           ${where}
           ORDER BY sp.semester DESC, sp.created_at DESC
           LIMIT ${lim} OFFSET ${off}`,
        params,
      );

      return { plans: res.rows };
    }
  );

  app.get(
    "/v1/semester-plannings/:id",
    { preHandler: readGuard },
    async (request, reply) => {
      const institutionId = requireTenant(request);
      const { id } = request.params as { id: string };

      const res = await query(
        `SELECT sp.*, c.code as course_code, c.name as course_name
           FROM semester_plannings sp
           JOIN courses c ON c.id = sp.course_id
          WHERE sp.id = $1 AND sp.institution_id = $2`,
        [id, institutionId],
      );

      if (!res.rowCount) throw notFound("Planejamento semestral");
      return { plan: res.rows[0] };
    }
  );

  app.post(
    "/v1/semester-plannings",
    { preHandler: writeGuard },
    async (request, reply) => {
      const institutionId = requireTenant(request);
      const claims = request.auth!;
      const parsed = semesterPlanSchema.safeParse(request.body);
      if (!parsed.success) throw badRequest("Dados inválidos", { issues: parsed.error.flatten() });

      const data = parsed.data;
      const res = await withTransaction(async (client) => {
        const crs = await client.query(
          "SELECT id FROM courses WHERE id = $1 AND institution_id = $2",
          [data.courseId, institutionId],
        );
        if (!crs.rowCount) throw badRequest("Curso não pertence a esta instituição");

        const ver = await client.query(
          `SELECT COALESCE(MAX(version), 0) + 1 as next_ver FROM semester_plannings
             WHERE institution_id = $1 AND course_id = $2 AND semester = $3`,
          [institutionId, data.courseId, data.semester],
        );
        const version = data.version ?? ver.rows[0].next_ver;

        const ins = await client.query(
          `INSERT INTO semester_plannings (
             institution_id, course_id, semester, form_code, version, status,
             activities, created_by
           ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
          [
            institutionId,
            data.courseId,
            data.semester,
            data.form_code,
            version,
            data.status ?? "draft",
            JSON.stringify(data.activities ?? []),
            claims.sub,
          ],
        );

        await audit(request, {
          institutionId,
          actorId: claims.sub,
          action: "semester_planning.create",
          resourceType: "semester_planning",
          resourceId: ins.rows[0].id,
          metadata: { courseId: data.courseId, semester: data.semester, version },
        });

        return ins.rows[0];
      });

      return reply.status(201).send({ plan: res });
    }
  );

  app.patch(
    "/v1/semester-plannings/:id",
    { preHandler: writeGuard },
    async (request, reply) => {
      const institutionId = requireTenant(request);
      const claims = request.auth!;
      const { id } = request.params as { id: string };
      const parsed = semesterPlanSchema.partial().safeParse(request.body);
      if (!parsed.success) throw badRequest("Dados inválidos", { issues: parsed.error.flatten() });

      const data = parsed.data;

      const cur = await query(
        "SELECT * FROM semester_plannings WHERE id = $1 AND institution_id = $2",
        [id, institutionId],
      );
      if (!cur.rowCount) throw notFound("Planejamento semestral");

      const newVersion = data.version ?? cur.rows[0]!.version;
      const isNewVersion = newVersion !== cur.rows[0]!.version;

      let res;
      if (isNewVersion) {
        const base = cur.rows[0]!;
        res = await withTransaction(async (client) => {
          const ins = await client.query(
            `INSERT INTO semester_plannings (
               institution_id, course_id, semester, form_code, version, status,
               activities, created_by
             ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
            [
              institutionId,
              base.course_id,
              base.semester,
              data.form_code ?? base.form_code,
              newVersion,
              data.status ?? base.status,
              JSON.stringify(data.activities ?? base.activities),
              claims.sub,
            ],
          );

          await audit(request, {
            institutionId,
            actorId: claims.sub,
            action: "semester_planning.create_version",
            resourceType: "semester_planning",
            resourceId: ins.rows[0].id,
            metadata: { courseId: base.course_id, semester: base.semester, version: newVersion, fromId: id },
          });

          return ins.rows[0];
        });
      } else {
        const base = cur.rows[0]!;
        res = await withTransaction(async (client) => {
          const upd = await client.query(
            `UPDATE semester_plannings SET
               form_code = COALESCE($1, form_code),
               status = COALESCE($2, status),
               activities = COALESCE($3, activities),
               updated_at = now()
             WHERE id = $4 AND institution_id = $5
             RETURNING *`,
            [
              data.form_code,
              data.status,
              data.activities ? JSON.stringify(data.activities) : null,
              id,
              institutionId,
            ],
          );

          await audit(request, {
            institutionId,
            actorId: claims.sub,
            action: "semester_planning.update",
            resourceType: "semester_planning",
            resourceId: id,
            metadata: { version: newVersion },
          });

          return upd.rows[0];
        });
      }

      return { plan: res };
    }
  );

  app.patch(
    "/v1/semester-plannings/:id/status",
    { preHandler: writeGuard },
    async (request, reply) => {
      const institutionId = requireTenant(request);
      const claims = request.auth!;
      const { id } = request.params as { id: string };
      const { status } = z.object({ status: z.enum(["draft", "published", "archived"]) }).parse(request.body);

      const res = await query(
        `UPDATE semester_plannings SET status = $1, updated_at = now()
           WHERE id = $2 AND institution_id = $3
           RETURNING *`,
        [status, id, institutionId],
      );
      if (!res.rowCount) throw notFound("Planejamento semestral");

      await audit(request, {
        institutionId,
        actorId: claims.sub,
        action: "semester_planning.status",
        resourceType: "semester_planning",
        resourceId: id,
        metadata: { status },
      });

      return { plan: res.rows[0] };
    }
  );
}
