import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { query, withTransaction } from "../db/pool.js";
import { requirePlatformAdmin, platformTargetId } from "../auth/middleware.js";
import { audit } from "../http/audit.js";
import { badRequest, conflict, notFound } from "../http/errors.js";
import { createInvite } from "../services/invites.js";
import { loadPlanLimits, loadUsage } from "../services/plans.js";

/**
 * Plano de controle da Vértice.
 *
 * Só `platform_admin` entra aqui. Todas as escritas deixam registro em
 * `audit_log` com o `institution_id` da instituição afetada e o ator da
 * Vértice — sem isso não há como provar o que a plataforma fez na conta de
 * um cliente, e essa pergunta vai aparecer no primeiro incidente.
 *
 * Nenhuma rota daqui lê dado de estudante. O painel de plataforma enxerga
 * contagem, plano e estado; não enxerga aluno, métrica nem documento.
 */

const slugSchema = z
  .string()
  .min(2)
  .max(63)
  .regex(/^[a-z0-9][a-z0-9-]{1,62}$/, "Slug só aceita minúsculas, números e hífen");

const createInstitutionSchema = z
  .object({
    slug: slugSchema,
    name: z.string().min(3).max(200),
    cnpj: z.string().max(20).optional(),
    planCode: z.string().min(2).max(40).default("piloto"),
    trialDays: z.number().int().min(0).max(365).optional(),
    adminName: z.string().min(3).max(200),
    adminEmail: z.string().email().max(320),
    /** Retenção padrão; o cliente pode ajustar depois com base no contrato. */
    retentionAlertsDays: z.number().int().positive().nullable().optional(),
    retentionRecordsDays: z.number().int().positive().nullable().optional(),
    retentionAuditDays: z.number().int().positive().nullable().optional(),
  })
  .strict();

const statusSchema = z
  .object({
    status: z.enum(["trial", "active", "past_due", "suspended", "churned"]),
    reason: z.string().min(3).max(500).optional(),
  })
  .strict();

const planSchema = z
  .object({
    planCode: z.string().min(2).max(40),
    reason: z.string().min(3).max(500).optional(),
  })
  .strict();

export async function platformRoutes(app: FastifyInstance): Promise<void> {
  // -------------------------------------------------------------------------
  // Instituições
  // -------------------------------------------------------------------------

  app.get("/v1/platform/institutions", async (request, reply) => {
    await requirePlatformAdmin(request);
    const q = request.query as Record<string, string>;
    const limit = Math.min(Number(q.limit ?? 100), 500);

    const result = await query(
      `SELECT i.id, i.slug, i.name, i.status, i.plan_code, i.trial_ends_at,
              i.activated_at, i.suspended_at, i.created_at,
              (SELECT count(*) FROM memberships m
                WHERE m.institution_id = i.id AND m.revoked_at IS NULL) AS users,
              (SELECT count(*) FROM courses c
                WHERE c.institution_id = i.id AND c.active)            AS courses,
              (SELECT count(*) FROM alerts a
                WHERE a.institution_id = i.id)                         AS alerts
         FROM institutions i
        WHERE ($1::text IS NULL OR i.status = $1)
        ORDER BY i.created_at DESC
        LIMIT $2`,
      [q.status ?? null, limit],
    );

    return reply.send({ institutions: result.rows });
  });

  app.get<{ Params: { id: string } }>("/v1/platform/institutions/:id", async (request, reply) => {
    await requirePlatformAdmin(request);
    const institutionId = platformTargetId(request.params.id);

    const result = await query(
      `SELECT id, slug, name, cnpj, status, plan_code, trial_ends_at, activated_at,
              suspended_at, retention_alerts_days, retention_records_days,
              retention_audit_days, created_at
         FROM institutions WHERE id = $1`,
      [institutionId],
    );
    const institution = result.rows[0];
    if (!institution) throw notFound("Instituição não encontrada");

    const [usage, limits] = await Promise.all([
      loadUsage(institutionId),
      loadPlanLimits(String(institution.plan_code)),
    ]);

    return reply.send({ institution, usage, limits });
  });

  /**
   * Provisionamento: instituição + primeiro administrador + convite.
   *
   * Tudo em uma transação. Se o convite falhar, a instituição não fica
   * criada pela metade — uma IES sem administrador é um registro órfão que
   * ninguém consegue usar nem apagar pela UI.
   */
  app.post("/v1/platform/institutions", async (request, reply) => {
    const claims = await requirePlatformAdmin(request);
    const parsed = createInstitutionSchema.safeParse(request.body);
    if (!parsed.success) throw badRequest(parsed.error.issues[0]?.message ?? "Corpo inválido");
    const data = parsed.data;

    const plan = await query<{ trial_days: number }>(
      `SELECT trial_days FROM plan_limits WHERE plan_code = $1`,
      [data.planCode],
    );
    if (!plan.rowCount) throw badRequest(`Plano desconhecido: ${data.planCode}`);
    const trialDays = data.trialDays ?? plan.rows[0]!.trial_days;

    const existing = await query("SELECT 1 FROM institutions WHERE slug = $1", [data.slug]);
    if (existing.rowCount) throw conflict(`Slug já usado: ${data.slug}`);

    const outcome = await withTransaction(async (client) => {
      const institution = await client.query<{ id: string }>(
        `INSERT INTO institutions
           (slug, name, cnpj, status, plan_code, trial_ends_at,
            retention_alerts_days, retention_records_days, retention_audit_days)
         VALUES ($1, $2, $3, $4, $5, now() + ($6 || ' days')::interval, $7, $8, $9)
         RETURNING id`,
        [
          data.slug,
          data.name,
          data.cnpj ?? null,
          trialDays > 0 ? "trial" : "active",
          data.planCode,
          String(trialDays),
          data.retentionAlertsDays ?? null,
          data.retentionRecordsDays ?? null,
          data.retentionAuditDays ?? null,
        ],
      );
      const institutionId = institution.rows[0]!.id;

      const invite = await createInvite(
        {
          institutionId,
          email: data.adminEmail,
          role: "institution_admin",
          invitedBy: claims.sub,
        },
        client,
      );

      return { institutionId, invite };
    });

    await audit(request, {
      institutionId: outcome.institutionId,
      actorId: claims.sub,
      action: "platform.institution.created",
      resourceType: "institution",
      resourceId: outcome.institutionId,
      metadata: { slug: data.slug, planCode: data.planCode, trialDays },
    });

    return reply.status(201).send({
      id: outcome.institutionId,
      inviteToken: outcome.invite.token,
      inviteExpiresAt: outcome.invite.expiresAt,
      adminEmail: data.adminEmail,
    });
  });

  app.patch<{ Params: { id: string } }>("/v1/platform/institutions/:id/status", async (request, reply) => {
    const claims = await requirePlatformAdmin(request);
    const institutionId = platformTargetId(request.params.id);
    const parsed = statusSchema.safeParse(request.body);
    if (!parsed.success) throw badRequest(parsed.error.issues[0]?.message ?? "Corpo inválido");

    const { status, reason } = parsed.data;
    const result = await query(
      `UPDATE institutions
          SET status       = $2,
              activated_at = CASE WHEN $2 = 'active' THEN coalesce(activated_at, now()) ELSE activated_at END,
              suspended_at = CASE WHEN $2 = 'suspended' THEN now() ELSE NULL END,
              updated_at   = now()
        WHERE id = $1
        RETURNING id, slug, status`,
      [institutionId, status],
    );
    const row = result.rows[0];
    if (!row) throw notFound("Instituição não encontrada");

    await audit(request, {
      institutionId,
      actorId: claims.sub,
      action: `platform.institution.${status}`,
      resourceType: "institution",
      resourceId: institutionId,
      // `reason` é justificativa comercial da Vértice, não dado de cliente.
      metadata: { status, reason: reason ?? null },
    });

    return reply.send({ institution: row });
  });

  app.patch<{ Params: { id: string } }>("/v1/platform/institutions/:id/plan", async (request, reply) => {
    const claims = await requirePlatformAdmin(request);
    const institutionId = platformTargetId(request.params.id);
    const parsed = planSchema.safeParse(request.body);
    if (!parsed.success) throw badRequest(parsed.error.issues[0]?.message ?? "Corpo inválido");

    const exists = await query("SELECT 1 FROM plan_limits WHERE plan_code = $1", [parsed.data.planCode]);
    if (!exists.rowCount) throw badRequest(`Plano desconhecido: ${parsed.data.planCode}`);

    const result = await query(
      `UPDATE institutions SET plan_code = $2, updated_at = now()
        WHERE id = $1 RETURNING id, slug, plan_code`,
      [institutionId, parsed.data.planCode],
    );
    const row = result.rows[0];
    if (!row) throw notFound("Instituição não encontrada");

    await audit(request, {
      institutionId,
      actorId: claims.sub,
      action: "platform.institution.plan_changed",
      resourceType: "institution",
      resourceId: institutionId,
      metadata: { planCode: parsed.data.planCode, reason: parsed.data.reason ?? null },
    });

    return reply.send({ institution: row });
  });

  // -------------------------------------------------------------------------
  // Catálogo de planos
  // -------------------------------------------------------------------------

  app.get("/v1/platform/plans", async (request, reply) => {
    await requirePlatformAdmin(request);
    const result = await query(
      `SELECT plan_code, label, max_users, max_alerts_month, max_storage_mb,
              max_batches_day, max_courses, max_batch_records, trial_days,
              price_brl_monthly, notes
         FROM plan_limits ORDER BY plan_code`,
    );
    return reply.send({ plans: result.rows });
  });

  // -------------------------------------------------------------------------
  // Saúde da plataforma
  //
  // Sem nome de instituição, sem dado de aluno: só contagem agregada. Serve
  // para responder "a plataforma está de pé?" sem abrir o banco.
  // -------------------------------------------------------------------------

  app.get("/v1/platform/overview", async (request, reply) => {
    await requirePlatformAdmin(request);
    const result = await query(
      `SELECT
         (SELECT count(*) FROM institutions WHERE status = 'active')     AS active_institutions,
         (SELECT count(*) FROM institutions WHERE status = 'trial')      AS trial_institutions,
         (SELECT count(*) FROM institutions WHERE status IN ('suspended','past_due'))
                                                                          AS attention_institutions,
         (SELECT count(*) FROM institutions WHERE status = 'trial'
            AND trial_ends_at IS NOT NULL AND trial_ends_at <= now())     AS trials_expired,
         (SELECT count(*) FROM alerts
            WHERE created_at >= date_trunc('day', now()))                 AS alerts_today,
         (SELECT count(*) FROM ingestion_batches
            WHERE created_at >= date_trunc('day', now()))                 AS batches_today`,
    );
    return reply.send({ overview: result.rows[0] });
  });
}
