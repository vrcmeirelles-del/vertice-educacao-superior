import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { withTransaction, query } from "../db/pool.js";
import { assertCourseAccess, canWrite, requireRole, requireTenant } from "../auth/middleware.js";
import { audit } from "../http/audit.js";
import { badRequest, conflict, forbidden, notFound } from "../http/errors.js";

const READ_ROLES = ["platform_admin", "institution_admin", "regulatory_manager", "coordinator"] as const;
const writeSchema = z
  .object({
    status: z.enum(["open", "assigned", "in_progress", "resolved", "dismissed", "snoozed"]),
    note: z.string().max(2000).optional(),
    actionCode: z.string().max(80).optional(),
    snoozedUntil: z.string().datetime({ offset: true }).optional(),
  })
  .strict();

const ALLOWED_TRANSITIONS: Record<string, string[]> = {
  open: ["assigned", "dismissed", "snoozed"],
  assigned: ["in_progress", "dismissed", "snoozed", "open"],
  in_progress: ["resolved", "dismissed", "snoozed"],
  snoozed: ["open", "assigned", "dismissed"],
  resolved: ["open"],
  dismissed: ["open"],
};

export async function alertRoutes(app: FastifyInstance): Promise<void> {
  app.get("/v1/alerts", async (request, reply) => {
    const claims = await requireRole(request, ...READ_ROLES);
    const institutionId = requireTenant(request);
    const q = request.query as Record<string, string>;

    const status = q.status ?? null;
    const courseId = q.courseId ?? null;
    const limit = Math.min(Number(q.limit ?? 50), 200);
    const offset = Math.max(Number(q.offset ?? 0), 0);

    // Coordenador com escopo restrito: filtra no banco, não na aplicação.
    const scope = claims.role === "coordinator" && claims.courseScope.length > 0
      ? claims.courseScope
      : null;

    const result = await query(
      `SELECT a.id, a.score, a.level, a.factors, a.status, a.rule_version,
              a.recommended_action, a.review_required, a.created_at, a.updated_at,
              a.assigned_to, a.snoozed_until,
              c.id AS course_id, c.name AS course_name, c.code AS course_code,
              r.observed_at, r.attendance_percent, r.consecutive_absences,
              r.assessment_average, r.open_requests
         FROM alerts a
         JOIN courses c ON c.id = a.course_id
         JOIN retention_records r ON r.id = a.record_id
        WHERE a.institution_id = $1
          AND ($2::text IS NULL OR a.status = $2)
          AND ($3::uuid IS NULL OR a.course_id = $3)
          AND ($4::uuid[] IS NULL OR a.course_id = ANY($4::uuid[]))
        ORDER BY
          CASE a.level WHEN 'critical' THEN 0 WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END,
          a.created_at DESC
        LIMIT $5 OFFSET $6`,
      [institutionId, status, courseId, scope, limit, offset],
    );

    const counts = await query<{ status: string; total: string }>(
      `SELECT status, count(*)::text AS total
         FROM alerts
        WHERE institution_id = $1
          AND ($2::uuid[] IS NULL OR course_id = ANY($2::uuid[]))
        GROUP BY status`,
      [institutionId, scope],
    );

    return reply.send({
      alerts: result.rows,
      countsByStatus: Object.fromEntries(counts.rows.map((r) => [r.status, Number(r.total)])),
      pagination: { limit, offset },
    });
  });

  app.get<{ Params: { id: string } }>("/v1/alerts/:id", async (request, reply) => {
    await requireRole(request, ...READ_ROLES);
    const institutionId = requireTenant(request);

    const alert = await query(
      `SELECT a.*, c.name AS course_name, c.code AS course_code,
              rs.version AS ruleset_version,
              r.observed_at, r.attendance_percent, r.consecutive_absences,
              r.assessment_average, r.passing_average, r.open_requests, r.source
         FROM alerts a
         JOIN courses c ON c.id = a.course_id
         JOIN retention_records r ON r.id = a.record_id
         LEFT JOIN rulesets rs ON rs.id = a.ruleset_id
        WHERE a.id = $1 AND a.institution_id = $2`,
      [request.params.id, institutionId],
    );
    const row = alert.rows[0];
    if (!row) throw notFound("Alerta não encontrado");

    const events = await query(
      `SELECT e.id, e.type, e.action_code, e.note, e.outcome, e.created_at,
              u.name AS actor_name
         FROM alert_events e
         LEFT JOIN users u ON u.id = e.actor_id
        WHERE e.alert_id = $1 AND e.institution_id = $2
        ORDER BY e.created_at ASC`,
      [request.params.id, institutionId],
    );

    return reply.send({ alert: row, timeline: events.rows });
  });

  /** Transições do fluxo de atendimento humano. */
  app.patch<{ Params: { id: string } }>("/v1/alerts/:id", async (request, reply) => {
    const claims = await requireRole(request, ...READ_ROLES);
    const institutionId = requireTenant(request);
    if (!canWrite(claims.role)) throw forbidden("Seu perfil é somente leitura");

    const parsed = writeSchema.safeParse(request.body);
    if (!parsed.success) throw badRequest(parsed.error.issues[0]?.message ?? "Corpo inválido");

    const current = await query<{ status: string; course_id: string }>(
      "SELECT status, course_id FROM alerts WHERE id = $1 AND institution_id = $2",
      [request.params.id, institutionId],
    );
    const alert = current.rows[0];
    if (!alert) throw notFound("Alerta não encontrado");
    assertCourseAccess(request, alert.course_id);

    const allowed = ALLOWED_TRANSITIONS[alert.status] ?? [];
    if (!allowed.includes(parsed.data.status)) {
      throw conflict(`Transição não permitida: ${alert.status} → ${parsed.data.status}`);
    }
    if (parsed.data.status === "snoozed" && !parsed.data.snoozedUntil) {
      throw badRequest("Informe snoozedUntil ao adiar o alerta");
    }

    const eventType =
      parsed.data.status === "resolved" ? "resolved"
      : parsed.data.status === "dismissed" ? "dismissed"
      : parsed.data.status === "snoozed" ? "snoozed"
      : parsed.data.status === "open" ? "reopened"
      : "assigned";

    await withTransaction(async (client) => {
      await client.query(
        `UPDATE alerts
            SET status = $2,
                assigned_to = CASE WHEN $2 IN ('assigned','in_progress') THEN $3 ELSE assigned_to END,
                snoozed_until = $4,
                updated_at = now()
          WHERE id = $1 AND institution_id = $5`,
        [
          request.params.id,
          parsed.data.status,
          claims.sub,
          parsed.data.snoozedUntil ? new Date(parsed.data.snoozedUntil) : null,
          institutionId,
        ],
      );

      await client.query(
        `INSERT INTO alert_events
           (institution_id, alert_id, actor_id, type, action_code, note, outcome)
         VALUES ($1,$2,$3,$4,$5,$6,$7)`,
        [
          institutionId,
          request.params.id,
          claims.sub,
          eventType,
          parsed.data.actionCode ?? null,
          parsed.data.note ?? null,
          parsed.data.status,
        ],
      );
    });

    await audit(request, {
      institutionId,
      actorId: claims.sub,
      action: "alert.transition",
      resourceType: "alert",
      resourceId: request.params.id,
      metadata: { from: alert.status, to: parsed.data.status },
    });

    return reply.send({ ok: true, status: parsed.data.status });
  });

  /** Resumo para o painel: distribuição por nível e curso. */
  app.get("/v1/alerts/summary", async (request, reply) => {
    const claims = await requireRole(request, ...READ_ROLES);
    const institutionId = requireTenant(request);

    const byLevel = await query(
      `SELECT level, count(*)::int AS total
         FROM alerts
        WHERE institution_id = $1 AND status NOT IN ('resolved','dismissed')
        GROUP BY level`,
      [institutionId],
    );

    const byCourse = await query(
      `SELECT c.id, c.name,
              count(*) FILTER (WHERE a.level IN ('critical','high'))::int AS urgent,
              count(*)::int AS total
         FROM alerts a
         JOIN courses c ON c.id = a.course_id
        WHERE a.institution_id = $1 AND a.status NOT IN ('resolved','dismissed')
        GROUP BY c.id, c.name
        ORDER BY urgent DESC, total DESC`,
      [institutionId],
    );

    const openAssignments = await query(
      `SELECT count(*)::int AS total
         FROM alerts
        WHERE institution_id = $1 AND status IN ('open')`,
      [institutionId],
    );

    return reply.send({
      byLevel: Object.fromEntries(byLevel.rows.map((r) => [r.level, r.total])),
      byCourse: byCourse.rows,
      unassigned: openAssignments.rows[0]?.total ?? 0,
      scope: claims.courseScope,
    });
  });
}
