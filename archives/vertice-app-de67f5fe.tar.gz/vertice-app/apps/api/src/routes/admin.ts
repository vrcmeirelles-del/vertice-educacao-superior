import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { calculateDate } from "../utils/date.js";
import { query, withTransaction } from "../db/pool.js";
import { canWrite, requireRole, requireTenant } from "../auth/middleware.js";
import { audit } from "../http/audit.js";
import { badRequest, forbidden, notFound } from "../http/errors.js";
import { newPairingToken } from "../auth/tokens.js";
import { hashPassword } from "../auth/password.js";
import { createRulesetVersion, listRulesets } from "../services/rulesets.js";
import { hashStudentRef } from "../domain/pseudonymize.js";
import { sha256 } from "../auth/middleware.js";
import { createInvite, listPendingInvites, revokeInvite } from "../services/invites.js";
import {
  assertInstitutionCanWrite,
  assertQuota,
  institutionSummary,
} from "../services/plans.js";

const ADMIN_ROLES = ["platform_admin", "institution_admin"] as const;
const READ_ROLES = [
  "platform_admin",
  "institution_admin",
  "regulatory_manager",
  "coordinator",
  "auditor_readonly",
  "privacy_officer",
] as const;
const PRIVACY_ROLES = ["platform_admin", "institution_admin", "privacy_officer"] as const;

export async function adminRoutes(app: FastifyInstance): Promise<void> {
  // -------------------------------------------------------------------------
  // Cursos
  // -------------------------------------------------------------------------

  /**
   * Estado do plano da instituição do usuário: status, limites e uso.
   * É o que a UI lê para mostrar "trial termina em X dias" e as barras de cota.
   */
  app.get("/v1/institution/plan", async (request, reply) => {
    await requireRole(request, ...READ_ROLES);
    const institutionId = requireTenant(request);
    return reply.send(await institutionSummary(institutionId));
  });

  app.get("/v1/courses", async (request, reply) => {
    const claims = await requireRole(request, "platform_admin", "institution_admin", "regulatory_manager", "coordinator");
    const institutionId = requireTenant(request);

    const result = await query(
      `SELECT id, code, name, campus, active
         FROM courses
        WHERE institution_id = $1
        ORDER BY name`,
      [institutionId],
    );

    const scoped =
      claims.role === "coordinator" && claims.courseScope.length > 0
        ? result.rows.filter((row) => claims.courseScope.includes((row as { id: string }).id))
        : result.rows;

    return reply.send({ courses: scoped });
  });

  app.post("/v1/courses", async (request, reply) => {
    const claims = await requireRole(request, ...ADMIN_ROLES);
    const institutionId = requireTenant(request);

    const parsed = z
      .object({
        code: z.string().min(1).max(64).regex(/^[A-Za-z0-9._:-]+$/),
        name: z.string().min(3).max(200),
        campus: z.string().max(120).optional(),
      })
      .strict()
      .safeParse(request.body);
    if (!parsed.success) throw badRequest(parsed.error.issues[0]?.message ?? "Corpo inválido");

    const inserted = await query<{ id: string }>(
      `INSERT INTO courses (institution_id, code, name, campus)
       VALUES ($1,$2,$3,$4) RETURNING id`,
      [institutionId, parsed.data.code, parsed.data.name, parsed.data.campus ?? null],
    );

    await audit(request, {
      institutionId,
      actorId: claims.sub,
      action: "course.create",
      resourceType: "course",
      resourceId: inserted.rows[0]!.id,
    });

    return reply.status(201).send({ id: inserted.rows[0]!.id });
  });

  // -------------------------------------------------------------------------
  // Usuários e papéis
  // -------------------------------------------------------------------------

  app.get("/v1/users", async (request, reply) => {
    await requireRole(request, ...ADMIN_ROLES);
    const institutionId = requireTenant(request);

    const result = await query(
      `SELECT u.id, u.name, u.email, u.is_active, u.last_login_at,
              m.role, m.course_scope, m.expires_at
         FROM memberships m
         JOIN users u ON u.id = m.user_id
        WHERE m.institution_id = $1 AND m.revoked_at IS NULL
        ORDER BY u.name`,
      [institutionId],
    );
    return reply.send({ users: result.rows });
  });

  /**
   * Convite de acesso.
   *
   * Substitui a criação de usuário com senha digitada pelo administrador. O
   * token é devolvido uma única vez; quem convidou entrega por canal seguro.
   * Quando houver provedor de e-mail, o envio entra em `createInvite` e esta
   * rota continua igual.
   */
  app.post("/v1/users/invites", async (request, reply) => {
    const claims = await requireRole(request, ...ADMIN_ROLES);
    const institutionId = requireTenant(request);

    const parsed = z
      .object({
        name: z.string().min(3).max(200).optional(),
        email: z.string().email().max(320),
        role: z.enum([
          "institution_admin",
          "regulatory_manager",
          "coordinator",
          "auditor_readonly",
          "privacy_officer",
        ]),
        courseScope: z.array(z.string().uuid()).max(100).optional(),
        expiresAt: z.string().datetime({ offset: true }).optional(),
      })
      .strict()
      .safeParse(request.body);
    if (!parsed.success) throw badRequest(parsed.error.issues[0]?.message ?? "Corpo inválido");

    await assertInstitutionCanWrite(institutionId, claims.role);
    await assertQuota(institutionId, "maxUsers");

    const invite = await createInvite({
      institutionId,
      email: parsed.data.email,
      role: parsed.data.role,
      courseScope: parsed.data.courseScope,
      expiresAt: parsed.data.expiresAt ?? null,
      invitedBy: claims.sub,
    });

    await audit(request, {
      institutionId,
      actorId: claims.sub,
      action: "user.invited",
      resourceType: "user_invite",
      resourceId: invite.id,
      metadata: { role: parsed.data.role },
    });

    return reply.status(201).send({
      id: invite.id,
      email: parsed.data.email,
      role: parsed.data.role,
      expiresAt: invite.expiresAt,
      // Devolvido aqui e só aqui: não é recuperável depois.
      inviteToken: invite.token,
    });
  });

  app.get("/v1/users/invites", async (request, reply) => {
    await requireRole(request, ...ADMIN_ROLES);
    const institutionId = requireTenant(request);
    return reply.send({ invites: await listPendingInvites(institutionId) });
  });

  app.delete<{ Params: { id: string } }>("/v1/users/invites/:id", async (request, reply) => {
    const claims = await requireRole(request, ...ADMIN_ROLES);
    const institutionId = requireTenant(request);
    await revokeInvite(institutionId, request.params.id);
    await audit(request, {
      institutionId,
      actorId: claims.sub,
      action: "user.invite_revoked",
      resourceType: "user_invite",
      resourceId: request.params.id,
    });
    return reply.send({ ok: true });
  });

  app.post("/v1/users", async (request, reply) => {
    const claims = await requireRole(request, ...ADMIN_ROLES);
    const institutionId = requireTenant(request);

    const parsed = z
      .object({
        name: z.string().min(3).max(200),
        email: z.string().email().max(320),
        password: z.string().min(12).max(200),
        role: z.enum([
          "institution_admin",
          "regulatory_manager",
          "coordinator",
          "auditor_readonly",
          "privacy_officer",
        ]),
        courseScope: z.array(z.string().uuid()).max(100).optional(),
        expiresAt: z.string().datetime({ offset: true }).optional(),
      })
      .strict()
      .safeParse(request.body);
    if (!parsed.success) throw badRequest(parsed.error.issues[0]?.message ?? "Corpo inválido");

    if (parsed.data.role === "auditor_readonly" && !parsed.data.expiresAt) {
      throw badRequest("Auditor temporário exige data de expiração");
    }

    await assertInstitutionCanWrite(institutionId, claims.role);
    // Conta só quem está ativo: auditor expirado não ocupa assento.
    await assertQuota(institutionId, "maxUsers");

    const passwordHash = await hashPassword(parsed.data.password);

    const userId = await withTransaction(async (client) => {
      const user = await client.query<{ id: string }>(
        `INSERT INTO users (email, name, password_hash)
         VALUES (lower($1),$2,$3)
         ON CONFLICT (email) DO UPDATE SET name = EXCLUDED.name, updated_at = now()
         RETURNING id`,
        [parsed.data.email, parsed.data.name, passwordHash],
      );
      const id = user.rows[0]!.id;

      await client.query(
        `INSERT INTO memberships (user_id, institution_id, role, course_scope, expires_at)
         VALUES ($1,$2,$3,$4::uuid[],$5)
         ON CONFLICT (user_id, institution_id, role)
         DO UPDATE SET course_scope = EXCLUDED.course_scope,
                       expires_at = EXCLUDED.expires_at,
                       revoked_at = NULL`,
        [
          id,
          institutionId,
          parsed.data.role,
          parsed.data.courseScope ?? [],
          parsed.data.expiresAt ?? null,
        ],
      );
      return id;
    });

    await audit(request, {
      institutionId,
      actorId: claims.sub,
      action: "user.upsert",
      resourceType: "user",
      resourceId: userId,
      metadata: { role: parsed.data.role },
    });

    return reply.status(201).send({ id: userId });
  });

  app.delete<{ Params: { id: string } }>("/v1/users/:id", async (request, reply) => {
    const claims = await requireRole(request, ...ADMIN_ROLES);
    const institutionId = requireTenant(request);

    const removed = await query(
      `UPDATE memberships SET revoked_at = now()
        WHERE user_id = $1 AND institution_id = $2 AND revoked_at IS NULL
        RETURNING id`,
      [request.params.id, institutionId],
    );
    if (!removed.rowCount) throw notFound("Vínculo não encontrado");

    await query("DELETE FROM revoked_sessions WHERE user_id = $1", [request.params.id]).catch(() => undefined);
    await audit(request, {
      institutionId,
      actorId: claims.sub,
      action: "membership.revoke",
      resourceType: "user",
      resourceId: request.params.id,
    });

    return reply.send({ ok: true });
  });

  // -------------------------------------------------------------------------
  // Regras de risco
  // -------------------------------------------------------------------------

  app.get("/v1/rulesets", async (request, reply) => {
    await requireRole(request, ...ADMIN_ROLES);
    const institutionId = requireTenant(request);
    return reply.send({ rulesets: await listRulesets(institutionId) });
  });

  app.post("/v1/rulesets", async (request, reply) => {
    const claims = await requireRole(request, ...ADMIN_ROLES);
    const institutionId = requireTenant(request);

    const parsed = z
      .object({
        courseId: z.string().uuid().nullable().optional(),
        rules: z
          .object({
            attendanceThreshold: z.number().min(0).max(100).optional(),
            attendanceWeight: z.number().int().min(0).max(100).optional(),
            consecutiveAbsenceThreshold: z.number().int().min(0).max(365).optional(),
            consecutiveAbsenceWeight: z.number().int().min(0).max(100).optional(),
            lowAssessmentWeight: z.number().int().min(0).max(100).optional(),
            exitRequestWeight: z.number().int().min(0).max(100).optional(),
          })
          .strict(),
      })
      .strict()
      .safeParse(request.body);
    if (!parsed.success) throw badRequest(parsed.error.issues[0]?.message ?? "Corpo inválido");

    const created = await createRulesetVersion(institutionId, {
      courseId: parsed.data.courseId ?? null,
      rules: parsed.data.rules,
      createdBy: claims.sub,
    });

    await audit(request, {
      institutionId,
      actorId: claims.sub,
      action: "ruleset.publish",
      resourceType: "ruleset",
      resourceId: (created as { id: string }).id,
      metadata: { courseId: parsed.data.courseId ?? null },
    });

    return reply.status(201).send(created);
  });

  // -------------------------------------------------------------------------
  // Extensão: tokens de pareamento
  // -------------------------------------------------------------------------

  app.post("/v1/pairing-tokens", async (request, reply) => {
    const claims = await requireRole(request, ...ADMIN_ROLES);
    const institutionId = requireTenant(request);

    const parsed = z
      .object({
        label: z.string().min(3).max(120),
        ttlMinutes: z.number().int().min(5).max(1440).optional(),
      })
      .strict()
      .safeParse(request.body);
    if (!parsed.success) throw badRequest(parsed.error.issues[0]?.message ?? "Corpo inválido");

    const token = newPairingToken();
    const ttl = parsed.data.ttlMinutes ?? 60;

    await query(
      `INSERT INTO pairing_tokens (institution_id, token_hash, label, created_by, expires_at)
       VALUES ($1,$2,$3,$4, now() + ($5 || ' minutes')::interval)`,
      [institutionId, sha256(token), parsed.data.label, claims.sub, String(ttl)],
    );

    await audit(request, {
      institutionId,
      actorId: claims.sub,
      action: "pairing_token.create",
      resourceType: "pairing_token",
      metadata: { label: parsed.data.label, ttlMinutes: ttl },
    });

    // O token em claro aparece uma única vez, na criação.
    return reply.status(201).send({ token, expiresInMinutes: ttl });
  });

  app.get("/v1/pairing-tokens", async (request, reply) => {
    await requireRole(request, ...ADMIN_ROLES);
    const institutionId = requireTenant(request);

    const result = await query(
      `SELECT id, label, expires_at, revoked_at, last_used_at, created_at
         FROM pairing_tokens
        WHERE institution_id = $1
        ORDER BY created_at DESC
        LIMIT 50`,
      [institutionId],
    );
    return reply.send({ tokens: result.rows });
  });

  app.delete<{ Params: { id: string } }>("/v1/pairing-tokens/:id", async (request, reply) => {
    const claims = await requireRole(request, ...ADMIN_ROLES);
    const institutionId = requireTenant(request);

    await query(
      "UPDATE pairing_tokens SET revoked_at = now() WHERE id = $1 AND institution_id = $2",
      [request.params.id, institutionId],
    );
    await audit(request, {
      institutionId,
      actorId: claims.sub,
      action: "pairing_token.revoke",
      resourceType: "pairing_token",
      resourceId: request.params.id,
    });
    return reply.send({ ok: true });
  });

  // -------------------------------------------------------------------------
  // LGPD
  // -------------------------------------------------------------------------

  app.post("/v1/privacy/requests", async (request, reply) => {
    const claims = await requireRole(request, ...PRIVACY_ROLES);
    const institutionId = requireTenant(request);
    if (!canWrite(claims.role)) throw forbidden();

    const parsed = z
      .object({
        requestType: z.enum(["access", "correction", "deletion", "anonymization", "export"]),
        studentRef: z.string().min(2).max(128).regex(/^[A-Za-z0-9._:-]+$/),
      })
      .strict()
      .safeParse(request.body);
    if (!parsed.success) throw badRequest(parsed.error.issues[0]?.message ?? "Corpo inválido");

    const inserted = await query<{ id: string }>(
      `INSERT INTO data_subject_requests (institution_id, request_type, student_ref_hash)
       VALUES ($1,$2,$3) RETURNING id`,
      [institutionId, parsed.data.requestType, hashStudentRef(parsed.data.studentRef)],
    );

    await audit(request, {
      institutionId,
      actorId: claims.sub,
      action: "privacy.request",
      resourceType: "data_subject_request",
      resourceId: inserted.rows[0]!.id,
      metadata: { requestType: parsed.data.requestType },
    });

    return reply.status(201).send({ id: inserted.rows[0]!.id });
  });

  /**
   * Executa a expurgação conforme a política da IES. Não apaga auditoria
   * (obrigação legal) — apenas dados operacionais.
   */
  app.post("/v1/privacy/purge", async (request, reply) => {
    const claims = await requireRole(request, "platform_admin", "institution_admin", "privacy_officer");
    const institutionId = requireTenant(request);

    const parsed = z
      .object({ confirm: z.literal(true), scope: z.enum(["alerts", "records", "both"]) })
      .strict()
      .safeParse(request.body);
    if (!parsed.success) throw badRequest("Confirmação explícita é obrigatória");

    const policy = await query<{
      retention_alerts_days: number | null;
      retention_records_days: number | null;
    }>(
      "SELECT retention_alerts_days, retention_records_days FROM institutions WHERE id = $1",
      [institutionId],
    );
    const row = policy.rows[0];
    if (!row) throw notFound("Instituição não encontrada");

    const result: Record<string, number> = {};

    if ((parsed.data.scope === "alerts" || parsed.data.scope === "both") && row.retention_alerts_days) {
      const deleted = await query(
        `DELETE FROM alerts
          WHERE institution_id = $1
            AND created_at < $2`,
        [institutionId, calculateDate(row.retention_alerts_days)],
      );
      result.alerts = deleted.rowCount ?? 0;
    }

    if ((parsed.data.scope === "records" || parsed.data.scope === "both") && row.retention_records_days) {
      const deleted = await query(
        `DELETE FROM retention_records
          WHERE institution_id = $1
            AND created_at < $2
            AND id NOT IN (SELECT record_id FROM alerts WHERE institution_id = $1)`,
        [institutionId, calculateDate(row.retention_records_days)],
      );
      result.records = deleted.rowCount ?? 0;
    }

    await audit(request, {
      institutionId,
      actorId: claims.sub,
      action: "privacy.purge",
      resourceType: "institution",
      resourceId: institutionId,
      metadata: { scope: parsed.data.scope, ...result },
    });

    return reply.send({ ok: true, deleted: result });
  });

  app.get("/v1/audit", async (request, reply) => {
    await requireRole(request, "platform_admin", "institution_admin", "auditor_readonly", "privacy_officer");
    const institutionId = requireTenant(request);
    const q = request.query as Record<string, string>;
    const limit = Math.min(Number(q.limit ?? 100), 500);

    const result = await query(
      `SELECT a.created_at, a.action, a.resource_type, a.resource_id,
              a.outcome, a.ip, a.metadata, u.name AS actor_name, u.email AS actor_email
         FROM audit_log a
         LEFT JOIN users u ON u.id = a.actor_id
        WHERE a.institution_id = $1
          AND ($2::text IS NULL OR a.action LIKE $2 || '%')
        ORDER BY a.created_at DESC
        LIMIT $3`,
      [institutionId, q.action ?? null, limit],
    );

    return reply.send({ events: result.rows });
  });
}
