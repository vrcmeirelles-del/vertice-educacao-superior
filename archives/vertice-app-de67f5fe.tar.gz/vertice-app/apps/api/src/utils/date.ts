/** Data de corte "agora menos N dias", para políticas de retenção. */
export function calculateDate(daysAgo: number): Date {
  const date = new Date();
  date.setUTCDate(date.getUTCDate() - daysAgo);
  return date;
}
