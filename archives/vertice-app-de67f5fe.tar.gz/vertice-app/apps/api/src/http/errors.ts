/** Erro de aplicação com status HTTP e código estável para a UI. */
export class AppError extends Error {
  constructor(
    public override readonly message: string,
    public readonly statusCode: number = 400,
    public readonly code: string = "bad_request",
    public readonly details?: unknown,
  ) {
    super(message);
    this.name = "AppError";
  }
}

export const badRequest = (message: string, details?: unknown) =>
  new AppError(message, 400, "invalid_request", details);

export const unauthorized = (message = "Autenticação necessária") =>
  new AppError(message, 401, "unauthorized");

export const forbidden = (message = "Acesso negado") =>
  new AppError(message, 403, "forbidden");

export const notFound = (message = "Recurso não encontrado") =>
  new AppError(message, 404, "not_found");

export const conflict = (message: string) => new AppError(message, 409, "conflict");

export const tooManyRequests = (message = "Limite de requisições excedido") =>
  new AppError(message, 429, "rate_limited");
