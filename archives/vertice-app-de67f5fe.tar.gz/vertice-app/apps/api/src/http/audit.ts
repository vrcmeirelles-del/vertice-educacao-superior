import type { FastifyRequest } from "fastify";
import { query } from "../db/pool.js";

export type AuditOutcome = "success" | "denied" | "error";

export interface AuditEntry {
  institutionId: string | null;
  actorId: string | null;
  actorKind?: "user" | "system" | "extension";
  action: string;
  resourceType: string;
  resourceId?: string | null;
  outcome?: AuditOutcome;
  /** Metadados operacionais. NUNCA incluir notas, nomes ou texto do aluno. */
  metadata?: Record<string, unknown>;
}

/**
 * Grava um evento de auditoria. Falhas aqui não derrubam a requisição de
 * negócio, mas são registradas no stderr para alerta operacional.
 */
export async function audit(request: FastifyRequest | null, entry: AuditEntry): Promise<void> {
  try {
    await query(
      `INSERT INTO audit_log
         (institution_id, actor_id, actor_kind, action, resource_type, resource_id,
          outcome, ip, user_agent, metadata)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
      [
        entry.institutionId,
        entry.actorId,
        entry.actorKind ?? "user",
        entry.action,
        entry.resourceType,
        entry.resourceId ?? null,
        entry.outcome ?? "success",
        request?.ip ?? null,
        request?.headers["user-agent"]?.slice(0, 300) ?? null,
        JSON.stringify(entry.metadata ?? {}),
      ],
    );
  } catch (error) {
    console.error("[audit] falha ao registrar evento", error);
  }
}
