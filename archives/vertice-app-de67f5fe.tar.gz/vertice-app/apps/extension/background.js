/**
 * Service worker da extensão.
 *
 * Regras invioláveis (ver docs/SEGURANCA-E-LGPD.md):
 *  - a leitura só ocorre após clique explícito do usuário no popup;
 *  - nenhuma navegação automática, nenhum laço por telas;
 *  - nenhuma senha é lida ou armazenada;
 *  - somente seletores declarados pelo adaptador são consultados;
 *  - em caso de layout desconhecido, aborta sem enviar nada da página.
 */

import { ADAPTERS, findAdapterFor } from "./adapters.js";

const DEFAULTS = {
  apiBaseUrl: "http://localhost:8787",
  pairingToken: "",
  adapterId: "auto",
};

async function getSettings() {
  return chrome.storage.local.get(DEFAULTS);
}

/**
 * Executada no contexto da página (mundo ISOLATED). Não acessa rede.
 * Recebe o adaptador serializado — nunca código arbitrário da página.
 */
function extractWithAdapter(adapter) {
  const root = document.querySelector(adapter.rootSelector);
  if (!root) {
    return {
      ok: false,
      code: "LAYOUT_NOT_RECOGNIZED",
      message:
        "Layout não reconhecido. O operador deve revisar o mapeamento e publicar uma nova versão do adaptador.",
    };
  }

  const num = (value, min, max) => {
    if (value == null || value === "") return null;
    const parsed = Number(String(value).replace(",", ".").replace(/[^\d.-]/g, ""));
    return Number.isFinite(parsed) && parsed >= min && parsed <= max ? parsed : null;
  };

  const int = (value, min, max) => {
    if (value == null || value === "") return null;
    const parsed = Number.parseInt(String(value).replace(/[^\d]/g, ""), 10);
    return Number.isInteger(parsed) && parsed >= min && parsed <= max ? parsed : null;
  };

  const allowed = new Set([
    "TRANSFER_REQUEST",
    "WITHDRAWAL_REQUEST",
    "HISTORY_REQUEST",
    "SYLLABUS_REQUEST",
    "OTHER",
  ]);

  const rows = Array.from(root.querySelectorAll(adapter.rowSelector));
  if (rows.length === 0) {
    return {
      ok: false,
      code: "NO_ROWS_FOUND",
      message: "Layout reconhecido, mas nenhuma linha de aluno foi encontrada nesta tela.",
    };
  }

  let unmapped = 0;
  const records = [];

  for (const row of rows) {
    const read = (selector) => {
      if (!selector) return null;
      const el = row.querySelector(selector);
      return el ? el.getAttribute(adapter.valueAttribute) ?? el.textContent : null;
    };

    const studentRef = read(adapter.fields.studentRef);
    const courseRaw = read(adapter.fields.courseRef);

    if (!studentRef || !courseRaw) {
      unmapped += 1;
      continue;
    }

    const courseRef = adapter.courseMap?.[courseRaw.trim()] ?? courseRaw.trim();
    const requests = (read(adapter.fields.openRequests) ?? "")
      .split(adapter.requestsSeparator ?? ",")
      .map((value) => value.trim().toUpperCase())
      .filter((value) => allowed.has(value));

    records.push({
      studentRef: studentRef.trim(),
      courseRef,
      attendancePercent: num(read(adapter.fields.attendancePercent), 0, 100),
      consecutiveAbsences: int(read(adapter.fields.consecutiveAbsences), 0, 365),
      assessmentAverage: num(read(adapter.fields.assessmentAverage), 0, 10),
      passingAverage: num(read(adapter.fields.passingAverage), 0, 10),
      openRequests: requests,
      observedAt: new Date().toISOString(),
      source: `portal-adapter:${adapter.id}`,
    });
  }

  // Defesa em profundidade: só passa o que casa com o contrato de referência.
  const safe = records.filter(
    (record) =>
      /^[A-Za-z0-9._:-]{2,128}$/.test(record.studentRef) &&
      /^[A-Za-z0-9._:-]{1,128}$/.test(record.courseRef),
  );

  if (safe.length === 0) {
    return {
      ok: false,
      code: "NO_SAFE_RECORDS",
      message: "As linhas encontradas não têm identificadores pseudonimizados válidos.",
      totalFound: rows.length,
    };
  }

  return {
    ok: true,
    records: safe,
    totalFound: rows.length,
    totalAccepted: safe.length,
    skipped: unmapped + (records.length - safe.length),
  };
}

async function readCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !tab.url) {
    return { ok: false, code: "NO_ACTIVE_TAB", message: "Aba ativa não encontrada." };
  }

  const settings = await getSettings();
  const adapter =
    settings.adapterId === "auto"
      ? findAdapterFor(tab.url)
      : ADAPTERS.find((item) => item.id === settings.adapterId);

  if (!adapter) {
    return {
      ok: false,
      code: "ADAPTER_NOT_CONFIGURED",
      message: "Nenhum adaptador autorizado para este domínio.",
    };
  }

  let execution;
  try {
    execution = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractWithAdapter,
      args: [adapter],
    });
  } catch (error) {
    return {
      ok: false,
      code: "INJECTION_FAILED",
      message: "Não foi possível ler a página. Recarregue a aba e tente novamente.",
    };
  }

  return execution?.[0]?.result ?? { ok: false, code: "EMPTY_RESULT" };
}

async function sendRecords(records) {
  const settings = await getSettings();
  if (!settings.pairingToken) {
    return { ok: false, code: "MISSING_TOKEN", message: "Informe o token de pareamento." };
  }

  const endpoint = `${settings.apiBaseUrl.replace(/\/+$/, "")}/v1/ingestions/extension`;

  let response;
  try {
    response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${settings.pairingToken}`,
      },
      body: JSON.stringify({ records }),
    });
  } catch {
    return {
      ok: false,
      code: "NETWORK_ERROR",
      message: "Falha de rede ao contatar a API. Verifique a URL configurada.",
    };
  }

  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    return {
      ok: false,
      code: "API_ERROR",
      status: response.status,
      message: payload.message ?? payload.error ?? "A API recusou o lote.",
    };
  }

  return { ok: true, ...payload };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "READ_AND_SEND") {
    readCurrentTab()
      .then(async (extracted) => {
        if (!extracted?.ok) return extracted;
        const result = await sendRecords(extracted.records);
        return { ...result, totalFound: extracted.totalFound, skipped: extracted.skipped };
      })
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, code: "UNEXPECTED", message: error.message }));
    return true;
  }

  if (message?.type === "PREVIEW_ONLY") {
    readCurrentTab()
      .then((extracted) => {
        if (!extracted?.ok) return extracted;
        return {
          ok: true,
          preview: extracted.records.slice(0, 5).map((record) => ({
            studentRef: record.studentRef,
            courseRef: record.courseRef,
            attendancePercent: record.attendancePercent,
            consecutiveAbsences: record.consecutiveAbsences,
          })),
          totalAccepted: extracted.totalAccepted,
          totalFound: extracted.totalFound,
          skipped: extracted.skipped,
        };
      })
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, code: "UNEXPECTED", message: error.message }));
    return true;
  }

  return undefined;
});
