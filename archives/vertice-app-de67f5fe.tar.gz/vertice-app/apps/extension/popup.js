const $ = (id) => document.getElementById(id);

const MESSAGES = {
  ADAPTER_NOT_CONFIGURED: "Nenhum adaptador autorizado para este domínio.",
  LAYOUT_NOT_RECOGNIZED: "Layout não reconhecido. Nada foi enviado.",
  NO_ROWS_FOUND: "Nenhuma linha de aluno encontrada nesta tela.",
  NO_SAFE_RECORDS: "Nenhum identificador pseudonimizado válido encontrado.",
  MISSING_TOKEN: "Informe o token de pareamento.",
  NETWORK_ERROR: "Falha de rede. Verifique a URL da API.",
};

function show(text, kind = "") {
  const el = $("result");
  el.className = kind;
  el.textContent = text;
}

async function load() {
  const settings = await chrome.storage.local.get({
    apiBaseUrl: "http://localhost:8787",
    pairingToken: "",
  });
  $("api").value = settings.apiBaseUrl;
  $("token").value = settings.pairingToken;
}

async function save() {
  const apiBaseUrl = $("api").value.trim().replace(/\/+$/, "");
  const pairingToken = $("token").value.trim();

  if (apiBaseUrl && !/^https?:\/\//.test(apiBaseUrl)) {
    show("A URL da API deve começar com http:// ou https://", "err");
    return false;
  }
  await chrome.storage.local.set({ apiBaseUrl, pairingToken });
  show("Configuração salva.", "ok");
  return true;
}

document.addEventListener("DOMContentLoaded", () => {
  load();

  $("save").addEventListener("click", save);

  $("preview").addEventListener("click", async () => {
    show("Lendo a aba atual…");
    const result = await chrome.runtime.sendMessage({ type: "PREVIEW_ONLY" });
    if (!result?.ok) {
      show(MESSAGES[result?.code] ?? result?.message ?? "Falha na leitura.", "err");
      return;
    }
    const rows = result.preview
      .map(
        (row) =>
          `<tr><td>${escapeHtml(row.studentRef)}</td><td>${escapeHtml(row.courseRef)}</td>` +
          `<td>${row.attendancePercent ?? "—"}</td><td>${row.consecutiveAbsences ?? "—"}</td></tr>`,
      )
      .join("");
    $("result").className = "ok";
    $("result").innerHTML =
      `Encontrados ${result.totalFound}, aceitos ${result.totalAccepted}, ignorados ${result.skipped}.` +
      `<table><thead><tr><th>Ref.</th><th>Curso</th><th>Freq.</th><th>Faltas</th></tr></thead>` +
      `<tbody>${rows}</tbody></table>` +
      (result.totalAccepted > 5 ? `<p>Exibindo 5 de ${result.totalAccepted}.</p>` : "");
  });

  $("send").addEventListener("click", async () => {
    const saved = await save();
    if (!saved) return;

    $("send").disabled = true;
    show("Lendo e enviando…");
    try {
      const result = await chrome.runtime.sendMessage({ type: "READ_AND_SEND" });
      if (!result?.ok) {
        show(MESSAGES[result?.code] ?? result?.message ?? "Falha no envio.", "err");
        return;
      }
      const parts = [
        `Aceitos: ${result.accepted}`,
        `Rejeitados: ${result.rejected ?? 0}`,
        `Alertas gerados: ${result.alertsCreated ?? 0}`,
      ];
      if (result.unknownCourses?.length) {
        parts.push(`Cursos não cadastrados: ${result.unknownCourses.join(", ")}`);
      }
      show(parts.join("\n"), "ok");
    } finally {
      $("send").disabled = false;
    }
  });
});

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char],
  );
}
