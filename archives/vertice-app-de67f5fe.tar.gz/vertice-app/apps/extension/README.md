# Extensão Vértice — leitura autorizada

Manifest V3. Lê **somente a aba atual**, após clique do usuário, e envia os campos mínimos
pseudonimizados para a API.

## Permissões e por que existem

| Permissão | Motivo | O que não faz |
|---|---|---|
| `activeTab` | acesso temporário à aba em que o usuário clicou | não concede acesso a outros sites |
| `scripting` | injetar o leitor na aba ativa sob clique | não injeta automaticamente |
| `storage` | guardar URL da API e token de pareamento | não guarda senha do portal |

`host_permissions` está vazio de propósito. O acesso vem do `activeTab`, concedido no clique no
ícone da extensão. Se você adicionar `host_permissions`, a instalação passa a pedir acesso amplo —
não faça isso sem necessidade documentada.

## Instalação para homologação

1. Abra `chrome://extensions` e ative **Modo do desenvolvedor**.
2. **Carregar sem compactação** → selecione esta pasta (`apps/extension`).
3. Abra `fixture-portal.html` no navegador (via `file://` ou servidor local).
4. No painel Vértice, em **Extensão**, emita um token de pareamento.
5. Clique no ícone da extensão; preencha a URL da API e o token; **Salvar configuração**.
6. Use **Pré-visualizar** (não envia) e depois **Ler e enviar**.

## Criando um adaptador para um portal real

Edite `adapters.js`. Um adaptador é um contrato de seletores:

```js
{
  id: "portal-x-v1",
  label: "Portal X — tela de acompanhamento",
  matchHosts: ["portal.x.edu.br"],
  rootSelector: "#grid-alunos",        // se não existir → layout não reconhecido
  rowSelector: "tr.linha-aluno",
  valueAttribute: "data-value",         // ou null para usar textContent
  requestsSeparator: ",",
  courseMap: { "Direito": "DIR", "Administração": "ADM" },
  fields: {
    studentRef: "td.ref",
    courseRef: "td.curso",
    attendancePercent: "td.frequencia",
    consecutiveAbsences: "td.faltas",
    assessmentAverage: "td.media",
    passingAverage: null,
    openRequests: "td.requerimentos"
  }
}
```

Regras obrigatórias:

- **Nunca** ler `innerText`/`innerHTML` da página inteira, senha ou campos de identificação direta.
- **Nunca** navegar automaticamente por várias telas.
- **Nunca** tentar adivinhar campos por visão computacional.
- Se `rootSelector` não existir, o resultado é `LAYOUT_NOT_RECOGNIZED` e **nada** é enviado.
- Homologue com dados fictícios e registre a versão do adaptador no changelog.

## Detecção de mudança de layout

O adaptador falha fechado: se a raiz ou as linhas não casarem, a extensão retorna erro e o operador
precisa revisar o mapeamento. Isso é intencional — enviar dados errados é pior do que não enviar.

## Empacotamento

```bash
cd apps/extension && zip -r ../../dist/vertice-extension.zip .
```

Para publicar na Chrome Web Store, use o mesmo conteúdo e mantenha `host_permissions` vazio. Para
distribuição interna, publique como extensão privada do domínio (Google Workspace).
