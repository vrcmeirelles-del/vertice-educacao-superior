/**
 * Catálogo de adaptadores autorizados.
 *
 * Cada adaptador é específico de um portal e precisa ser homologado com dados
 * fictícios antes de uso real. Nunca adicione um adaptador "genérico" que
 * tente adivinhar campos: se o layout não casar, a extensão deve parar.
 *
 * `rootSelector` e `rowSelector` são verificados antes de qualquer leitura.
 * `courseMap` traduz o texto exibido pelo portal para o código do curso na
 * Vértice, sem exigir que o portal mude.
 */

export const ADAPTERS = [
  {
    id: "demo-fixture-v1",
    label: "Portal de demonstração (fixture)",
    // O portal demo usa atributos data-*; troque pelos seletores reais ao
    // homologar um portal de verdade.
    matchHosts: ["localhost", "127.0.0.1"],
    rootSelector: "[data-vertice-portal]",
    rowSelector: "[data-vertice-student-row]",
    valueAttribute: "data-value",
    requestsSeparator: ",",
    courseMap: {},
    fields: {
      studentRef: "[data-field='studentRef']",
      courseRef: "[data-field='courseRef']",
      attendancePercent: "[data-field='attendancePercent']",
      consecutiveAbsences: "[data-field='consecutiveAbsences']",
      assessmentAverage: "[data-field='assessmentAverage']",
      passingAverage: "[data-field='passingAverage']",
      openRequests: "[data-field='openRequests']",
    },
  },
];

export function findAdapterFor(url) {
  let host;
  try {
    host = new URL(url).hostname;
  } catch {
    return null;
  }
  return ADAPTERS.find((adapter) =>
    adapter.matchHosts.some((allowed) => host === allowed || host.endsWith(`.${allowed}`)),
  ) ?? null;
}
