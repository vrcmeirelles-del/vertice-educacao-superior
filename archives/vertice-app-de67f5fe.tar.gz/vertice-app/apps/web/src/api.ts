/**
 * Cliente HTTP mínimo. O token fica em sessionStorage (não localStorage) para
 * reduzir a janela de exposição em máquinas compartilhadas de secretaria.
 */

const TOKEN_KEY = "vertice.session";

export interface SessionUser {
  id: string;
  name: string;
  email: string;
  institutionId: string | null;
  role: Role;
  courseScope: string[];
}

export type Role =
  | "platform_admin"
  | "institution_admin"
  | "regulatory_manager"
  | "coordinator"
  | "auditor_readonly"
  | "privacy_officer";

export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public code?: string,
    public details?: unknown,
  ) {
    super(message);
  }
}

export function getToken(): string | null {
  return sessionStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string | null): void {
  if (token) sessionStorage.setItem(TOKEN_KEY, token);
  else sessionStorage.removeItem(TOKEN_KEY);
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const token = getToken();
  const response = await fetch(path, {
    ...init,
    headers: {
      "content-type": "application/json",
      ...(token ? { authorization: `Bearer ${token}` } : {}),
      ...(init.headers ?? {}),
    },
  });

  const text = await response.text();
  const payload = text ? JSON.parse(text) : {};

  if (!response.ok) {
    if (response.status === 401) {
      setToken(null);
    }
    throw new ApiError(
      payload.message ?? payload.error ?? "Falha na requisição",
      response.status,
      payload.error,
      payload.details,
    );
  }
  return payload as T;
}

export const api = {
  login: (body: { email: string; password: string; institutionSlug?: string }) =>
    request<{ token: string; user: SessionUser }>("/v1/auth/login", {
      method: "POST",
      body: JSON.stringify(body),
    }),

  me: () => request<SessionUser>("/v1/auth/me"),

  logout: () => request<{ ok: true }>("/v1/auth/logout", { method: "POST" }),

  courses: () => request<{ courses: Course[] }>("/v1/courses"),

  alerts: (params: Record<string, string | undefined> = {}) => {
    const search = new URLSearchParams();
    for (const [key, value] of Object.entries(params)) {
      if (value) search.set(key, value);
    }
    const qs = search.toString();
    return request<AlertsResponse>(`/v1/alerts${qs ? `?${qs}` : ""}`);
  },

  alert: (id: string) => request<{ alert: AlertDetail; timeline: TimelineEvent[] }>(`/v1/alerts/${id}`),

  updateAlert: (
    id: string,
    body: { status: AlertStatus; note?: string; actionCode?: string; snoozedUntil?: string },
  ) => request<{ ok: true; status: string }>(`/v1/alerts/${id}`, {
    method: "PATCH",
    body: JSON.stringify(body),
  }),

  summary: () => request<AlertsSummary>("/v1/alerts/summary"),

  ingestions: () => request<{ batches: IngestionBatch[] }>("/v1/ingestions"),

  evaluate: (record: RetentionRecord) =>
    request<{ risk: RiskResult }>("/v1/risk/evaluate", {
      method: "POST",
      body: JSON.stringify(record),
    }),

  ingest: (records: RetentionRecord[]) =>
    request<IngestSummary>("/v1/ingestions", {
      method: "POST",
      body: JSON.stringify({ records }),
    }),

  evidence: (params: Record<string, string | undefined> = {}) => {
    const search = new URLSearchParams();
    for (const [key, value] of Object.entries(params)) if (value) search.set(key, value);
    const qs = search.toString();
    return request<{ evidence: EvidenceItem[]; countsByStatus: Record<string, number> }>(
      `/v1/evidence${qs ? `?${qs}` : ""}`,
    );
  },

  transitionEvidence: (id: string, body: { status: string; opinion?: string }) =>
    request<{ ok: true }>(`/v1/evidence/${id}/status`, {
      method: "PATCH",
      body: JSON.stringify(body),
    }),

  instruments: () => request<{ instruments: Instrument[] }>("/v1/instruments"),

  users: () => request<{ users: UserRow[] }>("/v1/users"),

  createUser: (body: Record<string, unknown>) =>
    request<{ id: string }>("/v1/users", { method: "POST", body: JSON.stringify(body) }),

  rulesets: () => request<{ rulesets: RulesetRow[] }>("/v1/rulesets"),

  createRuleset: (body: Record<string, unknown>) =>
    request<RulesetRow>("/v1/rulesets", { method: "POST", body: JSON.stringify(body) }),

  pairingTokens: () => request<{ tokens: PairingToken[] }>("/v1/pairing-tokens"),

  createPairingToken: (body: { label: string; ttlMinutes?: number }) =>
    request<{ token: string; expiresInMinutes: number }>("/v1/pairing-tokens", {
      method: "POST",
      body: JSON.stringify(body),
    }),

  audit: (limit = 100) => request<{ events: AuditEvent[] }>(`/v1/audit?limit=${limit}`),

  billingEvents: (params: { limit?: number; type?: string; outcome?: string } = {}) => {
    const search = new URLSearchParams();
    if (params.limit) search.set("limit", String(params.limit));
    if (params.type) search.set("type", params.type);
    if (params.outcome) search.set("outcome", params.outcome);
    const qs = search.toString();
    return request<BillingEventsResponse>(`/v1/billing/events${qs ? `?${qs}` : ""}`);
  },

  documents: () => request<{ documents: DocumentRow[] }>("/v1/documents"),

  createDocument: (body: {
    fileName: string;
    mimeType: string;
    sizeBytes: number;
    sha256Base64: string;
    classification?: "public" | "internal" | "restricted";
    evidenceId?: string | null;
  }) =>
    request<{
      documentId: string;
      uploadUrl: string;
      method: "PUT";
      headers: Record<string, string>;
      expiresInSeconds: number;
    }>("/v1/documents", { method: "POST", body: JSON.stringify(body) }),

  completeDocument: (id: string) =>
    request<{ documentId: string; scanStatus: string; scanDetail?: string }>(
      `/v1/documents/${id}/complete`,
      { method: "POST" },
    ),

  downloadDocument: (id: string) =>
    request<{ url: string; expiresInSeconds: number }>(`/v1/documents/${id}/download`),

  deleteDocument: (id: string) =>
    request<{ ok: true }>(`/v1/documents/${id}`, { method: "DELETE" }),

  linkDocument: (evidenceId: string, documentId: string) =>
    request<{ ok: true }>(`/v1/evidence/${evidenceId}/documents`, {
      method: "POST",
      body: JSON.stringify({ documentId }),
    }),

  // -------------------------------------------------------------------------
  // Plano da instituição
  // -------------------------------------------------------------------------

  institutionPlan: () => request<InstitutionPlan>("/v1/institution/plan"),

  // -------------------------------------------------------------------------
  // Convites
  // -------------------------------------------------------------------------

  invites: () => request<{ invites: InviteRow[] }>("/v1/users/invites"),

  createInvite: (body: { email: string; role: string; courseScope?: string[]; expiresAt?: string }) =>
    request<{ id: string; email: string; role: string; expiresAt: string; inviteToken: string }>(
      "/v1/users/invites",
      { method: "POST", body: JSON.stringify(body) },
    ),

  revokeInvite: (id: string) =>
    request<{ ok: true }>(`/v1/users/invites/${id}`, { method: "DELETE" }),

  previewInvite: (token: string) =>
    request<{ email: string; role: string; institutionName: string; expiresAt: string }>(
      `/v1/auth/invite?token=${encodeURIComponent(token)}`,
    ),

  acceptInvite: (body: { token: string; name: string; password: string }) =>
    request<{ institutionId: string; role: string }>("/v1/auth/invite/accept", {
      method: "POST",
      body: JSON.stringify(body),
    }),

  // -------------------------------------------------------------------------
  // Plano de controle (só platform_admin)
  // -------------------------------------------------------------------------

  platformInstitutions: (status?: string) =>
    request<{ institutions: PlatformInstitution[] }>(
      `/v1/platform/institutions${status ? `?status=${encodeURIComponent(status)}` : ""}`,
    ),

  platformCreateInstitution: (body: Record<string, unknown>) =>
    request<{
      id: string;
      inviteToken: string;
      inviteExpiresAt: string;
      adminEmail: string;
    }>("/v1/platform/institutions", { method: "POST", body: JSON.stringify(body) }),

  platformSetStatus: (id: string, body: { status: string; reason?: string }) =>
    request<{ institution: unknown }>(`/v1/platform/institutions/${id}/status`, {
      method: "PATCH",
      body: JSON.stringify(body),
    }),

  platformSetPlan: (id: string, body: { planCode: string; reason?: string }) =>
    request<{ institution: unknown }>(`/v1/platform/institutions/${id}/plan`, {
      method: "PATCH",
      body: JSON.stringify(body),
    }),

  platformPlans: () => request<{ plans: PlanLimits[] }>("/v1/platform/plans"),

  platformOverview: () =>
    request<{ overview: Record<string, string> }>("/v1/platform/overview"),

  // -------------------------------------------------------------------------
  // Planejamento Estratégico e Semestral
  // -------------------------------------------------------------------------

  strategicPlans: (params: Record<string, string | undefined> = {}) => {
    const search = new URLSearchParams();
    for (const [key, value] of Object.entries(params)) if (value) search.set(key, value);
    const qs = search.toString();
    return request<{ plans: unknown[] }>(`/v1/strategic-plans${qs ? `?${qs}` : ""}`);
  },

  strategicPlan: (id: string) =>
    request<{ plan: unknown }>(`/v1/strategic-plans/${id}`),

  createStrategicPlan: (body: unknown) =>
    request<{ plan: unknown }>("/v1/strategic-plans", {
      method: "POST",
      body: JSON.stringify(body),
    }),

  updateStrategicPlan: (id: string, body: unknown) =>
    request<{ plan: unknown }>(`/v1/strategic-plans/${id}`, {
      method: "PATCH",
      body: JSON.stringify(body),
    }),

  updateStrategicPlanStatus: (id: string, status: string) =>
    request<{ plan: unknown }>(`/v1/strategic-plans/${id}/status`, {
      method: "PATCH",
      body: JSON.stringify({ status }),
    }),

  semesterPlannings: (params: Record<string, string | undefined> = {}) => {
    const search = new URLSearchParams();
    for (const [key, value] of Object.entries(params)) if (value) search.set(key, value);
    const qs = search.toString();
    return request<{ plans: unknown[] }>(`/v1/semester-plannings${qs ? `?${qs}` : ""}`);
  },

  semesterPlanning: (id: string) =>
    request<{ plan: unknown }>(`/v1/semester-plannings/${id}`),

  createSemesterPlanning: (body: unknown) =>
    request<{ plan: unknown }>("/v1/semester-plannings", {
      method: "POST",
      body: JSON.stringify(body),
    }),

  updateSemesterPlanning: (id: string, body: unknown) =>
    request<{ plan: unknown }>(`/v1/semester-plannings/${id}`, {
      method: "PATCH",
      body: JSON.stringify(body),
    }),

  updateSemesterPlanningStatus: (id: string, status: string) =>
    request<{ plan: unknown }>(`/v1/semester-plannings/${id}/status`, {
      method: "PATCH",
      body: JSON.stringify({ status }),
    }),
};

// ---------------------------------------------------------------------------
// Tipos compartilhados com a UI
// ---------------------------------------------------------------------------

export type AlertStatus = "open" | "assigned" | "in_progress" | "resolved" | "dismissed" | "snoozed";
export type RiskLevel = "low" | "medium" | "high" | "critical";

export interface Course {
  id: string;
  code: string;
  name: string;
  campus: string | null;
  active: boolean;
}

export interface RiskFactor {
  code: string;
  points: number;
  observed: number | string;
  threshold: number | string;
  explanation: string;
}

export interface RiskResult {
  score: number;
  level: RiskLevel;
  factors: RiskFactor[];
  reviewRequired: boolean;
  recommendedAction: string;
  automatedDecision: null;
  ruleVersion: string;
}

export interface AlertRow {
  id: string;
  score: number;
  level: RiskLevel;
  factors: RiskFactor[];
  status: AlertStatus;
  rule_version: string;
  recommended_action: string;
  review_required: boolean;
  created_at: string;
  updated_at: string;
  assigned_to: string | null;
  snoozed_until: string | null;
  course_id: string;
  course_name: string;
  course_code: string;
  observed_at: string;
  attendance_percent: string | null;
  consecutive_absences: number | null;
  assessment_average: string | null;
  open_requests: string[];
}

export interface AlertDetail extends AlertRow {
  passing_average: string | null;
  source: string;
  ruleset_version: number | null;
}

export interface TimelineEvent {
  id: string;
  type: string;
  action_code: string | null;
  note: string | null;
  outcome: string | null;
  created_at: string;
  actor_name: string | null;
}

export interface AlertsResponse {
  alerts: AlertRow[];
  countsByStatus: Record<string, number>;
  pagination: { limit: number; offset: number };
}

export interface AlertsSummary {
  byLevel: Record<string, number>;
  byCourse: { id: string; name: string; urgent: number; total: number }[];
  unassigned: number;
  scope: string[];
}

export interface IngestionBatch {
  id: string;
  status: string;
  source: string;
  total_records: number;
  accepted_records: number;
  rejected_records: number;
  rejection_reason: string | null;
  created_at: string;
  processed_at: string | null;
}

export interface IngestSummary {
  batchId: string;
  total: number;
  accepted: number;
  rejected: number;
  alertsCreated: number;
  rejections: { index: number; reason: string; field?: string }[];
  unknownCourses: string[];
}

export interface RetentionRecord {
  studentRef: string;
  courseRef: string;
  attendancePercent?: number | null;
  consecutiveAbsences?: number | null;
  assessmentAverage?: number | null;
  passingAverage?: number | null;
  openRequests?: string[];
  observedAt: string;
  source: string;
}

export interface EvidenceItem {
  id: string;
  status: string;
  due_date: string | null;
  valid_until: string | null;
  updated_at: string;
  course_id: string | null;
  course_name: string | null;
  requirement_code: string;
  axis: string;
  indicator: string;
  criterion: string;
  expected_evidence: string;
  criticality: string;
  instrument_code: string;
  instrument_version: string;
  instrument_source: string;
  owner_name: string | null;
  document_count: number;
}

export interface Instrument {
  id: string;
  code: string;
  version: string;
  title: string;
  official_source: string;
  effective_from: string;
  effective_to: string | null;
  status: string;
  requirement_count: number;
}

export interface UserRow {
  id: string;
  name: string;
  email: string;
  is_active: boolean;
  last_login_at: string | null;
  role: Role;
  course_scope: string[];
  expires_at: string | null;
}

export interface RulesetRow {
  id: string;
  course_id: string | null;
  course_name: string | null;
  version: number;
  attendance_threshold: string;
  attendance_weight: number;
  consecutive_absence_threshold: number;
  consecutive_absence_weight: number;
  low_assessment_weight: number;
  exit_request_weight: number;
  status: string;
  created_at: string;
}

export interface PairingToken {
  id: string;
  label: string;
  expires_at: string;
  revoked_at: string | null;
  last_used_at: string | null;
  created_at: string;
}

export type ScanStatus = "pending_upload" | "pending_scan" | "clean" | "infected" | "failed";

export interface DocumentRow {
  id: string;
  file_name: string;
  mime_type: string;
  size_bytes: string;
  classification: "public" | "internal" | "restricted";
  scan_status: ScanStatus;
  scan_detail: string | null;
  scanned_at: string | null;
  created_at: string;
}

export type BillingEventOutcome = "applied" | "ignored" | "duplicate" | "pending";

export interface BillingEvent {
  id: string;
  provider: string;
  event_id: string;
  event_type: string;
  institution_id: string | null;
  institution_name: string | null;
  institution_slug: string | null;
  occurred_at: string | null;
  processed_at: string | null;
  skipped_reason: string | null;
  error: string | null;
  created_at: string;
  outcome: BillingEventOutcome;
}

export interface BillingEventsResponse {
  events: BillingEvent[];
  counts: Record<BillingEventOutcome, number>;
  lastEventAt: string | null;
  /** null quando quem consulta é `platform_admin` e vê todas as instituições. */
  scopeInstitutionId: string | null;
}

export interface AuditEvent {
  created_at: string;
  action: string;
  resource_type: string;
  resource_id: string | null;
  outcome: string;
  ip: string | null;
  metadata: Record<string, unknown>;
  actor_name: string | null;
  actor_email: string | null;
}

// ---------------------------------------------------------------------------
// Plano e cota
//
// `null` em qualquer limite significa "sem limite", nunca zero. A UI precisa
// tratar os dois casos de forma diferente.
// ---------------------------------------------------------------------------

export type InstitutionStatus =
  | "trial"
  | "trial_expired"
  | "active"
  | "past_due"
  | "suspended"
  | "churned";

export interface PlanLimits {
  planCode: string;
  maxUsers: number | null;
  maxAlertsMonth: number | null;
  maxStorageMb: number | null;
  maxBatchesDay: number | null;
  maxCourses: number | null;
  maxBatchRecords: number | null;
}

export interface PlanUsage {
  users: number;
  alertsMonth: number;
  storageMb: number;
  batchesDay: number;
  courses: number;
}

export interface InstitutionPlan {
  status: InstitutionStatus;
  planCode: string;
  trialEndsAt: string | null;
  limits: PlanLimits;
  usage: PlanUsage;
}

export interface InviteRow {
  id: string;
  email: string;
  role: Role;
  expires_at: string;
  created_at: string;
}

export interface PlatformInstitution {
  id: string;
  slug: string;
  name: string;
  status: InstitutionStatus;
  plan_code: string;
  trial_ends_at: string | null;
  activated_at: string | null;
  suspended_at: string | null;
  created_at: string;
  users: string;
  courses: string;
  alerts: string;
}

