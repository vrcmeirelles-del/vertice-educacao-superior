import { useState } from "react";
import type { ReactNode } from "react";

/**
 * Lista agrupada e recolhível.
 *
 * Serve para a leitura "por etapa" que o quadro não dá quando há muita coisa:
 * a mesma verdade, em linhas, com o total por grupo. Cada grupo abre e fecha
 * de forma independente.
 */

export interface ListGroup<T> {
  key: string;
  label: string;
  color?: string;
  items: T[];
  summary?: string;
  /** Abre recolhido por padrão. */
  collapsed?: boolean;
}

export interface GroupedListProps<T extends { id: string }> {
  groups: ListGroup<T>[];
  renderRow: (item: T) => ReactNode;
  onOpen?: (id: string) => void;
  emptyLabel?: string;
}

export function GroupedList<T extends { id: string }>({
  groups,
  renderRow,
  onOpen,
  emptyLabel = "Nenhum registro neste filtro.",
}: GroupedListProps<T>) {
  const [closed, setClosed] = useState<Record<string, boolean>>(() =>
    Object.fromEntries(groups.filter((group) => group.collapsed).map((group) => [group.key, true])),
  );

  const visible = groups.filter((group) => group.items.length > 0);

  if (visible.length === 0) {
    return (
      <div className="vx-groups">
        <div className="vx-group">
          <div className="vx-empty">{emptyLabel}</div>
        </div>
      </div>
    );
  }

  return (
    <div className="vx-groups">
      {visible.map((group) => {
        const isOpen = !closed[group.key];
        return (
          <section key={group.key} className="vx-group" data-open={isOpen ? "true" : "false"}>
            <button
              type="button"
              className="vx-group__head"
              aria-expanded={isOpen}
              onClick={() => setClosed((current) => ({ ...current, [group.key]: isOpen }))}
            >
              <span style={{ fontSize: 11, color: "var(--ink-soft)" }}>{isOpen ? "▾" : "▸"}</span>
              <span className="vx-dot" style={{ background: group.color ?? "var(--ink-soft)" }} />
              <span>{group.label}</span>
              <span className="vx-column__count">{group.items.length}</span>
              {group.summary && <span className="vx-group__sum">{group.summary}</span>}
            </button>

            {isOpen && (
              <div>
                {group.items.map((item) => (
                  <div
                    key={item.id}
                    role="button"
                    tabIndex={0}
                    onClick={() => onOpen?.(item.id)}
                    onKeyDown={(event) => {
                      if (event.key === "Enter") onOpen?.(item.id);
                    }}
                    style={{ cursor: onOpen ? "pointer" : undefined }}
                  >
                    {renderRow(item)}
                  </div>
                ))}
              </div>
            )}
          </section>
        );
      })}
    </div>
  );
}
