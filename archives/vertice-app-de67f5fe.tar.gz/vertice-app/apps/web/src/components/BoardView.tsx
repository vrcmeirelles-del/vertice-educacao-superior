import { useState } from "react";
import type { ReactNode } from "react";

/**
 * Quadro por etapa, com arrastar e soltar nativo do HTML.
 *
 * Sem biblioteca de drag and drop de propósito: o HTML5 resolve uma coluna
 * por etapa com poucas dezenas de cartões, e trazer uma dependência pesada
 * para isso custaria mais do que vale. O estado de arraste é só o id; quem
 * decide se a transição é válida é o `onMove` do chamador.
 */

export interface BoardColumn<T> {
  key: string;
  label: string;
  color?: string;
  items: T[];
  /** Texto à direita do cabeçalho, ex.: soma de valor. */
  summary?: string;
}

export interface BoardViewProps<T extends { id: string }> {
  columns: BoardColumn<T>[];
  renderCard: (item: T) => ReactNode;
  onMove: (id: string, columnKey: string) => void;
  onOpen?: (id: string) => void;
}

export function BoardView<T extends { id: string }>({
  columns,
  renderCard,
  onMove,
  onOpen,
}: BoardViewProps<T>) {
  const [dragging, setDragging] = useState<string | null>(null);
  const [over, setOver] = useState<string | null>(null);

  return (
    <div className="vx-board">
      {columns.map((column) => (
        <section key={column.key} className="vx-column" aria-label={column.label}>
          <div className="vx-column__head">
            <span className="vx-dot" style={{ background: column.color ?? "var(--ink-soft)" }} />
            <span>{column.label}</span>
            <span className="vx-column__count">{column.items.length}</span>
            {column.summary && <span className="vx-column__sum">{column.summary}</span>}
          </div>

          <div
            className="vx-column__body"
            data-over={over === column.key ? "true" : undefined}
            onDragOver={(event) => {
              event.preventDefault();
              setOver(column.key);
            }}
            onDragLeave={() => setOver((current) => (current === column.key ? null : current))}
            onDrop={(event) => {
              event.preventDefault();
              const id = event.dataTransfer.getData("text/plain");
              if (id) onMove(id, column.key);
              setOver(null);
              setDragging(null);
            }}
          >
            {column.items.map((item) => (
              <article
                key={item.id}
                className="vx-card"
                draggable
                data-dragging={dragging === item.id ? "true" : undefined}
                onDragStart={(event) => {
                  event.dataTransfer.setData("text/plain", item.id);
                  event.dataTransfer.effectAllowed = "move";
                  setDragging(item.id);
                }}
                onDragEnd={() => {
                  setDragging(null);
                  setOver(null);
                }}
                onClick={() => onOpen?.(item.id)}
                role="button"
                tabIndex={0}
                onKeyDown={(event) => {
                  if (event.key === "Enter") onOpen?.(item.id);
                }}
              >
                {renderCard(item)}
              </article>
            ))}

            {column.items.length === 0 && (
              <div className="vx-empty" style={{ padding: "18px 8px" }}>
                Arraste um cartão para cá.
              </div>
            )}
          </div>
        </section>
      ))}
    </div>
  );
}
