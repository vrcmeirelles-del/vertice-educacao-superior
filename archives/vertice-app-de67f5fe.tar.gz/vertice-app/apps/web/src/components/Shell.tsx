import type { ReactNode } from "react";
import type { Route } from "../App";
import type { SessionUser } from "../api";

/**
 * `platform_admin` não tem instituição, então toda tela de cliente responde
 * 403 para ele. O menu dele mostra só o console — um item que abre erro de
 * permissão é pior do que um item ausente.
 */
const INSTITUTION_ROLES: SessionUser["role"][] = [
  "institution_admin",
  "regulatory_manager",
  "coordinator",
  "auditor_readonly",
  "privacy_officer",
];

const NAV: { key: Route["name"]; label: string; roles?: SessionUser["role"][] }[] = [
  { key: "platform", label: "Instituições", roles: ["platform_admin"] },
  { key: "overview", label: "Visão geral", roles: INSTITUTION_ROLES },
  { key: "alerts", label: "Alertas", roles: INSTITUTION_ROLES },
  { key: "ingestion", label: "Importações", roles: INSTITUTION_ROLES },
  { key: "evidence", label: "Evidências", roles: INSTITUTION_ROLES },
  { key: "documents", label: "Documentos", roles: INSTITUTION_ROLES },
  { key: "rules", label: "Regras", roles: ["institution_admin"] },
  { key: "team", label: "Equipe", roles: ["institution_admin"] },
  { key: "extension", label: "Extensão", roles: ["institution_admin"] },
  { key: "audit", label: "Auditoria", roles: INSTITUTION_ROLES },
{ key: "billing", label: "Cobrança", roles: ["platform_admin", "institution_admin"] },
  { key: "captacao", label: "Captação", roles: INSTITUTION_ROLES },
 { key: "strategic", label: "Planejamento Estratégico", roles: INSTITUTION_ROLES },
];

const ROLE_LABEL: Record<SessionUser["role"], string> = {
  platform_admin: "Equipe Vértice",
  institution_admin: "Administrador da IES",
  regulatory_manager: "Regulação",
  coordinator: "Coordenação",
  auditor_readonly: "Auditor (leitura)",
  privacy_officer: "Privacidade",
};

export function Shell({
  user,
  route,
  onNavigate,
  onLogout,
  children,
}: {
  user: SessionUser;
  route: Route;
  onNavigate: (route: Route) => void;
  onLogout: () => void;
  children: ReactNode;
}) {
  const active = route.name === "alert" ? "alerts" : route.name;

  return (
    <div style={{ display: "flex", minHeight: "100%" }}>
      <aside
        style={{
          width: 248,
          flexShrink: 0,
          background: "#1d2b40",
          color: "#dbe3ee",
          display: "flex",
          flexDirection: "column",
          padding: "20px 14px",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0 8px 22px" }}>
          <div
            aria-hidden
            style={{
              width: 30,
              height: 30,
              borderRadius: 8,
              background: "#328ea8",
              clipPath: "polygon(50% 0%, 100% 100%, 0% 100%)",
            }}
          />
          <div>
            <div style={{ fontWeight: 700, letterSpacing: 0.4 }}>VÉRTICE</div>
            <div style={{ fontSize: 11, opacity: 0.65 }}>Governança regulatória</div>
          </div>
        </div>

        <nav style={{ display: "flex", flexDirection: "column", gap: 2 }}>
          {NAV.filter((item) => !item.roles || item.roles.includes(user.role)).map((item) => {
            const isActive = active === item.key;
            return (
              <button
                key={item.key}
                onClick={() => onNavigate({ name: item.key } as Route)}
                style={{
                  textAlign: "left",
                  padding: "9px 12px",
                  borderRadius: 8,
                  border: "none",
                  cursor: "pointer",
                  background: isActive ? "rgba(50,142,168,0.22)" : "transparent",
                  color: isActive ? "#ffffff" : "#c3cddb",
                  fontWeight: isActive ? 600 : 400,
                }}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        <div style={{ flex: 1 }} />

        <div style={{ borderTop: "1px solid rgba(255,255,255,0.12)", paddingTop: 14, padding: "14px 8px 0" }}>
          <div style={{ fontWeight: 600, fontSize: 13 }}>{user.name}</div>
          <div style={{ fontSize: 11, opacity: 0.6 }}>{ROLE_LABEL[user.role]}</div>
          <button
            onClick={onLogout}
            className="btn btn-ghost"
            style={{ marginTop: 10, color: "#c3cddb", padding: "6px 8px", fontSize: 12 }}
          >
            Sair
          </button>
        </div>
      </aside>

      <main style={{ flex: 1, padding: "28px 34px", maxWidth: 1280, margin: "0 auto", width: "100%" }}>
        {children}
      </main>
    </div>
  );
}

export function PageHeader({
  title,
  subtitle,
  actions,
}: {
  title: string;
  subtitle?: string;
  actions?: ReactNode;
}) {
  return (
    <header style={{ display: "flex", alignItems: "flex-start", gap: 16, marginBottom: 22 }}>
      <div>
        <h1 style={{ margin: 0, fontSize: 22, fontWeight: 700 }}>{title}</h1>
        {subtitle && (
          <p style={{ margin: "4px 0 0", color: "var(--ink-soft)", maxWidth: 720 }}>{subtitle}</p>
        )}
      </div>
      <div className="spacer" />
      {actions}
    </header>
  );
}

