import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { KeyboardEvent as ReactKeyboardEvent, ReactNode } from "react";

/**
 * Planilha editável.
 *
 * O comportamento que faz a tela ser usável no dia a dia, e que uma tabela
 * comum não tem, é a edição em linha mantendo as mãos no teclado:
 *
 *   setas      navegam entre células
 *   Enter      começa a editar; com a célula aberta, confirma e desce
 *   Escape     cancela a edição
 *   Tab        confirma e vai para a direita
 *   digitar    já abre a célula com o primeiro caractere
 *
 * O componente não conhece regra de negócio: recebe as colunas e o valor de
 * cada célula, e devolve `onChange`. Quem decide o que é válido é o chamador.
 */

export type CellKind = "text" | "number" | "money" | "date" | "select" | "readonly";

export interface SelectOption {
  value: string;
  label: string;
  color?: string;
}

export interface ColumnDef<T> {
  key: string;
  label: string;
  kind: CellKind;
  width?: number;
  options?: SelectOption[];
  hint?: string;
}

export interface SheetGridProps<T extends { id: string }> {
  columns: ColumnDef<T>[];
  rows: T[];
  valueOf: (row: T, key: string) => string;
  onChange: (id: string, key: string, value: string) => void;
  renderCell?: (row: T, column: ColumnDef<T>) => ReactNode | null;
  onOpen?: (id: string) => void;
  emptyLabel?: string;
  footer?: { left: ReactNode; right?: ReactNode };
}

interface Position {
  row: number;
  col: number;
}

export function SheetGrid<T extends { id: string }>({
  columns,
  rows,
  valueOf,
  onChange,
  renderCell,
  onOpen,
  emptyLabel = "Nenhum registro neste filtro.",
  footer,
}: SheetGridProps<T>) {
  const [cursor, setCursor] = useState<Position | null>(null);
  const [editing, setEditing] = useState<Position | null>(null);
  const [draft, setDraft] = useState("");
  const inputRef = useRef<HTMLInputElement | null>(null);
  const tableRef = useRef<HTMLTableElement | null>(null);

  const editableColumns = useMemo(
    () => columns.map((column, index) => ({ column, index })).filter((c) => c.column.kind !== "readonly"),
    [columns],
  );

  useEffect(() => {
    if (editing) {
      inputRef.current?.focus();
      inputRef.current?.select();
    }
  }, [editing]);

  const isEditable = useCallback(
    (pos: Position): boolean => columns[pos.col]?.kind !== "readonly",
    [columns],
  );

  const move = useCallback(
    (pos: Position, dRow: number, dCol: number): Position => {
      const row = Math.min(Math.max(pos.row + dRow, 0), Math.max(rows.length - 1, 0));
      let col = pos.col + dCol;
      // Ao passar da última coluna editável, volta para a primeira.
      if (col >= columns.length) col = 0;
      if (col < 0) col = Math.max(columns.length - 1, 0);
      return { row, col };
    },
    [columns.length, rows.length],
  );

  const beginEdit = useCallback(
    (pos: Position, seed?: string) => {
      const row = rows[pos.row];
      const column = columns[pos.col];
      if (!row || !column || column.kind === "readonly") return;
      setDraft(seed ?? valueOf(row, column.key));
      setEditing(pos);
    },
    [columns, rows, valueOf],
  );

  const commit = useCallback(
    (pos: Position, next?: Position) => {
      const row = rows[pos.row];
      const column = columns[pos.col];
      if (row && column) onChange(row.id, column.key, draft);
      setEditing(null);
      const alvo = next ?? pos;
      setCursor(alvo);
      // O input desmonta ao confirmar. Sem devolver o foco ao <td>, a navegacao
      // por teclado morre no primeiro Enter: o foco cai no body.
      requestAnimationFrame(() => {
        const celula = tableRef.current?.querySelector<HTMLElement>(
          `td[data-row="${alvo.row}"][data-col="${alvo.col}"]`,
        );
        celula?.focus();
      });
    },
    [columns, draft, onChange, rows],
  );

  const onCellKeyDown = useCallback(
    (event: ReactKeyboardEvent<HTMLTableCellElement>, pos: Position) => {
      if (editing && editing.row === pos.row && editing.col === pos.col) return;

      switch (event.key) {
        case "ArrowDown":
          event.preventDefault();
          setCursor(move(pos, 1, 0));
          return;
        case "ArrowUp":
          event.preventDefault();
          setCursor(move(pos, -1, 0));
          return;
        case "ArrowLeft":
          event.preventDefault();
          setCursor(move(pos, 0, -1));
          return;
        case "ArrowRight":
          event.preventDefault();
          setCursor(move(pos, 0, 1));
          return;
        case "Enter":
          event.preventDefault();
          if (isEditable(pos)) beginEdit(pos);
          else onOpen?.(rows[pos.row]?.id ?? "");
          return;
        case "Escape":
          setCursor(null);
          return;
        default:
          break;
      }

      // Letra ou número digitado: abre a célula já com o caractere.
      if (event.key.length === 1 && !event.ctrlKey && !event.metaKey && isEditable(pos)) {
        event.preventDefault();
        beginEdit(pos, event.key);
      }
    },
    [beginEdit, editing, isEditable, move, onOpen, rows],
  );

  const onEditorKeyDown = useCallback(
    (event: ReactKeyboardEvent<HTMLInputElement | HTMLSelectElement>, pos: Position) => {
      if (event.key === "Escape") {
        event.preventDefault();
        setEditing(null);
        return;
      }
      if (event.key === "Enter") {
        event.preventDefault();
        const column = columns[pos.col];
        // Select com Enter confirma e desce; texto também.
        commit(pos, column?.kind === "select" ? pos : move(pos, 1, 0));
        return;
      }
      if (event.key === "Tab") {
        event.preventDefault();
        const dCol = event.shiftKey ? -1 : 1;
        commit(pos, move(pos, 0, dCol));
      }
    },
    [columns, commit, move],
  );

  // Ao clicar fora, encerra a edição sem salvar o rascunho pendente.
  useEffect(() => {
    if (!editing) return;
    const handler = (event: MouseEvent) => {
      const target = event.target as HTMLElement | null;
      if (target?.closest("td[data-editing='true']")) return;
      setEditing(null);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [editing]);

  const widthOf = (column: ColumnDef<T>) => (column.width ? { width: column.width } : undefined);

  if (rows.length === 0) {
    return (
      <div className="vx-sheet">
        <div className="vx-empty">{emptyLabel}</div>
      </div>
    );
  }

  return (
    <div className="vx-sheet">
      <table ref={tableRef} role="grid" aria-label="Planilha de captação">
        <thead>
          <tr>
            {columns.map((column) => (
              <th key={column.key} style={widthOf(column)} title={column.hint}>
                <div className="vx-th">{column.label}</div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, rowIndex) => (
            <tr
              key={row.id}
              data-selected={cursor?.row === rowIndex ? "true" : undefined}
            >
              {columns.map((column, colIndex) => {
                const pos = { row: rowIndex, col: colIndex };
                const isEditing = editing?.row === rowIndex && editing?.col === colIndex;
                const custom = renderCell?.(row, column);

                if (isEditing) {
                  return (
                    <td key={column.key} data-editing="true" style={widthOf(column)}>
                      {column.kind === "select" ? (
                        <select
                          className="vx-cell__input"
                          value={draft}
                          onChange={(event) => {
                            setDraft(event.target.value);
                            onChange(row.id, column.key, event.target.value);
                            setEditing(null);
                          }}
                          onKeyDown={(event) => onEditorKeyDown(event, pos)}
                          onBlur={() => setEditing(null)}
                          autoFocus
                          ref={(node) => {
                            node?.focus();
                          }}
                        >
                          {(column.options ?? []).map((option) => (
                            <option key={option.value} value={option.value}>
                              {option.label}
                            </option>
                          ))}
                        </select>
                      ) : (
                        <input
                          ref={inputRef}
                          className={`vx-cell__input${column.kind === "number" || column.kind === "money" ? " vx-cell__input--num" : ""}`}
                          type={column.kind === "date" ? "date" : "text"}
                          inputMode={column.kind === "number" || column.kind === "money" ? "numeric" : undefined}
                          value={draft}
                          onChange={(event) => setDraft(event.target.value)}
                          onKeyDown={(event) => onEditorKeyDown(event, pos)}
                        />
                      )}
                    </td>
                  );
                }

                return (
                  <td
                    key={column.key}
                    data-row={rowIndex}
                    data-col={colIndex}
                    style={widthOf(column)}
                    tabIndex={editableColumns.length > 0 ? 0 : -1}
                    onFocus={() => setCursor(pos)}
                    onKeyDown={(event) => onCellKeyDown(event, pos)}
                    onDoubleClick={() => beginEdit(pos)}
                    onClick={() => setCursor(pos)}
                  >
                    {custom ?? (
                      <div
                        className={
                          column.kind === "number" || column.kind === "money"
                            ? "vx-cell vx-cell--num"
                            : column.kind === "readonly"
                              ? "vx-cell vx-cell--muted"
                              : "vx-cell"
                        }
                      >
                        {valueOf(row, column.key) || <span className="muted">—</span>}
                      </div>
                    )}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>

      {footer && (
        <div className="vx-foot">
          <span>{footer.left}</span>
          <div className="spacer" />
          {footer.right}
        </div>
      )}
    </div>
  );
}
