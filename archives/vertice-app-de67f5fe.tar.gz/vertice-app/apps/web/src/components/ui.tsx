import type { ReactNode } from "react";
import type { RiskLevel } from "../api";

const LEVEL_LABEL: Record<RiskLevel, string> = {
  critical: "Crítico",
  high: "Alto",
  medium: "Médio",
  low: "Baixo",
};

export function LevelBadge({ level }: { level: RiskLevel }) {
  return <span className={`badge badge-${level}`}>{LEVEL_LABEL[level]}</span>;
}

const STATUS_LABEL: Record<string, string> = {
  open: "Aberto",
  assigned: "Atribuído",
  in_progress: "Em atendimento",
  resolved: "Resolvido",
  dismissed: "Dispensado",
  snoozed: "Adiado",
  pending: "Pendente",
  in_review: "Em revisão",
  validated: "Validada",
  changes_requested: "Ajustes",
  expired: "Vencida",
  not_applicable: "Não aplicável",
  received: "Recebido",
  processed: "Processado",
  rejected: "Rejeitado",
  validated_batch: "Validado",
};

export function StatusBadge({ status }: { status: string }) {
  const color =
    status === "resolved" || status === "validated" || status === "processed"
      ? { background: "#e9f4ef", color: "#2f7d5b" }
      : status === "expired" || status === "rejected" || status === "dismissed"
        ? { background: "#fbe9e7", color: "#b75046" }
        : status === "changes_requested" || status === "snoozed"
          ? { background: "#fdf1e3", color: "#b8802c" }
          : { background: "#eef2f6", color: "#5b6b83" };

  return (
    <span className="badge" style={color}>
      {STATUS_LABEL[status] ?? status}
    </span>
  );
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 5 }}>
      <span style={{ fontSize: 12, fontWeight: 600, color: "var(--ink-soft)" }}>{label}</span>
      {children}
    </label>
  );
}

export function ErrorNote({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <div
      role="alert"
      style={{
        background: "#fbe9e7",
        color: "#b75046",
        padding: "10px 14px",
        borderRadius: 8,
        fontSize: 13,
      }}
    >
      {message}
    </div>
  );
}

export function Empty({ children }: { children: ReactNode }) {
  return (
    <div style={{ padding: "40px 20px", textAlign: "center", color: "var(--ink-soft)" }}>{children}</div>
  );
}

export function fmtDate(value: string | null | undefined): string {
  if (!value) return "—";
  return new Date(value).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
}

export function fmtDateOnly(value: string | null | undefined): string {
  if (!value) return "—";
  return new Date(value).toLocaleDateString("pt-BR");
}

export function Stat({
  label,
  value,
  tone,
}: {
  label: string;
  value: string | number;
  tone?: "danger" | "warn" | "ok";
}) {
  const color =
    tone === "danger" ? "var(--danger)" : tone === "warn" ? "var(--warn)" : tone === "ok" ? "var(--ok)" : "var(--ink)";
  return (
    <div className="card" style={{ padding: "16px 18px", flex: 1, minWidth: 160 }}>
      <div style={{ fontSize: 12, color: "var(--ink-soft)", fontWeight: 600 }}>{label}</div>
      <div style={{ fontSize: 28, fontWeight: 700, color, lineHeight: 1.2, marginTop: 4 }}>{value}</div>
    </div>
  );
}
