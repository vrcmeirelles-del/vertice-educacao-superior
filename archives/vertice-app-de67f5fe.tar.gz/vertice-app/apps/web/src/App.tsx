import { useCallback, useEffect, useState } from "react";
import { api, getToken, setToken, type SessionUser } from "./api";
import { Login } from "./pages/Login";
import { Shell } from "./components/Shell";
import { Overview } from "./pages/Overview";
import { Alerts } from "./pages/Alerts";
import { AlertDetail } from "./pages/AlertDetail";
import { Ingestion } from "./pages/Ingestion";
import { Evidence } from "./pages/Evidence";
import { Documents } from "./pages/Documents";
import { Rules } from "./pages/Rules";
import { Team } from "./pages/Team";
import { Audit } from "./pages/Audit";
import { Extension } from "./pages/Extension";
import { Platform } from "./pages/Platform";
import { AcceptInvite } from "./pages/AcceptInvite";
import { Billing } from "./pages/Billing";
import { Captacao } from "./pages/Captacao";
import { StrategicPlanning } from "./pages/StrategicPlanning";

export type Route =
  | { name: "overview" }
  | { name: "platform" }
  | { name: "alerts" }
  | { name: "alert"; id: string }
  | { name: "ingestion" }
  | { name: "evidence" }
  | { name: "documents" }
  | { name: "rules" }
  | { name: "team" }
  | { name: "audit" }
| { name: "extension" }
| { name: "billing" }
  | { name: "captacao" }
  | { name: "strategic" };

export default function App() {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [booting, setBooting] = useState(true);
  // `platform_admin` não tem instituição: a visão inicial dele é o console de
  // clientes, não o painel de uma IES que ele não tem.
  const [route, setRoute] = useState<Route>({ name: "overview" });

  // Convite: `#convite/<token>` abre a tela de definição de senha, que é
  // pública — quem recebeu o link ainda não tem conta.
  const inviteToken = window.location.hash.startsWith("#convite/")
    ? window.location.hash.slice("#convite/".length)
    : null;

  useEffect(() => {
    if (!getToken()) {
      setBooting(false);
      return;
    }
    api
      .me()
      .then(setUser)
      .catch(() => setToken(null))
      .finally(() => setBooting(false));
  }, []);

  const handleLogout = useCallback(async () => {
    await api.logout().catch(() => undefined);
    setToken(null);
    setUser(null);
    setRoute({ name: "overview" });
  }, []);

  if (inviteToken) {
    return (
      <AcceptInvite
        token={inviteToken}
        onBack={() => {
          window.location.hash = "";
          window.location.reload();
        }}
      />
    );
  }

  if (booting) {
    return <div style={{ display: "grid", placeItems: "center", height: "100%" }}>Carregando…</div>;
  }

  if (!user) {
    return <Login onSuccess={(u, token) => { setToken(token); setUser(u); }} />;
  }

  return (
    <Shell user={user} route={route} onNavigate={setRoute} onLogout={handleLogout}>
      {route.name === "platform" && <Platform />}
      {route.name === "overview" &&
        (user.role === "platform_admin" ? (
          <Platform />
        ) : (
          <Overview onOpenAlert={(id) => setRoute({ name: "alert", id })} />
        ))}
      {route.name === "alerts" && <Alerts onOpenAlert={(id) => setRoute({ name: "alert", id })} />}
      {route.name === "alert" && (
        <AlertDetail id={route.id} user={user} onBack={() => setRoute({ name: "alerts" })} />
      )}
      {route.name === "ingestion" && <Ingestion user={user} />}
      {route.name === "evidence" && <Evidence user={user} />}
      {route.name === "documents" && <Documents user={user} />}
      {route.name === "rules" && <Rules user={user} />}
      {route.name === "team" && <Team user={user} />}
      {route.name === "audit" && <Audit />}
      {route.name === "extension" && <Extension user={user} />}
{route.name === "billing" && <Billing />}
      {route.name === "captacao" && <Captacao />}
      {route.name === "strategic" && <StrategicPlanning user={user} />} 
    </Shell>
  );
}

