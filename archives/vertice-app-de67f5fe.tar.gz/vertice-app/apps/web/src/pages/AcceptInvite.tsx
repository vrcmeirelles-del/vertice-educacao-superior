import { useEffect, useState, type FormEvent } from "react";
import { api, ApiError } from "../api";
import { ErrorNote, Field } from "../components/ui";

/**
 * Definição de senha a partir do convite.
 *
 * Quem recebe o link não tem conta ainda, então esta é a única tela pública
 * que cria credencial. O e-mail vem do convite e não é editável: aceitar um
 * formulário livre permitiria tomar o convite de outra pessoa.
 */
export function AcceptInvite({ token, onBack }: { token: string; onBack: () => void }) {
  const [preview, setPreview] = useState<{ email: string; institutionName: string; role: string } | null>(
    null,
  );
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    api
      .previewInvite(token)
      .then(setPreview)
      .catch((err) => setError(err instanceof ApiError ? err.message : "Convite inválido"));
  }, [token]);

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (password !== confirm) {
      setError("As senhas não conferem.");
      return;
    }
    setError(null);
    setLoading(true);
    try {
      await api.acceptInvite({ token, name, password });
      setDone(true);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Não foi possível aceitar o convite");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ display: "grid", placeItems: "center", minHeight: "100%", padding: 24 }}>
      <div className="card" style={{ width: 420, padding: 28 }}>
        <div style={{ fontWeight: 700, letterSpacing: 0.5, marginBottom: 18 }}>VÉRTICE</div>

        {done ? (
          <>
            <h2 style={{ marginTop: 0, fontSize: 18 }}>Acesso definido</h2>
            <p className="muted small">
              Sua senha foi criada. Entre com {preview?.email} e a senha que você acabou de definir.
            </p>
            <button className="btn btn-primary" onClick={onBack}>
              Ir para o login
            </button>
          </>
        ) : (
          <>
            <h2 style={{ marginTop: 0, fontSize: 18 }}>Definir seu acesso</h2>
            {preview ? (
              <p className="muted small" style={{ marginTop: 0 }}>
                Convite para <strong>{preview.email}</strong> na instituição{" "}
                <strong>{preview.institutionName}</strong>.
              </p>
            ) : (
              !error && <p className="muted small">Verificando convite…</p>
            )}

            <form onSubmit={submit} className="stack">
              <Field label="Seu nome">
                <input
                  className="input"
                  required
                  minLength={3}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </Field>
              <Field label="Senha (mínimo 12 caracteres)">
                <input
                  className="input"
                  type="password"
                  autoComplete="new-password"
                  required
                  minLength={12}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </Field>
              <Field label="Repita a senha">
                <input
                  className="input"
                  type="password"
                  autoComplete="new-password"
                  required
                  minLength={12}
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                />
              </Field>

              <ErrorNote message={error} />

              <button
                className="btn btn-primary"
                type="submit"
                disabled={loading || !preview || password.length < 12 || password !== confirm}
              >
                {loading ? "Salvando…" : "Criar senha e acessar"}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}
