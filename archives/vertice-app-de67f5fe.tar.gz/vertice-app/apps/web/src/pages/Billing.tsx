import { useCallback, useEffect, useMemo, useState } from "react";
import { api, ApiError, type BillingEvent, type BillingEventOutcome } from "../api";
import { PageHeader } from "../components/Shell";
import { Empty, ErrorNote, StatusBadge, Stat, fmtDate } from "../components/ui";

/**
 * Operação da cobrança.
 *
 * A pergunta que esta tela responde não é "quanto faturei" — é "por que a
 * conta deste cliente está nesse estado?". Por isso a coluna que importa é
 * `skipped_reason`: um evento ignorado por chegar fora de ordem é a
 * explicação mais comum de "o pagamento entrou e a conta continua bloqueada".
 *
 * `outcome` vem pronto da API. A tela não recalcula o que é "ignorado" —
 * duplicar essa regra aqui faria a UI e o webhook discordarem com o tempo.
 */

const OUTCOME_LABEL: Record<BillingEventOutcome, string> = {
  applied: "Aplicado",
  ignored: "Ignorado",
  duplicate: "Duplicata",
  pending: "Pendente",
};

/** Rótulo e cor por desfecho. `pending` é o único que pede ação humana. */
const OUTCOME_STYLE: Record<BillingEventOutcome, { bg: string; fg: string }> = {
  applied: { bg: "#e9f4ef", fg: "#2f7d5b" },
  ignored: { bg: "#eef2f6", fg: "#5b6b83" },
  duplicate: { bg: "#eef2f6", fg: "#5b6b83" },
  pending: { bg: "#fbe9e7", fg: "#b75046" },
};

function OutcomeTag({ outcome }: { outcome: BillingEventOutcome }) {
  const { bg, fg } = OUTCOME_STYLE[outcome] ?? OUTCOME_STYLE.ignored;
  return (
    <span className="badge" style={{ background: bg, color: fg }}>
      {OUTCOME_LABEL[outcome] ?? outcome}
    </span>
  );
}

/**
 * Rótulos legíveis dos eventos do provedor.
 *
 * O banco guarda o identificador cru (`PAYMENT_OVERDUE`) porque é ele que o
 * provedor reenvia; traduzir na leitura mantém o dado fiel e a tela legível.
 */
const EVENT_LABEL: Record<string, string> = {
  PAYMENT_CONFIRMED: "Pagamento confirmado",
  PAYMENT_RECEIVED: "Pagamento recebido",
  PAYMENT_OVERDUE: "Pagamento em atraso",
  PAYMENT_CREATED: "Cobrança gerada",
  SUBSCRIPTION_DELETED: "Assinatura cancelada",
  SUBSCRIPTION_CREATED: "Assinatura criada",
  SUBSCRIPTION_UPDATED: "Assinatura alterada",
};

const FILTERS: { key: "all" | BillingEventOutcome; label: string }[] = [
  { key: "all", label: "Todos" },
  { key: "pending", label: "Pendentes" },
  { key: "applied", label: "Aplicados" },
  { key: "ignored", label: "Ignorados" },
  { key: "duplicate", label: "Duplicatas" },
];

export function Billing() {
  const [events, setEvents] = useState<BillingEvent[]>([]);
  const [counts, setCounts] = useState<Record<BillingEventOutcome, number> | null>(null);
  const [lastEventAt, setLastEventAt] = useState<string | null>(null);
  const [scoped, setScoped] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<"all" | BillingEventOutcome>("all");
  const [search, setSearch] = useState("");
  const [expanded, setExpanded] = useState<string | null>(null);

  const load = useCallback(() => {
    setLoading(true);
    setError(null);
    api
      .billingEvents({ limit: 200 })
      .then((r) => {
        setEvents(r.events);
        setCounts(r.counts);
        setLastEventAt(r.lastEventAt);
        setScoped(r.scopeInstitutionId !== null);
      })
      .catch((err) =>
        setError(err instanceof ApiError ? err.message : "Falha ao carregar eventos"),
      )
      .finally(() => setLoading(false));
  }, []);

  useEffect(load, [load]);

  const visible = useMemo(() => {
    const term = search.trim().toLowerCase();
    return events.filter((event) => {
      if (filter !== "all" && event.outcome !== filter) return false;
      if (!term) return true;
      return [
        event.event_type,
        event.event_id,
        event.institution_name ?? "",
        event.institution_slug ?? "",
        event.skipped_reason ?? "",
      ]
        .join(" ")
        .toLowerCase()
        .includes(term);
    });
  }, [events, filter, search]);

  const pending = counts?.pending ?? 0;

  return (
    <>
      <PageHeader
        title="Cobrança"
        subtitle={
          scoped
            ? "Eventos recebidos do provedor para a sua instituição. O motivo do descarte explica por que a conta não mudou."
            : "Eventos recebidos do provedor para todas as instituições. O motivo do descarte explica por que a conta não mudou."
        }
        actions={
          <button className="btn" onClick={load} disabled={loading}>
            {loading ? "Atualizando…" : "Atualizar"}
          </button>
        }
      />

      <ErrorNote message={error} />

      <div style={{ display: "flex", gap: 12, marginBottom: 18, flexWrap: "wrap" }}>
        <Stat label="Aplicados" value={counts?.applied ?? 0} tone="ok" />
        <Stat label="Ignorados" value={counts?.ignored ?? 0} />
        <Stat label="Duplicatas" value={counts?.duplicate ?? 0} />
        <Stat
          label="Pendentes"
          value={pending}
          tone={pending > 0 ? "danger" : undefined}
        />
      </div>

      {/*
        Um evento sem `processed_at` significa transação não concluída — o
        provedor acha que entregou e não entregou. É o único estado que exige
        alguém olhar, então ganha aviso próprio em vez de virar mais uma linha
        cinza na tabela.
      */}
      {pending > 0 && (
        <div
          role="status"
          style={{
            background: "#fbe9e7",
            color: "#b75046",
            padding: "10px 14px",
            borderRadius: 8,
            fontSize: 13,
            marginBottom: 14,
          }}
        >
          {pending === 1
            ? "1 evento foi recebido mas não terminou de ser processado."
            : `${pending} eventos foram recebidos mas não terminaram de ser processados.`}{" "}
          O provedor considera entregue; reenvie o evento ou verifique o log da API.
        </div>
      )}

      <section className="card">
        <div
          style={{
            display: "flex",
            gap: 8,
            alignItems: "center",
            marginBottom: 14,
            flexWrap: "wrap",
          }}
        >
          {FILTERS.map((item) => (
            <button
              key={item.key}
              className="btn"
              aria-pressed={filter === item.key}
              onClick={() => setFilter(item.key)}
              style={
                filter === item.key
                  ? { background: "var(--ink)", color: "#fff", borderColor: "var(--ink)" }
                  : undefined
              }
            >
              {item.label}
              {item.key !== "all" && counts ? ` (${counts[item.key]})` : ""}
            </button>
          ))}
          <div className="spacer" />
          <input
            className="input"
            style={{ width: 260 }}
            placeholder="Buscar por instituição, evento ou motivo"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        {visible.length === 0 ? (
          <Empty>
            {events.length === 0
              ? "Nenhum evento recebido ainda. Configure o webhook do provedor para começar."
              : "Nenhum evento com esse filtro."}
          </Empty>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Recebido</th>
                <th>Evento</th>
                {!scoped && <th>Instituição</th>}
                <th>Desfecho</th>
                <th>Motivo</th>
              </tr>
            </thead>
            <tbody>
              {visible.map((event) => {
                const open = expanded === event.id;
                return (
                  <>
                    <tr
                      key={event.id}
                      onClick={() => setExpanded(open ? null : event.id)}
                      style={{ cursor: "pointer" }}
                    >
                      <td className="small">{fmtDate(event.created_at)}</td>
                      <td className="small">
                        {EVENT_LABEL[event.event_type] ?? event.event_type}
                        <div className="muted mono small">{event.event_id}</div>
                      </td>
                      {!scoped && (
                        <td className="small">
                          {event.institution_name ?? <span className="muted">—</span>}
                          {event.institution_slug && (
                            <div className="muted small">{event.institution_slug}</div>
                          )}
                        </td>
                      )}
                      <td>
                        <OutcomeTag outcome={event.outcome} />
                      </td>
                      <td className="small muted" style={{ maxWidth: 320 }}>
                        {event.skipped_reason ?? event.error ?? "—"}
                      </td>
                    </tr>
                    {open && (
                      <tr key={`${event.id}-detail`}>
                        <td colSpan={scoped ? 4 : 5} style={{ background: "var(--surface-alt, #f7f9fb)" }}>
                          <div
                            style={{
                              display: "grid",
                              gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
                              gap: 12,
                              padding: "6px 2px",
                            }}
                          >
                            <Detail label="Provedor" value={event.provider} mono />
                            <Detail label="Id no provedor" value={event.event_id} mono />
                            <Detail
                              label="Ocorrido no provedor"
                              value={fmtDate(event.occurred_at)}
                            />
                            <Detail label="Processado em" value={fmtDate(event.processed_at)} />
                          </div>
                          {event.error && (
                            <div style={{ marginTop: 8 }}>
                              <span className="small" style={{ color: "var(--danger)" }}>
                                {event.error}
                              </span>
                            </div>
                          )}
                        </td>
                      </tr>
                    )}
                  </>
                );
              })}
            </tbody>
          </table>
        )}

        {lastEventAt && (
          <p className="small muted" style={{ marginTop: 12 }}>
            Último evento recebido em {fmtDate(lastEventAt)}.
          </p>
        )}
      </section>

      <p className="small muted" style={{ marginTop: 12, maxWidth: 760 }}>
        Reentrega é normal e não é erro: um evento marcado como duplicata é o
        provedor insistindo em algo já processado. Já um evento <em>ignorado</em>{" "}
        por ordem quer dizer que chegou depois de um mais novo — a conta reflete
        o mais recente, que é o correto.
      </p>
    </>
  );
}

function Detail({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div>
      <div style={{ fontSize: 11, fontWeight: 600, color: "var(--ink-soft)" }}>{label}</div>
      <div className={mono ? "mono small" : "small"}>{value || "—"}</div>
    </div>
  );
}
