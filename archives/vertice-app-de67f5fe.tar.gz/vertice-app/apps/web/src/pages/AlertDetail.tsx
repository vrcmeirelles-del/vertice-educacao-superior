import { useCallback, useEffect, useState } from "react";
import {
  api,
  ApiError,
  type AlertDetail as AlertDetailType,
  type AlertStatus,
  type SessionUser,
  type TimelineEvent,
} from "../api";
import { PageHeader } from "../components/Shell";
import { ErrorNote, Field, LevelBadge, StatusBadge, fmtDate } from "../components/ui";

const ACTIONS: { code: string; label: string }[] = [
  { code: "CONTACT_PHONE", label: "Contato telefônico" },
  { code: "CONTACT_EMAIL", label: "Contato por e-mail" },
  { code: "TUTORING", label: "Encaminhamento para monitoria/tutoria" },
  { code: "PEDAGOGICAL_SUPPORT", label: "Apoio pedagógico" },
  { code: "FINANCIAL_GUIDANCE", label: "Orientação sobre o fluxo de negociação" },
  { code: "NO_ACTION", label: "Sem ação necessária" },
];

/** Próximas transições válidas — espelham a regra do servidor. */
const NEXT: Record<AlertStatus, AlertStatus[]> = {
  open: ["assigned", "snoozed", "dismissed"],
  assigned: ["in_progress", "snoozed", "dismissed", "open"],
  in_progress: ["resolved", "snoozed", "dismissed"],
  snoozed: ["open", "assigned", "dismissed"],
  resolved: ["open"],
  dismissed: ["open"],
};

const EVENT_LABEL: Record<string, string> = {
  created: "Alerta criado",
  assigned: "Atendimento assumido",
  contact_logged: "Contato registrado",
  action_taken: "Ação registrada",
  snoozed: "Adiado",
  resolved: "Resolvido",
  dismissed: "Dispensado",
  reopened: "Reaberto",
  comment: "Comentário",
};

export function AlertDetail({
  id,
  user,
  onBack,
}: {
  id: string;
  user: SessionUser;
  onBack: () => void;
}) {
  const [alert, setAlert] = useState<AlertDetailType | null>(null);
  const [timeline, setTimeline] = useState<TimelineEvent[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [nextStatus, setNextStatus] = useState<AlertStatus | "">("");
  const [actionCode, setActionCode] = useState("");
  const [note, setNote] = useState("");
  const [snoozeDate, setSnoozeDate] = useState("");
  const [saving, setSaving] = useState(false);

  const readOnly = user.role === "auditor_readonly";

  const load = useCallback(() => {
    api
      .alert(id)
      .then((result) => {
        setAlert(result.alert);
        setTimeline(result.timeline);
      })
      .catch((err) => setError(err instanceof ApiError ? err.message : "Falha ao carregar alerta"));
  }, [id]);

  useEffect(load, [load]);

  async function submit() {
    if (!nextStatus) return;
    setSaving(true);
    setError(null);
    try {
      await api.updateAlert(id, {
        status: nextStatus,
        note: note || undefined,
        actionCode: actionCode || undefined,
        snoozedUntil: nextStatus === "snoozed" && snoozeDate ? new Date(snoozeDate).toISOString() : undefined,
      });
      setNote("");
      setActionCode("");
      setNextStatus("");
      setSnoozeDate("");
      load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Falha ao atualizar");
    } finally {
      setSaving(false);
    }
  }

  if (!alert) {
    return (
      <>
        <PageHeader title="Alerta" actions={<button className="btn" onClick={onBack}>Voltar</button>} />
        <ErrorNote message={error} />
      </>
    );
  }

  const transitions = NEXT[alert.status] ?? [];

  return (
    <>
      <PageHeader
        title={`Alerta · ${alert.course_name}`}
        subtitle={`Referência do estudante protegida por pseudônimo · coleta em ${fmtDate(alert.observed_at)}`}
        actions={
          <button className="btn" onClick={onBack}>
            Voltar
          </button>
        }
      />

      <ErrorNote message={error} />

      <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr", gap: 18, alignItems: "start" }}>
        <div className="stack">
          <section className="card" style={{ padding: 20 }}>
            <div className="row" style={{ marginBottom: 14 }}>
              <LevelBadge level={alert.level} />
              <span className="mono" style={{ fontSize: 26, fontWeight: 700 }}>
                {alert.score}
              </span>
              <span className="muted small">/ 100</span>
              <div className="spacer" />
              <StatusBadge status={alert.status} />
            </div>

            <h3 style={{ margin: "0 0 10px", fontSize: 15 }}>Por que este alerta foi gerado</h3>
            <table className="table">
              <thead>
                <tr>
                  <th>Fator</th>
                  <th>Observado</th>
                  <th>Limite</th>
                  <th style={{ textAlign: "right" }}>Pontos</th>
                </tr>
              </thead>
              <tbody>
                {alert.factors.map((factor) => (
                  <tr key={factor.code}>
                    <td>{factor.explanation}</td>
                    <td className="mono small">{String(factor.observed)}</td>
                    <td className="mono small muted">{String(factor.threshold)}</td>
                    <td style={{ textAlign: "right", fontWeight: 600 }}>+{factor.points}</td>
                  </tr>
                ))}
                {alert.factors.length === 0 && (
                  <tr>
                    <td colSpan={4} className="muted">
                      Sem fatores registrados.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>

            <div style={{ marginTop: 14, background: "#f7f9fb", borderRadius: 8, padding: 12 }}>
              <div className="small muted" style={{ marginBottom: 4 }}>
                Recomendação do sistema
              </div>
              <div>{alert.recommended_action}</div>
              <div className="small muted" style={{ marginTop: 8 }}>
                Regra aplicada: <span className="mono">{alert.rule_version}</span> · Nenhuma decisão
                automatizada é tomada sobre o estudante.
              </div>
            </div>
          </section>

          <section className="card" style={{ padding: 20 }}>
            <h3 style={{ margin: "0 0 12px", fontSize: 15 }}>Linha do tempo do atendimento</h3>
            {timeline.length === 0 ? (
              <p className="muted">Nenhum evento registrado.</p>
            ) : (
              <ol style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: 12 }}>
                {timeline.map((event) => (
                  <li key={event.id} style={{ display: "flex", gap: 12 }}>
                    <div
                      style={{
                        width: 8,
                        height: 8,
                        borderRadius: 4,
                        background: "var(--primary)",
                        marginTop: 7,
                        flexShrink: 0,
                      }}
                    />
                    <div>
                      <div style={{ fontWeight: 500 }}>
                        {EVENT_LABEL[event.type] ?? event.type}
                        {event.action_code && (
                          <span className="muted small">
                            {" "}
                            · {ACTIONS.find((a) => a.code === event.action_code)?.label ?? event.action_code}
                          </span>
                        )}
                      </div>
                      {event.note && <div className="small">{event.note}</div>}
                      <div className="small muted">
                        {fmtDate(event.created_at)} · {event.actor_name ?? "Sistema"}
                      </div>
                    </div>
                  </li>
                ))}
              </ol>
            )}
          </section>
        </div>

        <aside className="stack">
          <section className="card" style={{ padding: 20 }}>
            <h3 style={{ margin: "0 0 12px", fontSize: 15 }}>Registrar atendimento</h3>

            {readOnly ? (
              <p className="muted small">
                Seu perfil é somente leitura. Solicite a um coordenador o registro do atendimento.
              </p>
            ) : transitions.length === 0 ? (
              <p className="muted small">Nenhuma transição disponível para esta situação.</p>
            ) : (
              <div className="stack">
                <Field label="Próxima situação">
                  <select
                    className="select"
                    value={nextStatus}
                    onChange={(e) => setNextStatus(e.target.value as AlertStatus)}
                  >
                    <option value="">Selecione…</option>
                    {transitions.map((status) => (
                      <option key={status} value={status}>
                        {status === "assigned" ? "Assumir atendimento" : status.replace("_", " ")}
                      </option>
                    ))}
                  </select>
                </Field>

                {nextStatus === "snoozed" && (
                  <Field label="Reavaliar em">
                    <input
                      className="input"
                      type="date"
                      value={snoozeDate}
                      onChange={(e) => setSnoozeDate(e.target.value)}
                    />
                  </Field>
                )}

                <Field label="Ação institucional (opcional)">
                  <select className="select" value={actionCode} onChange={(e) => setActionCode(e.target.value)}>
                    <option value="">Nenhuma</option>
                    {ACTIONS.map((action) => (
                      <option key={action.code} value={action.code}>
                        {action.label}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Registro do contato">
                  <textarea
                    className="textarea"
                    rows={4}
                    maxLength={2000}
                    placeholder="Resumo do contato e do encaminhamento. Não inclua dados sensíveis."
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                  />
                </Field>

                <button className="btn btn-primary" onClick={submit} disabled={!nextStatus || saving}>
                  {saving ? "Salvando…" : "Registrar"}
                </button>
              </div>
            )}
          </section>

          <section className="card" style={{ padding: 20 }}>
            <h3 style={{ margin: "0 0 10px", fontSize: 15 }}>Dados observados</h3>
            <dl style={{ margin: 0, display: "grid", gridTemplateColumns: "1fr auto", gap: "8px 12px" }}>
              <dt className="muted small">Fonte</dt>
              <dd className="small mono" style={{ margin: 0 }}>{alert.source}</dd>
              <dt className="muted small">Frequência</dt>
              <dd className="small mono" style={{ margin: 0 }}>
                {alert.attendance_percent != null ? `${Number(alert.attendance_percent)}%` : "—"}
              </dd>
              <dt className="muted small">Faltas consecutivas</dt>
              <dd className="small mono" style={{ margin: 0 }}>{alert.consecutive_absences ?? "—"}</dd>
              <dt className="muted small">Média parcial</dt>
              <dd className="small mono" style={{ margin: 0 }}>
                {alert.assessment_average != null ? Number(alert.assessment_average) : "—"}
              </dd>
              <dt className="muted small">Média de referência</dt>
              <dd className="small mono" style={{ margin: 0 }}>
                {alert.passing_average != null ? Number(alert.passing_average) : "—"}
              </dd>
              <dt className="muted small">Requerimentos</dt>
              <dd className="small mono" style={{ margin: 0 }}>
                {alert.open_requests.length ? alert.open_requests.join(", ") : "—"}
              </dd>
            </dl>
            <p className="small muted" style={{ marginBottom: 0 }}>
              O identificador do estudante não é armazenado em claro. Use o procedimento interno da
              IES para localizar a matrícula.
            </p>
          </section>
        </aside>
      </div>
    </>
  );
}
