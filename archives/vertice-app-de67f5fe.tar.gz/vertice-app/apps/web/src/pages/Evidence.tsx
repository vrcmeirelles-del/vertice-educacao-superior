import { useCallback, useEffect, useMemo, useState } from "react";
import { api, ApiError, type EvidenceItem, type Instrument, type SessionUser } from "../api";
import { PageHeader } from "../components/Shell";
import { Empty, ErrorNote, StatusBadge, fmtDateOnly } from "../components/ui";

const STATUS_FLOW: Record<string, string[]> = {
  pending: ["in_review", "not_applicable"],
  in_review: ["validated", "changes_requested", "not_applicable"],
  changes_requested: ["in_review", "pending"],
  validated: ["expired", "in_review"],
  expired: ["in_review"],
  not_applicable: ["pending"],
};

export function Evidence({ user }: { user: SessionUser }) {
  const [items, setItems] = useState<EvidenceItem[]>([]);
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [instruments, setInstruments] = useState<Instrument[]>([]);
  const [statusFilter, setStatusFilter] = useState("");
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(() => {
    api
      .evidence({ status: statusFilter || undefined })
      .then((r) => {
        setItems(r.evidence);
        setCounts(r.countsByStatus);
      })
      .catch((err) => setError(err instanceof ApiError ? err.message : "Falha ao carregar"));
  }, [statusFilter]);

  useEffect(load, [load]);
  useEffect(() => {
    api.instruments().then((r) => setInstruments(r.instruments)).catch(() => undefined);
  }, []);

  const byAxis = useMemo(() => {
    const groups = new Map<string, EvidenceItem[]>();
    for (const item of items) {
      const list = groups.get(item.axis) ?? [];
      list.push(item);
      groups.set(item.axis, list);
    }
    return [...groups.entries()];
  }, [items]);

  const total = Object.values(counts).reduce((a, b) => a + b, 0);
  const validated = counts.validated ?? 0;
  const readiness = total > 0 ? Math.round((validated / total) * 100) : 0;

  async function transition(item: EvidenceItem, status: string) {
    const opinion = status === "validated" ? "" : status === "changes_requested"
      ? window.prompt("Descreva o ajuste necessário:") ?? ""
      : "";
    try {
      await api.transitionEvidence(item.id, { status, opinion: opinion || undefined });
      load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Falha na transição");
    }
  }

  const canWrite = user.role === "institution_admin" || user.role === "regulatory_manager" || user.role === "platform_admin";

  return (
    <>
      <PageHeader
        title="Evidências regulatórias"
        subtitle="Checklist organizado por instrumento, versão e fonte oficial. A plataforma não garante conceito."
      />

      <ErrorNote message={error} />

      <div className="row" style={{ gap: 14, marginBottom: 18, flexWrap: "wrap" }}>
        <section className="card" style={{ padding: "16px 18px", minWidth: 200 }}>
          <div className="small muted" style={{ fontWeight: 600 }}>Prontidão</div>
          <div style={{ fontSize: 26, fontWeight: 700, color: readiness >= 70 ? "var(--ok)" : "var(--warn)" }}>
            {readiness}%
          </div>
          <div className="small muted">{validated} de {total} evidências validadas</div>
        </section>
        {instruments.map((instrument) => (
          <section key={instrument.id} className="card" style={{ padding: "16px 18px", minWidth: 240 }}>
            <div className="small muted" style={{ fontWeight: 600 }}>{instrument.code} · {instrument.version}</div>
            <div style={{ fontWeight: 600, marginTop: 2 }}>{instrument.title}</div>
            <div className="small muted">{instrument.requirement_count} exigências · {instrument.status}</div>
            <div className="small" style={{ color: "var(--warn)", marginTop: 6 }}>
              Fonte: {instrument.official_source}
            </div>
          </section>
        ))}
      </div>

      <div className="row" style={{ marginBottom: 12 }}>
        <select className="select" style={{ width: 200 }} value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          <option value="">Todas as situações</option>
          <option value="pending">Pendentes</option>
          <option value="in_review">Em revisão</option>
          <option value="validated">Validadas</option>
          <option value="changes_requested">Ajustes solicitados</option>
          <option value="expired">Vencidas</option>
        </select>
        <div className="spacer" />
        <button className="btn" onClick={load}>Atualizar</button>
      </div>

      {byAxis.length === 0 && <section className="card"><Empty>Nenhuma evidência criada.</Empty></section>}

      {byAxis.map(([axis, list]) => (
        <section key={axis} className="card" style={{ marginBottom: 16 }}>
          <div style={{ padding: "14px 18px", borderBottom: "1px solid var(--line)", fontWeight: 600 }}>
            {axis}
          </div>
          <table className="table">
            <thead>
              <tr>
                <th style={{ width: 70 }}>Código</th>
                <th>Indicador</th>
                <th>Evidência esperada</th>
                <th>Responsável</th>
                <th>Prazo</th>
                <th>Situação</th>
                {canWrite && <th style={{ width: 200 }}>Ação</th>}
              </tr>
            </thead>
            <tbody>
              {list.map((item) => (
                <tr key={item.id}>
                  <td className="mono small">{item.requirement_code}</td>
                  <td>
                    <div style={{ fontWeight: 500 }}>{item.indicator}</div>
                    <div className="small muted">{item.criterion}</div>
                  </td>
                  <td className="small" style={{ maxWidth: 280 }}>{item.expected_evidence}</td>
                  <td className="small">{item.owner_name ?? "—"}</td>
                  <td className="small">{fmtDateOnly(item.due_date)}</td>
                  <td><StatusBadge status={item.status} /></td>
                  {canWrite && (
                    <td>
                      <select
                        className="select"
                        value=""
                        onChange={(e) => e.target.value && transition(item, e.target.value)}
                      >
                        <option value="">Alterar…</option>
                        {(STATUS_FLOW[item.status] ?? []).map((next) => (
                          <option key={next} value={next}>
                            {next.replace(/_/g, " ")}
                          </option>
                        ))}
                      </select>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      ))}

      <p className="muted small">
        Exigências são carregadas de um catálogo versionado com fonte oficial e vigência. Atualizar o
        instrumento não altera avaliações já encerradas.
      </p>
    </>
  );
}
