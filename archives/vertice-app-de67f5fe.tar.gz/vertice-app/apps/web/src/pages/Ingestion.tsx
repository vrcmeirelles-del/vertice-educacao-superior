import { useCallback, useEffect, useState } from "react";
import {
  api,
  ApiError,
  type Course,
  type IngestionBatch,
  type IngestSummary,
  type RetentionRecord,
  type SessionUser,
} from "../api";
import { PageHeader } from "../components/Shell";
import { Empty, ErrorNote, Field, StatusBadge, fmtDate } from "../components/ui";

/** Converte CSV colado em registros. Cabeçalho obrigatório, sem campos livres. */
function parseCsv(text: string): { records: RetentionRecord[]; errors: string[] } {
  const errors: string[] = [];
  const lines = text.trim().split(/\r?\n/).filter(Boolean);
  if (lines.length < 2) return { records: [], errors: ["CSV vazio ou sem linhas de dados."] };

  const header = lines[0]!.split(",").map((h) => h.trim());
  const required = ["studentRef", "courseRef", "observedAt", "source"];
  const missing = required.filter((field) => !header.includes(field));
  if (missing.length) {
    return { records: [], errors: [`Colunas obrigatórias ausentes: ${missing.join(", ")}`] };
  }

  const records: RetentionRecord[] = [];
  lines.slice(1).forEach((line, index) => {
    const cells = line.split(",").map((c) => c.trim());
    const row = Object.fromEntries(header.map((key, i) => [key, cells[i] ?? ""]));

    const num = (value: string) => (value === "" ? null : Number(value.replace(",", ".")));
    const record: RetentionRecord = {
      studentRef: row.studentRef ?? "",
      courseRef: row.courseRef ?? "",
      observedAt: row.observedAt?.includes("T")
        ? row.observedAt
        : new Date(`${row.observedAt}T12:00:00-03:00`).toISOString(),
      source: row.source ?? "csv-import",
      attendancePercent: num(row.attendancePercent ?? ""),
      consecutiveAbsences: row.consecutiveAbsences ? Number(row.consecutiveAbsences) : null,
      assessmentAverage: num(row.assessmentAverage ?? ""),
      passingAverage: num(row.passingAverage ?? ""),
      openRequests: (row.openRequests ?? "")
        .split("|")
        .map((v) => v.trim())
        .filter(Boolean),
    };

    if (Number.isNaN(Date.parse(record.observedAt))) {
      errors.push(`Linha ${index + 2}: observedAt inválido`);
      return;
    }
    records.push(record);
  });

  return { records, errors };
}

export function Ingestion({ user }: { user: SessionUser }) {
  const [tab, setTab] = useState<"csv" | "manual" | "batches">("csv");
  const [csv, setCsv] = useState("");
  const [courses, setCourses] = useState<Course[]>([]);
  const [batches, setBatches] = useState<IngestionBatch[]>([]);
  const [result, setResult] = useState<IngestSummary | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const [manual, setManual] = useState({
    studentRef: "",
    courseRef: "",
    attendancePercent: "",
    consecutiveAbsences: "",
    assessmentAverage: "",
    passingAverage: "",
    openRequests: [] as string[],
  });

  const loadBatches = useCallback(() => {
    api.ingestions().then((r) => setBatches(r.batches)).catch(() => undefined);
  }, []);

  useEffect(() => {
    api.courses().then((r) => setCourses(r.courses)).catch(() => undefined);
    loadBatches();
  }, [loadBatches]);

  async function sendRecords(records: RetentionRecord[]) {
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      const summary = await api.ingest(records);
      setResult(summary);
      loadBatches();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Falha na importação");
    } finally {
      setBusy(false);
    }
  }

  async function submitCsv() {
    const parsed = parseCsv(csv);
    if (parsed.errors.length) {
      setError(parsed.errors.slice(0, 5).join(" · "));
      return;
    }
    await sendRecords(parsed.records);
    setCsv("");
  }

  async function submitManual() {
    const record: RetentionRecord = {
      studentRef: manual.studentRef,
      courseRef: manual.courseRef,
      attendancePercent: manual.attendancePercent ? Number(manual.attendancePercent) : null,
      consecutiveAbsences: manual.consecutiveAbsences ? Number(manual.consecutiveAbsences) : null,
      assessmentAverage: manual.assessmentAverage ? Number(manual.assessmentAverage) : null,
      passingAverage: manual.passingAverage ? Number(manual.passingAverage) : null,
      openRequests: manual.openRequests,
      observedAt: new Date().toISOString(),
      source: "manual-entry",
    };
    await sendRecords([record]);
  }

  const canWrite = user.role !== "auditor_readonly";

  return (
    <>
      <PageHeader
        title="Importações"
        subtitle="Entrada de dados mínimos. O contrato rejeita nome, CPF, e-mail, telefone e texto livre."
      />

      <ErrorNote message={error} />

      <div className="row" style={{ marginBottom: 16, gap: 6 }}>
        {[
          { key: "csv", label: "Importar CSV" },
          { key: "manual", label: "Registro único" },
          { key: "batches", label: "Histórico" },
        ].map((item) => (
          <button
            key={item.key}
            className={tab === item.key ? "btn btn-primary" : "btn"}
            onClick={() => setTab(item.key as typeof tab)}
          >
            {item.label}
          </button>
        ))}
      </div>

      {result && (
        <section className="card" style={{ padding: 18, marginBottom: 16 }}>
          <div className="row">
            <strong>Lote processado</strong>
            <div className="spacer" />
            <span className="badge badge-low">{result.accepted} aceitos</span>
            {result.rejected > 0 && <span className="badge badge-critical">{result.rejected} rejeitados</span>}
            <span className="badge badge-medium">{result.alertsCreated} alertas</span>
          </div>
          {result.unknownCourses.length > 0 && (
            <p className="small" style={{ color: "var(--warn)", marginBottom: 0 }}>
              Cursos não cadastrados: {result.unknownCourses.join(", ")}. Cadastre o curso antes de importar.
            </p>
          )}
          {result.rejections.length > 0 && (
            <details style={{ marginTop: 8 }}>
              <summary className="small muted">Detalhes das rejeições</summary>
              <ul className="small">
                {result.rejections.slice(0, 20).map((item) => (
                  <li key={item.index}>
                    Linha {item.index + 2}: {item.reason}
                    {item.field ? ` (${item.field})` : ""}
                  </li>
                ))}
              </ul>
            </details>
          )}
        </section>
      )}

      {tab === "csv" && (
        <section className="card" style={{ padding: 20 }}>
          <p className="small muted" style={{ marginTop: 0 }}>
            Cabeçalho obrigatório:{" "}
            <span className="mono">
              studentRef,courseRef,attendancePercent,consecutiveAbsences,assessmentAverage,passingAverage,openRequests,observedAt,source
            </span>
            . Separe múltiplos requerimentos com <span className="mono">|</span>.
          </p>
          <textarea
            className="textarea mono"
            rows={12}
            placeholder={"studentRef,courseRef,attendancePercent,consecutiveAbsences,assessmentAverage,passingAverage,openRequests,observedAt,source\nabc123,DIR,72,4,4.5,6,TRANSFER_REQUEST,2026-10-27,portal"}
            value={csv}
            onChange={(e) => setCsv(e.target.value)}
            disabled={!canWrite}
          />
          <div className="row" style={{ marginTop: 12 }}>
            <div className="spacer" />
            <button className="btn btn-primary" onClick={submitCsv} disabled={!canWrite || busy || !csv.trim()}>
              {busy ? "Importando…" : "Importar registros"}
            </button>
          </div>
        </section>
      )}

      {tab === "manual" && (
        <section className="card" style={{ padding: 20 }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
            <Field label="Identificador do estudante (pseudônimo)">
              <input className="input mono" value={manual.studentRef} onChange={(e) => setManual({ ...manual, studentRef: e.target.value })} />
            </Field>
            <Field label="Curso">
              <select className="select" value={manual.courseRef} onChange={(e) => setManual({ ...manual, courseRef: e.target.value })}>
                <option value="">Selecione…</option>
                {courses.map((c) => (
                  <option key={c.id} value={c.code}>{c.name}</option>
                ))}
              </select>
            </Field>
            <Field label="Frequência (%)">
              <input className="input" type="number" min={0} max={100} value={manual.attendancePercent} onChange={(e) => setManual({ ...manual, attendancePercent: e.target.value })} />
            </Field>
            <Field label="Faltas consecutivas">
              <input className="input" type="number" min={0} value={manual.consecutiveAbsences} onChange={(e) => setManual({ ...manual, consecutiveAbsences: e.target.value })} />
            </Field>
            <Field label="Média parcial">
              <input className="input" type="number" min={0} max={10} step="0.1" value={manual.assessmentAverage} onChange={(e) => setManual({ ...manual, assessmentAverage: e.target.value })} />
            </Field>
            <Field label="Média de referência">
              <input className="input" type="number" min={0} max={10} step="0.1" value={manual.passingAverage} onChange={(e) => setManual({ ...manual, passingAverage: e.target.value })} />
            </Field>
          </div>
          <div className="row" style={{ marginTop: 12 }}>
            <span className="small muted">Requerimentos:</span>
            {["TRANSFER_REQUEST", "WITHDRAWAL_REQUEST", "HISTORY_REQUEST", "SYLLABUS_REQUEST"].map((code) => (
              <label key={code} className="small row" style={{ gap: 4 }}>
                <input
                  type="checkbox"
                  checked={manual.openRequests.includes(code)}
                  onChange={(e) =>
                    setManual({
                      ...manual,
                      openRequests: e.target.checked
                        ? [...manual.openRequests, code]
                        : manual.openRequests.filter((c) => c !== code),
                    })
                  }
                />
                {code.replace("_REQUEST", "").toLowerCase()}
              </label>
            ))}
          </div>
          <div className="row" style={{ marginTop: 16 }}>
            <div className="spacer" />
            <button
              className="btn btn-primary"
              onClick={submitManual}
              disabled={!canWrite || busy || !manual.studentRef || !manual.courseRef}
            >
              {busy ? "Enviando…" : "Avaliar e registrar"}
            </button>
          </div>
        </section>
      )}

      {tab === "batches" && (
        <section className="card">
          {batches.length === 0 ? (
            <Empty>Nenhum lote importado ainda.</Empty>
          ) : (
            <table className="table">
              <thead>
                <tr>
                  <th>Data</th>
                  <th>Origem</th>
                  <th>Status</th>
                  <th style={{ textAlign: "right" }}>Recebidos</th>
                  <th style={{ textAlign: "right" }}>Aceitos</th>
                  <th style={{ textAlign: "right" }}>Rejeitados</th>
                </tr>
              </thead>
              <tbody>
                {batches.map((batch) => (
                  <tr key={batch.id}>
                    <td className="small">{fmtDate(batch.created_at)}</td>
                    <td className="small mono">{batch.source}</td>
                    <td><StatusBadge status={batch.status} /></td>
                    <td style={{ textAlign: "right" }}>{batch.total_records}</td>
                    <td style={{ textAlign: "right" }}>{batch.accepted_records}</td>
                    <td style={{ textAlign: "right" }}>{batch.rejected_records}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      )}
    </>
  );
}
