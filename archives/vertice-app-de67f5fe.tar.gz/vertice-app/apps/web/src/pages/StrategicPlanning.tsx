import { useCallback, useEffect, useState } from "react";
import { api, ApiError, type Course, type SessionUser } from "../api";
import { PageHeader } from "../components/Shell";
import { ErrorNote, Field } from "../components/ui";

type TabKey =
  | "identificacao"
  | "visao"
  | "ciclo"
  | "bcg"
  | "porter"
  | "fcs"
  | "atributos"
  | "objetivos"
  | "operacional"
  | "semestre";

const TABS: { key: TabKey; label: string }[] = [
  { key: "identificacao", label: "1. Identificação" },
  { key: "visao", label: "2. Visão" },
  { key: "ciclo", label: "3. Ciclo de Vida" },
  { key: "bcg", label: "4. Matriz BCG" },
  { key: "porter", label: "5. Porter" },
  { key: "fcs", label: "6-9. FCS" },
  { key: "atributos", label: "10. Atributos" },
  { key: "objetivos", label: "11. Objetivos Estratégicos" },
  { key: "operacional", label: "12. Plano de Ação" },
  { key: "semestre", label: "Semestre" },
];

interface VisionReflection { item: string; current_state: string; desired_state: string; }
interface BcgStrategy { quadrant: string; strategy: string; }
interface FcsInstitutional { name: string; description: string; differentiator: string; }
interface FcsCourse { name: string; maturity: string; differentiator: string; }
interface FcsCompetitor { fcs_name: string; competitors: { name: string; rating: string }[]; }
interface FcsCompetitive { fcs_name: string; institution_code: string; rating: string; }
interface AttributeRow { attribute: string; importance: string; satisfaction: string; gap: string; }
interface StrategicObjective {
  theme: string;
  indicator: string;
  description: string;
  targets: { year1?: string; year2?: string; year3?: string; year4?: string; year5?: string };
}
interface OperationalObjective {
  description: string;
  responsible: string | null;
  deadline: string | null;
  resources: string | null;
  status: "planned" | "in_progress" | "completed" | "cancelled";
}
interface SemesterActivity {
  month: string;
  date: string;
  event: string;
  event_type: string | null;
  action: string | null;
  student_count: string | null;
  location: string | null;
  status: "planned" | "in_progress" | "completed" | "cancelled";
}

interface PlanDraft {
  id?: string;
  courseId: string;
  version: number;
  status: "draft" | "published" | "archived";
  coordinator_name: string | null;
  coordinator_since: string | null;
  enrolled_count: number | null;
  first_semester: string | null;
  vision_text: string | null;
  vision_inspirations: { text: string }[];
  vision_reflections: VisionReflection[];
  lifecycle_stage: string | null;
  lifecycle_strategies: { text: string }[];
  bcg_market_growth: string | null;
  bcg_market_share: string | null;
  bcg_quadrant: string | null;
  bcg_strategies: BcgStrategy[];
  porter_rivalry: string | null;
  porter_buyer_power: string | null;
  porter_supplier_power: string | null;
  porter_substitutes: string | null;
  porter_new_entrants: string | null;
  fcs_institutional: FcsInstitutional[];
  fcs_course: FcsCourse[];
  fcs_competitors: FcsCompetitor[];
  fcs_competitive_matrix: FcsCompetitive[];
  attributes_matrix: AttributeRow[];
  strategic_objectives: StrategicObjective[];
  operational_objectives: OperationalObjective[];
}

interface SemesterDraft {
  id?: string;
  courseId: string;
  semester: string;
  form_code: string | null;
  version: number;
  status: "draft" | "published" | "archived";
  activities: SemesterActivity[];
}

const EMPTY_PLAN: PlanDraft = {
  courseId: "", version: 1, status: "draft",
  coordinator_name: null, coordinator_since: null, enrolled_count: null, first_semester: null,
  vision_text: null, vision_inspirations: [], vision_reflections: [],
  lifecycle_stage: null, lifecycle_strategies: [],
  bcg_market_growth: null, bcg_market_share: null, bcg_quadrant: null, bcg_strategies: [],
  porter_rivalry: null, porter_buyer_power: null, porter_supplier_power: null,
  porter_substitutes: null, porter_new_entrants: null,
  fcs_institutional: [], fcs_course: [], fcs_competitors: [], fcs_competitive_matrix: [],
  attributes_matrix: [], strategic_objectives: [], operational_objectives: [],
};

const EMPTY_SEMESTER: SemesterDraft = {
  courseId: "", semester: "", form_code: null, version: 1, status: "draft", activities: [],
};

function TextField({ label, value, onChange, multiline = false, rows = 3 }: {
  label: string; value: string | null | undefined; onChange: (v: string) => void; multiline?: boolean; rows?: number;
}) {
  return (
    <Field label={label}>
      {multiline ? (
        <textarea className="textarea" rows={rows} value={value ?? ""} onChange={(e) => onChange(e.target.value)} />
      ) : (
        <input className="input" value={value ?? ""} onChange={(e) => onChange(e.target.value)} />
      )}
    </Field>
  );
}

function SectionCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="card" style={{ padding: 20 }}>
      <h3 style={{ margin: "0 0 14px", fontSize: 16, fontWeight: 650 }}>{title}</h3>
      <div className="stack">{children}</div>
    </div>
  );
}

function IdentificacaoTab({ plan, setPlan }: { plan: PlanDraft; setPlan: (p: PlanDraft) => void }) {
  return (
    <SectionCard title="Identificação do Curso">
      <TextField label="Nome do coordenador" value={plan.coordinator_name}
        onChange={(v) => setPlan({ ...plan, coordinator_name: v })} />
      <TextField label="Tempo na coordenação" value={plan.coordinator_since}
        onChange={(v) => setPlan({ ...plan, coordinator_since: v })} />
      <Field label="Matriculados (último censo)">
        <input className="input" type="number" value={plan.enrolled_count ?? ""}
          onChange={(e) => setPlan({ ...plan, enrolled_count: e.target.value === "" ? null : Number(e.target.value) })} />
      </Field>
      <TextField label="Semestre da primeira turma (AAAA/S)" value={plan.first_semester}
        onChange={(v) => setPlan({ ...plan, first_semester: v })} />
    </SectionCard>
  );
}

function VisaoTab({ plan, setPlan }: { plan: PlanDraft; setPlan: (p: PlanDraft) => void }) {
  return (
    <SectionCard title="Visão Estratégica">
      <TextField label="Onde o curso deseja estar no futuro?" value={plan.vision_text}
        onChange={(v) => setPlan({ ...plan, vision_text: v })} multiline rows={5} />
      <Field label="Reflexões (Estado Atual vs. Desejado)">
        <div className="stack" style={{ gap: 8 }}>
          {plan.vision_reflections.map((r, i) => (
            <div key={i} className="card" style={{ padding: 12 }}>
              <input className="input" placeholder="Item" value={r.item}
                onChange={(e) => {
                  const next = [...plan.vision_reflections];
                  next[i] = { ...r, item: e.target.value };
                  setPlan({ ...plan, vision_reflections: next });
                }} />
              <div className="row" style={{ marginTop: 6 }}>
                <input className="input" placeholder="Estado atual" value={r.current_state}
                  onChange={(e) => {
                    const next = [...plan.vision_reflections];
                    next[i] = { ...r, current_state: e.target.value };
                    setPlan({ ...plan, vision_reflections: next });
                  }} />
                <input className="input" placeholder="Estado desejado" value={r.desired_state}
                  onChange={(e) => {
                    const next = [...plan.vision_reflections];
                    next[i] = { ...r, desired_state: e.target.value };
                    setPlan({ ...plan, vision_reflections: next });
                  }} />
              </div>
            </div>
          ))}
          <button className="btn btn-ghost" onClick={() => setPlan({
            ...plan,
            vision_reflections: [...plan.vision_reflections, { item: "", current_state: "", desired_state: "" }],
          })}>+ Adicionar reflexão</button>
        </div>
      </Field>
    </SectionCard>
  );
}

function CicloTab({ plan, setPlan }: { plan: PlanDraft; setPlan: (p: PlanDraft) => void }) {
  const stages = ["Introdução", "Crescimento", "Maturidade", "Declínio"];
  return (
    <SectionCard title="Ciclo de Vida do Curso">
      <Field label="Estágio atual">
        <select className="select" value={plan.lifecycle_stage ?? ""}
          onChange={(e) => setPlan({ ...plan, lifecycle_stage: e.target.value || null })}>
          <option value="">— selecione —</option>
          {stages.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
      </Field>
      <Field label="Estratégias para o estágio">
        <div className="stack" style={{ gap: 6 }}>
          {plan.lifecycle_strategies.map((s, i) => (
            <input key={i} className="input" value={s.text}
              onChange={(e) => {
                const next = [...plan.lifecycle_strategies];
                next[i] = { text: e.target.value };
                setPlan({ ...plan, lifecycle_strategies: next });
              }} />
          ))}
          <button className="btn btn-ghost"
            onClick={() => setPlan({ ...plan, lifecycle_strategies: [...plan.lifecycle_strategies, { text: "" }] })}>
            + Adicionar estratégia
          </button>
        </div>
      </Field>
    </SectionCard>
  );
}

function BcgTab({ plan, setPlan }: { plan: PlanDraft; setPlan: (p: PlanDraft) => void }) {
  const quadrants = ["Estrela", "Interrogação", "Vaca Leiteira", "Abacaxi"];
  return (
    <SectionCard title="Matriz BCG">
      <TextField label="Taxa de crescimento do mercado" value={plan.bcg_market_growth}
        onChange={(v) => setPlan({ ...plan, bcg_market_growth: v })} />
      <TextField label="Participação relativa no mercado" value={plan.bcg_market_share}
        onChange={(v) => setPlan({ ...plan, bcg_market_share: v })} />
      <Field label="Quadrante">
        <select className="select" value={plan.bcg_quadrant ?? ""}
          onChange={(e) => setPlan({ ...plan, bcg_quadrant: e.target.value || null })}>
          <option value="">— selecione —</option>
          {quadrants.map((q) => <option key={q} value={q}>{q}</option>)}
        </select>
      </Field>
    </SectionCard>
  );
}

function PorterTab({ plan, setPlan }: { plan: PlanDraft; setPlan: (p: PlanDraft) => void }) {
  return (
    <SectionCard title="5 Forças de Porter">
      <TextField label="Rivalidade entre concorrentes" value={plan.porter_rivalry}
        onChange={(v) => setPlan({ ...plan, porter_rivalry: v })} multiline />
      <TextField label="Poder de negociação dos clientes" value={plan.porter_buyer_power}
        onChange={(v) => setPlan({ ...plan, porter_buyer_power: v })} multiline />
      <TextField label="Poder de negociação dos fornecedores" value={plan.porter_supplier_power}
        onChange={(v) => setPlan({ ...plan, porter_supplier_power: v })} multiline />
      <TextField label="Ameaça de produtos substitutos" value={plan.porter_substitutes}
        onChange={(v) => setPlan({ ...plan, porter_substitutes: v })} multiline />
      <TextField label="Ameaça de novos entrantes" value={plan.porter_new_entrants}
        onChange={(v) => setPlan({ ...plan, porter_new_entrants: v })} multiline />
    </SectionCard>
  );
}

function FcsTab({ plan, setPlan }: { plan: PlanDraft; setPlan: (p: PlanDraft) => void }) {
  return (
    <>
      <SectionCard title="FCS Institucionais (4 fatores)">
        <div className="stack" style={{ gap: 8 }}>
          {plan.fcs_institutional.map((f, i) => (
            <div key={i} className="card" style={{ padding: 12 }}>
              <input className="input" placeholder="Nome do FCS" value={f.name}
                onChange={(e) => { const n = [...plan.fcs_institutional]; n[i] = { ...f, name: e.target.value }; setPlan({ ...plan, fcs_institutional: n }); }} />
              <textarea className="textarea" rows={2} placeholder="Descrição" style={{ marginTop: 6 }} value={f.description}
                onChange={(e) => { const n = [...plan.fcs_institutional]; n[i] = { ...f, description: e.target.value }; setPlan({ ...plan, fcs_institutional: n }); }} />
              <textarea className="textarea" rows={2} placeholder="Diferencial estratégico" style={{ marginTop: 6 }} value={f.differentiator}
                onChange={(e) => { const n = [...plan.fcs_institutional]; n[i] = { ...f, differentiator: e.target.value }; setPlan({ ...plan, fcs_institutional: n }); }} />
            </div>
          ))}
          <button className="btn btn-ghost"
            onClick={() => setPlan({ ...plan, fcs_institutional: [...plan.fcs_institutional, { name: "", description: "", differentiator: "" }] })}>
            + Adicionar FCS institucional
          </button>
        </div>
      </SectionCard>

      <SectionCard title="FCS do Curso (maturidade + diferencial)">
        <div className="stack" style={{ gap: 8 }}>
          {plan.fcs_course.map((f, i) => (
            <div key={i} className="card" style={{ padding: 12 }}>
              <input className="input" placeholder="Nome do FCS" value={f.name}
                onChange={(e) => { const n = [...plan.fcs_course]; n[i] = { ...f, name: e.target.value }; setPlan({ ...plan, fcs_course: n }); }} />
              <div className="row" style={{ marginTop: 6 }}>
                <select className="select" value={f.maturity}
                  onChange={(e) => { const n = [...plan.fcs_course]; n[i] = { ...f, maturity: e.target.value }; setPlan({ ...plan, fcs_course: n }); }}>
                  <option value="">— maturidade —</option>
                  <option value="baixa">Baixa</option>
                  <option value="media">Média</option>
                  <option value="alta">Alta</option>
                </select>
                <input className="input" placeholder="Diferencial" value={f.differentiator}
                  onChange={(e) => { const n = [...plan.fcs_course]; n[i] = { ...f, differentiator: e.target.value }; setPlan({ ...plan, fcs_course: n }); }} />
              </div>
            </div>
          ))}
          <button className="btn btn-ghost"
            onClick={() => setPlan({ ...plan, fcs_course: [...plan.fcs_course, { name: "", maturity: "", differentiator: "" }] })}>
            + Adicionar FCS do curso
          </button>
        </div>
      </SectionCard>
    </>
  );
}

function AtributosTab({ plan, setPlan }: { plan: PlanDraft; setPlan: (p: PlanDraft) => void }) {
  return (
    <SectionCard title="Matriz de Atributos">
      <table className="table">
        <thead>
          <tr><th>Atributo</th><th>Importância</th><th>Satisfação</th><th>Gap</th></tr>
        </thead>
        <tbody>
          {plan.attributes_matrix.map((r, i) => (
            <tr key={i}>
              <td><input className="input" value={r.attribute}
                onChange={(e) => { const n = [...plan.attributes_matrix]; n[i] = { ...r, attribute: e.target.value }; setPlan({ ...plan, attributes_matrix: n }); }} /></td>
              <td><input className="input" value={r.importance}
                onChange={(e) => { const n = [...plan.attributes_matrix]; n[i] = { ...r, importance: e.target.value }; setPlan({ ...plan, attributes_matrix: n }); }} /></td>
              <td><input className="input" value={r.satisfaction}
                onChange={(e) => { const n = [...plan.attributes_matrix]; n[i] = { ...r, satisfaction: e.target.value }; setPlan({ ...plan, attributes_matrix: n }); }} /></td>
              <td><input className="input" value={r.gap}
                onChange={(e) => { const n = [...plan.attributes_matrix]; n[i] = { ...r, gap: e.target.value }; setPlan({ ...plan, attributes_matrix: n }); }} /></td>
            </tr>
          ))}
        </tbody>
      </table>
      <button className="btn btn-ghost"
        onClick={() => setPlan({ ...plan, attributes_matrix: [...plan.attributes_matrix, { attribute: "", importance: "", satisfaction: "", gap: "" }] })}>
        + Adicionar atributo
      </button>
    </SectionCard>
  );
}

function ObjetivosTab({ plan, setPlan }: { plan: PlanDraft; setPlan: (p: PlanDraft) => void }) {
  return (
    <SectionCard title="Objetivos Estratégicos (5 anos)">
      <div className="stack" style={{ gap: 10 }}>
        {plan.strategic_objectives.map((o, i) => (
          <div key={i} className="card" style={{ padding: 14 }}>
            <div className="row">
              <input className="input" placeholder="Tema" value={o.theme}
                onChange={(e) => { const n = [...plan.strategic_objectives]; n[i] = { ...o, theme: e.target.value }; setPlan({ ...plan, strategic_objectives: n }); }} />
              <input className="input" placeholder="Indicador" value={o.indicator}
                onChange={(e) => { const n = [...plan.strategic_objectives]; n[i] = { ...o, indicator: e.target.value }; setPlan({ ...plan, strategic_objectives: n }); }} />
            </div>
            <textarea className="textarea" rows={2} placeholder="Descrição" style={{ marginTop: 8 }} value={o.description}
              onChange={(e) => { const n = [...plan.strategic_objectives]; n[i] = { ...o, description: e.target.value }; setPlan({ ...plan, strategic_objectives: n }); }} />
            <div className="row" style={{ marginTop: 8 }}>
              {([1, 2, 3, 4, 5] as const).map((y) => (
                <input key={y} className="input" placeholder={`Ano ${y}`} style={{ flex: 1 }}
                  value={o.targets[`year${y}` as keyof typeof o.targets] ?? ""}
                  onChange={(e) => {
                    const n = [...plan.strategic_objectives];
                    n[i] = { ...o, targets: { ...o.targets, [`year${y}`]: e.target.value || undefined } };
                    setPlan({ ...plan, strategic_objectives: n });
                  }} />
              ))}
            </div>
          </div>
        ))}
        <button className="btn btn-ghost"
          onClick={() => setPlan({ ...plan, strategic_objectives: [...plan.strategic_objectives, { theme: "", indicator: "", description: "", targets: {} }] })}>
          + Adicionar objetivo
        </button>
      </div>
    </SectionCard>
  );
}

function OperacionalTab({ plan, setPlan }: { plan: PlanDraft; setPlan: (p: PlanDraft) => void }) {
  const statuses = ["planned", "in_progress", "completed", "cancelled"] as const;
  return (
    <SectionCard title="Objetivos Operacionais / Plano de Ação">
      <div className="stack" style={{ gap: 10 }}>
        {plan.operational_objectives.map((o, i) => (
          <div key={i} className="card" style={{ padding: 14 }}>
            <textarea className="textarea" rows={2} placeholder="Descrição do objetivo operacional" value={o.description}
              onChange={(e) => { const n = [...plan.operational_objectives]; n[i] = { ...o, description: e.target.value }; setPlan({ ...plan, operational_objectives: n }); }} />
            <div className="row" style={{ marginTop: 8 }}>
              <input className="input" placeholder="Responsável" value={o.responsible ?? ""}
                onChange={(e) => { const n = [...plan.operational_objectives]; n[i] = { ...o, responsible: e.target.value || null }; setPlan({ ...plan, operational_objectives: n }); }} />
              <input className="input" type="date" value={o.deadline ?? ""}
                onChange={(e) => { const n = [...plan.operational_objectives]; n[i] = { ...o, deadline: e.target.value || null }; setPlan({ ...plan, operational_objectives: n }); }} />
              <select className="select" value={o.status}
                onChange={(e) => { const n = [...plan.operational_objectives]; n[i] = { ...o, status: e.target.value as OperationalObjective["status"] }; setPlan({ ...plan, operational_objectives: n }); }}>
                {statuses.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <textarea className="textarea" rows={2} placeholder="Recursos necessários" style={{ marginTop: 8 }} value={o.resources ?? ""}
              onChange={(e) => { const n = [...plan.operational_objectives]; n[i] = { ...o, resources: e.target.value || null }; setPlan({ ...plan, operational_objectives: n }); }} />
          </div>
        ))}
        <button className="btn btn-ghost"
          onClick={() => setPlan({ ...plan, operational_objectives: [...plan.operational_objectives, { description: "", responsible: null, deadline: null, resources: null, status: "planned" }] })}>
          + Adicionar objetivo operacional
        </button>
      </div>
    </SectionCard>
  );
}

function SemestreTab({ draft, setDraft }: { draft: SemesterDraft; setDraft: (d: SemesterDraft) => void }) {
  const statuses = ["planned", "in_progress", "completed", "cancelled"] as const;
  return (
    <SectionCard title="Planejamento Semestral de Atividades">
      <div className="row">
        <Field label="Semestre (AAAA/S)">
          <input className="input" placeholder="2026/1" value={draft.semester}
            onChange={(e) => setDraft({ ...draft, semester: e.target.value })} />
        </Field>

      </div>
      <table className="table" style={{ marginTop: 12 }}>
        <thead>
          <tr><th>Mês</th><th>Data</th><th>Evento</th><th>Tipo</th><th>Status</th></tr>
        </thead>
        <tbody>
          {draft.activities.map((a, i) => (
            <tr key={i}>
              <td><input className="input" value={a.month} onChange={(e) => { const n = [...draft.activities]; n[i] = { ...a, month: e.target.value }; setDraft({ ...draft, activities: n }); }} /></td>
              <td><input className="input" value={a.date} onChange={(e) => { const n = [...draft.activities]; n[i] = { ...a, date: e.target.value }; setDraft({ ...draft, activities: n }); }} /></td>
              <td><input className="input" value={a.event} onChange={(e) => { const n = [...draft.activities]; n[i] = { ...a, event: e.target.value }; setDraft({ ...draft, activities: n }); }} /></td>
              <td><input className="input" value={a.event_type ?? ""} onChange={(e) => { const n = [...draft.activities]; n[i] = { ...a, event_type: e.target.value || null }; setDraft({ ...draft, activities: n }); }} /></td>
              <td>
                <select className="select" value={a.status}
                  onChange={(e) => { const n = [...draft.activities]; n[i] = { ...a, status: e.target.value as SemesterActivity["status"] }; setDraft({ ...draft, activities: n }); }}>
                  {statuses.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <button className="btn btn-ghost"
        onClick={() => setDraft({ ...draft, activities: [...draft.activities, { month: "", date: "", event: "", event_type: null, action: null, student_count: null, location: null, status: "planned" }] })}>
        + Adicionar atividade
      </button>
    </SectionCard>
  );
}

export function StrategicPlanning({ user }: { user: SessionUser }) {
  const [courses, setCourses] = useState<Course[]>([]);
  const [courseId, setCourseId] = useState<string>("");
  const [plans, setPlans] = useState<unknown[]>([]);
  const [tab, setTab] = useState<TabKey>("identificacao");
  const [draft, setDraft] = useState<PlanDraft>(EMPTY_PLAN);
  const [semDraft, setSemDraft] = useState<SemesterDraft>(EMPTY_SEMESTER);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const canWrite =
    user.role === "institution_admin" || user.role === "regulatory_manager" || user.role === "coordinator";

  const load = useCallback(() => {
    api.courses().then((r) => {
      setCourses(r.courses);
      const first = r.courses[0];
      if (!courseId && first) setCourseId(first.id);
    }).catch(() => undefined);
  }, [courseId]);

  useEffect(load, [load]);

  useEffect(() => {
    if (!courseId) return;
    api.strategicPlans({ courseId }).then((r) => setPlans(r.plans)).catch(() => undefined);
  }, [courseId]);

  function newPlan() {
    setDraft({ ...EMPTY_PLAN, courseId });
    setTab("identificacao");
  }

  function loadPlan(p: unknown) {
    const pl = p as PlanDraft;
    setDraft({
      id: (p as { id: string }).id,
      courseId: (p as { course_id?: string }).course_id ?? courseId,
      version: pl.version ?? 1,
      status: pl.status ?? "draft",
      coordinator_name: pl.coordinator_name ?? null,
      coordinator_since: pl.coordinator_since ?? null,
      enrolled_count: pl.enrolled_count ?? null,
      first_semester: pl.first_semester ?? null,
      vision_text: pl.vision_text ?? null,
      vision_inspirations: pl.vision_inspirations ?? [],
      vision_reflections: pl.vision_reflections ?? [],
      lifecycle_stage: pl.lifecycle_stage ?? null,
      lifecycle_strategies: pl.lifecycle_strategies ?? [],
      bcg_market_growth: pl.bcg_market_growth ?? null,
      bcg_market_share: pl.bcg_market_share ?? null,
      bcg_quadrant: pl.bcg_quadrant ?? null,
      bcg_strategies: pl.bcg_strategies ?? [],
      porter_rivalry: pl.porter_rivalry ?? null,
      porter_buyer_power: pl.porter_buyer_power ?? null,
      porter_supplier_power: pl.porter_supplier_power ?? null,
      porter_substitutes: pl.porter_substitutes ?? null,
      porter_new_entrants: pl.porter_new_entrants ?? null,
      fcs_institutional: pl.fcs_institutional ?? [],
      fcs_course: pl.fcs_course ?? [],
      fcs_competitors: pl.fcs_competitors ?? [],
      fcs_competitive_matrix: pl.fcs_competitive_matrix ?? [],
      attributes_matrix: pl.attributes_matrix ?? [],
      strategic_objectives: pl.strategic_objectives ?? [],
      operational_objectives: pl.operational_objectives ?? [],
    });
    setTab("identificacao");
  }

  async function savePlan() {
    setError(null);
    setSaving(true);
    try {
      const body = { ...draft, courseId };
      if (draft.id) {
        await api.updateStrategicPlan(draft.id, body);
      } else {
        await api.createStrategicPlan(body);
      }
      const r = await api.strategicPlans({ courseId });
      setPlans(r.plans);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Falha ao salvar");
    } finally {
      setSaving(false);
    }
  }

  async function saveSemester() {
    setError(null);
    setSaving(true);
    try {
      const body = { ...semDraft, courseId };
      if (semDraft.id) {
        await api.updateSemesterPlanning(semDraft.id, body);
      } else {
        await api.createSemesterPlanning(body);
      }
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Falha ao salvar planejamento semestral");
    } finally {
      setSaving(false);
    }
  }

  const selectedCourse = courses.find((c) => c.id === courseId);

  return (
    <>
      <PageHeader
        title="Planejamento Estratégico"
        subtitle="Formulários do PEC — Identificação, Visão, BCG, Porter, FCS, Atributos, Objetivos e Plano de Ação"
        actions={
          <div className="row">
            <select className="select" style={{ minWidth: 240 }} value={courseId} onChange={(e) => setCourseId(e.target.value)}>
              {courses.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.code} — {c.name}
                </option>
              ))}
            </select>
            {canWrite && (
              <button className="btn btn-primary" onClick={newPlan}>
                Novo planejamento
              </button>
            )}
          </div>
        }
      />

      {error && <ErrorNote message={error} />}

      <div className="card" style={{ padding: 12, marginBottom: 16 }}>
        <div className="vx-tabs">
          {TABS.map((t) => (
            <button
              key={t.key}
              className="vx-tab"
              aria-selected={tab === t.key}
              onClick={() => setTab(t.key)}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {tab === "identificacao" && <IdentificacaoTab plan={draft} setPlan={setDraft} />}
      {tab === "visao" && <VisaoTab plan={draft} setPlan={setDraft} />}
      {tab === "ciclo" && <CicloTab plan={draft} setPlan={setDraft} />}
      {tab === "bcg" && <BcgTab plan={draft} setPlan={setDraft} />}
      {tab === "porter" && <PorterTab plan={draft} setPlan={setDraft} />}
      {tab === "fcs" && <FcsTab plan={draft} setPlan={setDraft} />}
      {tab === "atributos" && <AtributosTab plan={draft} setPlan={setDraft} />}
      {tab === "objetivos" && <ObjetivosTab plan={draft} setPlan={setDraft} />}
      {tab === "operacional" && <OperacionalTab plan={draft} setPlan={setDraft} />}
      {tab === "semestre" && <SemestreTab draft={semDraft} setDraft={setSemDraft} />}

      {canWrite && tab !== "semestre" && (
        <div className="row" style={{ marginTop: 18 }}>
          <button className="btn btn-primary" disabled={saving || !courseId} onClick={savePlan}>
            {saving ? "Salvando..." : "Salvar planejamento"}
          </button>
        </div>
      )}

      {canWrite && tab === "semestre" && (
        <div className="row" style={{ marginTop: 18 }}>
          <button className="btn btn-primary" disabled={saving || !courseId || !semDraft.semester} onClick={saveSemester}>
            {saving ? "Salvando..." : "Salvar planejamento semestral"}
          </button>
        </div>
      )}

      {plans.length > 0 && tab !== "semestre" && (
        <div className="card" style={{ padding: 18, marginTop: 22 }}>
          <h3 style={{ margin: "0 0 12px", fontSize: 15 }}>Versões anteriores</h3>
          <table className="table">
            <thead>
              <tr>
                <th>Versão</th>
                <th>Status</th>
                <th>Criado em</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {(plans as { id: string; version: number; status: string; created_at: string }[]).map((p) => (
                <tr key={p.id}>
                  <td>v{p.version}</td>
                  <td>{p.status}</td>
                  <td>{new Date(p.created_at).toLocaleDateString("pt-BR")}</td>
                  <td>
                    <button className="btn btn-sm" onClick={() => loadPlan(p)}>
                      Carregar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
