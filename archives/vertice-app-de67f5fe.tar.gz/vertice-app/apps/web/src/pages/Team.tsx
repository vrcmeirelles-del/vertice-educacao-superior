import { useCallback, useEffect, useState } from "react";
import { api, ApiError, type Course, type InviteRow, type PlanUsage, type SessionUser, type UserRow } from "../api";
import { PageHeader } from "../components/Shell";
import { Empty, ErrorNote, Field, fmtDate } from "../components/ui";

/**
 * Equipe e permissões.
 *
 * O administrador não digita mais a senha de ninguém: ele emite um convite, e
 * a pessoa define a própria senha. A senha de outra pessoa nunca é conhecida
 * por quem administra — o que também tira do suporte a tarefa de "informar a
 * senha".
 */
const ROLES = [
  { value: "institution_admin", label: "Administrador da IES" },
  { value: "regulatory_manager", label: "Gestor de regulação" },
  { value: "coordinator", label: "Coordenação de curso" },
  { value: "auditor_readonly", label: "Auditor (somente leitura)" },
  { value: "privacy_officer", label: "Encarregado de privacidade" },
];

export function Team({ user }: { user: SessionUser }) {
  const [users, setUsers] = useState<UserRow[]>([]);
  const [invites, setInvites] = useState<InviteRow[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [usage, setUsage] = useState<PlanUsage | null>(null);
  const [maxUsers, setMaxUsers] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({
    email: "",
    role: "coordinator",
    courseScope: [] as string[],
    expiresAt: "",
  });
  const [issued, setIssued] = useState<{ email: string; token: string } | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(() => {
    api.users().then((r) => setUsers(r.users)).catch((err) =>
      setError(err instanceof ApiError ? err.message : "Falha ao carregar"),
    );
    api.invites().then((r) => setInvites(r.invites)).catch(() => undefined);
    api
      .institutionPlan()
      .then((r) => {
        setUsage(r.usage);
        setMaxUsers(r.limits.maxUsers);
      })
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    load();
    api.courses().then((r) => setCourses(r.courses)).catch(() => undefined);
  }, [load]);

  async function sendInvite() {
    setBusy(true);
    setError(null);
    try {
      const result = await api.createInvite({
        email: form.email,
        role: form.role,
        courseScope: form.courseScope.length ? form.courseScope : undefined,
        expiresAt:
          form.role === "auditor_readonly" && form.expiresAt
            ? new Date(form.expiresAt).toISOString()
            : undefined,
      });
      setIssued({ email: result.email, token: result.inviteToken });
      setForm({ email: "", role: "coordinator", courseScope: [], expiresAt: "" });
      load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Falha ao emitir convite");
    } finally {
      setBusy(false);
    }
  }

  async function revoke(id: string) {
    setError(null);
    try {
      await api.revokeInvite(id);
      load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Falha ao cancelar convite");
    }
  }

  const seatsLeft = maxUsers === null ? null : Math.max(maxUsers - (usage?.users ?? 0), 0);
  const atCapacity = seatsLeft !== null && seatsLeft <= 0;
  const inviteLink = issued ? `${window.location.origin}/#convite/${issued.token}` : null;

  return (
    <>
      <PageHeader
        title="Equipe e permissões"
        subtitle="Menor privilégio por papel e por curso. Auditor temporário exige data de expiração."
      />

      <ErrorNote message={error} />

      {issued && inviteLink && (
        <section className="card" style={{ padding: 16, marginBottom: 16, borderColor: "#cfe3dc" }}>
          <strong>Convite emitido para {issued.email}.</strong> Envie este link por canal seguro — ele
          não pode ser recuperado depois:
          <div className="mono small" style={{ marginTop: 8, wordBreak: "break-all" }}>
            {inviteLink}
          </div>
          <p className="small muted" style={{ marginBottom: 0 }}>
            A pessoa define a própria senha ao abrir o link. A Vértice e a administração da IES nunca
            veem essa senha.
          </p>
        </section>
      )}

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1.4fr", gap: 18, alignItems: "start" }}>
        <section className="card" style={{ padding: 20 }}>
          <h3 style={{ margin: "0 0 4px", fontSize: 15 }}>Convidar acesso</h3>
          <p className="small muted" style={{ margin: "0 0 14px" }}>
            {seatsLeft === null
              ? "Plano sem limite de assentos."
              : `${seatsLeft} de ${maxUsers} assentos disponíveis neste plano.`}
          </p>

          {atCapacity ? (
            <div className="card" style={{ padding: 14, borderColor: "#e8cdc9", background: "#fdf7f6" }}>
              <strong className="small">Todos os assentos estão em uso.</strong>
              <p className="small muted" style={{ margin: "6px 0 0" }}>
                Cancele um convite pendente ou peça ampliação de plano à Vértice.
              </p>
            </div>
          ) : (
            <div className="stack">
              <Field label="E-mail">
                <input
                  className="input"
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                />
              </Field>
              <Field label="Papel">
                <select
                  className="select"
                  value={form.role}
                  onChange={(e) => setForm({ ...form, role: e.target.value })}
                >
                  {ROLES.map((role) => (
                    <option key={role.value} value={role.value}>{role.label}</option>
                  ))}
                </select>
              </Field>

              {form.role === "coordinator" && (
                <Field label="Cursos autorizados (vazio = todos)">
                  <select
                    className="select"
                    multiple
                    size={4}
                    value={form.courseScope}
                    onChange={(e) =>
                      setForm({
                        ...form,
                        courseScope: Array.from(e.target.selectedOptions, (o) => o.value),
                      })
                    }
                  >
                    {courses.map((course) => (
                      <option key={course.id} value={course.id}>{course.name}</option>
                    ))}
                  </select>
                </Field>
              )}

              {form.role === "auditor_readonly" && (
                <Field label="Expira em (obrigatório)">
                  <input
                    className="input"
                    type="date"
                    value={form.expiresAt}
                    onChange={(e) => setForm({ ...form, expiresAt: e.target.value })}
                  />
                </Field>
              )}

              <button
                className="btn btn-primary"
                onClick={sendInvite}
                disabled={
                  busy ||
                  !form.email ||
                  (form.role === "auditor_readonly" && !form.expiresAt)
                }
              >
                {busy ? "Emitindo…" : "Emitir convite"}
              </button>
            </div>
          )}
        </section>

        <div style={{ display: "grid", gap: 18 }}>
          {invites.length > 0 && (
            <section className="card">
              <div style={{ padding: "14px 18px", borderBottom: "1px solid var(--line)", fontWeight: 600 }}>
                Convites pendentes ({invites.length})
              </div>
              <table className="table">
                <thead>
                  <tr>
                    <th>E-mail</th>
                    <th>Papel</th>
                    <th>Expira</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {invites.map((row) => (
                    <tr key={row.id}>
                      <td className="small">{row.email}</td>
                      <td className="small">{ROLES.find((r) => r.value === row.role)?.label ?? row.role}</td>
                      <td className="small muted">{fmtDate(row.expires_at)}</td>
                      <td>
                        <button className="btn btn-sm" onClick={() => void revoke(row.id)}>
                          Cancelar
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </section>
          )}

          <section className="card">
            <div style={{ padding: "14px 18px", borderBottom: "1px solid var(--line)", fontWeight: 600 }}>
              Acessos ativos ({users.length})
            </div>
            {users.length === 0 ? (
              <Empty>Nenhum usuário cadastrado.</Empty>
            ) : (
              <table className="table">
                <thead>
                  <tr>
                    <th>Nome</th>
                    <th>Papel</th>
                    <th>Último acesso</th>
                    <th>Expira</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((row) => (
                    <tr key={`${row.id}-${row.role}`}>
                      <td>
                        <div style={{ fontWeight: 500 }}>{row.name}</div>
                        <div className="small muted">{row.email}</div>
                      </td>
                      <td className="small">{ROLES.find((r) => r.value === row.role)?.label ?? row.role}</td>
                      <td className="small muted">{fmtDate(row.last_login_at)}</td>
                      <td className="small muted">{row.expires_at ? fmtDate(row.expires_at) : "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </section>
        </div>
      </div>
    </>
  );
}
