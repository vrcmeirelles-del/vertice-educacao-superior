import { useState, type FormEvent } from "react";
import { api, ApiError, type SessionUser } from "../api";
import { ErrorNote, Field } from "../components/ui";

export function Login({ onSuccess }: { onSuccess: (user: SessionUser, token: string) => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [institutionSlug, setInstitutionSlug] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const result = await api.login({
        email,
        password,
        institutionSlug: institutionSlug || undefined,
      });
      onSuccess(result.user, result.token);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Não foi possível entrar");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ display: "grid", placeItems: "center", minHeight: "100%", padding: 24 }}>
      <div className="card" style={{ width: 400, padding: 28 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
          <div
            aria-hidden
            style={{
              width: 30,
              height: 30,
              borderRadius: 8,
              background: "#328ea8",
              clipPath: "polygon(50% 0%, 100% 100%, 0% 100%)",
            }}
          />
          <div style={{ fontWeight: 700, letterSpacing: 0.5 }}>VÉRTICE</div>
        </div>
        <p className="muted small" style={{ marginTop: 0, marginBottom: 20 }}>
          Acesso restrito à equipe da IES e à equipe Vértice.
        </p>

        <form onSubmit={submit} className="stack">
          <Field label="E-mail">
            <input
              className="input"
              type="email"
              autoComplete="username"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </Field>
          <Field label="Senha">
            <input
              className="input"
              type="password"
              autoComplete="current-password"
              required
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </Field>
          <Field label="Instituição (opcional)">
            <input
              className="input"
              placeholder="ex.: demo"
              value={institutionSlug}
              onChange={(e) => setInstitutionSlug(e.target.value)}
            />
          </Field>

          <ErrorNote message={error} />

          <button className="btn btn-primary" type="submit" disabled={loading}>
            {loading ? "Entrando…" : "Entrar"}
          </button>
        </form>

        <p className="muted small" style={{ marginBottom: 0 }}>
          Alertas de acompanhamento apoiam a decisão humana. A plataforma não bloqueia serviços
          acadêmicos nem decide sobre direitos do estudante.
        </p>
      </div>
    </div>
  );
}
