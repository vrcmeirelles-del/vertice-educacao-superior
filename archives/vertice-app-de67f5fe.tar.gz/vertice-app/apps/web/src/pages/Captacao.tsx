import { useMemo, useState } from "react";
import { SheetGrid, type ColumnDef, type SelectOption } from "../components/SheetGrid";
import { BoardView, type BoardColumn } from "../components/BoardView";
import { GroupedList, type ListGroup } from "../components/GroupedList";
import {
  COST_LABEL,
  DEMO_COSTS,
  DEMO_CYCLE,
  DEMO_LEADS,
  ORIGIN_LABEL,
  PRIORITY_COLOR,
  PRIORITY_LABEL,
  STAGE_COLOR,
  STAGE_LABEL,
  STAGE_ORDER,
  avatarColor,
  byOrigin,
  computeMetrics,
  initials,
  decimal,
  money,
  moneyExact,
  number,
  percent,
  shortDate,
  type CostCategory,
  type CostEntry,
  type Frente,
  type Lead,
  type Origin,
  type Priority,
  type Stage,
} from "../lib/captacao";

type View = "planilha" | "quadro" | "lista" | "custo";

const VIEWS: { key: View; label: string }[] = [
  { key: "planilha", label: "Planilha" },
  { key: "quadro", label: "Quadro" },
  { key: "lista", label: "Lista" },
  { key: "custo", label: "Custos" },
];

const STAGE_OPTIONS: SelectOption[] = STAGE_ORDER.map((stage) => ({
  value: stage,
  label: STAGE_LABEL[stage],
  color: STAGE_COLOR[stage],
}));

const PRIORITY_OPTIONS: SelectOption[] = (Object.keys(PRIORITY_LABEL) as Priority[]).map((p) => ({
  value: p,
  label: PRIORITY_LABEL[p],
  color: PRIORITY_COLOR[p],
}));

const ORIGIN_OPTIONS: SelectOption[] = (Object.keys(ORIGIN_LABEL) as Origin[]).map((o) => ({
  value: o,
  label: ORIGIN_LABEL[o],
}));

const FRENTE_OPTIONS: SelectOption[] = [
  "Estratégia e governança",
  "Qualidade e conformidade",
  "Captação e permanência",
  "Sustentabilidade e capacidade",
  "Pesquisa e pós-graduação",
  "Dados, liderança e desenvolvimento",
  "Aquisições e due diligence",
].map((frente) => ({ value: frente, label: frente }));

const COST_OPTIONS: SelectOption[] = (Object.keys(COST_LABEL) as CostCategory[]).map((c) => ({
  value: c,
  label: COST_LABEL[c],
}));

/** Converte texto digitado em reais inteiros. Aceita "96.000" e "96000,00". */
function parseMoney(raw: string): number {
  const digits = raw.replace(/[^0-9]/g, "");
  if (!digits) return 0;
  const value = Number(digits);
  return Number.isFinite(value) ? value : 0;
}

const LEAD_COLUMNS: ColumnDef<Lead>[] = [
  { key: "instituicao", label: "Instituição", kind: "text", width: 230 },
  { key: "frente", label: "Frente", kind: "select", width: 210, options: FRENTE_OPTIONS },
  { key: "estagio", label: "Etapa", kind: "select", width: 150, options: STAGE_OPTIONS },
  { key: "prioridade", label: "Prioridade", kind: "select", width: 110, options: PRIORITY_OPTIONS },
  { key: "responsavel", label: "Responsável", kind: "text", width: 140 },
  { key: "valorEstimado", label: "Valor", kind: "money", width: 120 },
  { key: "origem", label: "Origem", kind: "select", width: 140, options: ORIGIN_OPTIONS },
  { key: "prazo", label: "Prazo", kind: "date", width: 120 },
  { key: "proximoPasso", label: "Próximo passo", kind: "text", width: 260 },
];

const COST_COLUMNS: ColumnDef<CostEntry>[] = [
  { key: "categoria", label: "Categoria", kind: "select", width: 150, options: COST_OPTIONS },
  { key: "descricao", label: "Descrição", kind: "text", width: 320 },
  { key: "ciclo", label: "Ciclo", kind: "text", width: 100 },
  { key: "valor", label: "Valor", kind: "money", width: 130 },
];

function Badge({ label, color }: { label: string; color: string }) {
  return (
    <span
      className="badge"
      style={{ background: `${color}18`, color }}
    >
      <span className="vx-dot" style={{ background: color }} />
      {label}
    </span>
  );
}

function Avatar({ name }: { name: string }) {
  return (
    <span className="vx-avatar" style={{ background: avatarColor(name) }} aria-hidden="true">
      {initials(name)}
    </span>
  );
}

function Kpi({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="vx-kpi">
      <div className="vx-kpi__label">{label}</div>
      <div className="vx-kpi__value">{value}</div>
      {hint && <div className="vx-kpi__hint">{hint}</div>}
    </div>
  );
}

export function Captacao() {
  const [leads, setLeads] = useState<Lead[]>(DEMO_LEADS);
  const [costs, setCosts] = useState<CostEntry[]>(DEMO_COSTS);
  const [view, setView] = useState<View>("planilha");
  const [search, setSearch] = useState("");
  const [stageFilter, setStageFilter] = useState<Stage | "todos">("todos");
  const [openId, setOpenId] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    return leads.filter((lead) => {
      const matchesStage = stageFilter === "todos" || lead.estagio === stageFilter;
      if (!matchesStage) return false;
      if (!term) return true;
      return (
        lead.instituicao.toLowerCase().includes(term) ||
        lead.frente.toLowerCase().includes(term) ||
        lead.responsavel.toLowerCase().includes(term) ||
        lead.proximoPasso.toLowerCase().includes(term)
      );
    });
  }, [leads, search, stageFilter]);

  const metrics = useMemo(() => computeMetrics(leads, costs), [leads, costs]);
  const openLead = useMemo(() => leads.find((lead) => lead.id === openId) ?? null, [leads, openId]);

  const updateLead = (id: string, key: string, value: string) => {
    setLeads((current) =>
      current.map((lead) => {
        if (lead.id !== id) return lead;
        switch (key) {
          case "valorEstimado":
            return { ...lead, valorEstimado: parseMoney(value) };
          case "estagio":
            return { ...lead, estagio: value as Stage };
          case "prioridade":
            return { ...lead, prioridade: value as Priority };
          case "origem":
            return { ...lead, origem: value as Origin };
          case "frente":
            return { ...lead, frente: value as Frente };
          case "prazo":
            return { ...lead, prazo: value || null };
          case "instituicao":
          case "responsavel":
          case "proximoPasso":
            return { ...lead, [key]: value };
          default:
            return lead;
        }
      }),
    );
  };

  const updateCost = (id: string, key: string, value: string) => {
    setCosts((current) =>
      current.map((entry) => {
        if (entry.id !== id) return entry;
        if (key === "valor") return { ...entry, valor: parseMoney(value) };
        if (key === "categoria") return { ...entry, categoria: value as CostCategory };
        if (key === "descricao" || key === "ciclo") return { ...entry, [key]: value };
        return entry;
      }),
    );
  };

  const leadValue = (lead: Lead, key: string): string => {
    switch (key) {
      case "valorEstimado":
        return String(lead.valorEstimado);
      case "prazo":
        return lead.prazo ?? "";
      case "estagio":
        return lead.estagio;
      case "prioridade":
        return lead.prioridade;
      case "origem":
        return lead.origem;
      case "frente":
        return lead.frente;
      case "instituicao":
        return lead.instituicao;
      case "responsavel":
        return lead.responsavel;
      case "proximoPasso":
        return lead.proximoPasso;
      default:
        return "";
    }
  };

  const costValue = (entry: CostEntry, key: string): string => {
    if (key === "valor") return String(entry.valor);
    if (key === "categoria") return entry.categoria;
    if (key === "descricao") return entry.descricao;
    if (key === "ciclo") return entry.ciclo;
    return "";
  };

  const renderLeadCell = (lead: Lead, column: ColumnDef<Lead>) => {
    if (column.key === "valorEstimado") {
      return <div className="vx-cell vx-cell--num">{money(lead.valorEstimado)}</div>;
    }
    if (column.key === "estagio") {
      return (
        <div className="vx-cell">
          <Badge label={STAGE_LABEL[lead.estagio]} color={STAGE_COLOR[lead.estagio]} />
        </div>
      );
    }
    if (column.key === "prioridade") {
      return (
        <div className="vx-cell">
          <Badge label={PRIORITY_LABEL[lead.prioridade]} color={PRIORITY_COLOR[lead.prioridade]} />
        </div>
      );
    }
    if (column.key === "responsavel") {
      return (
        <div className="vx-cell">
          <Avatar name={lead.responsavel} />
          <span>{lead.responsavel}</span>
        </div>
      );
    }
    if (column.key === "prazo") {
      return <div className="vx-cell vx-cell--muted">{shortDate(lead.prazo)}</div>;
    }
    if (column.key === "origem") {
      return <div className="vx-cell vx-cell--muted">{ORIGIN_LABEL[lead.origem]}</div>;
    }
    return null;
  };

  const boardColumns: BoardColumn<Lead>[] = STAGE_ORDER.map((stage) => {
    const items = filtered.filter((lead) => lead.estagio === stage);
    const sum = items.reduce((acc, lead) => acc + lead.valorEstimado, 0);
    return {
      key: stage,
      label: STAGE_LABEL[stage],
      color: STAGE_COLOR[stage],
      items,
      summary: sum > 0 ? money(sum) : undefined,
    };
  });

  const listGroups: ListGroup<Lead>[] = STAGE_ORDER.map((stage) => {
    const items = filtered.filter((lead) => lead.estagio === stage);
    const sum = items.reduce((acc, lead) => acc + lead.valorEstimado, 0);
    return {
      key: stage,
      label: STAGE_LABEL[stage],
      color: STAGE_COLOR[stage],
      items,
      summary: sum > 0 ? money(sum) : undefined,
      collapsed: stage === "perdido",
    };
  });

  const origins = byOrigin(leads);

  return (
    <div className="vx-page">
      <div className="vx-topbar">
        <div>
          <h1>Captação</h1>
          <p>
            Funil de clientes-IES e custo do ciclo {DEMO_CYCLE}. Dados de demonstração — nenhum
            registro institucional real.
          </p>
        </div>
        <div className="vx-topbar__actions">
          <button className="btn btn-sm" type="button" onClick={() => setView("custo")}>
            Ver custos
          </button>
          <button className="btn btn-primary btn-sm" type="button">
            Nova oportunidade
          </button>
        </div>
      </div>

      <div className="vx-tabs" role="tablist" aria-label="Modo de visualização">
        {VIEWS.map((item) => (
          <button
            key={item.key}
            type="button"
            role="tab"
            className="vx-tab"
            aria-selected={view === item.key}
            onClick={() => setView(item.key)}
          >
            {item.label}
          </button>
        ))}
      </div>

      <div className="vx-toolbar">
        <input
          className="input vx-search"
          placeholder="Buscar instituição, frente, responsável ou próximo passo"
          value={search}
          onChange={(event) => setSearch(event.target.value)}
        />
        <button
          type="button"
          className="vx-chip"
          aria-pressed={stageFilter === "todos"}
          onClick={() => setStageFilter("todos")}
        >
          Todas as etapas
        </button>
        {STAGE_ORDER.map((stage) => (
          <button
            key={stage}
            type="button"
            className="vx-chip"
            aria-pressed={stageFilter === stage}
            onClick={() => setStageFilter(stage)}
          >
            {STAGE_LABEL[stage]}
          </button>
        ))}
        <div className="spacer" />
        <span className="vx-count">
          {filtered.length} de {leads.length} oportunidades
        </span>
      </div>

      <div className="vx-kpis">
        <Kpi label="Custo do ciclo" value={money(metrics.custoTotal)} hint={`${costs.length} lançamentos`} />
        <Kpi
          label="CAC"
          value={metrics.cac === null ? "—" : money(metrics.cac)}
          hint={metrics.cac === null ? "sem negócio fechado no ciclo" : `${metrics.ganhos} contratos ganhos`}
        />
        <Kpi
          label="Custo por oportunidade"
          value={metrics.custoPorLead === null ? "—" : money(metrics.custoPorLead)}
          hint="divide por todas as oportunidades"
        />
        <Kpi
          label="Conversão"
          value={metrics.conversao === null ? "—" : percent(metrics.conversao)}
          hint="ganhos sobre decididas"
        />
        <Kpi
          label="Pipeline em aberto"
          value={money(metrics.valorEmAberto)}
          hint={`${metrics.emAberto} em andamento`}
        />
        <Kpi
          label="Receita / custo"
          value={metrics.roas === null ? "—" : `${decimal(metrics.roas)}×`}
          hint={metrics.ticketMedio === null ? undefined : `ticket ${money(metrics.ticketMedio)}`}
        />
      </div>

      {view === "planilha" && (
        <SheetGrid<Lead>
          columns={LEAD_COLUMNS}
          rows={filtered}
          valueOf={leadValue}
          onChange={updateLead}
          renderCell={renderLeadCell}
          onOpen={setOpenId}
          emptyLabel="Nenhuma oportunidade neste filtro."
          footer={{
            left: `${filtered.length} registros · soma ${money(
              filtered.reduce((acc, lead) => acc + lead.valorEstimado, 0),
            )}`,
            right: "Enter edita · setas navegam · Tab avança",
          }}
        />
      )}

      {view === "quadro" && (
        <BoardView<Lead>
          columns={boardColumns}
          onMove={(id, columnKey) => updateLead(id, "estagio", columnKey)}
          onOpen={setOpenId}
          renderCard={(lead) => (
            <>
              <div className="vx-card__title">{lead.instituicao}</div>
              <div className="vx-card__meta">
                <span className="vx-dot" style={{ background: PRIORITY_COLOR[lead.prioridade] }} />
                <span>{lead.frente}</span>
              </div>
              <div className="vx-card__meta">
                <Avatar name={lead.responsavel} />
                <span>{shortDate(lead.prazo)}</span>
                <span className="vx-card__value">{money(lead.valorEstimado)}</span>
              </div>
            </>
          )}
        />
      )}

      {view === "lista" && (
        <GroupedList<Lead>
          groups={listGroups}
          onOpen={setOpenId}
          renderRow={(lead) => (
            <div className="vx-row">
              <span className="vx-dot" style={{ background: PRIORITY_COLOR[lead.prioridade] }} />
              <span style={{ fontWeight: 600 }}>{lead.instituicao}</span>
              <span className="muted">{lead.frente}</span>
              <span className="vx-row__num">{money(lead.valorEstimado)}</span>
              <span className="vx-row__num muted">{shortDate(lead.prazo)}</span>
              <span className="muted">{ORIGIN_LABEL[lead.origem]}</span>
            </div>
          )}
        />
      )}

      {view === "custo" && (
        <>
          <div className="vx-toolbar">
            <span className="vx-count">
              Ciclo {DEMO_CYCLE} · total {moneyExact(metrics.custoTotal)}
            </span>
            <div className="spacer" />
            <span className="vx-count">Soma por categoria</span>
            {(Object.keys(COST_LABEL) as CostCategory[]).map((category) => {
              const total = costs
                .filter((entry) => entry.categoria === category)
                .reduce((acc, entry) => acc + entry.valor, 0);
              if (total === 0) return null;
              return (
                <span key={category} className="vx-chip" style={{ cursor: "default" }}>
                  {COST_LABEL[category]} {money(total)}
                </span>
              );
            })}
          </div>

          <SheetGrid<CostEntry>
            columns={COST_COLUMNS}
            rows={costs}
            valueOf={costValue}
            onChange={updateCost}
            renderCell={(entry, column) =>
              column.key === "valor" ? (
                <div className="vx-cell vx-cell--num">{money(entry.valor)}</div>
              ) : column.key === "categoria" ? (
                <div className="vx-cell muted">{COST_LABEL[entry.categoria]}</div>
              ) : null
            }
            emptyLabel="Nenhum custo lançado no ciclo."
            footer={{
              left: `${costs.length} lançamentos`,
              right: <strong>{moneyExact(metrics.custoTotal)}</strong>,
            }}
          />

          <div className="vx-toolbar">
            <span className="vx-count">
              Origem das oportunidades:{" "}
              {origins
                .map((row) => `${ORIGIN_LABEL[row.origin]} ${row.ganhos}/${row.total}`)
                .join(" · ")}
            </span>
          </div>
        </>
      )}

      {openLead && (
        <aside className="vx-drawer" aria-label="Detalhe da oportunidade">
          <div className="vx-drawer__head">
            <Badge label={STAGE_LABEL[openLead.estagio]} color={STAGE_COLOR[openLead.estagio]} />
            <div className="spacer" />
            <button className="btn btn-ghost btn-sm" type="button" onClick={() => setOpenId(null)}>
              Fechar
            </button>
          </div>
          <div className="vx-drawer__body">
            <div>
              <div className="vx-drawer__label">Instituição</div>
              <div className="vx-drawer__value" style={{ fontWeight: 650, fontSize: 17 }}>
                {openLead.instituicao}
              </div>
            </div>
            <div className="vx-drawer__field">
              <div className="vx-drawer__label">Frente de interesse</div>
              <div className="vx-drawer__value">{openLead.frente}</div>
            </div>
            <div className="vx-drawer__field">
              <div className="vx-drawer__label">Valor estimado</div>
              <div className="vx-drawer__value">{moneyExact(openLead.valorEstimado)}</div>
            </div>
            <div className="vx-drawer__field">
              <div className="vx-drawer__label">Responsável</div>
              <div className="vx-drawer__value row">
                <Avatar name={openLead.responsavel} />
                {openLead.responsavel}
              </div>
            </div>
            <div className="vx-drawer__field">
              <div className="vx-drawer__label">Origem</div>
              <div className="vx-drawer__value">{ORIGIN_LABEL[openLead.origem]}</div>
            </div>
            <div className="vx-drawer__field">
              <div className="vx-drawer__label">Prioridade</div>
              <div className="vx-drawer__value">
                <Badge
                  label={PRIORITY_LABEL[openLead.prioridade]}
                  color={PRIORITY_COLOR[openLead.prioridade]}
                />
              </div>
            </div>
            <div className="vx-drawer__field">
              <div className="vx-drawer__label">Próximo passo</div>
              <div className="vx-drawer__value">{openLead.proximoPasso}</div>
            </div>
            <div className="vx-drawer__field">
              <div className="vx-drawer__label">Prazo</div>
              <div className="vx-drawer__value">{shortDate(openLead.prazo)}</div>
            </div>
            <div className="vx-drawer__field">
              <div className="vx-drawer__label">Criado em</div>
              <div className="vx-drawer__value">{shortDate(openLead.criadoEm)}</div>
            </div>
            <p className="muted small" style={{ marginTop: 4 }}>
              Oportunidade institucional. Não há nome, CPF, e-mail ou telefone de aluno neste
              registro. {number(openLead.valorEstimado)} é valor estimado, não receita realizada.
            </p>
          </div>
        </aside>
      )}
    </div>
  );
}
