import { useCallback, useEffect, useState } from "react";
import { api, ApiError, type PairingToken, type SessionUser } from "../api";
import { PageHeader } from "../components/Shell";
import { Empty, ErrorNote, Field, fmtDate } from "../components/ui";

export function Extension({ user }: { user: SessionUser }) {
  const [tokens, setTokens] = useState<PairingToken[]>([]);
  const [label, setLabel] = useState("");
  const [ttl, setTtl] = useState(60);
  const [issued, setIssued] = useState<{ token: string; expiresInMinutes: number } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(() => {
    api.pairingTokens().then((r) => setTokens(r.tokens)).catch((err) =>
      setError(err instanceof ApiError ? err.message : "Falha ao carregar"),
    );
  }, []);

  useEffect(load, [load]);

  async function issue() {
    setError(null);
    try {
      const result = await api.createPairingToken({ label, ttlMinutes: ttl });
      setIssued(result);
      setLabel("");
      load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Falha ao emitir token");
    }
  }

  const canManage = user.role === "institution_admin" || user.role === "platform_admin";

  return (
    <>
      <PageHeader
        title="Extensão de navegador"
        subtitle="A extensão lê apenas a aba atual, após clique do usuário, e envia somente os campos mínimos."
      />

      <ErrorNote message={error} />

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1.2fr", gap: 18, alignItems: "start" }}>
        <section className="card" style={{ padding: 20 }}>
          <h3 style={{ margin: "0 0 14px", fontSize: 15 }}>Emitir token de pareamento</h3>
          <div className="stack">
            <Field label="Identificação (ex.: Secretaria — Campus Centro)">
              <input className="input" value={label} onChange={(e) => setLabel(e.target.value)} />
            </Field>
            <Field label="Validade (minutos)">
              <input className="input" type="number" min={5} max={1440} value={ttl} onChange={(e) => setTtl(Number(e.target.value))} />
            </Field>
            <button className="btn btn-primary" onClick={issue} disabled={!canManage || label.length < 3}>
              Emitir token
            </button>

            {issued && (
              <div style={{ background: "#f7f9fb", borderRadius: 8, padding: 12 }}>
                <div className="small muted">Token (visível apenas agora):</div>
                <code className="mono small" style={{ wordBreak: "break-all" }}>{issued.token}</code>
                <div className="small muted" style={{ marginTop: 8 }}>
                  Expira em {issued.expiresInMinutes} minutos. Cole no popup da extensão.
                </div>
              </div>
            )}
          </div>
        </section>

        <section className="card">
          <div style={{ padding: "14px 18px", borderBottom: "1px solid var(--line)", fontWeight: 600 }}>
            Tokens emitidos
          </div>
          {tokens.length === 0 ? (
            <Empty>Nenhum token emitido.</Empty>
          ) : (
            <table className="table">
              <thead>
                <tr>
                  <th>Identificação</th>
                  <th>Expira</th>
                  <th>Último uso</th>
                  <th>Estado</th>
                </tr>
              </thead>
              <tbody>
                {tokens.map((token) => {
                  const expired = new Date(token.expires_at).getTime() < Date.now();
                  return (
                    <tr key={token.id}>
                      <td className="small">{token.label}</td>
                      <td className="small muted">{fmtDate(token.expires_at)}</td>
                      <td className="small muted">{fmtDate(token.last_used_at)}</td>
                      <td>
                        <span className={`badge ${token.revoked_at || expired ? "badge-critical" : "badge-low"}`}>
                          {token.revoked_at ? "Revogado" : expired ? "Expirado" : "Ativo"}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </section>
      </div>

      <section className="card" style={{ padding: 20, marginTop: 18 }}>
        <h3 style={{ margin: "0 0 10px", fontSize: 15 }}>Como a extensão se comporta</h3>
        <ul className="small" style={{ margin: 0, paddingLeft: 18, color: "var(--ink-soft)" }}>
          <li>Executa somente após clique do usuário na aba ativa.</li>
          <li>Permissões iniciais: <span className="mono">activeTab</span> e <span className="mono">scripting</span>.</li>
          <li>Lê apenas os seletores do adaptador autorizado — nunca o HTML inteiro.</li>
          <li>Não armazena nem transmite senha do portal.</li>
          <li>Se o layout não for reconhecido, interrompe e informa “layout não reconhecido”.</li>
        </ul>
      </section>
    </>
  );
}
