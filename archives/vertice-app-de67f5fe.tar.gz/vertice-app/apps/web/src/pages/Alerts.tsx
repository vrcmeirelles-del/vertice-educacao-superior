import { useCallback, useEffect, useState } from "react";
import { api, ApiError, type AlertsResponse, type AlertStatus, type Course } from "../api";
import { PageHeader } from "../components/Shell";
import { Empty, ErrorNote, LevelBadge, StatusBadge, fmtDate } from "../components/ui";

const STATUSES: { value: AlertStatus | ""; label: string }[] = [
  { value: "", label: "Todos" },
  { value: "open", label: "Abertos" },
  { value: "assigned", label: "Atribuídos" },
  { value: "in_progress", label: "Em atendimento" },
  { value: "snoozed", label: "Adiados" },
  { value: "resolved", label: "Resolvidos" },
  { value: "dismissed", label: "Dispensados" },
];

export function Alerts({ onOpenAlert }: { onOpenAlert: (id: string) => void }) {
  const [data, setData] = useState<AlertsResponse | null>(null);
  const [courses, setCourses] = useState<Course[]>([]);
  const [status, setStatus] = useState<AlertStatus | "">("");
  const [courseId, setCourseId] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(() => {
    setLoading(true);
    api
      .alerts({ status: status || undefined, courseId: courseId || undefined, limit: "100" })
      .then(setData)
      .catch((err) => setError(err instanceof ApiError ? err.message : "Falha ao carregar alertas"))
      .finally(() => setLoading(false));
  }, [status, courseId]);

  useEffect(load, [load]);
  useEffect(() => {
    api.courses().then((r) => setCourses(r.courses)).catch(() => undefined);
  }, []);

  return (
    <>
      <PageHeader
        title="Alertas de acompanhamento"
        subtitle="Sinais que precisam de decisão humana da coordenação. Nenhuma ação é automática."
      />

      <ErrorNote message={error} />

      <div className="card" style={{ padding: 14, display: "flex", gap: 12, marginBottom: 16, flexWrap: "wrap" }}>
        <select className="select" style={{ width: 190 }} value={status} onChange={(e) => setStatus(e.target.value as AlertStatus | "")}>
          {STATUSES.map((item) => (
            <option key={item.value} value={item.value}>
              {item.label}
            </option>
          ))}
        </select>
        <select className="select" style={{ width: 240 }} value={courseId} onChange={(e) => setCourseId(e.target.value)}>
          <option value="">Todos os cursos</option>
          {courses.map((course) => (
            <option key={course.id} value={course.id}>
              {course.name}
            </option>
          ))}
        </select>
        <div className="spacer" />
        <button className="btn" onClick={load} disabled={loading}>
          {loading ? "Carregando…" : "Atualizar"}
        </button>
      </div>

      <section className="card">
        {data?.alerts.length ? (
          <table className="table">
            <thead>
              <tr>
                <th>Nível</th>
                <th>Curso</th>
                <th>Fatores</th>
                <th>Frequência</th>
                <th>Faltas</th>
                <th>Situação</th>
                <th>Coleta</th>
              </tr>
            </thead>
            <tbody>
              {data.alerts.map((alert) => (
                <tr key={alert.id} onClick={() => onOpenAlert(alert.id)} style={{ cursor: "pointer" }}>
                  <td>
                    <div className="row" style={{ gap: 8 }}>
                      <LevelBadge level={alert.level} />
                      <span className="mono small muted">{alert.score}</span>
                    </div>
                  </td>
                  <td style={{ fontWeight: 500 }}>{alert.course_name}</td>
                  <td className="small" style={{ maxWidth: 320 }}>
                    {alert.factors.map((f) => f.explanation).join(" · ") || "—"}
                  </td>
                  <td className="mono small">
                    {alert.attendance_percent != null ? `${Number(alert.attendance_percent)}%` : "—"}
                  </td>
                  <td className="mono small">{alert.consecutive_absences ?? "—"}</td>
                  <td>
                    <StatusBadge status={alert.status} />
                  </td>
                  <td className="small muted">{fmtDate(alert.observed_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <Empty>{loading ? "Carregando…" : "Nenhum alerta neste filtro."}</Empty>
        )}
      </section>
    </>
  );
}
