import { useCallback, useEffect, useRef, useState } from "react";
import { api, ApiError, type DocumentRow, type ScanStatus, type SessionUser } from "../api";
import { PageHeader } from "../components/Shell";
import { Empty, ErrorNote, fmtDate } from "../components/ui";

const SCAN_LABEL: Record<ScanStatus, string> = {
  pending_upload: "Aguardando envio",
  pending_scan: "Em verificação",
  clean: "Aprovado",
  infected: "Reprovado",
  failed: "Falha na verificação",
};

const SCAN_COLOR: Record<ScanStatus, { background: string; color: string }> = {
  pending_upload: { background: "#eef2f6", color: "#5b6b83" },
  pending_scan: { background: "#fdf1e3", color: "#b8802c" },
  clean: { background: "#e9f4ef", color: "#2f7d5b" },
  infected: { background: "#fbe9e7", color: "#b75046" },
  failed: { background: "#fbe9e7", color: "#b75046" },
};

const MAX_BYTES = 25 * 1024 * 1024;
const ACCEPTED = [
  "application/pdf",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "image/png",
  "image/jpeg",
].join(",");

export function Documents({ user }: { user: SessionUser }) {
  const [rows, setRows] = useState<DocumentRow[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [progress, setProgress] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const canWrite = user.role !== "auditor_readonly" && user.role !== "privacy_officer";

  const load = useCallback(() => {
    api
      .documents()
      .then((r) => {
        setRows(r.documents);
        setError(null);
      })
      .catch((err) => setError(err instanceof ApiError ? err.message : "Falha ao carregar"));
  }, []);

  useEffect(load, [load]);

  /**
   * Fluxo de três passos: pede URL, envia direto ao bucket, confirma.
   * O corpo do arquivo nunca passa pela API.
   */
  const upload = useCallback(
    async (file: File) => {
      setError(null);

      if (!ACCEPTED.split(",").includes(file.type)) {
        setError("Tipo não permitido. Use PDF, DOCX, XLSX, PNG ou JPEG.");
        return;
      }
      if (file.size > MAX_BYTES) {
        setError("Arquivo acima de 25 MB.");
        return;
      }

      setBusy(file.name);
      try {
        setProgress("Calculando integridade…");
        const digest = await crypto.subtle.digest("SHA-256", await file.arrayBuffer());
        const sha256Base64 = btoa(String.fromCharCode(...new Uint8Array(digest)));

        setProgress("Preparando envio…");
        const created = await api.createDocument({
          fileName: file.name,
          mimeType: file.type,
          sizeBytes: file.size,
          sha256Base64,
          classification: "internal",
        });

        setProgress("Enviando arquivo…");
        const put = await fetch(created.uploadUrl, {
          method: "PUT",
          headers: created.headers,
          body: file,
        });
        if (!put.ok) {
          throw new Error(`O bucket recusou o envio (HTTP ${put.status})`);
        }

        setProgress("Verificando arquivo…");
        await api.completeDocument(created.documentId);
        setProgress(null);
        load();
      } catch (err) {
        setProgress(null);
        setError(
          err instanceof ApiError
            ? err.message
            : err instanceof Error
              ? err.message
              : "Falha no envio",
        );
        load();
      } finally {
        setBusy(null);
        if (inputRef.current) inputRef.current.value = "";
      }
    },
    [load],
  );

  const download = useCallback(async (row: DocumentRow) => {
    try {
      const { url } = await api.downloadDocument(row.id);
      window.open(url, "_blank", "noopener,noreferrer");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Falha ao gerar link");
    }
  }, []);

  const remove = useCallback(
    async (row: DocumentRow) => {
      if (!window.confirm(`Remover "${row.file_name}"? O arquivo será apagado do storage.`)) return;
      setBusy(row.id);
      try {
        await api.deleteDocument(row.id);
        load();
      } catch (err) {
        setError(err instanceof ApiError ? err.message : "Falha ao remover");
      } finally {
        setBusy(null);
      }
    },
    [load],
  );

  return (
    <>
      <PageHeader
        title="Documentos"
        subtitle="Arquivos ficam em bucket privado. Todo acesso passa por link assinado e é registrado."
      />

      <ErrorNote message={error} />

      {canWrite && (
        <div className="card" style={{ padding: 18, marginBottom: 18 }}>
          <div style={{ fontWeight: 600, marginBottom: 4 }}>Enviar documento</div>
          <p style={{ color: "var(--ink-soft)", fontSize: 13, margin: "0 0 12px" }}>
            PDF, DOCX, XLSX, PNG ou JPEG até 25 MB. O arquivo é verificado por antivírus antes de
            poder ser vinculado a uma evidência.
          </p>
          <input
            ref={inputRef}
            type="file"
            accept={ACCEPTED}
            disabled={busy !== null}
            onChange={(event) => {
              const file = event.target.files?.[0];
              if (file) void upload(file);
            }}
            style={{ fontSize: 13 }}
          />
          {progress && (
            <div style={{ marginTop: 12, fontSize: 13, color: "var(--ink-soft)" }}>
              {busy ? `${busy} — ` : ""}
              {progress}
            </div>
          )}
        </div>
      )}

      <div className="card" style={{ padding: 0 }}>
        {rows.length === 0 ? (
          <Empty>Nenhum documento enviado.</Empty>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Arquivo</th>
                <th>Tamanho</th>
                <th>Verificação</th>
                <th>Enviado</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id}>
                  <td>
                    <div style={{ fontWeight: 500 }}>{row.file_name}</div>
                    <div style={{ fontSize: 12, color: "var(--ink-soft)" }}>{row.mime_type}</div>
                  </td>
                  <td>{(Number(row.size_bytes) / 1024).toFixed(0)} KB</td>
                  <td>
                    <span className="badge" style={SCAN_COLOR[row.scan_status]}>
                      {SCAN_LABEL[row.scan_status]}
                    </span>
                    {row.scan_detail && row.scan_status !== "clean" && (
                      <div style={{ fontSize: 11, color: "var(--ink-soft)", marginTop: 4 }}>
                        {row.scan_detail}
                      </div>
                    )}
                  </td>
                  <td>{fmtDate(row.created_at)}</td>
                  <td style={{ textAlign: "right", whiteSpace: "nowrap" }}>
                    <button
                      className="btn btn-ghost"
                      disabled={row.scan_status !== "clean"}
                      onClick={() => void download(row)}
                      title={
                        row.scan_status === "clean"
                          ? "Gerar link de download"
                          : "Disponível apenas após aprovação do antivírus"
                      }
                    >
                      Baixar
                    </button>
                    {canWrite && (
                      <button
                        className="btn btn-ghost"
                        disabled={busy === row.id}
                        onClick={() => void remove(row)}
                      >
                        Remover
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}
