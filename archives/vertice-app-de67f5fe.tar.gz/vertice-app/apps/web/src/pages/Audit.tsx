import { useEffect, useState } from "react";
import { api, ApiError, type AuditEvent } from "../api";
import { PageHeader } from "../components/Shell";
import { Empty, ErrorNote, StatusBadge, fmtDate } from "../components/ui";

export function Audit() {
  const [events, setEvents] = useState<AuditEvent[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState("");

  useEffect(() => {
    api
      .audit(200)
      .then((r) => setEvents(r.events))
      .catch((err) => setError(err instanceof ApiError ? err.message : "Falha ao carregar"));
  }, []);

  const visible = filter
    ? events.filter((e) => e.action.startsWith(filter) || e.resource_type.includes(filter))
    : events;

  return (
    <>
      <PageHeader
        title="Trilha de auditoria"
        subtitle="Registro append-only de quem fez o quê, quando e com qual resultado. Não contém notas nem texto de requerimento."
        actions={
          <input
            className="input"
            style={{ width: 240 }}
            placeholder="Filtrar por ação (ex.: alert)"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          />
        }
      />

      <ErrorNote message={error} />

      <section className="card">
        {visible.length === 0 ? (
          <Empty>Nenhum evento.</Empty>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Quando</th>
                <th>Quem</th>
                <th>Ação</th>
                <th>Recurso</th>
                <th>Resultado</th>
                <th>IP</th>
              </tr>
            </thead>
            <tbody>
              {visible.map((event, index) => (
                <tr key={`${event.created_at}-${index}`}>
                  <td className="small">{fmtDate(event.created_at)}</td>
                  <td className="small">
                    {event.actor_name ?? "Sistema"}
                    {event.actor_email && <div className="muted small">{event.actor_email}</div>}
                  </td>
                  <td className="mono small">{event.action}</td>
                  <td className="small muted">{event.resource_type}</td>
                  <td>
                    <StatusBadge
                      status={event.outcome === "success" ? "validated" : event.outcome === "denied" ? "rejected" : "pending"}
                    />
                  </td>
                  <td className="mono small muted">{event.ip ?? "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>
    </>
  );
}
