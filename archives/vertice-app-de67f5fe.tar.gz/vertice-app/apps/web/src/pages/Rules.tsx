import { useCallback, useEffect, useState } from "react";
import { api, ApiError, type Course, type RulesetRow, type SessionUser } from "../api";
import { PageHeader } from "../components/Shell";
import { Empty, ErrorNote, Field, StatusBadge, fmtDate } from "../components/ui";

const DEFAULTS = {
  attendanceThreshold: 80,
  attendanceWeight: 35,
  consecutiveAbsenceThreshold: 3,
  consecutiveAbsenceWeight: 25,
  lowAssessmentWeight: 20,
  exitRequestWeight: 30,
};

export function Rules({ user }: { user: SessionUser }) {
  const [rulesets, setRulesets] = useState<RulesetRow[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [courseId, setCourseId] = useState("");
  const [form, setForm] = useState({ ...DEFAULTS });
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const load = useCallback(() => {
    api.rulesets().then((r) => setRulesets(r.rulesets)).catch(() => undefined);
  }, []);

  useEffect(() => {
    load();
    api.courses().then((r) => setCourses(r.courses)).catch(() => undefined);
  }, [load]);

  async function publish() {
    setSaving(true);
    setError(null);
    try {
      await api.createRuleset({ courseId: courseId || null, rules: form });
      load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Falha ao publicar");
    } finally {
      setSaving(false);
    }
  }

  const canManage = user.role === "institution_admin" || user.role === "platform_admin";
  const totalWeight =
    form.attendanceWeight + form.consecutiveAbsenceWeight + form.lowAssessmentWeight + form.exitRequestWeight;

  return (
    <>
      <PageHeader
        title="Regras de risco"
        subtitle="Pesos e limites versionados por instituição e curso. Nenhuma regra é editada no lugar: cada publicação cria uma versão."
      />

      <ErrorNote message={error} />

      <div style={{ display: "grid", gridTemplateColumns: "1.3fr 1fr", gap: 18, alignItems: "start" }}>
        <section className="card" style={{ padding: 20 }}>
          <h3 style={{ margin: "0 0 14px", fontSize: 15 }}>Publicar nova versão</h3>

          <div className="stack">
            <Field label="Escopo">
              <select className="select" value={courseId} onChange={(e) => setCourseId(e.target.value)}>
                <option value="">Toda a instituição (padrão)</option>
                {courses.map((course) => (
                  <option key={course.id} value={course.id}>{course.name}</option>
                ))}
              </select>
            </Field>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <Field label="Limite de frequência (%)">
                <input className="input" type="number" min={0} max={100} value={form.attendanceThreshold} onChange={(e) => setForm({ ...form, attendanceThreshold: Number(e.target.value) })} />
              </Field>
              <Field label="Peso da frequência">
                <input className="input" type="number" min={0} max={100} value={form.attendanceWeight} onChange={(e) => setForm({ ...form, attendanceWeight: Number(e.target.value) })} />
              </Field>
              <Field label="Faltas consecutivas (limite)">
                <input className="input" type="number" min={0} value={form.consecutiveAbsenceThreshold} onChange={(e) => setForm({ ...form, consecutiveAbsenceThreshold: Number(e.target.value) })} />
              </Field>
              <Field label="Peso das faltas">
                <input className="input" type="number" min={0} max={100} value={form.consecutiveAbsenceWeight} onChange={(e) => setForm({ ...form, consecutiveAbsenceWeight: Number(e.target.value) })} />
              </Field>
              <Field label="Peso da média baixa">
                <input className="input" type="number" min={0} max={100} value={form.lowAssessmentWeight} onChange={(e) => setForm({ ...form, lowAssessmentWeight: Number(e.target.value) })} />
              </Field>
              <Field label="Peso de requerimento de saída">
                <input className="input" type="number" min={0} max={100} value={form.exitRequestWeight} onChange={(e) => setForm({ ...form, exitRequestWeight: Number(e.target.value) })} />
              </Field>
            </div>

            <div className="small muted">
              Soma dos pesos: <strong>{totalWeight}</strong>. O escore é limitado a 100, então somas
              acima disso saturam — o que é esperado e auditável.
            </div>

            <div className="row">
              <div className="spacer" />
              <button className="btn" onClick={() => setForm({ ...DEFAULTS })}>Restaurar padrões</button>
              <button className="btn btn-primary" onClick={publish} disabled={!canManage || saving}>
                {saving ? "Publicando…" : "Publicar versão"}
              </button>
            </div>
          </div>
        </section>

        <section className="card">
          <div style={{ padding: "14px 18px", borderBottom: "1px solid var(--line)", fontWeight: 600 }}>
            Histórico de versões
          </div>
          {rulesets.length === 0 ? (
            <Empty>Nenhuma versão publicada.</Empty>
          ) : (
            <table className="table">
              <thead>
                <tr>
                  <th>Escopo</th>
                  <th>Versão</th>
                  <th>Situação</th>
                  <th>Criada</th>
                </tr>
              </thead>
              <tbody>
                {rulesets.map((ruleset) => (
                  <tr key={ruleset.id}>
                    <td className="small">{ruleset.course_name ?? "Instituição"}</td>
                    <td className="mono small">v{ruleset.version}</td>
                    <td><StatusBadge status={ruleset.status === "active" ? "validated" : "dismissed"} /></td>
                    <td className="small muted">{fmtDate(ruleset.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      </div>
    </>
  );
}
