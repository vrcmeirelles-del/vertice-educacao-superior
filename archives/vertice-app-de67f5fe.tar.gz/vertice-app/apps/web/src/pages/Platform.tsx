import { useCallback, useEffect, useState } from "react";
import {
  api,
  ApiError,
  type InstitutionStatus,
  type PlatformInstitution,
} from "../api";
import { PageHeader } from "../components/Shell";
import { Empty, ErrorNote, Field, fmtDate } from "../components/ui";

/**
 * Console da Vértice.
 *
 * Só `platform_admin` chega aqui. O que esta tela mostra é estado comercial e
 * contagem — nunca dado de estudante: a Vértice opera a conta do cliente, não
 * audita o conteúdo dela.
 *
 * Não há exclusão de instituição. Encerrar é `churned`, que preserva auditoria
 * e permite exportação; um DELETE apagaria o registro do que a plataforma fez.
 */

const STATUS_LABEL: Record<InstitutionStatus, string> = {
  trial: "Avaliação",
  trial_expired: "Avaliação vencida",
  active: "Ativa",
  past_due: "Pagamento em atraso",
  suspended: "Suspensa",
  churned: "Encerrada",
};

function StatusTag({ status }: { status: InstitutionStatus }) {
  const palette: Record<InstitutionStatus, { bg: string; fg: string }> = {
    trial: { bg: "#eef2f6", fg: "#5b6b83" },
    trial_expired: { bg: "#fdf1e3", fg: "#b8802c" },
    active: { bg: "#e9f4ef", fg: "#2f7d5b" },
    past_due: { bg: "#fdf1e3", fg: "#b8802c" },
    suspended: { bg: "#fbe9e7", fg: "#b75046" },
    churned: { bg: "#eef2f6", fg: "#5b6b83" },
  };
  const { bg, fg } = palette[status] ?? palette.trial;
  return (
    <span className="badge" style={{ background: bg, color: fg }}>
      {STATUS_LABEL[status] ?? status}
    </span>
  );
}

export function Platform() {
  const [institutions, setInstitutions] = useState<PlatformInstitution[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({
    slug: "",
    name: "",
    cnpj: "",
    planCode: "piloto",
    trialDays: 30,
    adminName: "",
    adminEmail: "",
  });

  const load = useCallback(() => {
    api
      .platformInstitutions()
      .then((r) => setInstitutions(r.institutions))
      .catch((err) => setError(err instanceof ApiError ? err.message : "Falha ao carregar"));
  }, []);

  useEffect(load, [load]);

  async function create() {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const created = await api.platformCreateInstitution({
        slug: form.slug.trim().toLowerCase(),
        name: form.name.trim(),
        cnpj: form.cnpj.trim() || undefined,
        planCode: form.planCode,
        trialDays: Number(form.trialDays),
        adminName: form.adminName.trim(),
        adminEmail: form.adminEmail.trim(),
      });
      const link = `${window.location.origin}/#convite/${created.inviteToken}`;
      setNotice(
        `Instituição criada. Envie o link de convite para ${created.adminEmail} por canal seguro — ` +
          `ele expira em ${fmtDate(created.inviteExpiresAt)} e não pode ser recuperado depois:\n\n${link}`,
      );
      setForm({ ...form, slug: "", name: "", cnpj: "", adminName: "", adminEmail: "" });
      load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Falha ao criar instituição");
    } finally {
      setBusy(false);
    }
  }

  async function changeStatus(row: PlatformInstitution, status: InstitutionStatus) {
    const reason =
      status === "suspended"
        ? window.prompt(`Motivo da suspensão de ${row.name} (fica na auditoria):`) ?? undefined
        : undefined;
    if (status === "suspended" && !reason) return;
    setError(null);
    try {
      await api.platformSetStatus(row.id, { status, reason });
      setNotice(`${row.name}: estado alterado para ${STATUS_LABEL[status].toLowerCase()}.`);
      load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Falha ao alterar estado");
    }
  }

  async function changePlan(row: PlatformInstitution, planCode: string) {
    if (!planCode || planCode === row.plan_code) return;
    setError(null);
    try {
      await api.platformSetPlan(row.id, { planCode });
      setNotice(`${row.name}: plano alterado para ${planCode}.`);
      load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Falha ao alterar plano");
    }
  }

  return (
    <>
      <PageHeader
        title="Instituições"
        subtitle="Provisionamento, plano e ciclo de vida. Contagem e estado comercial apenas — nenhum dado de estudante."
      />

      <ErrorNote message={error} />

      {notice && (
        <section
          className="card"
          style={{ padding: 14, marginBottom: 16, borderColor: "#cfe3dc", whiteSpace: "pre-wrap" }}
        >
          <strong>Convite emitido.</strong> {notice}
        </section>
      )}

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1.4fr", gap: 18, alignItems: "start" }}>
        <section className="card" style={{ padding: 20 }}>
          <h3 style={{ margin: "0 0 14px", fontSize: 15 }}>Nova instituição</h3>
          <div style={{ display: "grid", gap: 12 }}>
            <Field label="Nome da IES">
              <input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Faculdade Exemplo"
              />
            </Field>
            <Field label="Slug (identificador de login)">
              <input
                value={form.slug}
                onChange={(e) => setForm({ ...form, slug: e.target.value })}
                placeholder="faculdade-exemplo"
              />
            </Field>
            <Field label="CNPJ (opcional)">
              <input value={form.cnpj} onChange={(e) => setForm({ ...form, cnpj: e.target.value })} />
            </Field>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <Field label="Plano">
                <select
                  value={form.planCode}
                  onChange={(e) => setForm({ ...form, planCode: e.target.value })}
                >
                  <option value="piloto">Piloto</option>
                  <option value="essencial">Essencial</option>
                  <option value="institucional">Institucional</option>
                  <option value="contrato">Contrato</option>
                </select>
              </Field>
              <Field label="Dias de avaliação">
                <input
                  type="number"
                  min={0}
                  max={365}
                  value={form.trialDays}
                  onChange={(e) => setForm({ ...form, trialDays: Number(e.target.value) })}
                />
              </Field>
            </div>
            <Field label="Administrador — nome">
              <input
                value={form.adminName}
                onChange={(e) => setForm({ ...form, adminName: e.target.value })}
              />
            </Field>
            <Field label="Administrador — e-mail">
              <input
                type="email"
                value={form.adminEmail}
                onChange={(e) => setForm({ ...form, adminEmail: e.target.value })}
                placeholder="direcao@faculdade.edu.br"
              />
            </Field>
            <button
              className="btn btn-primary"
              disabled={busy || !form.name || !form.slug || !form.adminEmail || !form.adminName}
              onClick={create}
            >
              {busy ? "Criando…" : "Criar e emitir convite"}
            </button>
            <p className="small" style={{ color: "var(--ink-soft)", margin: 0 }}>
              O administrador define a própria senha pelo link. A Vértice nunca vê nem informa senha de
              usuário do cliente.
            </p>
          </div>
        </section>

        <section className="card" style={{ padding: 20 }}>
          <h3 style={{ margin: "0 0 14px", fontSize: 15 }}>
            Instituições ({institutions.length})
          </h3>
          {institutions.length === 0 ? (
            <Empty>Nenhuma instituição provisionada ainda.</Empty>
          ) : (
            <table className="table">
              <thead>
                <tr>
                  <th>Instituição</th>
                  <th>Plano</th>
                  <th>Estado</th>
                  <th>Uso</th>
                  <th>Ações</th>
                </tr>
              </thead>
              <tbody>
                {institutions.map((row) => (
                  <tr key={row.id}>
                    <td>
                      <div style={{ fontWeight: 600 }}>{row.name}</div>
                      <div className="small mono" style={{ color: "var(--ink-soft)" }}>
                        {row.slug}
                      </div>
                    </td>
                    <td>
                      <select
                        value={row.plan_code}
                        onChange={(e) => void changePlan(row, e.target.value)}
                      >
                        <option value="piloto">Piloto</option>
                        <option value="essencial">Essencial</option>
                        <option value="institucional">Institucional</option>
                        <option value="contrato">Contrato</option>
                      </select>
                    </td>
                    <td>
                      <StatusTag status={row.status} />
                      {row.status === "trial" && row.trial_ends_at && (
                        <div className="small" style={{ color: "var(--ink-soft)", marginTop: 4 }}>
                          até {fmtDate(row.trial_ends_at)}
                        </div>
                      )}
                    </td>
                    <td className="small" style={{ color: "var(--ink-soft)" }}>
                      {row.users} usuários · {row.courses} cursos · {row.alerts} alertas
                    </td>
                    <td>
                      <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                        {row.status !== "active" && (
                          <button className="btn btn-sm" onClick={() => void changeStatus(row, "active")}>
                            Ativar
                          </button>
                        )}
                        {row.status !== "suspended" && (
                          <button className="btn btn-sm" onClick={() => void changeStatus(row, "suspended")}>
                            Suspender
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          <p className="small" style={{ color: "var(--ink-soft)", marginTop: 14 }}>
            Suspender bloqueia escrita e mantém leitura e exportação. Encerrar não apaga nada — a
            auditoria do cliente é registro legal, não dado de plano.
          </p>
        </section>
      </div>
    </>
  );
}
