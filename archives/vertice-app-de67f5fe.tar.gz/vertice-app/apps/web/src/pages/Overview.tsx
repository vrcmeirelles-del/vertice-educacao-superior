import { useEffect, useState } from "react";
import { api, ApiError, type AlertsResponse, type AlertsSummary } from "../api";
import { PageHeader } from "../components/Shell";
import { Empty, ErrorNote, LevelBadge, Stat, StatusBadge, fmtDate } from "../components/ui";

export function Overview({ onOpenAlert }: { onOpenAlert: (id: string) => void }) {
  const [summary, setSummary] = useState<AlertsSummary | null>(null);
  const [recent, setRecent] = useState<AlertsResponse["alerts"]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    Promise.all([api.summary(), api.alerts({ limit: "8" })])
      .then(([s, a]) => {
        setSummary(s);
        setRecent(a.alerts);
      })
      .catch((err) => setError(err instanceof ApiError ? err.message : "Falha ao carregar"));
  }, []);

  const critical = summary?.byLevel.critical ?? 0;
  const high = summary?.byLevel.high ?? 0;
  const total = Object.values(summary?.byLevel ?? {}).reduce((acc, n) => acc + n, 0);

  return (
    <>
      <PageHeader
        title="Visão geral"
        subtitle="Sinais de acompanhamento acadêmico e prontidão das evidências institucionais."
      />

      <ErrorNote message={error} />

      <div style={{ display: "flex", gap: 14, flexWrap: "wrap", marginBottom: 22 }}>
        <Stat label="Alertas abertos" value={total} />
        <Stat label="Críticos" value={critical} tone="danger" />
        <Stat label="Altos" value={high} tone="warn" />
        <Stat label="Sem responsável" value={summary?.unassigned ?? 0} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 18, alignItems: "start" }}>
        <section className="card">
          <div style={{ padding: "16px 18px", borderBottom: "1px solid var(--line)", fontWeight: 600 }}>
            Alertas prioritários
          </div>
          {recent.length === 0 ? (
            <Empty>
              Nenhum alerta registrado. Importe um lote para gerar os primeiros sinais.
            </Empty>
          ) : (
            <table className="table">
              <thead>
                <tr>
                  <th>Nível</th>
                  <th>Curso</th>
                  <th>Situação</th>
                  <th>Coleta</th>
                </tr>
              </thead>
              <tbody>
                {recent.map((alert) => (
                  <tr
                    key={alert.id}
                    onClick={() => onOpenAlert(alert.id)}
                    style={{ cursor: "pointer" }}
                  >
                    <td>
                      <div className="row" style={{ gap: 8 }}>
                        <LevelBadge level={alert.level} />
                        <span className="mono small muted">{alert.score}</span>
                      </div>
                    </td>
                    <td>
                      <div style={{ fontWeight: 500 }}>{alert.course_name}</div>
                      <div className="small muted">{alert.factors[0]?.explanation ?? "—"}</div>
                    </td>
                    <td>
                      <StatusBadge status={alert.status} />
                    </td>
                    <td className="small muted">{fmtDate(alert.observed_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>

        <section className="card">
          <div style={{ padding: "16px 18px", borderBottom: "1px solid var(--line)", fontWeight: 600 }}>
            Por curso
          </div>
          {summary?.byCourse.length ? (
            <table className="table">
              <thead>
                <tr>
                  <th>Curso</th>
                  <th style={{ textAlign: "right" }}>Urgentes</th>
                  <th style={{ textAlign: "right" }}>Total</th>
                </tr>
              </thead>
              <tbody>
                {summary.byCourse.map((course) => (
                  <tr key={course.id}>
                    <td>{course.name}</td>
                    <td style={{ textAlign: "right", fontWeight: 600 }}>{course.urgent}</td>
                    <td style={{ textAlign: "right" }} className="muted">
                      {course.total}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <Empty>Sem dados por curso.</Empty>
          )}
        </section>
      </div>

      <p className="muted small" style={{ marginTop: 20 }}>
        Os níveis são faixas de produto para priorizar acompanhamento humano — não são diagnóstico
        de evasão nem decisão sobre o estudante.
      </p>
    </>
  );
}
