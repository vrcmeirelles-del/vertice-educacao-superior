/**
 * Modelo de captação — a parte que a tela desenha.
 *
 * Duas fronteiras deliberadas:
 *
 *  1. **Não existe pessoa física aqui.** O registro é a instituição-alvo
 *     (reescrita como `instituicao`) ligada a uma frente de consultoria. Nome
 *     de aluno, CPF, e-mail e telefone continuam fora do produto, como em
 *     `docs/SEGURANCA-E-LGPD.md`.
 *  2. **Dinheiro é inteiro em reais.** Nada de float acumulando centavo em
 *     soma de custo. A conversão para exibição acontece só na borda.
 *
 * Quando a API do módulo existir, `DEMO_LEADS` e `DEMO_COSTS` saem daqui e a
 * página passa a ler de `/v1/acquisition/*`. Os tipos ficam iguais.
 */

export type Stage = "novo" | "contato" | "diagnostico" | "proposta" | "ganho" | "perdido";

export type Priority = "alta" | "media" | "baixa";

export type Origin = "indicacao" | "site" | "evento" | "prospeccao" | "linkedin";

export type Frente =
  | "Estratégia e governança"
  | "Qualidade e conformidade"
  | "Captação e permanência"
  | "Sustentabilidade e capacidade"
  | "Pesquisa e pós-graduação"
  | "Dados, liderança e desenvolvimento"
  | "Aquisições e due diligence";

export interface Lead {
  id: string;
  instituicao: string;
  frente: Frente;
  estagio: Stage;
  prioridade: Priority;
  responsavel: string;
  valorEstimado: number;
  origem: Origin;
  proximoPasso: string;
  prazo: string | null;
  criadoEm: string;
}

export type CostCategory = "midia" | "pessoa" | "ferramenta" | "evento" | "producao";

export interface CostEntry {
  id: string;
  ciclo: string;
  categoria: CostCategory;
  descricao: string;
  valor: number;
}

/* -------------------------------------------------------------------------- */
/* Rótulos e cores                                                            */
/* -------------------------------------------------------------------------- */

export const STAGE_ORDER: Stage[] = [
  "novo",
  "contato",
  "diagnostico",
  "proposta",
  "ganho",
  "perdido",
];

export const STAGE_LABEL: Record<Stage, string> = {
  novo: "Novo",
  contato: "Contato feito",
  diagnostico: "Diagnóstico",
  proposta: "Proposta enviada",
  ganho: "Ganho",
  perdido: "Perdido",
};

/** Etapas que contam como receita fechada no ciclo. */
export const STAGES_WON: Stage[] = ["ganho"];

export const PRIORITY_LABEL: Record<Priority, string> = {
  alta: "Alta",
  media: "Média",
  baixa: "Baixa",
};

export const PRIORITY_COLOR: Record<Priority, string> = {
  alta: "#b75046",
  media: "#b8802c",
  baixa: "#5b6b83",
};

export const ORIGIN_LABEL: Record<Origin, string> = {
  indicacao: "Indicação",
  site: "Site",
  evento: "Evento",
  prospeccao: "Prospecção ativa",
  linkedin: "LinkedIn",
};

export const COST_LABEL: Record<CostCategory, string> = {
  midia: "Mídia paga",
  pessoa: "Pessoas",
  ferramenta: "Ferramentas",
  evento: "Eventos",
  producao: "Produção",
};

/**
 * Cores das etapas. Seguem a mesma lógica dos badges do painel: neutro para
 * trabalho em andamento, verde para o que fechou e vermelho para o que saiu.
 */
export const STAGE_COLOR: Record<Stage, string> = {
  novo: "#5b6b83",
  contato: "#4a7fa0",
  diagnostico: "#328ea8",
  proposta: "#b8802c",
  ganho: "#2f7d5b",
  perdido: "#b75046",
};

/* -------------------------------------------------------------------------- */
/* Formatação                                                                 */
/* -------------------------------------------------------------------------- */

const BRL = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
  maximumFractionDigits: 0,
});

const BRL_EXACT = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
  minimumFractionDigits: 2,
});

const DATE_SHORT = new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "short" });

const NUMBER = new Intl.NumberFormat("pt-BR");

const DECIMAL = new Intl.NumberFormat("pt-BR", {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

const PERCENT = new Intl.NumberFormat("pt-BR", { style: "percent", maximumFractionDigits: 0 });

export const money = (value: number): string => BRL.format(value);
export const moneyExact = (value: number): string => BRL_EXACT.format(value);
export const number = (value: number): string => NUMBER.format(value);
/** Decimal com vírgula: `1.84` vira `1,84`. */
export const decimal = (value: number): string => DECIMAL.format(value);
/** Percentual inteiro: `0.666` vira `67%`. */
export const percent = (value: number): string => PERCENT.format(value);

export function shortDate(iso: string | null | undefined): string {
  if (!iso) return "—";
  const date = new Date(`${iso}T12:00:00`);
  if (Number.isNaN(date.getTime())) return "—";
  return DATE_SHORT.format(date);
}

/** Iniciais para o avatar: no máximo duas letras, sem dado sensível. */
export function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "?";
  const first = parts[0]?.[0] ?? "";
  const last = parts.length > 1 ? (parts[parts.length - 1]?.[0] ?? "") : "";
  return `${first}${last}`.toUpperCase();
}

/** Cor estável por nome — o mesmo responsável tem a mesma cor sempre. */
export function avatarColor(name: string): string {
  const palette = ["#328ea8", "#5b6b83", "#2f7d5b", "#b8802c", "#7a6b9a", "#a05b7d"];
  let hash = 0;
  for (let i = 0; i < name.length; i += 1) {
    hash = (hash * 31 + name.charCodeAt(i)) % 100000;
  }
  return palette[hash % palette.length] ?? palette[0]!;
}

/* -------------------------------------------------------------------------- */
/* Cálculo                                                                    */
/* -------------------------------------------------------------------------- */

export interface CaptureMetrics {
  /** Custo somado do ciclo. */
  custoTotal: number;
  /** Negócios fechados no ciclo. */
  ganhos: number;
  /** Em aberto: tudo que não é ganho nem perdido. */
  emAberto: number;
  perdidos: number;
  /** Pipeline em aberto, em reais. */
  valorEmAberto: number;
  /** CAC: custo do ciclo dividido por ganhos. `null` sem ganho — não é zero. */
  cac: number | null;
  /** Custo médio por lead trabalhado (todas as oportunidades do ciclo). */
  custoPorLead: number | null;
  /** Conversão: ganhos sobre oportunidades decididas (ganho + perdido). */
  conversao: number | null;
  /** Receita média por contrato ganho. */
  ticketMedio: number | null;
  /** Receita estimada / custo. `null` sem custo — não é infinito. */
  roas: number | null;
}

/**
 * Calcula os indicadores do ciclo.
 *
 * Regra que não é óbvia: `cac` e `custoPorLead` dividem por populações
 * diferentes. CAC usa só o que pagou o custo (ganhos). Custo por lead usa
 * todas as oportunidades, porque toda oportunidade consumiu algum esforço de
 * captação, mesmo a perdida. Dividir custo por lead pelos ganhos infla o
 * número e faz o canal parecer pior do que é.
 */
export function computeMetrics(leads: Lead[], costs: CostEntry[]): CaptureMetrics {
  const custoTotal = costs.reduce((acc, entry) => acc + entry.valor, 0);
  const ganhos = leads.filter((lead) => lead.estagio === "ganho");
  const perdidos = leads.filter((lead) => lead.estagio === "perdido").length;
  const abertos = leads.filter((lead) => lead.estagio !== "ganho" && lead.estagio !== "perdido");

  const receita = ganhos.reduce((acc, lead) => acc + lead.valorEstimado, 0);
  const decididos = ganhos.length + perdidos;

  return {
    custoTotal,
    ganhos: ganhos.length,
    emAberto: abertos.length,
    perdidos,
    valorEmAberto: abertos.reduce((acc, lead) => acc + lead.valorEstimado, 0),
    cac: ganhos.length > 0 ? Math.round(custoTotal / ganhos.length) : null,
    custoPorLead: leads.length > 0 ? Math.round(custoTotal / leads.length) : null,
    conversao: decididos > 0 ? ganhos.length / decididos : null,
    ticketMedio: ganhos.length > 0 ? Math.round(receita / ganhos.length) : null,
    roas: custoTotal > 0 && receita > 0 ? receita / custoTotal : null,
  };
}

/** Custo por etapa do funil: quanto custou produzir as oportunidades que chegaram ali. */
export function costByStage(costs: CostEntry[], leads: Lead[]): { stage: Stage; count: number; share: number }[] {
  const total = costs.reduce((acc, entry) => acc + entry.valor, 0);
  return STAGE_ORDER.map((stage) => {
    const count = leads.filter((lead) => lead.estagio === stage).length;
    return {
      stage,
      count,
      share: leads.length > 0 ? count / leads.length : 0,
    };
  }).map((row) => ({ ...row, share: row.share * (total > 0 ? 1 : 0) }));
}

/** Soma por origem — a pergunta "de onde vem o que fecha". */
export function byOrigin(leads: Lead[]): { origin: Origin; total: number; ganhos: number; valor: number }[] {
  const origins = Object.keys(ORIGIN_LABEL) as Origin[];
  return origins
    .map((origin) => {
      const subset = leads.filter((lead) => lead.origem === origin);
      const ganhos = subset.filter((lead) => lead.estagio === "ganho");
      return {
        origin,
        total: subset.length,
        ganhos: ganhos.length,
        valor: ganhos.reduce((acc, lead) => acc + lead.valorEstimado, 0),
      };
    })
    .filter((row) => row.total > 0);
}

/* -------------------------------------------------------------------------- */
/* Dados de demonstração                                                      */
/* -------------------------------------------------------------------------- */

/**
 * Ciclo demonstrativo. Existe para dar forma à tela enquanto a API do módulo
 * não entra; a página diz isso em texto, não esconde.
 */
export const DEMO_CYCLE = "2026-H2";

export const DEMO_LEADS: Lead[] = [
  {
    id: "ld-01",
    instituicao: "Faculdade Vale do Paraíba",
    frente: "Qualidade e conformidade",
    estagio: "proposta",
    prioridade: "alta",
    responsavel: "Virgílio M.",
    valorEstimado: 96000,
    origem: "indicacao",
    proximoPasso: "Revisar escopo e enviar proposta revisada",
    prazo: "2026-11-12",
    criadoEm: "2026-09-18",
  },
  {
    id: "ld-02",
    instituicao: "Centro Universitário Serrano",
    frente: "Captação e permanência",
    estagio: "diagnostico",
    prioridade: "alta",
    responsavel: "Virgílio M.",
    valorEstimado: 72000,
    origem: "site",
    proximoPasso: "Fechar entrevista com a pró-reitoria acadêmica",
    prazo: "2026-11-06",
    criadoEm: "2026-10-02",
  },
  {
    id: "ld-03",
    instituicao: "Instituto Tecnológico Cerrado",
    frente: "Sustentabilidade e capacidade",
    estagio: "contato",
    prioridade: "media",
    responsavel: "Ana P.",
    valorEstimado: 48000,
    origem: "linkedin",
    proximoPasso: "Confirmar reunião de diagnóstico",
    prazo: "2026-11-09",
    criadoEm: "2026-10-20",
  },
  {
    id: "ld-04",
    instituicao: "Faculdade Costa Verde",
    frente: "Estratégia e governança",
    estagio: "ganho",
    prioridade: "alta",
    responsavel: "Virgílio M.",
    valorEstimado: 120000,
    origem: "indicacao",
    proximoPasso: "Kickoff e plano de trabalho",
    prazo: "2026-11-03",
    criadoEm: "2026-08-11",
  },
  {
    id: "ld-05",
    instituicao: "Centro Educacional Litoral Norte",
    frente: "Dados, liderança e desenvolvimento",
    estagio: "novo",
    prioridade: "baixa",
    responsavel: "Ana P.",
    valorEstimado: 36000,
    origem: "evento",
    proximoPasso: "Qualificar demanda e decidir se avança",
    prazo: "2026-11-20",
    criadoEm: "2026-10-28",
  },
  {
    id: "ld-06",
    instituicao: "Faculdade Planalto Central",
    frente: "Qualidade e conformidade",
    estagio: "perdido",
    prioridade: "media",
    responsavel: "Ana P.",
    valorEstimado: 54000,
    origem: "prospeccao",
    proximoPasso: "Retomar no próximo ciclo",
    prazo: null,
    criadoEm: "2026-07-30",
  },
  {
    id: "ld-07",
    instituicao: "Instituto Superior do Recôncavo",
    frente: "Captação e permanência",
    estagio: "proposta",
    prioridade: "media",
    responsavel: "Virgílio M.",
    valorEstimado: 84000,
    origem: "site",
    proximoPasso: "Aguardar parecer do conselho",
    prazo: "2026-11-18",
    criadoEm: "2026-09-29",
  },
  {
    id: "ld-08",
    instituicao: "Faculdades Integradas do Sul",
    frente: "Aquisições e due diligence",
    estagio: "diagnostico",
    prioridade: "alta",
    responsavel: "Ana P.",
    valorEstimado: 150000,
    origem: "indicacao",
    proximoPasso: "Levantar documentos da operação-alvo",
    prazo: "2026-11-14",
    criadoEm: "2026-10-08",
  },
  {
    id: "ld-09",
    instituicao: "Faculdade Regional da Serra",
    frente: "Estratégia e governança",
    estagio: "ganho",
    prioridade: "media",
    responsavel: "Virgílio M.",
    valorEstimado: 60000,
    origem: "evento",
    proximoPasso: "Reunião de alinhamento mensal",
    prazo: "2026-11-25",
    criadoEm: "2026-06-15",
  },
  {
    id: "ld-10",
    instituicao: "Centro de Ensino São Bento",
    frente: "Qualidade e conformidade",
    estagio: "contato",
    prioridade: "baixa",
    responsavel: "Ana P.",
    valorEstimado: 42000,
    origem: "prospeccao",
    proximoPasso: "Enviar material institucional",
    prazo: "2026-11-27",
    criadoEm: "2026-10-24",
  },
];

export const DEMO_COSTS: CostEntry[] = [
  { id: "ct-01", ciclo: DEMO_CYCLE, categoria: "pessoa", descricao: "Horas de consultoria sênior", valor: 48000 },
  { id: "ct-02", ciclo: DEMO_CYCLE, categoria: "midia", descricao: "LinkedIn Ads", valor: 14500 },
  { id: "ct-03", ciclo: DEMO_CYCLE, categoria: "midia", descricao: "Google Ads", valor: 9200 },
  { id: "ct-04", ciclo: DEMO_CYCLE, categoria: "ferramenta", descricao: "Assinaturas e infraestrutura", valor: 4100 },
  { id: "ct-05", ciclo: DEMO_CYCLE, categoria: "evento", descricao: "Congresso de mantenedoras", valor: 7800 },
  { id: "ct-06", ciclo: DEMO_CYCLE, categoria: "producao", descricao: "Material e apresentações", valor: 3400 },
  { id: "ct-07", ciclo: DEMO_CYCLE, categoria: "pessoa", descricao: "Apoio comercial", valor: 11000 },
];
