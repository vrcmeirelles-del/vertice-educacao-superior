# Vértice — Retenção e Governança Regulatória

Camada SaaS de governança e inteligência para IES privadas. Detecta sinais de possível evasão e
organiza evidências institucionais **sem** substituir o ERP acadêmico, a Secretaria, o e-MEC, a CPA
ou a decisão humana da IES.

> A promessa correta: **“a Vértice organiza sinais, evidências e ações de acompanhamento em um só
> lugar”**. Não há garantia de conceito do MEC e nenhuma decisão é tomada automaticamente sobre o
> estudante.

## O que está neste repositório

```
apps/
  api/         Fastify + PostgreSQL — tenancy, RBAC, motor de risco, evidências, auditoria
  web/         React + Vite — painel operacional da IES
  extension/   Chrome MV3 — leitura autorizada de um portal, sob clique
docs/          operação, segurança, deploy e critérios de aceite
docker-compose.yml, Caddyfile, Dockerfile por app
```

## Requisitos

- Node.js 22+
- PostgreSQL 16+ (ou Docker)
- Chrome 116+ (apenas para a extensão)

## Subir localmente (sem Docker)

```bash
npm install
cp .env.example .env          # edite segredos e credenciais do banco
npm --workspace @vertice/api run migrate
npm --workspace @vertice/api run seed
npm run dev:api               # http://localhost:8787
npm run dev:web               # http://localhost:5173
```

O seed cria a instituição `demo`, três cursos e um administrador com o e-mail/senha de
`SEED_ADMIN_EMAIL`/`SEED_ADMIN_PASSWORD` (fallback de demonstração é avisado no console).

Para subir as duas pontas:

```bash
npm run dev:api
```

```bash
npm run dev:web
```

## Subir com Docker

```bash
cp .env.example .env   # preencha POSTGRES_PASSWORD, JWT_SECRET, PSEUDONYM_PEPPER
docker compose up -d --build
```

As migrações e o seed rodam como serviço separado, uma vez:

```bash
docker compose --profile setup up migrate
```

O painel fica em `http://localhost:8080`; o proxy TLS (Caddy) assume o domínio real configurado no
`Caddyfile`.

## Verificar antes de publicar

```bash
npm run check
npm test
npm run build
```

## Contrato de ingestão

A API aceita **apenas** estes campos por registro:

| Campo | Tipo | Obrigatório |
|---|---|---|
| `studentRef` | identificador pseudonimizado | sim |
| `courseRef` | código do curso | sim |
| `attendancePercent` | 0–100 | não |
| `consecutiveAbsences` | inteiro 0–365 | não |
| `assessmentAverage` | 0–10 | não |
| `passingAverage` | 0–10 | não |
| `openRequests` | lista fechada de tipos | não |
| `observedAt` | ISO 8601 com offset | sim |
| `source` | identificador do adaptador | sim |

Qualquer campo fora dessa lista rejeita o registro. Nome, CPF, RG, e-mail, telefone, endereço,
senha, biometria e texto livre são rejeitados explicitamente e o evento vai para a auditoria.

## Endpoints principais

| Método | Rota | Papéis |
|---|---|---|
| POST | `/v1/auth/login` | público (rate limit 10/min) |
| GET | `/v1/auth/me` | autenticado |
| POST | `/v1/risk/evaluate` | admin, regulação, coordenação |
| POST | `/v1/ingestions` | admin, regulação, coordenação |
| POST | `/v1/ingestions/extension` | token de pareamento |
| GET | `/v1/alerts` · `/v1/alerts/:id` | leitura autenticada |
| PATCH | `/v1/alerts/:id` | admin, regulação, coordenação |
| GET | `/v1/evidence` · `/v1/instruments` | leitura autenticada |
| PATCH | `/v1/evidence/:id/status` | admin, regulação |
| GET/POST | `/v1/rulesets` | admin da IES |
| GET/POST/DELETE | `/v1/users` | admin da IES |
| POST/GET/DELETE | `/v1/pairing-tokens` | admin da IES |
| GET | `/v1/audit` | admin, auditor, privacidade |
| POST | `/v1/privacy/purge` | admin, privacidade |

## Papéis

`platform_admin` · `institution_admin` · `regulatory_manager` · `coordinator` ·
`auditor_readonly` (exige expiração) · `privacy_officer`

Coordenador com `courseScope` preenchido só enxerga os cursos autorizados — o filtro é aplicado no
SQL, não na interface.

## Decisões que não devem ser revertidas

1. **Tenant vem do token**, nunca do corpo da requisição.
2. **Identificador do estudante** é persistido como HMAC-SHA256 com pepper — nunca em claro.
3. **Motor determinístico**, com regra e versão devolvidas em cada alerta.
4. **`automatedDecision` é sempre `null`.** A coluna existe para auditoria.
5. **Auditoria é append-only** (trigger no banco bloqueia UPDATE/DELETE).
6. **Nenhum serviço acadêmico é bloqueado.** Requerimento de histórico/ementa gera alerta, não trava.
7. **Regras nunca são editadas no lugar** — publicar cria nova versão.
8. **Extensão falha fechado**: layout desconhecido = nada é enviado.

## Documentação

- [docs/DEPLOY.md](docs/DEPLOY.md) — do zero ao domínio com HTTPS
- [docs/SEGURANCA-E-LGPD.md](docs/SEGURANCA-E-LGPD.md) — controles e o que ainda não está pronto
- [docs/OPERACAO.md](docs/OPERACAO.md) — rotina diária, backup, resposta a incidente
- [docs/ACEITE.md](docs/ACEITE.md) — os 12 critérios do briefing, com onde cada um é atendido
- [docs/PLANO-DE-TRABALHO.md](docs/PLANO-DE-TRABALHO.md) — o que falta para produção
