# COMO ABRIR O VÉRTICE NO SEU COMPUTADOR

Guia para copiar e colar. Não precisa entender de programação.
Você vai abrir **3 janelas** pretas (Prompt de Comando) e deixá-las abertas.

---

## ANTES DE COMEÇAR: abrir as 3 janelas

1. Aperte a tecla **Windows** do teclado.
2. Digite: `cmd`
3. Aperte **Enter**. Abre uma janela preta.
4. Repita isso mais **2 vezes**, para ter **3 janelas pretas** abertas.

---

## JANELA 1 — o banco de dados

Copie a linha abaixo, cole na **janela 1** e aperte **Enter**:

```bash
cd "C:\Users\Virgilio\OneDrive - Virgilio Meirelles - Sociedade individual de advocacia\Documentos Virgilio\Empresas\Vertice\EMPRESA\produto\vertice-app"
```

Agora copie esta segunda linha, cole na **mesma janela 1** e aperte **Enter**:

```bash
npm run banco
```

**Vai aparecer** uma mensagem assim:

```
 BANCO PRONTO. Deixe esta janela aberta.
```

✅ A janela 1 está pronta. **Não feche ela.**

> Na primeira vez demora uns 40 segundos e ele cria tudo do zero.
> Nas próximas vezes é instantâneo.

---

## JANELA 2 — o sistema (o "motor")

Copie e cole na **janela 2**:

```bash
cd "C:\Users\Virgilio\OneDrive - Virgilio Meirelles - Sociedade individual de advocacia\Documentos Virgilio\Empresas\Vertice\EMPRESA\produto\vertice-app"
```

Depois cole esta e aperte **Enter**:

```bash
npm run api
```

**Vai aparecer**:

```
[api] ouvindo em http://:8787
```

✅ A janela 2 está pronta. **Não feche ela.**

---

## JANELA 3 — o site (a tela que você usa)

Copie e cole na **janela 3**:

```bash
cd "C:\Users\Virgilio\OneDrive - Virgilio Meirelles - Sociedade individual de advocacia\Documentos Virgilio\Empresas\Vertice\EMPRESA\produto\vertice-app"
```

Depois cole esta e aperte **Enter**:

```bash
npm run site
```

**Vai aparecer**:

```
➜  Local:   http://localhost:5173/
```

✅ Agora abra o navegador (Chrome, Edge) e digite:

```
http://localhost:5173
```

---

## ENTRAR NO SISTEMA

| Campo | O que digitar |
|---|---|
| **E-mail** | `admin@unitop.local` |
| **Senha** | `Vertice-Demo-2026` |
| **Instituição** | deixe em branco |

Clique em **Entrar**.

---

## COLOCAR OS DADOS DA PLANILHA DENTRO DO SISTEMA

Isso só precisa ser feito **uma vez**.
Com as 3 janelas abertas, abra uma **4ª janela preta** (Windows → `cmd` → Enter) e cole:

```bash
cd "C:\Users\Virgilio\OneDrive - Virgilio Meirelles - Sociedade individual de advocacia\Documentos Virgilio\Empresas\Vertice\EMPRESA\produto\vertice-app"
```

Depois cole esta e aperte **Enter**:

```bash
npm run importar
```

**Vai aparecer**:

```
   Registros gravados: 840
   Recusados:          0
   Cursos no painel:   84
   Matriculados 2026/02: 3794
   Cursos com aluno:     41

   DIREITO 2026/02: 245 matriculados
   Semestre anterior: 220
   Variacao: 11%
   Turmas com aluno: 10
```

✅ Pronto. Os dados estão dentro.
Para ver no site: entre e clique em **Importações** e depois em **Histórico**.

---

## COMO DESLIGAR TUDO

Nas **3 janelas**, clique dentro dela e aperte **Ctrl + C**. Depois feche.

**Ordem importa:** feche primeiro a janela 3 (site), depois a 2 (motor), depois a 1 (banco).

---

## SE DER ERRO

### "EADDRINUSE" ou "address already in use"
Já existe uma janela antiga rodando. Feche **todas** as janelas pretas,
abra 3 novas e comece de novo do passo da janela 1.

### Na janela 1 diz "directory exists but is not empty"
Normal, é só o banco já ter sido criado antes. Ignore.
Se travar, apague a pasta `vertice-app\.tmp-pg\dados` e rode `npm run banco` de novo.

### O site abre mas dá "Erro interno" ao entrar
A janela 2 (motor) não está rodando. Volte nela e rode `npm run api`.

### "npm não é reconhecido"
O Node.js não está instalado. Baixe em https://nodejs.org
(escolha a versão **LTS**, instale com tudo padrão, depois reinicie o computador).

---

## O QUE CADA JANELA FAZ

Pense num restaurante:

| Janela | É o quê | Comando |
|---|---|---|
| 1 | A **despensa** — guarda os dados | `npm run banco` |
| 2 | A **cozinha** — processa tudo | `npm run api` |
| 3 | O **salão** — o que você vê e usa | `npm run site` |

Se a despensa não estiver aberta, a cozinha não funciona.
Se a cozinha não estiver aberta, o salão fica vazio.

---

## RESUMO EM 6 LINHAS

```bash
cd "C:\Users\Virgilio\OneDrive - Virgilio Meirelles - Sociedade individual de advocacia\Documentos Virgilio\Empresas\Vertice\EMPRESA\produto\vertice-app"
npm run banco
```

```bash
cd "C:\Users\Virgilio\OneDrive - Virgilio Meirelles - Sociedade individual de advocacia\Documentos Virgilio\Empresas\Vertice\EMPRESA\produto\vertice-app"
npm run api
```

```bash
cd "C:\Users\Virgilio\OneDrive - Virgilio Meirelles - Sociedade individual de advocacia\Documentos Virgilio\Empresas\Vertice\EMPRESA\produto\vertice-app"
npm run site
```

Depois: abrir `http://localhost:5173` e entrar com `admin@unitop.local` / `Vertice-Demo-2026`.
