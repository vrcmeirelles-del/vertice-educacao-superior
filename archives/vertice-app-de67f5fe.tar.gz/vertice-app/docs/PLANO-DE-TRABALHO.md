# Plano de trabalho para o desenvolvedor

O que está pronto, o que falta e em que ordem. Estimativas em dias úteis de um desenvolvedor
full-stack sênior já familiarizado com o código.

## Semana 1 — fechar o piloto

| Tarefa | Entrega | Dias |
|---|---|---|
| Upload de documentos | S3/MinIO, presigned URL, validação de MIME e tamanho, SHA-256, antivírus (ClamAV ou serviço) | 3 |
| Testes de integração | Suíte com PostgreSQL real (testcontainers) no CI cobrindo login, ingestão, transição e isolamento por tenant | 1 |
| MFA para administradores | TOTP obrigatório para `institution_admin` e `platform_admin` | 1 |

## Semana 2 — completar o critério de aceite

| Tarefa | Entrega | Dias |
|---|---|---|
| Importador da matriz | XLSX/CSV do instrumento oficial → `instrument_requirements`, com validação e pré-visualização | 2 |
| Plano de ação | Entidade `action_plan` (responsável, prazo, status) ligada a alerta/achado; tela de acompanhamento | 2 |
| Exportação de prontidão | XLSX + PDF com fonte oficial, versão do instrumento, data e assinatura de responsável | 1 |

## Semana 3 — endurecer e operar

| Tarefa | Entrega | Dias |
|---|---|---|
| Onboarding de instituição | Criar IES + primeiro admin pela UI, sem seed | 1 |
| Observabilidade | Log estruturado para arquivo, métrica de ingestão/alertas, alerta de 5xx | 1 |
| Backup cifrado | `pg_dump` → Age/GPG → bucket, com teste de restauração documentado | 1 |
| Revisão de segurança | Revisão externa focada em tenancy, RBAC e ingestão | 1 |
| Documentos legais | Contrato de operador, aviso de privacidade, política de retenção por IES | (jurídico) |

## Dívidas técnicas registradas

1. **Sem testes de integração** — maior risco atual. O motor de risco e a validação têm boa cobertura,
   mas SQL e transações não têm.
2. **`services/ingestion.ts` importa `query` dinamicamente** dentro de `loadCourses` para evitar
   ciclo. Vale reorganizar em `db/queries/*` quando o módulo crescer.
3. **Front-end sem roteador** — navegação por estado em `App.tsx`. Funciona, mas deep link e
   histórico do navegador não existem. Adotar `react-router` quando houver mais de 12 telas.
4. **Sem paginação real em evidências e auditoria** — limites fixos (200/500). Suficiente para o
   piloto, insuficiente para 3 anos de histórico.
5. **`documents` sem serviço de arquivo** — tabela pronta, upload não implementado.
6. **Sem cache** — cada tela consulta a API. Para o volume do piloto é adequado; medir antes de
   adicionar Redis.
7. **Extensão depende de adaptador por portal** — cada portal novo é um trabalho de homologação de
   ~0,5 dia. Isso é característica do problema, não bug.

## Decisões que o desenvolvedor não deve “simplificar”

- Não mover o `institutionId` para o corpo da requisição “para facilitar o front”.
- Não trocar o HMAC do identificador por armazenamento em claro “para permitir busca por nome”.
  Busca por nome exige outro desenho (e outra base legal).
- Não transformar o alerta em bloqueio de matrícula. É o erro de produto mais provável e o de maior
  risco jurídico.
- Não remover o trigger append-only da auditoria para “corrigir” um registro. Corrija com um novo
  evento.
- Não editar ruleset existente. Publique versão nova.
- Não permitir que a extensão leia `innerText` da página inteira para “pegar mais dados”.
