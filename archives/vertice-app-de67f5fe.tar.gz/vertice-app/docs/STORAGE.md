# Armazenamento de documentos

Como configurar o bucket e como o fluxo de upload funciona.

## Modelo de segurança

Cinco decisões que sustentam o resto:

1. **Bucket privado.** Nenhuma leitura anônima. Toda leitura sai por URL
   pré-assinada de 5 minutos.
2. **O arquivo nunca passa pela API.** O cliente recebe uma URL de `PUT`,
   envia direto ao bucket e depois confirma. A API só trafega metadados —
   menos memória, menos superfície de ataque.
3. **A chave do objeto não tem dado pessoal.** Formato:
   `{institution_id}/{evidence_id|avulso}/{document_id}/{nome-sanitizado}`.
   Nunca matrícula, nome de aluno ou CPF.
4. **Nada é vinculado a uma evidência sem passar pelo antivírus.** Há um
   trigger no banco (`evidence_documents_require_clean`) que recusa o vínculo
   mesmo que uma rota futura esqueça a checagem na aplicação.
5. **Falha fechada.** Se o antivírus não responder, o documento fica `failed`
   e bloqueado. Nunca vira `clean` por ausência de resposta.

## Ciclo de vida

```
pending_upload ──PUT──▶ pending_scan ──scan ok──▶ clean ──▶ vinculável
                              │
                              ├── ameaça encontrada ──▶ infected  (objeto apagado)
                              └── erro / timeout ─────▶ failed    (reenvio necessário)
```

`failed` é recuperável: basta reenviar o mesmo arquivo. `infected` não —
o objeto é removido do bucket e o registro fica como prova do evento.

## Provedores

Qualquer S3-compatível funciona. Recomendação para dado de IES brasileira:

| Provedor | Endpoint | Região | Observação |
|---|---|---|---|
| Magalu Cloud | `https://s3.magalu.cloud` | `br-ne-1` | residência no Brasil, preço em real |
| AWS S3 | — | `sa-east-1` | auditoria mais madura, mais caro |
| Cloudflare R2 | `https://<id>.r2.cloudflarestorage.com` | `auto` | sem custo de egress, dado fora do BR |
| MinIO (on-prem) | `http://minio:9000` | `us-east-1` | `S3_FORCE_PATH_STYLE=true` |

## Criar o bucket (Magalu Cloud / AWS)

```bash
aws s3api create-bucket \
  --bucket vertice-documentos \
  --region br-ne-1 \
  --create-bucket-configuration LocationConstraint=br-ne-1

aws s3api put-public-access-block \
  --bucket vertice-documentos \
  --public-access-block-configuration \
  "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"

aws s3api put-bucket-encryption \
  --bucket vertice-documentos \
  --server-side-encryption-configuration \
  '{"Rules":[{"ApplyServerSideEncryptionByDefault":{"SSEAlgorithm":"AES256"}}]}'

aws s3api put-bucket-versioning \
  --bucket vertice-documentos --versioning-configuration Status=Enabled
```

O versionamento protege contra remoção acidental e contra ransomware.

## Política IAM mínima da API

A credencial da API não pode listar o bucket nem apagar fora do prefixo dela.
Ajuste `ACCOUNT` e o nome do bucket:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "SomenteOsObjetosQuePrecisamos",
      "Effect": "Allow",
      "Action": ["s3:PutObject", "s3:GetObject", "s3:DeleteObject"],
      "Resource": "arn:aws:s3:::vertice-documentos/*"
    }
  ]
}
```

Sem `s3:ListBucket`, sem `s3:*`. O necessário é: `PutObject` (upload),
`GetObject` (scan e download) e `DeleteObject` (documento reprovado ou
excluído a pedido).

## Variáveis de ambiente

```bash
S3_ENDPOINT=https://s3.magalu.cloud
S3_REGION=br-ne-1
S3_BUCKET=vertice-documentos
S3_ACCESS_KEY_ID=...
S3_SECRET_ACCESS_KEY=...
S3_FORCE_PATH_STYLE=false
S3_UPLOAD_TTL_SECONDS=600
S3_DOWNLOAD_TTL_SECONDS=300
MAX_UPLOAD_BYTES=26214400
```

Se `S3_BUCKET`, `S3_ACCESS_KEY_ID` ou `S3_SECRET_ACCESS_KEY` estiverem vazios,
a rota de upload responde `503 storage_unavailable` em vez de falhar de forma
confusa. Leitura continua funcionando.

## Antivírus

O `docker-compose.yml` sobe um `clamav/clamav` na rede interna. O primeiro
start baixa as assinaturas (2–5 min, ~1 GB). Configure `start_period` do
healthcheck de acordo — já está em 300s.

```bash
ANTIVIRUS_MODE=required
CLAMAV_HOST=clamav
CLAMAV_PORT=3310
CLAMAV_TIMEOUT_MS=30000
```

`ANTIVIRUS_MODE=disabled` existe só para desenvolvimento: nesse modo **nada é
aprovado**, porque `scanBuffer` devolve `failed` em vez de `clean`. Não há como
desligar o antivírus e continuar validando evidências.

Verificar manualmente:

```bash
docker compose exec clamav clamdscan --version
docker compose exec api node -e "fetch('http://127.0.0.1:8787/health')"
```

## API

| Método | Rota | Papel | O que faz |
|---|---|---|---|
| GET | `/v1/documents` | leitura | lista os 200 mais recentes |
| POST | `/v1/documents` | escrita | cria registro e devolve URL de `PUT` |
| POST | `/v1/documents/:id/complete` | escrita | confere tamanho e escaneia |
| GET | `/v1/documents/:id/download` | leitura | devolve URL de `GET` assinada |
| DELETE | `/v1/documents/:id` | escrita | remoção lógica + apaga objeto |
| POST | `/v1/evidence/:id/documents` | escrita | vincula (exige `scan_status = clean`) |

### Exemplo de upload

```bash
TOKEN="..."; INST="..."; FILE=./ppc.pdf

SHA=$(openssl dgst -sha256 -binary "$FILE" | base64 -w0)
SIZE=$(wc -c < "$FILE")

# 1. pede a URL
curl -s -X POST https://app.suaies.com.br/v1/documents \
  -H "authorization: Bearer $TOKEN" -H "content-type: application/json" \
  -d "{\"fileName\":\"ppc.pdf\",\"mimeType\":\"application/pdf\",\"sizeBytes\":$SIZE,\"sha256Base64\":\"$SHA\"}"
```

Resposta traz `uploadUrl` e `headers`. Use-os literalmente — pular o
`x-amz-checksum-sha256` faz o bucket recusar o `PUT`:

```bash
# 2. envia direto ao bucket
curl -X PUT "$UPLOAD_URL" \
  -H "Content-Type: application/pdf" \
  -H "x-amz-checksum-sha256: $SHA" \
  -H "x-amz-sdk-checksum-algorithm: SHA256" \
  --data-binary @"$FILE"

# 3. confirma e dispara o antivírus
curl -s -X POST https://app.suaies.com.br/v1/documents/$DOC_ID/complete \
  -H "authorization: Bearer $TOKEN"
```

## Auditoria

Toda operação grava em duas trilhas:

- **`audit_log`** — evento de negócio, entra no painel de Auditoria.
- **`document_access_log`** — quem emitiu cada URL e o resultado de cada scan.
  Tabela append-only: `UPDATE` e `DELETE` disparam exceção.

Ações registradas: `upload_url_issued`, `upload_confirmed`,
`download_url_issued`, `scan_completed`, `document.approved`,
`document.infected`, `document.deleted`.

## O que ainda não está pronto

Limites conscientes desta versão:

- **Scan em memória.** `/complete` baixa o objeto e escaneia num processo só.
  Funciona até ~25 MB com pouca concorrência. Acima disso, mova o scan para um
  worker com fila; o contrato de `scan_status` continua idêntico.
- **Upload multipart.** Arquivos grandes (>25 MB) exigem outro fluxo. O limite
  atual foi escolhido justamente para caber num `PUT` simples.
- **Retenção automática.** Não há expurgo programado. A política de guarda de
  evidência precisa ser combinada em contrato com cada IES e implementada com
  um job de lifecycle no bucket.
- **Paginação.** `/v1/documents` devolve no máximo 200 linhas.
