# Operação — rotina, backup e resposta a incidente

## Rotina diária

| Frequência | Verificação |
|---|---|
| Diária | `docker compose ps` — todos os serviços `running`/`healthy` |
| Diária | Importações com rejeição: painel → Importações → Histórico |
| Diária | Fila de alertas `open` sem responsável há mais de 48 h |
| Semanal | Crescimento do banco (`docker compose exec db psql -U vertice -c "\l+"`) |
| Semanal | Erros 5xx em `docker compose logs api \| grep internal_error` |
| Mensal | Revisão de acessos na tela Equipe; revogar ex-funcionários |
| Trimestral | Teste de restauração de backup |

## Comandos úteis

Saúde da API:

```bash
curl -s https://app.suaies.com.br/health
```

Logs em tempo real:

```bash
docker compose logs -f api
```

Reiniciar apenas a API:

```bash
docker compose restart api
```

Backup manual:

```bash
docker compose exec -T db pg_dump -U vertice -d vertice | gzip > vertice-$(date +%F).sql.gz
```

Restaurar em banco de teste:

```bash
gunzip -c vertice-2026-10-01.sql.gz | docker compose exec -T db psql -U vertice -d vertice_test
```

## Sintomas e causas prováveis

**A importação retorna “Curso não encontrado”.**
O `courseRef` do arquivo não bate com `courses.code`. Verifique acentuação/caixa — o código é
sensível. Cadastre o curso antes de importar.

**Todos os registros rejeitados com “A requisição contém campos proibidos”.**
O CSV tem uma coluna extra (geralmente `nome` ou `cpf`). Remova a coluna; o contrato é fechado de
propósito.

**Extensão retorna “Layout não reconhecido”.**
O portal mudou. Não edite os dados na mão: acione quem mantém `apps/extension/adapters.js`, atualize
os seletores, homologue com `fixture-portal.html` e publique nova versão.

**Alertas deixaram de aparecer.**
O alerta só é criado quando o escore é maior que zero. Se todas as coletas estão normalizadas (100%
de frequência, média acima da referência, sem requerimento de saída), não há alerta — é o esperado.

**“régua” de nível mudou sem eu mexer.**
Alguém publicou nova versão de ruleset. O histórico em **Regras** mostra a versão e a data. Alertas
antigos preservam a versão que os gerou (`alerts.rule_version`).

## Revogar acesso imediatamente

Pela interface: **Equipe** → remover vínculo do usuário. O efeito é imediato, porque a membership é
reverificada no banco a cada requisição.

Por força maior, direto no banco:

```bash
docker compose exec db psql -U vertice -d vertice -c "UPDATE memberships SET revoked_at = now() WHERE user_id = 'UUID_DO_USUARIO';"
```

```bash
docker compose exec db psql -U vertice -d vertice -c "INSERT INTO revoked_sessions (jti, user_id, reason) SELECT gen_random_uuid(), 'UUID_DO_USUARIO', 'incidente';"
```

## Resposta a incidente de dados

1. **Conter** — revogar memberships e tokens de pareamento; se necessário, derrubar a API
   (`docker compose stop api`).
2. **Preservar evidência** — exportar `audit_log` imediatamente; ele é append-only e serve de
   registro.
3. **Dimensionar** — identificar instituições e recursos afetados via `audit_log` filtrado por
   `created_at`.
4. **Comunicar** — a IES controladora decide sobre comunicação à ANPD e ao titular nos prazos da
   LGPD. A Vértice (operadora) apoia com o relatório técnico.
5. **Corrigir** e registrar o post-mortem.

Contato do encarregado de cada IES deve estar no contrato; mantenha a lista atualizada fora do
repositório.

## Manutenção do catálogo regulatório

Quando sair um instrumento novo:

1. Insira a nova linha em `instruments` (`status = 'draft'`).
2. Carregue as exigências em `instrument_requirements`.
3. Revise com o gestor de regulação da IES.
4. Mude para `status = 'active'` e marque a anterior como `superseded`.
5. Não altere exigências de instrumento já usado em avaliação encerrada — crie versão nova.

## Capacidade

O piloto com uma IES e ~5 mil matrículas/mês cabe confortavelmente no VPS de 2 vCPU / 4 GB. O ponto
de atenção é o lote de ingestão: mantenha `maxBatchRecords` em 1000 e envie em lotes, não um único
arquivo gigante.
