# Deploy no servidor — Supabase (banco + storage) + VPS pequena

Topologia escolhida: **Postgres e bucket no Supabase** (região `sa-east-1`,
São Paulo) e **API + painel + antivírus na VPS**. Roteiro do zero ao endereço com
HTTPS.

> Para o caminho sem servidor nenhum (rodar migração e API da sua máquina), veja
> `docs/SUPABASE-MIGRACAO.md`. Este documento é o de produção.

## Antes de começar: o que você precisa ter

| Item | Onde | Observação |
|---|---|---|
| Projeto Supabase | Plano **Pro** | No Free o projeto pausa após uma semana sem uso |
| Bucket privado | Supabase → Storage | `vertice-documentos`, público **desmarcado** |
| Chaves S3 | Supabase → Settings → Storage | Não são a `anon key` |
| VPS | 2 vCPU / 4 GB (mínimo) | Só API, painel, Caddy e ClamAV rodam aqui |
| Domínio | Registro.br ou outro | O DNS precisa apontar antes do proxy subir |

### Por que 4 GB bastam nesta topologia

Sem o Postgres local, a conta de memória cai de ~3,2 GB para ~2,3 GB:

| Serviço | RAM |
|---|---|
| ClamAV | 2 GB |
| Node/API | ~0,2 GB |
| Nginx + Caddy | ~0,06 GB |
| Ubuntu | ~0,4 GB |
| **Total** | **~2,7 GB** |

2 vCPU / 4 GB atende com folga. Mais do que isso só se o volume de upload crescer.

---

## 1. Criar o projeto no Supabase

1. https://supabase.com/dashboard → **New project**.
2. **Name:** `vertice-producao`
3. **Database Password:** gere uma longa e guarde. Não aparece de novo.
4. **Region:** `South America (São Paulo)` — `sa-east-1`.
5. **Plan:** Pro.

### 1.1 Criar o bucket

Storage → **New bucket**:

- **Name:** `vertice-documentos`
- **Public bucket:** **desmarcado** (obrigatório)
- **File size limit:** `25 MB`

### 1.2 Gerar as chaves S3

Settings → **Storage** → **S3 Connection** → **Generate new access key**.
Guarde o **Access key ID** e o **Secret access key** (aparece uma vez).

> Essas chaves dão acesso total ao Storage e ignoram RLS. Trate como senha de root.

### 1.3 Confirmar a extensão `pgcrypto`

A migração `0001_init.sql` roda `CREATE EXTENSION IF NOT EXISTS pgcrypto`. No
Supabase a extensão já está criada. Se a migração falhar nessa linha, habilite em
**Database → Extensions** e rode de novo.

---

## 2. Preparar o servidor

Ubuntu 24.04:

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y docker.io docker-compose-v2 git ufw
sudo usermod -aG docker "$USER"
```

Saia e entre na sessão de novo, então:

```bash
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

Não abra 5432 nem 8787. Nesta topologia a API só fala com o Supabase por saída;
nada precisa entrar além de 80/443.

```bash
sudo mkdir -p /opt/vertice && sudo chown "$USER":"$USER" /opt/vertice
```

---

## 3. Enviar o projeto

Do seu computador:

```bash
scp vertice-deploy.tar.gz usuario@IP_DO_SERVIDOR:/tmp/
```

No servidor:

```bash
cd /opt/vertice && tar xzf /tmp/vertice-deploy.tar.gz --strip-components=1 && ls
```

Deve listar `apps/`, `docs/`, `Caddyfile`, `docker-compose.supabase.yml`.

---

## 4. Configurar segredos

```bash
cp .env.supabase.example .env
chmod 600 .env
```

Gere três valores independentes:

```bash
openssl rand -base64 48
```

```bash
openssl rand -base64 48
```

```bash
openssl rand -base64 48
```

Use em `JWT_SECRET`, `PSEUDONYM_PEPPER` e `SEED_ADMIN_PASSWORD` (16+ caracteres).
Preencha também `DATABASE_URL` (com `?sslmode=require`), os quatro `S3_*` do
Supabase, `ALLOWED_ORIGINS`, `SEED_ADMIN_EMAIL` e `DOMAIN`.

> Guarde `PSEUDONYM_PEPPER` no cofre da empresa. Trocá-lo invalida a correlação
> de registros antigos com o identificador pseudonimizado do estudante.

Confira que nada obrigatório ficou vazio — o Compose recusa subir:

```bash
grep -E "^(DATABASE_URL|JWT_SECRET|PSEUDONYM_PEPPER|DOMAIN|S3_ENDPOINT|S3_BUCKET|S3_ACCESS_KEY_ID|S3_SECRET_ACCESS_KEY|ALLOWED_ORIGINS)=" .env
```

---

## 5. Apontar o domínio

No DNS do provedor, crie um registro `A` para `app.suaies.com.br` → IP do
servidor. Aguarde a propagação — o Caddy só emite o certificado quando o domínio
já resolve aqui.

```bash
dig +short app.suaies.com.br
```

Tem que devolver o IP do servidor antes de seguir.

---

## 5.1 Pré-voo: validar a conexão antes de subir

Antes de subir o painel, rode o pré-voo. Ele exercita os três caminhos que o
produto realmente usa — banco, bucket e antivírus — e diz o que impede o deploy.

Rode a partir do projeto local (com Node 22 e `.env` preenchido):

```bash
npm --workspace @vertice/api run preflight
```

Saída de um ambiente saudável:

```
OK    DATABASE_URL definida     postgresql://postgres.***@aws-0-sa-east-1...
OK    TLS configurado no banco  sslmode na URL
OK    Conexão com o Postgres    PostgreSQL 17.4
OK    TLS negociado na prática  TLSv1.3 / TLS_AES_256_GCM_SHA384
OK    Extensão pgcrypto         instalada
OK    Migrações                 banco virgem — rode o migrate
OK    Permissão de escrita      CREATE/INSERT em transação descartada
OK    Storage configurado       bucket vertice-documentos @ sa-east-1
OK    Endpoint S3 no formato do Supabase
OK    Leitura do bucket         autenticou e chegou ao bucket
OK    Antivírus (ClamAV)        clamav:3310 respondeu

PRONTO — banco, bucket e antivírus respondendo.
```

Ele **não** cria nem altera nada permanentemente: a escrita é testada numa tabela
temporária descartada com `ROLLBACK`.

### Como ler as falhas

| Saída | Significado | Correção |
|---|---|---|
| `TLS negociado: conexão SEM TLS` | O `sslmode` não chegou ao driver | acrescente `?sslmode=require` à `DATABASE_URL` |
| `Conexão com o Postgres` com erro de senha | Senha errada ou não substituiu `[SENHA]` | confira no painel do Supabase |
| `Leitura do bucket: 403` | Chave S3 inválida para este bucket | gere de novo em Settings → Storage → S3 |
| `Leitura do bucket: 400/404 de bucket` | O bucket não existe com esse nome | crie `vertice-documentos` |
| `Endpoint S3 no formato do Supabase` | URL no formato errado | use `https://<ref>.storage.supabase.co/storage/v1/s3` |
| `Extensão pgcrypto: AUSENTE` | Falta `gen_random_uuid` | habilite em Database → Extensions |
| `Antivírus: sem resposta` | ClamAV local não está no ar | esperado antes do primeiro `up`; suba o Compose |

O código de saída é `0` quando não há erro fatal. Erros que impedem o deploy
(banco inacessível, storage não configurado, antivírus desligado) retornam `1` —
serve para portão de CI.

## 6. Migrar e subir

Sempre com o arquivo da topologia Supabase:

```bash
docker compose -f docker-compose.supabase.yml up -d --build
```

O primeiro start baixa as assinaturas do ClamAV (~2 min) e o build compila a API.

Aplique as migrações e crie o primeiro administrador — uma vez só:

```bash
docker compose -f docker-compose.supabase.yml --profile setup up migrate
```

Confira:

```bash
docker compose -f docker-compose.supabase.yml ps
```

Esperado: `api` *healthy*, `clamav` *healthy* (pode levar 5 min na primeira vez),
`web` e `proxy` *running*, `migrate` *exited (0)*.

```bash
curl -s https://app.suaies.com.br/health
```

Deve responder `{"status":"ok","version":"1.0.0"}`.

---

## 7. Provar que o storage funciona

Este é o teste que costuma falhar. O upload vai direto ao bucket, sem passar pela
API, então uma chave errada só aparece aqui.

```bash
TOKEN=$(curl -s -X POST https://app.suaies.com.br/v1/auth/login \
  -H "content-type: application/json" \
  -d '{"email":"SEU_ADMIN","password":"SUA_SENHA"}' \
  | node -e "let d='';process.stdin.on('data',c=>d+=c).on('end',()=>console.log(JSON.parse(d).token))")
```

```bash
printf '%%PDF-1.4\n1 0 obj<</Type/Catalog>>endobj\ntrailer<</Root 1 0 R>>\n%%%%EOF\n' > /tmp/teste.pdf
SHA=$(openssl dgst -sha256 -binary /tmp/teste.pdf | base64)
SIZE=$(wc -c < /tmp/teste.pdf)
curl -s -X POST https://app.suaies.com.br/v1/documents \
  -H "authorization: Bearer $TOKEN" -H "content-type: application/json" \
  -d "{\"fileName\":\"teste.pdf\",\"mimeType\":\"application/pdf\",\"sizeBytes\":$SIZE,\"sha256Base64\":\"$SHA\"}"
```

Guarde `documentId` e `uploadUrl`, envie e confirme:

```bash
curl -X PUT "$UPLOAD_URL" -H "content-type: application/pdf" --data-binary @/tmp/teste.pdf
```

```bash
curl -s -X POST https://app.suaies.com.br/v1/documents/$DOC_ID/complete \
  -H "authorization: Bearer $TOKEN"
```

Resposta esperada: `{"scanStatus":"clean"}`.

- `403` no PUT → chave S3 ou endpoint errado.
- `failed` no complete → o ClamAV não respondeu. Veja `docker compose -f docker-compose.supabase.yml logs clamav`.

---

## 8. Primeiro acesso e troca de senha

1. Abra `https://app.suaies.com.br` e entre com `SEED_ADMIN_EMAIL`/`SEED_ADMIN_PASSWORD`.
2. **Troque a senha imediatamente.**

O seed cria a instituição `demo` e um `institution_admin`. Para operar a
plataforma (criar IES de verdade), crie um `platform_admin` pelo banco — não há
rota para isso de propósito. Veja `docs/SAAS.md`, passo 2.

---

## 9. Atualizar

```bash
cd /opt/vertice && git pull   # ou envie o tar.gz de novo
docker compose -f docker-compose.supabase.yml up -d --build
docker compose -f docker-compose.supabase.yml --profile setup up migrate
```

Não há rolling deploy: há uma janela curta de indisponibilidade.

---

## 10. Backup

Aqui a responsabilidade é dividida — e é fácil achar que está tudo coberto quando
não está.

| O quê | Quem protege | Como |
|---|---|---|
| Banco | **Supabase** | Backups diários automáticos no Pro |
| Banco, ponto exato no tempo | **Você** | PITR: add-on de US$ 100/mês, 7 dias |
| Bucket | **Você** | Supabase não versiona seu bucket por padrão |
| `.env` | **Você** | Cofre de senhas, fora do servidor |

O que mais importa aqui: **sem `PSEUDONYM_PEPPER` e sem os segredos do `.env`, o
banco restaurado não serve** — não dá para decifrar sessões nem correlacionar os
identificadores. Guarde o `.env` fora do servidor antes de precisar dele.

Dump lógico manual, para ter uma cópia sua:

```bash
docker compose -f docker-compose.supabase.yml run --rm \
  -e PGPASSWORD="$DB_PASS" api \
  sh -c 'pg_dump "$DATABASE_URL" | gzip' > /var/backups/vertice-$(date +%F).sql.gz
```

Para copiar o bucket:

```bash
aws s3 sync s3://vertice-documentos /var/backups/bucket --endpoint-url "$S3_ENDPOINT"
```

Teste a restauração trimestralmente num projeto Supabase descartável.

---

## Checklist de go-live

- [ ] Projeto Supabase em `sa-east-1`, plano **Pro**
- [ ] Bucket `vertice-documentos` privado, limite de 25 MB
- [ ] `JWT_SECRET` e `PSEUDONYM_PEPPER` únicos, 48 bytes, fora do Git
- [ ] `DATABASE_URL` com `?sslmode=require`
- [ ] `.env` com permissão 600, e uma cópia no cofre
- [ ] Senha de seed trocada no primeiro acesso
- [ ] HTTPS válido, HSTS ativo, HTTP redirecionando
- [ ] Portas 5432 e 8787 fechadas no firewall
- [ ] `ALLOWED_ORIGINS` sem `localhost`
- [ ] Upload de PDF de teste retorna `clean`
- [ ] `platform_admin` criado antes de provisionar a primeira IES
- [ ] Encarregado de privacidade cadastrado como `privacy_officer`

## Limitações desta topologia

- **A API depende do Supabase estar no ar.** Se o Supabase cair, o painel não lê
  nem grava. Não há réplica local.
- **Latência minima, mas real:** API na VPS → Supabase em São Paulo. Para uma
  resposta com várias consultas, some alguns milissegundos por ida e volta.
- **Sem failover.** Um único servidor de API. Se ele cair, o sistema inteiro sai.
- **ClamAV na VPS** continua sendo o serviço mais pesado (~2 GB) e o mais lento
  para reiniciar (~5 min até o healthcheck ficar verde).
