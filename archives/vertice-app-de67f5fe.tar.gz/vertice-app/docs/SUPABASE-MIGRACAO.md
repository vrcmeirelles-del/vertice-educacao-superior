# Migração para Supabase — roteiro completo

Guia para levar a Vértice do repositório local para o Supabase (PostgreSQL gerenciado +
Storage S3-compatível). Feito para ser executado **uma única vez** por quem vai operar o ambiente,
sem precisar de Docker.

> **Tempo estimado:** 45–60 minutos.
> **Pré-requisitos:** conta no Supabase, o repositório em mãos e Node.js 22+ instalado.
>
> **Plano:** para produção use **Pro**. No **Free** o projeto pausa após uma semana
> sem atividade — um cliente que abre o painel a cada quinzena encontraria o
> sistema fora do ar. O Free serve para testar a integração, não para operar.
>
> Para subir isso em servidor (API + painel + antivírus), o roteiro de produção é
> `docs/DEPLOY-SUPABASE.md`. Este documento aqui é o caminho local, sem Docker.

---

## Parte 1 — Criar o projeto no Supabase

1. Acesse https://supabase.com/dashboard e clique em **New project**.
2. Preencha:
   - **Name:** `vertice-producao` (ou `vertice-piloto`)
   - **Database Password:** gere uma senha longa e **guarde no gerenciador de senhas**.
     Ela não aparece de novo.
   - **Region:** `South America (São Paulo)` — `sa-east-1`.
   - **Plan:** Free (para piloto) ou Pro (recomendado para produção).
3. Aguarde a criação (~2 minutos).

## Parte 2 — Obter as credenciais do banco

1. No painel do projeto, vá em **Settings → Database**.
2. Localize a seção **Connection string** e copie a URI do modo **Connection pooling**
   (porta `6543`), não a conexão direta (porta `5432`).
3. Substitua `[YOUR-PASSWORD]` pela senha que você criou.
4. O resultado será algo assim:

```
postgresql://postgres.abcdefghijklmnop:[SENHA]@aws-0-sa-east-1.pooler.supabase.com:6543/postgres
```

> **Por que o pooler?** O modo direto limita a 60 conexões e derruba conexões ociosas. O pooler
> (pgBouncer) aguenta o padrão da API. Se você usar o modo direto, ajuste `PG_POOL_MAX=2` no `.env`.

## Parte 3 — Criar o bucket de documentos

O bucket é onde os arquivos ficam. Precisa ser **privado**.

1. Vá em **Storage → New bucket**.
2. Preencha:
   - **Name:** `vertice-documentos`
   - **Public bucket:** **desmarcado** (obrigatório)
   - **File size limit:** `25 MB` (igual ao `MAX_UPLOAD_BYTES`)
3. Clique em **Create bucket**.

## Parte 4 — Gerar as chaves S3

O Supabase expõe o Storage via protocolo S3, mas com chaves próprias — não é a `anon key`.

1. Vá em **Project Settings → Storage**.
2. Role até **S3 Connection**.
3. Clique em **Generate new access key** (ou **New access key**).
4. Copie e guarde:
   - **Access key ID**
   - **Secret access key** (aparece **uma única vez**)

> Essas chaves dão acesso total ao Storage. Trate como senha de root.

## Parte 5 — Configurar o `.env`

Na raiz do projeto (`vertice-app/`), copie o exemplo e preencha:

```bash
cp .env.example .env
```

Edite o `.env` com os valores abaixo:

```dotenv
# --- Banco (Parte 2) ---
# O `?sslmode=require` NÃO é opcional: o driver `pg` não liga TLS sozinho e,
# sem ele, a conexão com o pooler do Supabase sai em claro pela internet.
# Alternativa equivalente: omitir da URL e definir PG_SSL=require no ambiente.
DATABASE_URL=postgresql://postgres.SEUREF:[SENHA]@aws-0-sa-east-1.pooler.supabase.com:6543/postgres?sslmode=require

# --- Segredos da aplicação ---
# Gere com: openssl rand -base64 48
JWT_SECRET=<48 bytes aleatórios em base64>
PSEUDONYM_PEPPER=<outros 48 bytes aleatórios>

SESSION_TTL_SECONDS=28800
ALLOWED_ORIGINS=https://app.suaies.com.br

# --- Storage (Partes 3 e 4) ---
S3_ENDPOINT=https://SEUREF.storage.supabase.co/storage/v1/s3
S3_REGION=sa-east-1
S3_BUCKET=vertice-documentos
S3_ACCESS_KEY_ID=<access key da Parte 4>
S3_SECRET_ACCESS_KEY=<secret key da Parte 4>
S3_FORCE_PATH_STYLE=false
S3_UPLOAD_TTL_SECONDS=600
S3_DOWNLOAD_TTL_SECONDS=300
MAX_UPLOAD_BYTES=26214400

# --- Antivírus ---
# Sem ClamAV no Supabase. Veja a nota abaixo.
ANTIVIRUS_MODE=required
CLAMAV_HOST=127.0.0.1
CLAMAV_PORT=3310

# --- Primeiro administrador ---
SEED_ADMIN_EMAIL=admin@suaies.com.br
SEED_ADMIN_PASSWORD=<senha forte com 16+ caracteres>

# --- Rede ---
PORT=8787
WEB_PORT=8080
```

> **Sobre `S3_REGION`:** o Supabase exige que a região seja `sa-east-1` (ou a região do seu projeto)
> mesmo com endpoint customizado. O SDK da AWS valida isso.

## Parte 6 — Rodar as migrações

Com o `.env` preenchido, na raiz do projeto:

```bash
npm --workspace @vertice/api run migrate
```

Saída esperada:

```
[migrate] aplicando 0001_init.sql
[migrate] aplicando 0002_documents.sql
[migrate] concluído
```

Se aparecer erro de `pgcrypto`, rode no **SQL Editor** do Supabase:

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;
```

Depois repita a migração.

## Parte 7 — Criar o primeiro administrador

```bash
npm --workspace @vertice/api run seed
```

Isso cria:
- instituição de demonstração
- usuário administrador com o e-mail e senha do `.env`
- catálogo de exemplo

> **Importante:** rode o seed **uma vez**. Rodar duas vezes não duplica (é idempotente), mas use
> `SEED_ADMIN_PASSWORD` forte e troque a senha no primeiro login em produção.

## Parte 8 — Subir a API

```bash
npm --workspace @vertice/api run build
npm --workspace @vertice/api run start
```

Verifique:

```bash
curl https://seu-dominio/health
# {"status":"ok","version":"1.0.0"}
```

## Parte 9 — Testar o upload de documentos

O teste real, para confirmar que bucket e chaves funcionam:

**1. Faça login e guarde o token:**

```bash
TOKEN=$(curl -s -X POST https://seu-dominio/v1/auth/login \
  -H "content-type: application/json" \
  -d '{"email":"admin@suaies.com.br","password":"SUA_SENHA"}' \
  | node -e "let d='';process.stdin.on('data',c=>d+=c).on('end',()=>console.log(JSON.parse(d).token))")
```

**2. Crie um PDF de teste e calcule o hash:**

```bash
printf '%%PDF-1.4\n1 0 obj<</Type/Catalog>>endobj\ntrailer<</Root 1 0 R>>\n%%%%EOF\n' > teste.pdf
SHA=$(openssl dgst -sha256 -binary teste.pdf | base64)
SIZE=$(wc -c < teste.pdf)
```

**3. Peça a URL de upload:**

```bash
curl -s -X POST https://seu-dominio/v1/documents \
  -H "authorization: Bearer $TOKEN" \
  -H "content-type: application/json" \
  -d "{\"fileName\":\"teste.pdf\",\"mimeType\":\"application/pdf\",\"sizeBytes\":$SIZE,\"sha256Base64\":\"$SHA\"}"
```

Guarde o `documentId` e o `uploadUrl` da resposta.

**4. Envie o arquivo direto ao bucket:**

```bash
curl -X PUT "$UPLOAD_URL" \
  -H "content-type: application/pdf" \
  --data-binary @teste.pdf
```

Deve retornar `200`. Se retornar `403`, o problema é a chave S3 ou o endpoint.

**5. Confirme o upload e dispare o scan:**

```bash
curl -s -X POST https://seu-dominio/v1/documents/$DOC_ID/complete \
  -H "authorization: Bearer $TOKEN"
```

Resposta esperada: `{"scanStatus":"clean"}` ou `{"scanStatus":"failed"}` se o ClamAV não estiver acessível.

**6. Baixe de volta:**

```bash
curl -s https://seu-dominio/v1/documents/$DOC_ID/download \
  -H "authorization: Bearer $TOKEN"
```

Use a `url` retornada para baixar o arquivo.

---

## Antivírus — a decisão que você precisa tomar

O Supabase **não** oferece scanner de vírus. Hoje o código exige um ClamAV acessível em
`CLAMAV_HOST:CLAMAV_PORT`. Você tem três caminhos:

### Opção A — Rodar o ClamAV num VPS separado (recomendado)

Um VPS pequeno (~US$ 5/mês) com o ClamAV em Docker, exposto apenas por VPN privada ou IP
restringido. A API aponta `CLAMAV_HOST` para esse IP.

```bash
# no VPS do ClamAV
docker run -d --name clamav -p 3310:3310 clamav/clamav:stable
```

Não exponha a porta 3310 na internet aberta — restrinja por firewall ao IP da API.

### Opção B — Usar API de antivírus gerenciada

Trocar `scanViaClam` em `services/antivirus.ts` por uma chamada à API do VirusTotal ou similar.
O contrato de retorno (`clean` / `infected` / `failed`) continua igual.

### Opção C — Aceitar `failed` como "não aprovado"

Com `ANTIVIRUS_MODE=disabled`, **nenhum** documento é aprovado — tudo fica `failed` e não pode ser
vinculado a evidência. Só use se a IES concordar em operar sem scan (não recomendado).

---

## Checklist final

- [ ] Projeto Supabase criado na região `sa-east-1`
- [ ] Senha do banco guardada no gerenciador
- [ ] Bucket `vertice-documentos` criado e **privado**
- [ ] Chaves S3 geradas e guardadas
- [ ] `.env` preenchido com banco + storage + segredos
- [ ] `npm run migrate` executado sem erro
- [ ] `npm run seed` executado e admin criado
- [ ] `/health` responde `ok`
- [ ] Login funciona
- [ ] Upload de PDF de teste retorna `200`
- [ ] `/complete` retorna `clean`
- [ ] Download funciona
- [ ] ClamAV acessível (ou decisão registrada de não usar)
- [ ] Senha inicial do admin trocada

## O que **não** é migrado

- Documentos antigos (não há): o bucket começa vazio.
- Dados de demonstração: o seed cria o mínimo; dados reais entram pela ingestão.
- Backups do Supabase: **ative o Point-in-Time Recovery** no plano Pro se for produção.
