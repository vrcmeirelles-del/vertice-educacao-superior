# Segurança, privacidade e LGPD

Este documento diz **o que está implementado** e **o que ainda não está**. A segunda lista é a mais
importante para não prometer o que não existe.

## Base legal e princípio de minimização

O produto é desenhado para tratar **dado pessoal mínimo** e preferencialmente pseudonimizado.

| Dado | Tratamento |
|---|---|
| Nome, CPF, RG, e-mail, telefone, endereço | **Não são coletados nem armazenados** |
| Identificador do estudante | HMAC-SHA256 com pepper de servidor; o valor original nunca é gravado |
| Frequência, faltas, média, requerimento | Armazenados como métricas operacionais |
| Texto de requerimento / justificativa | **Não é coletado** — apenas o tipo, de lista fechada |
| Nota de atendimento do coordenador | Texto curto, opcional, com aviso para não inserir dado sensível |

O estudante **não é titular de conta** na plataforma neste escopo. Se o produto passar a fazer
contato direto com o estudante, é necessária nova avaliação de base legal e transparência.

## Controles implementados

### Autenticação e sessão
- Senha com **scrypt** (N=2^15, r=8, p=1), salt por usuário, comparação em tempo constante.
- Sessão em **JWT HS256** com `iss`, `aud`, `exp` e `jti`.
- **Revogação imediata** via tabela `revoked_sessions` verificada a cada requisição.
- Login com **rate limit** de 10/min por IP.
- Hash de senha *dummy* é verificado mesmo quando o e-mail não existe (não vaza existência de conta).
- Auditor temporário tem **expiração obrigatória** validada no banco a cada chamada.

### Autorização e isolamento
- Seis papéis com menor privilégio.
- `institutionId` vem **do token**, nunca do corpo/query.
- Coordenador com escopo de curso filtra no SQL.
- Auditor é somente leitura em todas as rotas de escrita.
- Toda rota de escrita registra evento em `audit_log`.

### Proteção de dados
- `audit_log` protegido por trigger que impede `UPDATE` e `DELETE`.
- Auditoria guarda metadados operacionais — **nunca** notas, nomes ou texto de requerimento.
- Consultas parametrizadas em todas as chamadas (sem concatenação de SQL).
- Helmet, CORS por lista explícita de origens, limite de corpo de 2 MB, rate limit global.
- `req.headers.authorization` é removido dos logs.

### Extensão
- Verificação de origem pelo manifesto (`activeTab` + `scripting`, `host_permissions` vazio).
- Leitura apenas após clique, apenas da aba ativa.
- Falha fechada em layout desconhecido.
- Token de pareamento com TTL curto, guardado apenas como hash SHA-256.

### Matrícula agregada
- `enrollments` não tem identificador de estudante — nem coluna, nem chave derivável. É contagem
  de vínculos por curso e semestre (9 status do e-ORBIT + turmas).
- O contrato (`enrollmentRecordSchema`, `.strict()`) recusa qualquer campo do contrato de retenção:
  `studentRef`, frequência, faltas, médias, requerimentos. Quem colar a planilha de aluno na tela
  de matrícula recebe 400 com o nome do campo, não um sucesso com dado descartado.
- A rota valida só o **envelope** do lote; cada registro é conferido no serviço. Uma célula mal
  formatada nas 840 linhas não derruba a importação inteira.
- Divergência da origem (soma por turma ≠ subtotal, total ≠ soma dos status) é publicada como
  está e marcada para revisão. O sistema não "conserta" número acadêmico.
- Coordenador com `courseScope` restrito filtra no SQL, não em memória.

### Retenção
- `institutions.retention_alerts_days`, `retention_records_days`, `retention_audit_days`.
- Rota `POST /v1/privacy/purge` com confirmação explícita apaga dados operacionais fora da janela
  e nunca apaga auditoria (obrigação de registro).

## Lacunas conhecidas — o que falta antes de produção

Estas são reais e precisam de decisão do desenvolvedor responsável:

1. **Criptografia em repouso** depende do provedor (disco do VPS ou banco gerenciado). Não há
   criptografia por coluna. Para dado acadêmico, `pgcrypto` por coluna pode ser necessário.
2. **MFA** não está implementado. A coluna `users.mfa_secret` existe, mas não há fluxo. MFA deve ser
   obrigatório para `institution_admin` e `platform_admin` antes de produção.
3. **Varredura antimalware de uploads** não existe. O endpoint de documentos está registrado no
   schema, mas o upload de arquivos (S3/MinIO + presigned URL + antivírus) não foi implementado
   nesta entrega.
4. **Encarregado de privacidade** é um papel, não um fluxo completo de DSR: a rota registra a
   solicitação, mas a resposta ao titular ainda é manual.
5. **Sem criptografia de backup.** O `pg_dump` sai em claro; o arquivo precisa ir para um bucket
   cifrado.
6. **Sem WAF.** Ataques de camada 7 dependem do proxy/borda (Cloudflare) ou de regras de nginx.
7. **Sem log centralizado** nem alerta de anomalia. Logs ficam no container.
8. **Sem testes de integração com banco real** nesta entrega — o CI só cobre unidade.
9. **Sem revisão jurídica** do contrato de tratamento de dados e do aviso de privacidade. O produto
   precisa deles assinados com a IES antes de operar.

## Checklist para o desenvolvedor antes do piloto com dado real

- [ ] MFA obrigatório para administradores
- [ ] Antivírus/validação nos uploads (se documentos forem habilitados)
- [ ] Backup cifrado e restauração testada
- [ ] Contrato de operador (LGPD art. 39) e aviso de privacidade aprovados
- [ ] Encarregado da IES identificado e registrado
- [ ] Política de retenção definida com a IES (não usar o default)
- [ ] Teste de carga com o volume real de matrículas
- [ ] Revisão de permissões com um usuário real de cada papel
- [ ] Plano de resposta a incidente divulgado (ver `OPERACAO.md`)

## Aviso de produto

A plataforma **não**:
- decide aprovação, reprovação, bolsa ou sanção;
- bloqueia matrícula, rematrícula, diploma ou acesso ao portal;
- substitui o e-MEC, o ERP, a Secretaria ou a CPA;
- garante conceito em avaliação do MEC.

Os níveis `baixo/médio/alto/crítico` são **faixas de priorização de acompanhamento humano** e devem
aparecer com esse rótulo em toda tela e em todo relatório exportado.
