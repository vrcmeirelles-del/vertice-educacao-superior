# Deploy — do servidor vazio ao endereço com HTTPS

Passo a passo para um VPS Linux (Ubuntu 24.04 LTS).

> **Memória.** 2 vCPU / 4 GB é o piso, não a folga. O ClamAV sozinho tem limite
> de 2 GB no Compose e a soma de todos os serviços chega a ~3,2 GB com o SO.
> Num servidor de 4 GB a máquina trabalha com menos de 1 GB livre — o build da
> imagem pode estourar. Para o piloto, **4 vCPU / 8 GB** é o tamanho confortável.
> Em 4 GB, adicione swap antes de buildar:
>
> ```bash
> sudo fallocate -l 4G /swapfile && sudo chmod 600 /swapfile
> sudo mkswap /swapfile && sudo swapon /swapfile
> echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
> ```

## 1. Preparar o servidor

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y docker.io docker-compose-v2 git ufw
sudo usermod -aG docker "$USER"   # saia e entre novamente na sessão
```

Firewall:

```bash
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

Não abra a porta 5432 nem a 8787. Elas só existem dentro da rede do Compose.

## 2. Obter o código

```bash
sudo mkdir -p /opt/vertice && sudo chown "$USER":"$USER" /opt/vertice
git clone URL_DO_REPOSITORIO /opt/vertice
cd /opt/vertice
```

## 3. Configurar segredos

```bash
cp .env.example .env
chmod 600 .env
```

Gere três valores independentes:

```bash
openssl rand -base64 48
```

```bash
openssl rand -base64 48
```

```bash
openssl rand -base64 48
```

Use-os em `POSTGRES_PASSWORD`, `JWT_SECRET` e `PSEUDONYM_PEPPER`. Preencha também
`SEED_ADMIN_EMAIL` e `SEED_ADMIN_PASSWORD` (16+ caracteres) e ajuste `ALLOWED_ORIGINS` para o
domínio real.

> Guarde o `PSEUDONYM_PEPPER` no cofre de senhas da empresa. Trocá-lo invalida a correlação de
> registros antigos com o identificador pseudonimizado do estudante.

## 4. Apontar o domínio

No DNS do provedor, crie um registro `A` para `app.suaies.com.br` → IP do servidor. Aguarde a
propagação antes de subir o proxy (o Caddy precisa do domínio resolvendo para emitir o certificado).

## 5. Configurar domínio no proxy

Edite `Caddyfile` trocando `app.vertice.com.br` pelo domínio real.

## 6. Subir

```bash
docker compose up -d --build
docker compose --profile setup up migrate
docker compose ps
```

Esperado: `db` e `api` com status *healthy*, `web` e `proxy` *running*.

Verificações:

```bash
curl -s https://app.suaies.com.br/health
```

```bash
docker compose logs -f api
```

## 7. Primeiro acesso

1. Abra `https://app.suaies.com.br`.
2. Entre com `SEED_ADMIN_EMAIL` e `SEED_ADMIN_PASSWORD`.
3. **Troque a senha imediatamente** (crie um segundo administrador e revogue o de seed).
4. Cadastre os cursos reais (ou importe via `POST /v1/courses`).
5. Revise as regras de risco em **Regras** e publique a versão da instituição.
6. Cadastre coordenadores com escopo de curso.

## 8. Atualizar a aplicação

```bash
cd /opt/vertice
git pull
docker compose up -d --build
docker compose --profile setup up migrate
```

Sem downtime real ainda (não há rolling deploy). Para janelas de manutenção, faça backup antes.

## 9. Backup

Banco:

```bash
docker compose exec -T db pg_dump -U vertice -d vertice | gzip > /var/backups/vertice-$(date +%F).sql.gz
```

Agende no cron do host (`crontab -e`):

```text
15 2 * * * cd /opt/vertice && docker compose exec -T db pg_dump -U vertice -d vertice | gzip > /var/backups/vertice-$(date +\%F).sql.gz
```

Retenção de 30 dias e cópia fora do servidor (S3/Backblaze) são obrigatórias para dado de produção.
**Testar a restauração** trimestralmente:

```bash
gunzip -c /var/backups/vertice-2026-10-01.sql.gz | docker compose exec -T db psql -U vertice -d vertice_test
```

## 10. Checklist de go-live

- [ ] `JWT_SECRET` e `PSEUDONYM_PEPPER` únicos, com 48 bytes, fora do Git
- [ ] `.env` com permissão 600 e dono correto
- [ ] Senha de seed trocada e usuário de seed revogado
- [ ] HTTPS válido, HSTS ativo, HTTP redirecionando
- [ ] Portas 5432 e 8787 fechadas no firewall
- [ ] Backup automático rodando e restauração testada
- [ ] `ALLOWED_ORIGINS` sem `localhost`
- [ ] Logs sem `authorization` (o redact do Fastify já cobre)
- [ ] Política de retenção configurada por instituição
- [ ] Encarregado de privacidade cadastrado como `privacy_officer`

## Alternativa gerenciada (Render/Railway/Fly.io)

O Compose é portável, mas banco gerenciado + API em container exige ajustes:

| Serviço | Configuração |
|---|---|
| PostgreSQL gerenciado | use `DATABASE_URL` com `?sslmode=require` |
| API | imagem do `apps/api`, healthcheck `/health`, variáveis do `.env.example` |
| Web | build estático (`apps/web/dist`) servido por CDN; proxy `/v1` para a API |
| Migrações | job único antes do deploy, com `node dist/db/seed.js` ou só migrate |

Em plataformas que não permitem `pgcrypto`, a extensão já é criada com `IF NOT EXISTS` — precisa
estar habilitada no plano gerenciado.
