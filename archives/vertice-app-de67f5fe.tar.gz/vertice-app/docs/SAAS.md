# SaaS — plano, cota e ciclo de vida

## O que mudou

Antes, criar uma instituição exigia editar o `seed.ts` e rodar `npm run seed`. O
primeiro usuário de cada IES era criado por um administrador que **digitava a
senha** — ou seja, a Vértice conhecia a senha do cliente.

Agora existe um plano de controle:

| Antes | Agora |
|---|---|
| Instituição só pelo seed | `POST /v1/platform/institutions` |
| Admin digita a senha do novo usuário | Convite; a pessoa define a própria senha |
| Limite de lote fixo no `config.ts` | Cota por plano |
| Status da conta não existia | `trial`/`active`/`past_due`/`suspended`/`churned` |
| Nenhuma barreira de cobrança | Escrita bloqueada em trial vencido e suspensão |

## Modelo de dados

`0003_saas.sql` cria:

- **`plan_limits`** — catálogo de planos com cotas. `NULL` = sem limite; preço
  fica fora do banco de propósito (é decisão contratual).
- **`institutions.status` / `plan_code` / `trial_ends_at`** — ciclo de vida.
- **`subscriptions`** — assinatura com índice único parcial: uma aberta por IES.
- **`billing_events`** — idempotência do webhook (`UNIQUE (provider, event_id)`).
- **`user_invites`** — convite com hash do token. `CHECK` recusa `platform_admin`.

## Regras que não são óbvias

1. **Plano é cota e estado, nunca permissão.** Quem pode o quê continua sendo
   `membership.role`.
2. **`past_due` escreve.** Inadimplência não pode derrubar a operação de um
   cliente no meio de uma renovação de reconhecimento. Só `suspended` bloqueia.
3. **Suspensão bloqueia escrita, não leitura.** Cortar acesso ao dado pessoal
   por cobrança cria problema de LGPD e impede a IES de responder ao MEC.
4. **Trial vencido é calculado, não gravado.** `effectiveStatus()` compara
   `trial_ends_at` com `now()` — não depende de cron ter rodado.
5. **`platform_admin` não passa por cota nem por suspensão.** Ele opera a conta
   do cliente; suspender não pode impedir a Vértice de corrigi-la.
6. **Assento = pessoa ativa ou convite pendente.** Contar só memberships
   deixaria convidar ilimitado.
7. **Nunca há envio ao provedor de pagamento dentro de uma requisição.** O
   estado vem do banco, atualizado por webhook. Provedor fora do ar não para a
   plataforma.

## Passos de aplicação

### 1. Aplicar a migração

```bash
npm run migrate
```

Só roda `0003_saas.sql`, que ainda não está em `schema_migrations`. É
transacional: se falhar, nada muda.

O que ela faz com dados existentes:

- instituições já cadastradas passam a `active` (são clientes em operação);
- todas recebem `plan_code = 'piloto'` por padrão.

Confira antes de rodar em produção:

```bash
psql "$DATABASE_URL" -c "select slug, name from institutions order by created_at"
```

Se alguma dessas instituições já tem contrato com cota maior, ajuste o plano
**depois** da migração (passo 3), não antes — a migração sobrescreveria.

### 2. Criar o primeiro operador da Vértice

Não existe rota para isso: criar o primeiro `platform_admin` por API seria uma
porta aberta. Faça pelo banco, com um único comando:

```bash
psql "$DATABASE_URL" -c "
  INSERT INTO users (email, name, password_hash)
  VALUES ('ops@vertice.com.br', 'Operador Vértice', '<hash>');

  INSERT INTO memberships (user_id, institution_id, role)
  SELECT id, NULL, 'platform_admin' FROM users WHERE email = 'ops@vertice.com.br';
"
```

O `<hash>` sai de `hashPassword()` em `apps/api/src/auth/password.ts`. Gere com:

```bash
npm --workspace @vertice/api exec tsx -e "
  import('./src/auth/password.ts').then(async m => console.log(await m.hashPassword(process.argv[1])))
" 'sua-senha-aqui'
```

`membership` de `platform_admin` tem `institution_id NULL` — é isso que impede
esse usuário de acessar qualquer dado de cliente.

### 3. Ajustar planos das instituições existentes

Com o operador criado, faça login e use o console (menu **Instituições**), ou:

```bash
curl -X PATCH https://sua-api/v1/platform/institutions/<id>/plan \
  -H "authorization: Bearer $OPS_TOKEN" \
  -H "content-type: application/json" \
  -d '{"planCode":"institucional","reason":"contrato 2026"}'
```

### 4. Configurar o webhook do provedor

Defina as variáveis e reinicie a API:

```bash
BILLING_PROVIDER=pagarme           # ou 'asaas'
BILLING_WEBHOOK_SECRET=<segredo>   # o mesmo cadastrado no painel do provedor
```

Aponte o provedor para `https://sua-api/v1/billing/webhook`.

| Provedor | Autenticação esperada |
|---|---|
| `pagarme` | HMAC-SHA256 do corpo bruto em `x-signature` (hex) |
| `asaas` | Segredo compartilhado em `asaas-access-token` |
| `manual` | Sem verificação — só desenvolvimento |

Sem `BILLING_WEBHOOK_SECRET` a rota responde **503** em vez de aceitar
qualquer coisa. Falha fechada de propósito: um webhook aberto deixa qualquer
um marcar a conta de um cliente como paga.

#### Eventos tratados

| Evento Asaas | Efeito |
|---|---|
| `PAYMENT_CONFIRMED`, `PAYMENT_RECEIVED` | assinatura `active`, instituição `active` |
| `PAYMENT_OVERDUE` | assinatura `past_due`, instituição `past_due` |
| `SUBSCRIPTION_DELETED` | assinatura `canceled`, instituição `churned` |
| qualquer outro | gravado e ignorado |

`past_due` **continua escrevendo** — só `suspended`, decisão humana, bloqueia.
Um provedor atrasado não pode parar a operação de um cliente em dia com o MEC.

#### Como a idempotência funciona

Quatro camadas, na ordem em que agem:

1. **`UNIQUE (provider, event_id)`** com `INSERT ... ON CONFLICT DO NOTHING`.
   Se não inseriu, já foi processado: responde 200 com `duplicate: true`.
   Funciona entre processos — oito entregas simultâneas do mesmo evento
   gravam uma linha só.
2. **`SELECT ... FOR UPDATE`** na assinatura. Serializa eventos *distintos* da
   mesma assinatura que chegam juntos.
3. **`occurred_at` × `last_event_at`.** Evento mais antigo que o já aplicado é
   gravado com `skipped_reason` e **não** regride a conta. Isso é o que separa
   "evento repetido" de "evento fora de ordem" — o segundo é o erro caro, e a
   chave única não o pega.
4. **Assinatura inválida não grava nada** e responde 401.

Sempre **200** para evento autenticado, mesmo ignorado: provedor reentrega
qualquer resposta fora da faixa 2xx, e um evento que não nos diz respeito
viraria fila de reentrega infinita. 400 só para corpo malformado, 401 só para
assinatura inválida.

#### Diagnóstico

```bash
psql "$DATABASE_URL" -c "
  select created_at, event_type, skipped_reason, processed_at
    from billing_events order by created_at desc limit 20"
```

`skipped_reason` responde "por que a conta não mudou?". Se um evento aparece
sem `processed_at`, a transação não completou — investigue o log da API.

Reenviar um evento manualmente (o provedor perdeu a entrega):

```bash
curl -X POST https://sua-api/v1/billing/webhook \
  -H "content-type: application/json" \
  -H "x-signature: <hmac-do-corpo>" \
  -d @evento.json
```

Se o evento já foi processado, a resposta é 200 com `duplicate: true`.

### 5. Verificar

```bash
npm run check   # typecheck api + web
npm test        # inclui os testes de ciclo de vida e cota
```

Depois, na UI: entre como operador, crie uma instituição de teste, copie o link
de convite, aceite em uma janela anônima, e confirme que:

- a nova IES entra em `trial` com o plano escolhido;
- o menu do operador mostra apenas **Instituições**;
- suspender a instituição faz a próxima escrita retornar 402 `subscription_blocked`
  enquanto leitura e auditoria continuam respondendo 200.

## Rotas

### Plataforma (`platform_admin`)

| Método | Rota | Efeito |
|---|---|---|
| GET | `/v1/platform/institutions` | lista com contagem de uso |
| GET | `/v1/platform/institutions/:id` | detalhe + uso + limites |
| POST | `/v1/platform/institutions` | provisiona IES + convite do admin |
| PATCH | `/v1/platform/institutions/:id/status` | muda ciclo de vida |
| PATCH | `/v1/platform/institutions/:id/plan` | muda plano |
| GET | `/v1/platform/plans` | catálogo |
| GET | `/v1/platform/overview` | contagem agregada |

### Instituição

| Método | Rota | Papel |
|---|---|---|
| GET | `/v1/institution/plan` | qualquer papel |
| POST | `/v1/users/invites` | administrador |
| GET | `/v1/users/invites` | administrador |
| DELETE | `/v1/users/invites/:id` | administrador |

### Cobrança

| Método | Rota | Autenticação |
|---|---|---|
| POST | `/v1/billing/webhook` | assinatura do provedor (ver passo 4) |
| GET | `/v1/auth/invite?token=` | público |
| POST | `/v1/auth/invite/accept` | público |

## Onde a cota é aplicada

| Cota | Rota | Observação |
|---|---|---|
| `maxUsers` | `POST /v1/users/invites` | conta acesso ativo + convite pendente |
| `maxStorageMb` | `POST /v1/documents` | total atual + arquivo entrando |
| `maxBatchRecords` | `POST /v1/ingestions` | tamanho do lote |
| `maxBatchesDay` | `POST /v1/ingestions` | lotes do dia |
| `maxAlertsMonth` | — | ainda não aplicada: alerta nasce de ingestão já limitada |
| `maxCourses` | — | ainda não aplicada: curso é criado só pelo seed |

## Pendências conhecidas

- **`maxCourses` e `maxAlertsMonth`** estão no catálogo mas não barram nada —
  as rotas que criariam esses recursos são de seed ou derivadas da ingestão.
- **E-mail de convite** não é enviado: o link é devolvido para quem convidou.
  Quando houver provedor, o envio entra em `createInvite`.
- **`billing_events.error`** existe na tabela mas nunca é preenchido: um erro
  dentro da transação faz rollback, então o evento nem chega a ser gravado. Se
  isso virar problema (querer rastrear falha de processamento), o caminho é
  gravar o evento fora da transação e processá-lo depois — decisão adiada de
  propósito, porque hoje um evento perdido é reentregue pelo provedor.
- **`listBillingEvents`** existe no serviço e ainda não tem tela.
- **Não há exclusão de instituição.** Encerrar é `churned`, que preserva a
  auditoria — apagar o registro apagaria a prova do que a plataforma fez.
