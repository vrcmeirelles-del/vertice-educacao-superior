# Matrícula agregada por curso

A rota de **retenção** (`POST /v1/ingestions`) trabalha por aluno. Esta trabalha por **curso e
semestre**: quantas matrículas, abertas nos nove status do e-ORBIT, e quantas turmas têm aluno.

## Por que existe

O painel da coordenação abre com "quantos alunos o Direito tem neste semestre, e isso subiu ou
desceu?". Essa pergunta não se responde varrendo `retention_records` — ali o dado só existe quando
a extensão já leu tela de aluno, e o número agregado some no meio da pseudonimização. A planilha
`CLIENTES/UNITOP/planilhas/Vertice_Extracao_eORBIT_2022-2026.xlsx` define o formato; esta rota é o
contrato que o recebe.

## O que **não** entra

| Campo | Por quê |
|---|---|
| `studentRef` | Matrícula agregada não tem aluno. O contrato recusa com 400. |
| frequência, faltas, médias | São do contrato de retenção. `POST /v1/ingestions`. |
| `openRequests` | Requerimento é por aluno; não existe no agregado. |
| nome, CPF, RG, e-mail | `detectForbiddenFields` recusa o lote inteiro. |

Se alguém colar a planilha de aluno na tela de matrícula, a resposta é 400 nomeando o campo —
não um sucesso com 90% do dado descartado.

## Endpoints

| Método | Rota | Papéis | O que faz |
|---|---|---|---|
| `POST` | `/v1/enrollments` | admin, regulatory, coordinator | Importa lote do painel |
| `POST` | `/v1/enrollments/extension` | token de pareamento | Importa lote da extensão |
| `GET` | `/v1/enrollments/panel?semester=2026/02` | leitura | Painel por curso + variação |
| `GET` | `/v1/enrollments/history?courseRef=027` | leitura | Série histórica do curso |
| `GET` | `/v1/enrollments/batches` | leitura | Lotes importados |

`semester` é `AAAA/01` ou `AAAA/02`. Omitido, o painel usa o mais recente que a instituição tem.

### Corpo de `POST /v1/enrollments`

```json
{
  "records": [
    {
      "courseRef": "027",
      "semester": "2026/02",
      "vagas": 650,
      "matriculado": 245,
      "preMatriculado": 8,
      "trancado": 11,
      "abandono": 0,
      "concluido": 0,
      "cancelado": 4,
      "transferido": 2,
      "trocaCurso": 0,
      "graduado": 0,
      "totalRegistros": 270,
      "turmasSomadas": 243,
      "turmas": [
        { "serie": 1, "turma": "DIR-1A", "matriculados": 38 },
        { "serie": 2, "turma": "DIR-2A", "matriculados": 36 }
      ],
      "observedAt": "2026-10-29T12:00:00-03:00",
      "source": "eorbit-v1"
    }
  ]
}
```

Até 2.000 registros por lote. A rota valida o **envelope**; cada registro é conferido no serviço,
então uma célula mal formatada não derruba a importação — ela volta em `rejections` com o número
da linha e o campo.

### Resposta

```json
{
  "batchId": "…",
  "total": 840,
  "accepted": 840,
  "rejected": 0,
  "upserted": 840,
  "unknownCourses": [],
  "rejections": []
}
```

## Regras que o código garante

1. **Reimportar substitui.** Um agregado é o retrato do semestre, não um fato que se acumula.
   `UNIQUE (institution_id, course_id, semester)` + `ON CONFLICT DO UPDATE`.
2. **Divergência é publicada, não corrigida.** Se a soma das turmas não fechar com o subtotal da
   origem, os dois números ficam e a linha vai para `decision.verdict = "review"`. O sistema não
   "conserta" número acadêmico.
3. **Sem base, sem percentual.** Variação sobre semestre zerado é `null`, não `100%`.
4. **Curso encerrado não publica.** Zero matrícula no semestre atual e zero turmas → `skip`.
5. **Contagem de vínculos, não de pessoas.** Um aluno com duas matrículas conta duas vezes.
6. **Coordenador filtra no SQL.** `courseScope` restrito vira `WHERE`, não peneira em memória.

## Verificação

```bash
npm test                        # 97 testes, inclui test/enrollment.test.ts
npm run check                   # typecheck api + web
```

Além dos testes unitários, a rota foi exercitada contra Postgres real duas vezes:

- **sintético** — `POST` → painel → reimportação → isolamento entre duas instituições → recusa de
  `studentRef`/CPF → histórico. 23 asserções.
- **real** — as 840 linhas da planilha importadas pela rota; conferem com os números de controle do
  acervo (2026/02 = 3.794 matriculados, Direito = 245 com 10 turmas, variação total −6%). 16 asserções.

## Ligação com a planilha

| Aba | Uso |
|---|---|
| `02_Curso_Semestre` | Linha → registro do `POST /v1/enrollments` |
| `03_Turmas` | Vira o array `turmas` de cada registro |
| `04_Publicacao_Curso` | É exatamente a resposta de `GET /v1/enrollments/panel` |

O arquivo pronto para importar está em
`CLIENTES/UNITOP/planilhas/matricula_agregada.json` (840 registros, 427 KB).
