# Critérios de aceite — onde cada um é atendido

Mapa direto entre o briefing e o código entregue. “Implementado” significa que existe código
funcional; “parcial” significa que a estrutura existe mas falta uma peça.

| # | Critério do briefing | Estado | Onde |
|---|---|---|---|
| 1 | Cadastrar o curso de Direito | **Implementado** | `POST /v1/courses` · painel → Equipe/Regras |
| 2 | Importar a matriz de requisitos | **Parcial** | `GET /v1/instruments/:id/requirements`; catálogo é semeado em `seed.ts`. Falta importador XLSX/CSV do instrumento oficial |
| 3 | Atribuir responsáveis e prazos | **Implementado** | `evidence_items.owner_id`, `due_date` · `POST /v1/evidence` |
| 4 | Anexar evidências | **Parcial** | Tabelas `documents` + `evidence_documents` e rota de vínculo lógico. Falta o upload físico (S3/MinIO + presigned URL + antivírus) |
| 5 | Aprovar ou rejeitar evidências | **Implementado** | `PATCH /v1/evidence/:id/status` com máquina de estados e histórico |
| 6 | Registrar achados de auditoria | **Parcial** | `alert_events` cobre achados operacionais. Não existe entidade `audit_finding` dedicada |
| 7 | Gerar plano de ação | **Parcial** | `alert_events.action_code` com lista fechada de ações institucionais. Falta entidade `action_plan` com responsável/prazo |
| 8 | Acompanhar painel por eixo | **Implementado** | `GET /v1/alerts/summary` + tela Visão geral; evidências agrupadas por eixo |
| 9 | Exportar relatório de prontidão | **Não implementado** | Dados já estão em `GET /v1/evidence`; falta gerador (CSV/XLSX/PDF) e rota de download |
| 10 | Consultar histórico completo das alterações | **Implementado** | `GET /v1/audit`, `evidence_history`, `alert_events`, tela Auditoria |
| 11 | Motor de risco explicável | **Implementado** | `domain/risk-engine.ts` + 9 testes; fatores com observado/limite/pontos |
| 12 | Extensão de leitura autorizada | **Implementado** | `apps/extension` com adaptador, preview e falha fechada |

## O que ainda falta para “piloto pronto”

Em ordem de esforço e risco:

1. **Upload de documentos** (S3/MinIO, presigned URL, validação de MIME, limite de tamanho, hash
   SHA-256, antivírus). ~2–3 dias.
2. **Importador da matriz oficial** do instrumento (XLSX/CSV → `instrument_requirements`). ~2 dias.
3. **Entidade `action_plan`** com responsável, prazo, status e vínculo ao alerta/achado. ~2 dias.
4. **Exportação de relatório de prontidão** (XLSX + PDF com fonte, versão do instrumento e data). ~1–2 dias.
5. **Testes de integração com PostgreSQL** em CI (testcontainers ou serviço no Actions). ~1 dia.
6. **MFA obrigatório para administradores**. ~1 dia.
7. **Onboarding de instituição** (criar instituição + primeiro admin pela UI, hoje só via seed/API). ~1 dia.

## Testes automatizados existentes

```bash
npm test
```

Cobre o motor de risco (determinismo, saturação, fronteiras, ruleset customizado) e o contrato de
validação (campo extra, faixa, data sem offset, requerimento inválido, detecção de CPF/e-mail
aninhados, lote parcialmente aceito).

**Não** há teste de integração com banco nesta entrega — é a lacuna mais relevante para o
desenvolvedor fechar antes do piloto.
