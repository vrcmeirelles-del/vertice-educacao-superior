import type { User } from "../../drizzle/schema";

/** Both values come from server configuration; browser input never grants ownership. */
export function matchesOwnerIdentity(user: Pick<User, "openId" | "email">): boolean {
  const id = process.env.OWNER_OPEN_ID?.trim();
  const email = process.env.OWNER_EMAIL?.trim().toLowerCase();
  return Boolean(id && email && user.openId === id && user.email?.trim().toLowerCase() === email);
}

export function isOwner(user: User | null): boolean {
  return Boolean(user && user.role === "admin" && matchesOwnerIdentity(user));
}
