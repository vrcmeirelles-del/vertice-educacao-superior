import type { RequestHandler } from "express";

export const securityHeaders: RequestHandler = (_req, res, next) => {
  res.set({
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
    "X-Frame-Options": "DENY",
  });
  if (process.env.NODE_ENV === "production") {
    res.set("Strict-Transport-Security", "max-age=31536000");
    res.set("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; object-src 'none'; form-action 'self'");
  }
  next();
};

// Per-process protection. A shared gateway limiter is still needed for multiple replicas.
export function protectApi(now = Date.now): RequestHandler {
  const windows = new Map<string, { count: number; until: number }>();
  return (req, res, next) => {
    res.set("Cache-Control", "no-store");
    if (!["GET", "HEAD", "OPTIONS"].includes(req.method)) {
      const expected = process.env.PUBLIC_SITE_ORIGIN?.replace(/\/$/, "");
      if (!expected || req.headers.origin !== expected || req.headers["sec-fetch-site"] === "cross-site") {
        res.status(403).json({ error: "Origem não autorizada" }); return;
      }
    }
    const time = now();
    for (const [key, value] of windows) if (value.until <= time) windows.delete(key);
    const key = req.ip || req.socket.remoteAddress || "unknown";
    let window = windows.get(key);
    if (!window) {
      if (windows.size >= 10000) { res.status(503).end(); return; }
      window = { count: 0, until: time + 60000 }; windows.set(key, window);
    }
    if (++window.count > 120) {
      res.set("Retry-After", String(Math.ceil((window.until - time) / 1000)));
      res.status(429).json({ error: "Muitas tentativas. Aguarde e tente novamente." }); return;
    }
    next();
  };
}
