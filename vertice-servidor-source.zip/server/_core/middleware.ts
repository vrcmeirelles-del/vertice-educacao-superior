import { TRPCError } from "@trpc/server";
import { protectedProcedure, t } from "./trpc";
import { getDb } from "../db";
import { userInstitutionRoles } from "../../drizzle/schema";
import { eq, and } from "drizzle-orm";
import { z } from "zod";

const institutionInputSchema = z.object({
  institutionId: z.string(),
});

/**
 * Middleware que verifica se o usuário tem acesso à instituição solicitada.
 * Adiciona `institutionId` e `role` ao contexto.
 */
const requireInstitutionAccess = t.middleware(async ({ ctx, next, input }) => {
  if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
  const db = await getDb();
  if (!db) {
    throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
  }

  const parsed = institutionInputSchema.safeParse(input);
  if (!parsed.success) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "institutionId is required" });
  }

  const { institutionId } = parsed.data;

  const role = await db
    .select()
    .from(userInstitutionRoles)
    .where(and(eq(userInstitutionRoles.userId, ctx.user.id), eq(userInstitutionRoles.institutionId, institutionId)))
    .limit(1);

  if (role.length === 0) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Access denied to this institution" });
  }

  return next({
    ctx: {
      ...ctx,
      institutionId,
      userRole: role[0].role,
      userSector: role[0].sector,
    },
  });
});

export const institutionProcedure = protectedProcedure.use(requireInstitutionAccess);