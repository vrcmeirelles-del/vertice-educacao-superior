import type { Express } from "express";
import { COOKIE_NAME } from "../../shared/const";
import { getSessionCookieOptions } from "./cookies";
import { sdk } from "./sdk";
import { isOwner } from "./owner";

export function loginConfigured(env: NodeJS.ProcessEnv = process.env) {
  return ["DATABASE_URL", "MANUS_PROJECT_ID", "MANUS_OAUTH_API_URL", "MANUS_OAUTH_PORTAL_URL"].every(key => Boolean(env[key]?.trim())) && (env.MANUS_JWT_SECRET?.length ?? 0) >= 32;
}

export function registerLoginRoutes(app: Express) {
  app.get("/api/auth/status", async (req, res) => {
    res.set("Cache-Control", "no-store");
    const configured = loginConfigured();
    if (!configured) { res.json({ configured: false, authenticated: false, isOwner: false }); return; }
    try {
      const user = await sdk.authenticateRequest(req);
      res.json({ configured: true, authenticated: true, isOwner: isOwner(user), email: user.email });
    } catch { res.json({ configured: true, authenticated: false, isOwner: false }); }
  });
  app.post("/api/auth/logout", (req, res) => {
    const expectedOrigin = process.env.PUBLIC_SITE_ORIGIN || `${req.protocol}://${req.get("host")}`;
    if (req.headers.origin !== expectedOrigin.replace(/\/$/, "")) { res.status(403).json({ error: "Origem não autorizada" }); return; }
    res.set("Cache-Control", "no-store");
    res.clearCookie(COOKIE_NAME, { ...getSessionCookieOptions(req), maxAge: -1 });
    res.json({ success: true });
  });
}
