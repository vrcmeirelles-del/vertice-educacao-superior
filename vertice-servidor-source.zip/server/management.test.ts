import { describe, expect, it } from "vitest";
import {
  enrichAction,
  goalProgress,
  goalSummary,
  type Goal,
} from "../client/src/lib/management";
import type { Action } from "../client/src/lib/pilot";

const goal = (patch: Partial<Goal> = {}): Goal => ({
  id: "meta-teste",
  title: "Indicador de teste",
  axis: "teste",
  objective: "Validar cálculo",
  unit: "%",
  baseline: 20,
  target: 40,
  current: 30,
  direction: "up",
  weight: 2,
  period: "Ciclo demonstrativo",
  owner: "Responsável fictício",
  source: "Fonte fictícia",
  frequency: "Mensal",
  ...patch,
});

const action = (patch: Partial<Action> = {}): Action => ({
  id: "acao-teste",
  title: "Ação demonstrativa",
  dimension: "governanca",
  owner: "Pessoa fictícia",
  deadline: "A definir",
  priority: "Média",
  status: "A fazer",
  ...patch,
});

describe("gestão demonstrativa", () => {
  it("calcula avanço de alta e baixa com a mesma fórmula relativa", () => {
    expect(goalProgress(goal())).toMatchObject({
      progress: 50,
      delta: 10,
    });
    expect(goalProgress(goal({ baseline: 80, target: 40, current: 60, direction: "down" }))).toMatchObject({
      progress: 50,
      delta: -20,
    });
  });

  it("mantém medição nula como desconhecida", () => {
    const result = goalProgress(goal({ current: null }));
    expect(result.progress).toBeNull();
    expect(result.delta).toBeNull();
    expect(result.reason).toContain("desconhecido");
  });

  it("aceita baseline zero quando a meta torna a divisão válida", () => {
    expect(goalProgress(goal({ baseline: 0, target: 16, current: 4 }))).toMatchObject({
      progress: 25,
      delta: 4,
    });
  });

  it("recusa direção incompatível e divisão por meta igual ao baseline", () => {
    expect(goalProgress(goal({ baseline: 40, target: 20, direction: "up" })).progress).toBeNull();
    expect(goalProgress(goal({ baseline: 20, target: 20 })).reason).toContain("meta inválida");
  });

  it("recusa peso zero e números não finitos", () => {
    expect(goalProgress(goal({ weight: 0 })).reason).toContain("peso inválido");
    expect(goalProgress(goal({ current: Number.NaN })).progress).toBeNull();
  });

  it("limita avanço abaixo e acima da faixa, sem transformar em aprovação", () => {
    const below = goalProgress(goal({ current: 2 }));
    const above = goalProgress(goal({ current: 90 }));
    expect(below.progress).toBe(0);
    expect(above.progress).toBe(100);
    expect(above.reason).toContain("não é indicador de aprovação");
  });

  it("calcula resumo ponderado e exclui nulos, pesos inválidos e metas inválidas", () => {
    const result = goalSummary([
      goal({ id: "a", current: 30, weight: 2 }),
      goal({ id: "b", current: null, weight: 3 }),
      goal({ id: "c", current: 40, weight: 0 }),
      goal({ id: "d", baseline: 30, target: 30, current: 35, weight: 7 }),
      goal({ id: "e", baseline: null, current: 20, weight: 1 }),
    ]);
    expect(result).toEqual({ progress: 50, measured: 1, total: 5, validWeight: 2 });
  });

  it("preenche ações antigas sem inventar execução, datas ou valores", () => {
    const oldAction = action();
    const enriched = enrichAction(oldAction) as Action & Record<string, unknown>;
    expect(enriched).toMatchObject({
      ...oldAction,
      relatedGoal: "",
      plannedStart: "",
      plannedEnd: "",
      actualStart: "",
      actualEnd: "",
      budget: null,
      expectedReturn: null,
      tags: [],
    });
  });

  it("preserva campos 5W2H já preenchidos", () => {
    const existing = action() as Action & Record<string, unknown>;
    existing.relatedGoal = "meta-existente";
    existing.why = "Motivo registrado";
    existing.how = "Passos registrados";
    existing.plannedStart = "2031-02-03";
    existing.budget = 1450;
    existing.tags = ["revisar"];
    const enriched = enrichAction(existing) as Action & Record<string, unknown>;
    expect(enriched.relatedGoal).toBe("meta-existente");
    expect(enriched.why).toBe("Motivo registrado");
    expect(enriched.how).toBe("Passos registrados");
    expect(enriched.plannedStart).toBe("2031-02-03");
    expect(enriched.budget).toBe(1450);
    expect(enriched.tags).toEqual(["revisar"]);
  });
});
