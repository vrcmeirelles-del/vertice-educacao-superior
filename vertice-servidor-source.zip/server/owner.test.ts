import { afterEach, describe, expect, it, vi } from "vitest";
import { isOwner, matchesOwnerIdentity } from "./_core/owner";
import { ownerRouter } from "./routers/owner";
import type { User } from "../drizzle/schema";
import type { TrpcContext } from "./_core/context";

const user = { id: 1, openId: "verified-provider-id", email: "vrcmeirelles@gmail.com", role: "admin" } as User;
afterEach(() => vi.unstubAllEnvs());
function configure() {
  vi.stubEnv("OWNER_OPEN_ID", user.openId);
  vi.stubEnv("OWNER_EMAIL", user.email!);
}
describe("owner authorization", () => {
  it("accepts the configured identity and administrator role", () => { configure(); expect(isOwner(user)).toBe(true); });
  it("does not grant ownership to an email alone", () => { configure(); expect(isOwner({ ...user, openId: "attacker" })).toBe(false); });
  it("does not grant ownership to a provider id with a different email", () => { configure(); expect(isOwner({ ...user, email: "other@example.com" })).toBe(false); });
  it("does not grant ownership to another administrator", () => { configure(); expect(isOwner({ ...user, openId: "other-admin", email: "other@example.com" })).toBe(false); });
  it("requires administrator role", () => { configure(); expect(isOwner({ ...user, role: "user" })).toBe(false); });
  it("fails closed when configuration or session is missing", () => { vi.stubEnv("OWNER_OPEN_ID", ""); expect(isOwner(user)).toBe(false); expect(isOwner(null)).toBe(false); });
  it("normalizes email case only, preserving provider identity", () => { configure(); expect(matchesOwnerIdentity({ ...user, email: " VRCMEIRELLES@GMAIL.COM " })).toBe(true); });
  it("blocks anonymous API access before querying the database", async () => {
    configure(); const caller = ownerRouter.createCaller({ user: null } as TrpcContext);
    await expect(caller.overview()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
  it("blocks non-owner API access before querying the database", async () => {
    configure(); const caller = ownerRouter.createCaller({ user: { ...user, openId: "other-admin" } } as TrpcContext);
    await expect(caller.overview()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
