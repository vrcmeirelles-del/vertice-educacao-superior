import { TRPCError } from "@trpc/server";
import { router, protectedProcedure } from "../_core/trpc";
import { isOwner } from "../_core/owner";
import { getDb } from "../db";
import { users, institutions, courses, userInstitutionRoles } from "../../drizzle/schema";

const ownerProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (!isOwner(ctx.user)) throw new TRPCError({ code: "FORBIDDEN", message: "Acesso exclusivo do proprietário." });
  return next({ ctx });
});

export const ownerRouter = router({
  access: protectedProcedure.query(({ ctx }) => ({ isOwner: isOwner(ctx.user) })),
  overview: ownerProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Banco institucional indisponível." });
    const [allInstitutions, allCourses, allUsers, memberships] = await Promise.all([
      db.select().from(institutions),
      db.select().from(courses),
      db.select({ id: users.id, name: users.name, email: users.email, role: users.role, lastSignedIn: users.lastSignedIn }).from(users),
      db.select({ userId: userInstitutionRoles.userId, institutionId: userInstitutionRoles.institutionId, role: userInstitutionRoles.role, sector: userInstitutionRoles.sector }).from(userInstitutionRoles),
    ]);
    return { institutions: allInstitutions, courses: allCourses, users: allUsers, memberships };
  }),
});
