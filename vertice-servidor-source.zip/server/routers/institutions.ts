import { z } from "zod";
import { eq, and, inArray } from "drizzle-orm";
import { protectedProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import { institutions, courses, userInstitutionRoles } from "../../drizzle/schema";
import { TRPCError } from "@trpc/server";

export const institutionRouter = router({
  // Criar nova IES (apenas para admins ou primeiro acesso)
  create: protectedProcedure.input(z.object({ name: z.string().trim().min(1).max(255), cnpj: z.string().trim().max(18).optional() })).mutation(async ({ ctx, input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });

    // Verificar se usuário já tem vínculo
    const existing = await db.select().from(userInstitutionRoles).where(eq(userInstitutionRoles.userId, ctx.user.id)).limit(1);
    if (existing.length > 0 && ctx.user.role !== 'admin') {
       throw new TRPCError({ code: "FORBIDDEN", message: "Usuário já vinculado a uma instituição." });
    }

    const id = `ies-${Date.now()}`;
    await db.insert(institutions).values({
      id,
      name: input.name,
      cnpj: input.cnpj,
    });

    // Vincular criador como gestor/admin
    await db.insert(userInstitutionRoles).values({
      id: `role-${Date.now()}`,
      userId: ctx.user.id,
      institutionId: id,
      role: 'admin',
      sector: 'gestao',
    });

    return { success: true, institutionId: id };
  }),

  // Listar IES do usuário
  listMy: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];

    const roles = await db.select().from(userInstitutionRoles).where(eq(userInstitutionRoles.userId, ctx.user.id));
    const ids = roles.map(r => r.institutionId);

    if (ids.length === 0) return [];

    return await db.select().from(institutions).where(inArray(institutions.id, ids));
  }),

  // Adicionar curso
  addCourse: protectedProcedure.input(z.object({ institutionId: z.string().min(1).max(64), code: z.string().trim().min(1).max(32), name: z.string().trim().min(1).max(255) })).mutation(async ({ ctx, input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

    // Verificar permissão na IES
    const role = await db.select().from(userInstitutionRoles).where(
      and(eq(userInstitutionRoles.userId, ctx.user.id), eq(userInstitutionRoles.institutionId, input.institutionId))
    ).limit(1);

    if (role.length === 0) throw new TRPCError({ code: "FORBIDDEN" });

    const id = `curso-${Date.now()}`;
    await db.insert(courses).values({
      id,
      institutionId: input.institutionId,
      code: input.code,
      name: input.name,
    });

    return { success: true };
  }),
});