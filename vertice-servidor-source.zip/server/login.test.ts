import { describe, expect, it } from "vitest";
import { loginConfigured } from "./_core/loginRoutes";
const config = { DATABASE_URL: "mysql://test", MANUS_PROJECT_ID: "test", MANUS_OAUTH_API_URL: "https://auth.example.com", MANUS_OAUTH_PORTAL_URL: "https://login.example.com", MANUS_JWT_SECRET: "a".repeat(32) };
describe("login configuration", () => {
  it("requires the database, provider and a session secret", () => { expect(loginConfigured(config)).toBe(true); expect(loginConfigured({})).toBe(false); });
  it.each(Object.keys(config))("rejects missing %s", key => { expect(loginConfigured({ ...config, [key]: "" })).toBe(false); });
  it("rejects a short signing secret", () => { expect(loginConfigured({ ...config, MANUS_JWT_SECRET: "short" })).toBe(false); });
});
