import { describe, expect, it } from "vitest";
import { protectApi, securityHeaders } from "./_core/security";
function response() {
  const headers: Record<string, string> = {};
  return { headers, code: 200, set(key: string | Record<string,string>, value?: string) { if(typeof key === "string") headers[key] = value!; else Object.assign(headers,key); return this; }, status(code: number) { this.code = code; return this; }, json() {return this;}, end() {} };
}
describe("API safeguards", () => {
  it("rejects a foreign-origin write before reaching the handler", () => {
    const res = response(); let reached = false;
    protectApi()({method:"POST",headers:{origin:"https://attacker.invalid"},socket:{}} as any,res as any,()=>{reached=true;});
    expect(res.code).toBe(403); expect(reached).toBe(false);
  });
  it("throttles repeated requests and recovers after the window", () => {
    let now=0; const guard=protectApi(()=>now); let count=0;
    const req={method:"GET",headers:{},ip:"test",socket:{}};
    for(let i=0;i<120;i++) guard(req as any,response() as any,()=>{count++;});
    const blocked=response(); guard(req as any,blocked as any,()=>{count++;});
    expect(count).toBe(120); expect(blocked.code).toBe(429);
    now=60001; guard(req as any,response() as any,()=>{count++;}); expect(count).toBe(121);
  });
  it("sets anti-sniff and framing headers",()=>{
    const res=response(); securityHeaders({} as any,res as any,()=>{});
    expect(res.headers["X-Content-Type-Options"]).toBe("nosniff");
    expect(res.headers["X-Frame-Options"]).toBe("DENY");
  });
});
