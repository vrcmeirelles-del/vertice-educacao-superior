import {describe,it,expect,vi} from 'vitest';
import {passwordMfaFactor,passwordChangeError} from '../client/src/lib/passwordMfa';

function auth(level:string,factors:{id:string;status:string}[]){return {mfa:{
 getAuthenticatorAssuranceLevel:vi.fn(async()=>({data:{currentLevel:level},error:null})),
 listFactors:vi.fn(async()=>({data:{totp:factors},error:null}))
}};}
describe('password changes with MFA',()=>{
 it('requires the verified factor for a recovery session at aal1',async()=>{
  const client=auth('aal1',[{id:'unfinished',status:'unverified'},{id:'verified',status:'verified'}]);
  expect(await passwordMfaFactor(client)).toBe('verified');
 });
 it('allows an already challenged session without asking for another code',async()=>{
  const client=auth('aal2',[{id:'verified',status:'verified'}]);
  expect(await passwordMfaFactor(client)).toBeNull();expect(client.mfa.listFactors).not.toHaveBeenCalled();
 });
 it('does not treat an unfinished enrollment as an active second factor',async()=>{
  expect(await passwordMfaFactor(auth('aal1',[{id:'unfinished',status:'unverified'}]))).toBeNull();
 });
 it('stops when assurance cannot be checked',async()=>{
  const client={mfa:{getAuthenticatorAssuranceLevel:async()=>({data:null,error:new Error('unavailable')}),listFactors:vi.fn()}};
  await expect(passwordMfaFactor(client)).rejects.toThrow('unavailable');expect(client.mfa.listFactors).not.toHaveBeenCalled();
 });
 it('distinguishes the reported AAL2 error from an expired session',()=>{
  expect(passwordChangeError({status:401,message:'AAL2 session is required to update email or password when MFA is enabled.'})).toContain('autenticador');
  expect(passwordChangeError({code:'session_expired'})).toContain('expirou');
 });
});
