import { describe, expect, it } from "vitest";
import {
  attentionLevel,
  calculateResults,
  dimensions,
  initialState,
  toCsv,
  type Criterion,
} from "../client/src/lib/pilot";

describe("piloto Vértice", () => {
  it("expõe seis dimensões e três critérios demonstrativos por dimensão", () => {
    expect(dimensions).toHaveLength(6);
    expect(initialState.criteria).toHaveLength(18);
    expect(new Set(dimensions.map((dimension) => dimension.id)).size).toBe(6);

    for (const dimension of dimensions) {
      expect(initialState.criteria.filter((criterion) => criterion.dimension === dimension.id)).toHaveLength(3);
    }

    expect(initialState.actions).toHaveLength(6);
    expect(initialState.actions.every((action) => action.owner.includes("(exemplo)"))).toBe(true);
    expect(initialState.pending.map((pending) => pending.title)).toEqual([
      "Referência de gestão identificada",
      "Questões do diagnóstico",
      "Métricas oficiais",
      "Identidade visual",
      "Autorização",
      "Validação regulatória",
    ]);
  });

  it("calcula a média dos escores válidos sem tratar nulos como zero", () => {
    const result = calculateResults(initialState.criteria);

    expect(result).toMatchObject({ score: 60, answered: 15, total: 18, attention: 8 });
    expect(result.coverage).toBeCloseTo((15 / 18) * 100, 10);
    expect(result.byDimension).toHaveLength(6);
    expect(result.byDimension.map((dimension) => dimension.id)).toEqual(dimensions.map((dimension) => dimension.id));
    expect(result.byDimension.map((dimension) => dimension.score)).toEqual([63, 67, 63, 67, 38, 58]);
  });

  it("filtra o resumo geral, mantendo todas as dimensões no detalhamento", () => {
    const result = calculateResults(initialState.criteria, "governanca");

    expect(result).toMatchObject({ score: 63, answered: 2, total: 3, attention: 1 });
    expect(result.coverage).toBeCloseTo((2 / 3) * 100, 10);
    expect(result.byDimension).toHaveLength(6);
    expect(result.byDimension[0]).toMatchObject({ id: "governanca", score: 63, answered: 2, total: 3 });
    expect(result.byDimension.slice(1).every((dimension) => dimension.total === 3)).toBe(true);
  });

  it("retorna ausência de avaliação quando não há escore válido", () => {
    const criteria = initialState.criteria.map((criterion) => ({ ...criterion, score: null }));
    const result = calculateResults(criteria);

    expect(result).toMatchObject({ score: null, answered: 0, total: 18, attention: 0, coverage: 0 });
    expect(result.byDimension.every((dimension) => dimension.score === null && dimension.answered === 0)).toBe(true);
  });

  it("conta atenção apenas entre respostas válidas e dentro da escala", () => {
    const criteria: Criterion[] = [
      { ...initialState.criteria[0]!, score: 0 },
      { ...initialState.criteria[1]!, score: 4 },
      { ...initialState.criteria[2]!, score: null },
      { ...initialState.criteria[3]!, score: -1 },
      { ...initialState.criteria[4]!, score: 4.5 },
    ];
    const result = calculateResults(criteria);

    expect(result).toMatchObject({ score: 50, answered: 2, total: 5, attention: 1 });
    expect(result.coverage).toBe(40);
  });

  it("classifica os limiares de atenção de forma determinística", () => {
    expect(attentionLevel(null)).toBe("Sem avaliação");
    expect(attentionLevel(49)).toBe("Crítico");
    expect(attentionLevel(50)).toBe("Atenção");
    expect(attentionLevel(74.99)).toBe("Atenção");
    expect(attentionLevel(75)).toBe("Consolidado");
  });

  it("escapa delimitadores, aspas, quebras de linha e fórmulas no CSV", () => {
    const criterion: Criterion = {
      id: "csv_01",
      dimension: "dados",
      question: "=SOMA(1,2)",
      score: null,
      observation: 'Texto, com "aspas"\nna segunda linha',
      evidence: "@evidencia",
      recommendation: "+aguardar validação",
    };

    const csv = toCsv([criterion]);

    expect(csv.startsWith("id,dimension,question,score,observation,evidence,recommendation\n")).toBe(true);
    expect(csv).toContain('"\'=SOMA(1,2)"');
    expect(csv).toContain('"Texto, com ""aspas""\nna segunda linha"');
    expect(csv).toContain("'@evidencia");
    expect(csv).toContain("'+aguardar validação");
    expect(csv.endsWith("\n")).toBe(true);
  });
});
