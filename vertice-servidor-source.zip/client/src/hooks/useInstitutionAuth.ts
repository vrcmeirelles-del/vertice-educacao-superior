import { trpc } from "@/lib/trpc";

export function useInstitutionAuth() {
  const meQuery = trpc.auth.me.useQuery();
  const createInstitutionMutation = trpc.institutions.create.useMutation();
  const listMyInstitutionsQuery = trpc.institutions.listMy.useQuery(undefined, {
    enabled: !!meQuery.data,
  });

  return {
    user: meQuery.data,
    isLoading: meQuery.isLoading,
    institutions: listMyInstitutionsQuery.data || [],
    createInstitution: createInstitutionMutation.mutateAsync,
    isCreating: createInstitutionMutation.isPending,
  };
}