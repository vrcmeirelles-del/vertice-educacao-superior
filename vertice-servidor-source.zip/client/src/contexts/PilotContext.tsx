import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";
import { initialState, type PilotState } from "@/lib/pilot";
import { initialGoals, enrichAction } from "@/lib/management";
import type { Institution } from "@/lib/institutions";

const KEY = "vertice-piloto-v1";
const INSTITUTION_KEY = "vertice-instituicao-v1";
export const emptyInstitution: Institution = {
  id: "ies-local",
  name: "",
  courses: [],
  sectors: [
    { sectorId: "gestao", label: "Gestão institucional", role: "gestor", canAnswer: true, canReview: true },
    { sectorId: "academico", label: "Coordenação acadêmica", role: "academico", canAnswer: true, canReview: false },
    { sectorId: "regulacao", label: "Regulação e evidências", role: "regulacao", canAnswer: true, canReview: false },
  ],
};
function loadInstitution(): Institution {
  try {
    const raw = localStorage.getItem(INSTITUTION_KEY);
    if (raw) return { ...structuredClone(emptyInstitution), ...JSON.parse(raw) };
  } catch {
    /* O diagnóstico continua disponível sem persistência local. */
  }
  return structuredClone(emptyInstitution);
}
export function migratePilot(parsed: Partial<PilotState>): PilotState {
  return {
    ...structuredClone(initialState),
    ...parsed,
    criteria: parsed.criteria ?? structuredClone(initialState.criteria),
    pending: parsed.pending ?? structuredClone(initialState.pending),
    actions: (parsed.actions ?? initialState.actions).map(enrichAction),
    goals: Array.isArray(parsed.goals)
      ? parsed.goals
      : structuredClone(initialGoals),
  };
}
function load(): PilotState {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as PilotState;
      if (
        Array.isArray(parsed.criteria) &&
        Array.isArray(parsed.actions) &&
        Array.isArray(parsed.pending) &&
        parsed.criteria.every(
          c =>
            typeof c.id === "string" &&
            typeof c.question === "string" &&
            (c.score === null ||
              (Number.isInteger(c.score) && c.score >= 0 && c.score <= 4))
        )
      ) {
        if (
          !Array.isArray(parsed.goals) &&
          !localStorage.getItem(`${KEY}-antes-empresarial`)
        ) {
          try {
            localStorage.setItem(`${KEY}-antes-empresarial`, raw);
          } catch {
            /* Preservar o cenário carregado mesmo se o backup estiver bloqueado. */
          }
        }
        return migratePilot(parsed);
      }
    }
  } catch {
    /* A demonstração funciona mesmo sem armazenamento local. */
  }
  return migratePilot(initialState);
}
const Context = createContext<{
  state: PilotState;
  setState: React.Dispatch<React.SetStateAction<PilotState>>;
  institution: Institution;
  setInstitution: React.Dispatch<React.SetStateAction<Institution>>;
  storageAvailable: boolean;
} | null>(null);
export function PilotProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<PilotState>(load);
  const [institution, setInstitution] = useState<Institution>(loadInstitution);
  const [storageAvailable, setStorageAvailable] = useState(true);
  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
      localStorage.setItem(INSTITUTION_KEY, JSON.stringify(institution));
      setStorageAvailable(true);
    } catch {
      setStorageAvailable(false);
    }
  }, [state, institution]);
  return (
    <Context.Provider
      value={{ state, setState, institution, setInstitution, storageAvailable }}
    >
      {children}
    </Context.Provider>
  );
}
export function usePilot() {
  const value = useContext(Context);
  if (!value) throw new Error("PilotProvider ausente");
  return value;
}
export function downloadFile(
  content: string,
  filename: string,
  type = "application/json;charset=utf-8"
) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
