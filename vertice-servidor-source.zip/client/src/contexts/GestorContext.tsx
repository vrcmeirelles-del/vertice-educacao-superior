import React, { createContext, useContext, useState, type ReactNode } from "react";
import { Institution } from "@/lib/institutions";

type GestorContextValue = {
  institution: Institution;
  setInstitution: React.Dispatch<React.SetStateAction<Institution>>;
};

const GestorContext = createContext<GestorContextValue | null>(null);

export function GestorProvider({ children }: { children: ReactNode }) {
  const [institution, setInstitution] = useState<Institution>(() => ({
    id: "ies-local",
    name: "",
    courses: [],
    sectors: [
      { sectorId: "gestao", label: "Gestão institucional", role: "gestor", canAnswer: true, canReview: true },
      { sectorId: "academico", label: "Coordenação acadêmica", role: "academico", canAnswer: true, canReview: false },
      { sectorId: "regulacao", label: "Setor regulatório", role: "regulacao", canAnswer: true, canReview: false },
    ],
  }));
  return <GestorContext.Provider value={{ institution, setInstitution }}>{children}</GestorContext.Provider>;
}

export function useGestor() {
  const value = useContext(GestorContext);
  if (!value) throw new Error("GestorProvider ausente");
  return value;
}
