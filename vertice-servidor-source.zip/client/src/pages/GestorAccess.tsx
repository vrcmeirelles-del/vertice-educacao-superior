import Login from "./public/Login";
export default Login;
