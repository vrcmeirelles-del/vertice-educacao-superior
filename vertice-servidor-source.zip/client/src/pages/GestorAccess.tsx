import React, { useState } from "react";
import { LockKeyhole, ShieldCheck, UsersRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { usePilot } from "@/contexts/PilotContext";

const sectorLabels = [
  { id: "gestao", label: "Gestão institucional" },
  { id: "academico", label: "Coordenação acadêmica" },
  { id: "academico-colegiado", label: "Colegiado acadêmico" },
  { id: "evidencia", label: "Setor de evidências" },
  { id: "regulacao", label: "Setor regulatório" },
];

export default function GestorAccess() {
  const { institution, setInstitution } = usePilot();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [authorized, setAuthorized] = useState<string[]>(["gestao"]);
  const [error, setError] = useState("");

  const login = (e: React.FormEvent) => {
    e.preventDefault();
    const token = `${email.trim().toLowerCase()}|${password}`;
    if (!token.includes("@") || !password) {
      setError("Informe e-mail institucional e senha para continuar.");
      return;
    }
    setError("");
    setAuthorized(institution.sectors.map(s => s.sectorId).filter(id => id === "gestao" || true));
  };

  const release = (sectorId: string, canAnswer: boolean) => {
    const next = institution.sectors.map(s =>
      s.sectorId === sectorId
        ? { ...s, canAnswer, canReview: canAnswer ? s.canReview : false }
        : s
    );
    setInstitution({ ...institution, sectors: next });
  };

  return (
    <div className="gestor-composition">
      <div className="gestor-panel">
        <span className="corp-eyebrow">
          <span />
          ÁREA DE GESTOR
        </span>
        <h2>Cadastro institucional</h2>
        <p>
          O gestor da instituição entra com o e-mail institucional, cadastra a
          instituição e os cursos, e concede acesso aos setores que participam do
          diagnóstico.
        </p>
        <form onSubmit={login} className="gestor-form">
          <input
            className="text-input"
            type="email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            placeholder="gestor@instituicao.br"
            aria-label="E-mail institucional"
          />
          <input
            className="text-input"
            type="password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            placeholder="Senha"
            aria-label="Senha"
          />
          <button type="submit" className="corp-button">
            <LockKeyhole size={16} /> Entrar no diagnóstico
          </button>
          {error && <span className="muted-text">{error}</span>}
        </form>
      </div>

      <div className="gestor-panel">
        <span className="corp-eyebrow">
          <span />
          SETORES AUTORIZADOS
        </span>
        <h2>Liberação por setor</h2>
        <p>
          Cada setor pode responder e/ou revisar o diagnóstico do curso em que
          foi habilitado.
        </p>
        <div className="gestor-list">
          {institution.sectors.map(s => (
            <div key={s.sectorId} className="gestor-row">
              <div>
                <strong>{s.label}</strong>
                <span className="muted-text">{s.sectorId}</span>
              </div>
              <div className="gestor-actions">
                <label className="admin-check">
                  <input
                    type="checkbox"
                    checked={s.canAnswer}
                    onChange={e => release(s.sectorId, e.target.checked)}
                  />
                  Responder
                </label>
                <label className="admin-check">
                  <input
                    type="checkbox"
                    checked={s.canReview}
                    onChange={e => release(s.sectorId, e.target.checked)}
                  />
                  Revisar
                </label>
              </div>
            </div>
          ))}
        </div>
        <div className="gestor-footnote">
          <ShieldCheck size={15} /> O acesso é por setor, no mesmo navegador local do gestor.
        </div>
      </div>
    </div>
  );
}
