import { trpc } from "@/lib/trpc";
import { startLogin } from "@/const";
import { useState } from "react";

export default function OwnerDashboard() {
  const [loginError, setLoginError] = useState("");
  const me = trpc.auth.me.useQuery(undefined, { retry: false });
  const access = trpc.owner.access.useQuery(undefined, { enabled: Boolean(me.data), retry: false });
  const data = trpc.owner.overview.useQuery(undefined, { enabled: access.data?.isOwner === true, retry: false });
  if (me.isLoading) return <main className="corp-container corp-section"><h1>Acesso do proprietário</h1><p>Verificando sua sessão…</p></main>;
  if (me.isError) return <main className="corp-container corp-section"><h1>Acesso master indisponível</h1><p>Não foi possível consultar o servidor de autenticação. A demonstração estática não oferece acesso master.</p></main>;
  if (!me.data) return <main className="corp-container corp-section"><h1>Acesso do proprietário</h1><p>Entre com sua identidade autenticada para consultar as instituições e os usuários da empresa.</p><button className="corp-button" onClick={() => { try { startLogin(); } catch { setLoginError("O provedor de autenticação ainda não foi configurado neste ambiente."); } }}>Entrar</button>{loginError && <p role="alert">{loginError}</p>}</main>;
  if (access.isLoading) return <p>Verificando permissão de proprietário…</p>;
  if (!access.data?.isOwner) return <main className="corp-container corp-section"><h1>Acesso restrito</h1><p>Esta conta não possui permissão de proprietário. A autorização é verificada no servidor.</p></main>;
  if (data.isLoading) return <p>Carregando dados da empresa…</p>;
  if (!data.data) return <main className="corp-container corp-section"><h1>Painel do proprietário</h1><p role="alert">Não foi possível carregar os dados institucionais. Tente novamente quando o banco estiver disponível.</p></main>;
  const result = data.data;
  return <main className="corp-container corp-section">
    <h1>Painel do proprietário</h1><p>Conectado como {me.data.email}. Dados cadastrados no servidor.</p>
    <div className="stats-row"><div className="stat-card">Instituições<strong className="stat-value">{result.institutions.length}</strong></div><div className="stat-card">Cursos<strong className="stat-value">{result.courses.length}</strong></div><div className="stat-card">Usuários<strong className="stat-value">{result.users.length}</strong></div></div>
    <h2>Instituições e cursos</h2><div className="table-scroll"><table><thead><tr><th>Instituição</th><th>Curso</th><th>Código</th><th>Situação</th></tr></thead><tbody>{result.institutions.flatMap(institution => { const courses = result.courses.filter(c => c.institutionId === institution.id); return courses.length ? courses.map(course => <tr key={course.id}><td>{institution.name}</td><td>{course.name}</td><td>{course.code}</td><td>{course.active === "true" ? "Ativo" : "Inativo"}</td></tr>) : [<tr key={institution.id}><td>{institution.name}</td><td colSpan={3}>Nenhum curso cadastrado</td></tr>]; })}</tbody></table></div>
    {!result.institutions.length && <p>Nenhuma instituição cadastrada no servidor.</p>}
    <h2>Usuários e vínculos</h2><div className="table-scroll"><table><thead><tr><th>Nome</th><th>E-mail</th><th>Perfil do sistema</th><th>Vínculos institucionais</th></tr></thead><tbody>{result.users.map(user => <tr key={user.id}><td>{user.name ?? "—"}</td><td>{user.email ?? "—"}</td><td>{user.role === "admin" ? "Administrador" : "Usuário"}</td><td>{result.memberships.filter(m => m.userId === user.id).map(m => `${result.institutions.find(i => i.id === m.institutionId)?.name ?? m.institutionId}: ${m.role}${m.sector ? ` (${m.sector})` : ""}`).join("; ") || "Sem vínculo"}</td></tr>)}</tbody></table></div>
    <p>Os diagnósticos, metas e documentos da demonstração permanecem locais e não são apresentados como dados compartilhados neste painel.</p>
  </main>;
}
