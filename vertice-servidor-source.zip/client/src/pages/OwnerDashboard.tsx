import {useEffect, useState, type FormEvent} from 'react';
import {Link} from 'wouter';
import {supabase} from '@/lib/supabase';
import type {Session} from '@supabase/supabase-js';

type Institution={id:string;name:string};
type Course={id:string;institution_id:string;name:string;code:string|null};
type Membership={user_id:string;institution_id:string;role:string};
type Enrollment={id:string;course_id:string;semester:string;class_label:string;enrolled:number;capacity:number;available:number;source_report_at:string;reported_total:number|null;student_status:string};
export default function OwnerDashboard(){
 const [session,setSession]=useState<Session|null>(null);
 const [loading,setLoading]=useState(true),[busy,setBusy]=useState(false),[error,setError]=useState('');
 const [aal,setAal]=useState(''),[master,setMaster]=useState(false);
 const [factor,setFactor]=useState(''),[qr,setQr]=useState(''),[code,setCode]=useState('');
 const [institutions,setInstitutions]=useState<Institution[]>([]),[courses,setCourses]=useState<Course[]>([]),[members,setMembers]=useState<Membership[]>([]);
 const [enrollments,setEnrollments]=useState<Enrollment[]>([]);
 const [semester,setSemester]=useState('2026/02');
 const selected=enrollments.filter(r=>r.semester===semester);
 const rowTotal=selected.reduce((sum,r)=>sum+r.enrolled,0);
 const reportedTotal=selected[0]?.reported_total;
 async function load(){
  setLoading(true);setError('');
  try{
   const {data:{session:current}}=await supabase.auth.getSession();setSession(current);
   if(!current)return;
   const {data:assurance,error:aError}=await supabase.auth.mfa.getAuthenticatorAssuranceLevel();if(aError)throw aError;
   setAal(assurance.currentLevel??'aal1');
   if(assurance.currentLevel!=='aal2'){
    const {data,error:fError}=await supabase.auth.mfa.listFactors();if(fError)throw fError;
    setFactor(data.totp[0]?.id??'');return;
   }
   const results=await Promise.all([
    supabase.from('vertice_admins').select('user_id').eq('user_id',current.user.id),
    supabase.from('vertice_institutions').select('id,name').order('name'),
    supabase.from('vertice_courses').select('id,institution_id,name,code').order('name'),
    supabase.from('vertice_memberships').select('user_id,institution_id,role'),
    supabase.from('vertice_enrollment_snapshots').select('id,course_id,semester,class_label,enrolled,capacity,available,source_report_at,reported_total,student_status').order('source_report_at',{ascending:false})
   ]);
   if(results.some(r=>r.error))throw new Error('data unavailable');
   setMaster(Boolean(results[0].data?.length));setInstitutions(results[1].data as Institution[]);setCourses(results[2].data as Course[]);setMembers(results[3].data as Membership[]);
   const latest=new Map<string,Enrollment>();
   for(const row of results[4].data as Enrollment[]){const key=[row.course_id,row.semester,row.student_status,row.class_label].join('|');if(!latest.has(key))latest.set(key,row);}
   setEnrollments([...latest.values()]);
  }catch{setError('Não foi possível consultar os dados protegidos. Tente novamente.');}
  finally{setLoading(false);}
 }
 useEffect(()=>{load(); const {data}=supabase.auth.onAuthStateChange((event,current)=>{if(event==='SIGNED_OUT'){setSession(current);setInstitutions([]);setCourses([]);setMembers([]);setEnrollments([]);setMaster(false);}});return()=>data.subscription.unsubscribe();},[]);
 async function enroll(){setBusy(true);setError('');try{
  const {data:existing,error:listError}=await supabase.auth.mfa.listFactors();if(listError)throw listError;
  const pending=existing.all.find(f=>f.factor_type==='totp' && f.status==='unverified');
  if(pending){const {error}=await supabase.auth.mfa.unenroll({factorId:pending.id});if(error)throw error;}
  const {data,error}=await supabase.auth.mfa.enroll({factorType:'totp',friendlyName:'Vértice'});if(error)throw error;setFactor(data.id);setQr(data.totp.qr_code);
 }catch{setError('Não foi possível iniciar o segundo fator. Tente novamente.');}finally{setBusy(false);}}
 async function verify(e:FormEvent){e.preventDefault();setBusy(true);setError('');try{
  const {error}=await supabase.auth.mfa.challengeAndVerify({factorId:factor,code});if(error)throw error;setCode('');setQr('');await load();
 }catch{setError('Código não validado. Confira o autenticador e tente novamente.');}finally{setBusy(false);}}
 return <main className="corp-container corp-section"><h1>{master?'Painel do proprietário':'Minha área'}</h1>
 {loading?<p role="status">Verificando acesso…</p>:!session?<><p>Entre para acessar sua conta.</p><Link className="corp-button" href="/entrar">Entrar</Link></>:<>
 <p>Conectado como <strong>{session.user.email}</strong>.</p>
 {aal!=='aal2'?<section className="corp-login-card"><h2>Proteja seu acesso</h2><p>O segundo fator é obrigatório para consultar os dados das instituições.</p>
 {!factor?<button className="corp-button" disabled={busy} onClick={enroll}>Configurar aplicativo autenticador</button>:<>
 {qr&&<><p>Leia o QR code no seu aplicativo autenticador. Não compartilhe esta imagem.</p><img alt="QR code para configurar seu autenticador" src={qr} width={200} height={200}/></>}
 <form className="access-form" onSubmit={verify}><label>Código do autenticador<input autoComplete="one-time-code" inputMode="numeric" pattern="[0-9]{6}" maxLength={6} required value={code} onChange={e=>setCode(e.target.value)}/></label><button className="corp-button" disabled={busy}>Validar segundo fator</button></form></>}
 </section>:<><p>{master?'Visão das instituições da empresa.':'Você vê somente as instituições vinculadas à sua conta.'}</p>
 <div className="stats-row"><div className="stat-card">Instituições<strong className="stat-value">{institutions.length}</strong></div><div className="stat-card">Cursos<strong className="stat-value">{courses.length}</strong></div><div className="stat-card">Vínculos<strong className="stat-value">{members.length}</strong></div></div>
 <h2>Instituições e cursos</h2>{!institutions.length?<p>Nenhuma instituição disponível para esta conta. O vínculo deve ser autorizado pela administração.</p>:<div className="table-scroll"><table><thead><tr><th>Instituição</th><th>Cursos</th></tr></thead><tbody>{institutions.map(i=><tr key={i.id}><td>{i.name}</td><td>{courses.filter(c=>c.institution_id===i.id).map(c=>c.name).join(', ')||'Nenhum curso cadastrado'}</td></tr>)}</tbody></table></div>}
 <h2>Direito · Matrículas por turma</h2>
 <label>Semestre <select value={semester} onChange={e=>setSemester(e.target.value)}>{[...new Set(enrollments.map(r=>r.semester))].sort().reverse().map(s=><option key={s} value={s}>{s}</option>)}</select></label>
 {!selected.length?<p>Nenhum relatório importado para este semestre.</p>:<>
 <p>Fonte: relatório estatístico do e-ORBIT, status MATRICULADO. Consulta em {new Date(selected[0].source_report_at).toLocaleString('pt-BR',{timeZone:'America/Sao_Paulo'})}.</p>
 <div className="stats-row"><div className="stat-card">Total informado no relatório<strong className="stat-value">{reportedTotal??'Não informado'}</strong></div><div className="stat-card">Soma das turmas<strong className="stat-value">{rowTotal}</strong></div><div className="stat-card">Turmas<strong className="stat-value">{selected.length}</strong></div></div>
 {reportedTotal!==null&&reportedTotal!==undefined&&reportedTotal!==rowTotal&&<p role="alert">Conferência pendente: o total informado ({reportedTotal}) difere da soma das turmas ({rowTotal}). Os valores da origem foram preservados.</p>}
 <div className="table-scroll"><table><thead><tr><th>Série / turma na origem</th><th>Matrículas</th><th>Vagas</th><th>Disponíveis</th></tr></thead><tbody>{selected.slice().sort((a,b)=>a.class_label.localeCompare(b.class_label,'pt-BR',{numeric:true})).map(r=><tr key={r.id}><td>{r.class_label}</td><td>{r.enrolled}</td><td>{r.capacity}</td><td>{r.available}</td></tr>)}</tbody></table></div>
 {semester==='2026/02'&&<p>Conferir na secretaria: DIR-5A2026/02 aparece como 6ª série no relatório.</p>}
 <p>Quantitativos por turma não comprovam alunos únicos, retenção, captação efetiva ou participação na AV1. Esses indicadores dependem do cruzamento individual.</p></>}
 <p>Os dados desta área vêm do banco. Os exemplos da demonstração permanecem separados.</p><button className="corp-login-text-button" onClick={load}>Atualizar dados</button></>}
 <button className="corp-login-text-button" onClick={async()=>{const {error}=await supabase.auth.signOut();if(error)setError('Não foi possível encerrar a sessão.');}}>Sair da conta</button></>}
 {error&&<p role="alert">{error}</p>}<p><Link href="/privacidade.html">Privacidade</Link> · <Link href="/">Voltar ao site</Link></p></main>;
}
