import { Link } from "wouter";
import {
  ArrowRight,
  ArrowUpRight,
  BookOpen,
  CheckCircle2,
  Compass,
  FileCheck2,
  GraduationCap,
  Layers3,
  ShieldCheck,
  Target,
} from "lucide-react";
import { PageHeader } from "@/components/PilotLayout";
import { dimensions } from "@/lib/pilot";

export default function Methodology() {
  return (
    <>
      <PageHeader
        eyebrow="METODOLOGIA + CONSULTORIA"
        title="Um método que conecta decisões."
        description="Diagnóstico, metas, execução, desenvolvimento e revisão contínua."
      />
      <section className="method-hero">
        <div>
          <span className="eyebrow">MÉTODO VÉRTICE</span>
          <h2>
            Consultoria de crescimento.
            <br />
            <em>Com método, não só opinião.</em>
          </h2>
          <p>
            A Vértice organiza a experiência de gestão em perguntas,
            evidências, achados e ações. A proposta não substitui a reitoria nem
            os sistemas acadêmicos: ajuda a gestão a entender onde está e o que
            precisa estruturar.
          </p>
        </div>
        <span className="method-symbol">
          <Compass size={86} strokeWidth={0.8} />
        </span>
      </section>
      <div className="section-heading">
        <div>
          <h2>Três entregas diferentes, uma lógica conectada</h2>
          <p>Usar as palavras certas também dá credibilidade à proposta.</p>
        </div>
      </div>
      <div className="method-cards">
        {[
          {
            icon: Compass,
            n: "01",
            title: "Diagnóstico",
            text: "Mapeia a situação por critérios definidos. Organiza respostas, contextos e lacunas para uma discussão estruturada com a gestão.",
            note: "É o que este piloto demonstra.",
          },
          {
            icon: FileCheck2,
            n: "02",
            title: "Auditoria",
            text: "Verifica evidências contra critérios formais, com escopo, registros, competência e independência adequados. Não é apenas preencher uma escala.",
            note: "Não é uma certificação oferecida pelo piloto.",
          },
          {
            icon: Target,
            n: "03",
            title: "Acompanhamento",
            text: "Transforma recomendações discutidas em ações com responsáveis e marcos. Revisa a execução e aprende com os resultados efetivamente observados.",
            note: "O plano atual é exclusivamente ilustrativo.",
          },
        ].map(m => (
          <article className="panel method-card" key={m.n}>
            <div>
              <span className="method-icon">
                <m.icon size={24} strokeWidth={1.5} />
              </span>
              <span className="method-number">{m.n}</span>
            </div>
            <h3>{m.title}</h3>
            <p>{m.text}</p>
            <small>{m.note}</small>
          </article>
        ))}
      </div>
      <section className="panel method-dimensions">
        <div className="panel-heading">
          <div>
            <h3>Dimensões iniciais, abertas à sua experiência</h3>
            <p>Um ponto de partida, não o instrumento definitivo.</p>
          </div>
          <Layers3 size={20} />
        </div>
        <div className="method-dimension-list">
          {dimensions.map((d, i) => (
            <Link key={d.id} href={`/diagnostico?dimensao=${d.id}`}>
              <span style={{ color: d.color }}>0{i + 1}</span>
              <div>
                <h4>{d.name}</h4>
                <p>{d.description}</p>
              </div>
              <ArrowUpRight size={17} />
            </Link>
          ))}
        </div>
      </section>
      <div className="section-heading">
        <div>
          <h2>Da demonstração a um serviço comercial</h2>
          <p>
            Hipótese de modelo de negócio a validar com potenciais clientes.
          </p>
        </div>
      </div>
      <section className="consulting-model">
        <article>
          <span className="eyebrow">ENTRADA</span>
          <h3>Diagnóstico contratado</h3>
          <p>
            Escopo delimitado, coleta autorizada e relatório discutido com a
            gestão. A instituição contrata uma entrega concreta, não uma
            promessa de crescimento.
          </p>
        </article>
        <article>
          <span className="eyebrow">CONTINUIDADE</span>
          <h3>Consultoria de acompanhamento</h3>
          <p>
            Reuniões de revisão, apoio às prioridades e monitoramento de
            indicadores acordados. O valor e a frequência dependem do escopo
            validado.
          </p>
        </article>
        <article>
          <span className="eyebrow">EVOLUÇÃO</span>
          <h3>Metodologia + plataforma</h3>
          <p>
            Após validar a utilidade do serviço, estudar licenciamento para
            outras instituições. Multi-instituição, permissões e segurança não
            estão implementados neste piloto.
          </p>
        </article>
      </section>
      <section className="panel institutional-note">
        <ShieldCheck size={26} />
        <div>
          <h3>Crescer com responsabilidade</h3>
          <p>
            Antes de comercializar, esclareça a titularidade da metodologia e
            dos materiais, as obrigações do seu vínculo profissional, possíveis
            conflitos de interesse, confidencialidade e autorização de uso de
            dados. Não apresente dados internos como propriedade pessoal.
          </p>
          <p>
            Para o stricto sensu, a demonstração apenas organiza perguntas de
            planejamento. A viabilidade deve ser examinada por especialistas e
            pelas regras e processos oficiais aplicáveis; não há garantia de
            aprovação.
          </p>
        </div>
      </section>
      <div className="method-next">
        <div>
          <CheckCircle2 size={23} />
          <span>
            Objetivos claros, ações responsáveis e revisão com evidências.
          </span>
        </div>
        <Link href="/premissas" className="button secondary">
          O que falta validar <ArrowRight size={16} />
        </Link>
      </div>
      <div className="reference-note">
        <BookOpen size={14} />
        <p>
          Contexto conceitual consultado:{" "}
          Utilizamos princípios gerais de gestão com adaptação própria ao ensino superior. Não existe vínculo, integração, certificação ou endosso a plataformas externas.
        </p>
      </div>
    </>
  );
}
