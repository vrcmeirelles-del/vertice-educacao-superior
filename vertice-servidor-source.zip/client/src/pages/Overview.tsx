import { useState } from "react";
import { Link } from "wouter";
import {
  ArrowRight,
  ArrowUpRight,
  BookOpen,
  CheckCircle2,
  ChevronRight,
  Compass,
  Download,
  GraduationCap,
  Info,
  Play,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import { PageHeader, Filter } from "@/components/PilotLayout";
import {
  ActionSummary,
  DimensionProgress,
  MaturityRadar,
  Stats,
} from "@/components/PilotCharts";
import { dimensions, calculateResults } from "@/lib/pilot";
import { usePilot, downloadFile } from "@/contexts/PilotContext";

export default function Overview() {
  return (
    <>
      <PageHeader
        eyebrow="DA ESTRATÉGIA À EXECUÇÃO"
        title="Um novo olhar para crescer."
        description="Diagnóstico, prioridades e acompanhamento em um só espaço."
      >
        <Link href="/apresentacao" className="button secondary">
          <Play size={15} />
          Apresentar a proposta
        </Link>
      </PageHeader>
      <section className="hero-panel">
        <div className="hero-main">
          <span className="hero-label">
            <span />
            INTELIGÊNCIA PARA O ENSINO SUPERIOR
          </span>
          <h2>
            Crescimento com direção.
            <br />
            Decisões com <em>evidências.</em>
          </h2>
          <p>
            Transforme a experiência de gestão em uma metodologia de diagnóstico
            — e o diagnóstico em um plano de ação que a reitoria pode
            acompanhar.
          </p>
          <div className="hero-actions">
            <Link href="/diagnostico" className="button hero-cta">
              Explorar o diagnóstico <ArrowUpRight size={17} />
            </Link>
            <Link href="/metodologia" className="hero-text-link">
              Entenda a metodologia <ArrowRight size={16} />
            </Link>
          </div>
        </div>
        <div className="hero-aside">
          <span className="hero-aside-icon">
            <Compass size={26} strokeWidth={1.3} />
          </span>
          <span className="hero-aside-caption">CENÁRIO DEMONSTRATIVO</span>
          <strong>Ensino superior</strong>
          <p>Instituição fictícia para explorar o método</p>
          <div className="hero-context-number">
            6
            <span>
              dimensões estratégicas
              <br />sem dados de clientes
            </span>
          </div>
          <div className="hero-context-bottom">
            <GraduationCap size={19} />
            <span>
              Pesquisa e pós-graduação
              <br />
              <small>Planejamento sujeito a requisitos*</small>
            </span>
          </div>
        </div>
      </section>
      <div className="section-heading">
        <div>
          <h2>O cenário, em perspectiva</h2>
          <p>Uma amostra de como os resultados podem apoiar decisões.</p>
        </div>
        <Link href="/painel">
          Abrir painel executivo <ArrowRight size={16} />
        </Link>
      </div>
      <Stats />
      <div className="overview-columns">
        <section className="panel">
          <div className="panel-heading">
            <div>
              <h3>Onde concentrar a atenção</h3>
              <p>Estruturação por dimensão • dados de exemplo</p>
            </div>
            <span className="subtle-icon">
              <Compass size={19} />
            </span>
          </div>
          <DimensionProgress />
          <div className="panel-footer">
            <Info size={14} />
            Índices calculados a partir das respostas de exemplo.
          </div>
        </section>
        <section className="panel">
          <div className="panel-heading">
            <div>
              <h3>Da leitura à ação</h3>
              <p>Prioridades iniciais do cenário demonstrativo</p>
            </div>
            <Link
              href="/plano"
              className="round-arrow"
              aria-label="Ver plano de ação"
            >
              <ArrowUpRight size={18} />
            </Link>
          </div>
          <ActionSummary />
          <div className="consulting-note">
            <Sparkles size={19} />
            <div>
              <strong>O diferencial é a metodologia.</strong>
              <p>
                O software organiza. A consultoria interpreta, prioriza e
                acompanha.
              </p>
            </div>
          </div>
        </section>
      </div>
      <section className="journey-strip">
        <div className="journey-intro">
          <span className="eyebrow">COMO FUNCIONA</span>
          <h3>
            Uma decisão melhor,
            <br />a cada etapa.
          </h3>
        </div>
        {[
          {
            number: "01",
            title: "Diagnosticar",
            text: "Critérios, respostas e evidências",
            href: "/diagnostico",
          },
          {
            number: "02",
            title: "Priorizar",
            text: "Achados e recomendações",
            href: "/matriz",
          },
          {
            number: "03",
            title: "Acompanhar",
            text: "Responsáveis e andamento",
            href: "/plano",
          },
        ].map((s, i) => (
          <Link href={s.href} className="journey-step" key={s.number}>
            <span>{s.number}</span>
            <div>
              <strong>{s.title}</strong>
              <p>{s.text}</p>
            </div>
            {i < 2 ? <ChevronRight size={17} /> : <CheckCircle2 size={18} />}
          </Link>
        ))}
      </section>
      <p className="context-footnote">
        * Dados fictícios. O diagnóstico não comprova conformidade ou viabilidade.
        Planejamento de stricto sensu não significa aprovação ou credenciamento.
      </p>
    </>
  );
}
export function Executive() {
  const [dimension, setDimension] = useState("all");
  const { state } = usePilot();
  const result = calculateResults(
    state.criteria,
    dimension === "all" ? undefined : dimension
  );
  const selected = dimensions.find(d => d.id === dimension);
  return (
    <>
      <PageHeader
        eyebrow="VISÃO DA REITORIA"
        title="Clareza para decidir."
        description="Um retrato demonstrativo da estruturação institucional, sem avaliação oficial."
      >
        <button
          className="button secondary"
          onClick={() =>
            downloadFile(
              JSON.stringify(
                {
                  simulation: true,
                  dimension: selected?.name ?? "Todas",
                  result,
                  criteria: state.criteria.filter(
                    c => dimension === "all" || c.dimension === dimension
                  ),
                },
                null,
                2
              ),
              "vertice-resultados-simulados.json"
            )
          }
        >
          <Download size={16} />
          Exportar resultados
        </button>
      </PageHeader>
      <div className="filter-bar">
        <span className="live-note">
          <span />
          Resultados das respostas locais
        </span>
        <Filter
          value={dimension}
          onChange={setDimension}
          options={dimensions}
        />
      </div>
      <Stats dimension={dimension} />
      <div className="executive-columns">
        <section className="panel">
          <div className="panel-heading">
            <div>
              <h3>Mapa de estruturação</h3>
              <p>Todas as dimensões • não é indicador oficial</p>
            </div>
          </div>
          <MaturityRadar />
        </section>
        <section className="panel">
          <div className="panel-heading">
            <div>
              <h3>{selected ? selected.name : "Leitura por dimensão"}</h3>
              <p>Selecione uma dimensão para aprofundar os critérios.</p>
            </div>
            <Link href="/diagnostico" className="text-link">
              Diagnóstico <ArrowUpRight size={14} />
            </Link>
          </div>
          {selected ? (
            <div className="selected-dimension">
              <span className="selected-score">
                {result.score ?? "—"}
                <small>/100</small>
              </span>
              <p>{selected.description}</p>
              <Link
                href={`/diagnostico?dimensao=${selected.id}`}
                className="button secondary"
              >
                Ver critérios da dimensão <ArrowRight size={15} />
              </Link>
            </div>
          ) : (
            <DimensionProgress />
          )}
        </section>
      </div>
      <section className="panel calculation-panel">
        <div className="calculation-icon">
          <BookOpen size={22} />
        </div>
        <div>
          <h3>O que este índice significa — e o que não significa</h3>
          <p>
            Índice = média das respostas preenchidas ÷ 4 × 100, arredondada.
            Cada critério tem o mesmo peso. Respostas em branco não entram na
            média. O preenchimento indica a proporção de critérios respondidos.
            Pontos de atenção são respostas abaixo de 3.
          </p>
          <p>
            A escala vai de 0 (ausente) a 4 (monitorado). Ela descreve um
            cenário do piloto, não qualidade acadêmica comprovada, conformidade
            regulatória ou probabilidade de aprovação.
          </p>
          <div className="scale-legend">
            <span>0–49: crítico</span>
            <span>50–74: atenção</span>
            <span>75–100: consolidado</span>
          </div>
        </div>
      </section>
      <div className="notice-inline">
        <ShieldCheck size={17} />
        <p>
          Os resultados mudam ao editar o diagnóstico. Antes de usar com dados
          reais, valide critérios, pesos, evidências, permissões e a
          metodologia.
        </p>
      </div>
    </>
  );
}
