import { useEffect, useState } from "react";
import { Link } from "wouter";
import {
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Check,
  Compass,
  Flag,
  ShieldCheck,
  X,
} from "lucide-react";
import { Brand } from "@/components/PilotLayout";
import { calculateResults, dimensions } from "@/lib/pilot";
import { usePilot } from "@/contexts/PilotContext";

const steps = [
  {
    label: "O desafio",
    title: "Crescer exige mais do que abrir novos cursos.",
    text: "Uma instituição em expansão precisa enxergar prioridades, identificar lacunas e sustentar suas escolhas com evidências. Este piloto propõe organizar essa conversa antes de investir em um sistema completo.",
    takeaway:
      "A pergunta: como transformar experiência de gestão em decisões rastreáveis?",
  },
  {
    label: "O método",
    title: "Perguntas claras. Uma leitura compartilhada.",
    text: "O diagnóstico reúne dimensões estratégicas, critérios editáveis e respostas em escala. Cada resposta pode receber observações e referências de evidência. A matriz permite voltar da recomendação ao critério que a originou.",
    takeaway:
      "A proposta: uma metodologia própria, validada com a realidade da instituição.",
  },
  {
    label: "A leitura",
    title: "O painel mostra onde investigar — não dá um veredito.",
    text: "Os resultados deste exemplo mudam quando as respostas são editadas. O índice resume a estruturação informada; os pontos de atenção ajudam a direcionar a discussão. Não representam qualidade oficial ou conformidade comprovada.",
    takeaway: "Todos os números desta demonstração são ilustrativos.",
  },
  {
    label: "A execução",
    title: "O diagnóstico só tem valor quando vira ação.",
    text: "As recomendações são discutidas, priorizadas e organizadas em um plano com responsáveis e prazos. A consultoria ajuda a interpretar os achados e acompanhar as decisões; o software mantém essa história visível.",
    takeaway:
      "A entrega comercial sugerida: diagnóstico + acompanhamento, apoiados pela plataforma.",
  },
  {
    label: "A validação",
    title: "Um piloto pequeno. Uma decisão bem fundamentada.",
    text: "O próximo passo proposto é validar as questões, definir um recorte de uso e obter autorização para trabalhar com dados apropriados. As entregas, responsabilidades e critérios de acompanhamento são pactuados antes do trabalho real.",
    takeaway:
      "A decisão solicitada ao reitor seria autorizar uma avaliação delimitada do piloto — não aprovar um sistema inteiro.",
  },
];
export default function Presentation() {
  const [step, setStep] = useState(0);
  const { state } = usePilot();
  const results = calculateResults(state.criteria);
  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if (event.key === "ArrowRight")
        setStep(s => Math.min(s + 1, steps.length - 1));
      if (event.key === "ArrowLeft") setStep(s => Math.max(s - 1, 0));
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);
  const current = steps[step];
  return (
    <main className="presentation-shell">
      <header className="presentation-header">
        <Link href="/demonstracao" aria-label="Voltar à visão geral">
          <Brand />
        </Link>
        <span className="presentation-label">
          PERCURSO GUIADO • DADOS ILUSTRATIVOS
        </span>
        <Link href="/demonstracao" className="presentation-close">
          <X size={18} />
          Sair da apresentação
        </Link>
      </header>
      <div className="presentation-main">
        <div className="presentation-copy" key={step}>
          <span className="hero-label">
            ETAPA 0{step + 1} <span>•</span> {current.label.toUpperCase()}
          </span>
          <h1>{current.title}</h1>
          <p>{current.text}</p>
          <div className="presentation-takeaway">
            <span />
            <strong>{current.takeaway}</strong>
          </div>
          {step === 4 && (
            <Link href="/premissas" className="button hero-cta">
              Ver pendências de validação <ArrowUpRight size={17} />
            </Link>
          )}
        </div>
        <div className="presentation-visual">
          {step === 0 && (
            <div className="tour-context">
              <Compass size={48} strokeWidth={1} />
              <span>CENÁRIO DEMONSTRATIVO</span>
              <h2>Vértice</h2>
              <strong>
                7 <small>eixos de gestão</small>
              </strong>
              <p>Graduação • Tecnólogos • Pós-graduação</p>
              <div>
                Planejamento com critérios e evidências
                <br />
                <small>Sem promessa de aprovação ou viabilidade</small>
              </div>
            </div>
          )}
          {step === 1 && (
            <div className="tour-dimensions">
              <span className="tour-panel-title">
                SEIS DIMENSÕES PARA COMEÇAR
              </span>
              {dimensions.map((d, i) => (
                <div key={d.id}>
                  <span>0{i + 1}</span>
                  <strong>{d.name}</strong>
                  <Check size={15} />
                </div>
              ))}
              <Link href="/diagnostico">
                Explorar o instrumento <ArrowRight size={16} />
              </Link>
            </div>
          )}
          {step === 2 && (
            <div className="tour-results">
              <span className="tour-panel-title">CENÁRIO DEMONSTRATIVO</span>
              <div className="tour-score">
                {results.score ?? "—"}
                <span>/100</span>
              </div>
              <h3>Índice de estruturação</h3>
              <p>Média das respostas ÷ 4 × 100</p>
              <div className="tour-result-pairs">
                <div>
                  <strong>
                    {results.answered}/{results.total}
                  </strong>
                  <span>critérios respondidos</span>
                </div>
                <div>
                  <strong>{results.attention}</strong>
                  <span>pontos de atenção</span>
                </div>
              </div>
              <Link href="/painel">
                Abrir painel executivo <ArrowRight size={16} />
              </Link>
            </div>
          )}
          {step === 3 && (
            <div className="tour-actions">
              <span className="tour-panel-title">PLANO DE AÇÃO DE EXEMPLO</span>
              {state.actions.slice(0, 3).map(a => (
                <div key={a.id}>
                  <Flag size={18} />
                  <h3>{a.title}</h3>
                  <span>
                    {a.status} • {a.deadline}
                  </span>
                </div>
              ))}
              <Link href="/plano">
                Explorar o plano <ArrowRight size={16} />
              </Link>
            </div>
          )}
          {step === 4 && (
            <div className="tour-validation">
              <ShieldCheck size={42} strokeWidth={1} />
              <span className="tour-panel-title">ANTES DO USO REAL</span>
              {[
                "Validar critérios e método",
                "Delimitar o recorte do piloto",
                "Autorizar acesso e uso de dados",
                "Definir entregas e responsabilidades",
                "Revisar o modelo comercial",
              ].map(t => (
                <div key={t}>
                  <span />
                  <strong>{t}</strong>
                </div>
              ))}
              <p>
                Sem dados pessoais, conexão entre usuários ou integrações nesta
                demonstração.
              </p>
            </div>
          )}
        </div>
      </div>
      <footer className="presentation-footer">
        <div className="presentation-steps">
          {steps.map((s, i) => (
            <button
              key={s.label}
              className={i === step ? "selected" : i < step ? "visited" : ""}
              onClick={() => setStep(i)}
              aria-label={`Etapa ${i + 1}: ${s.label}`}
              aria-current={i === step ? "step" : undefined}
            >
              <span>{String(i + 1).padStart(2, "0")}</span>
              {s.label}
            </button>
          ))}
        </div>
        <div className="presentation-controls">
          <button
            className="button tour-button"
            disabled={step === 0}
            onClick={() => setStep(s => Math.max(s - 1, 0))}
            aria-label="Etapa anterior"
          >
            <ArrowLeft size={18} />
          </button>
          {step < steps.length - 1 ? (
            <button
              className="button hero-cta"
              onClick={() => setStep(s => s + 1)}
            >
              Próxima etapa <ArrowRight size={17} />
            </button>
          ) : (
            <Link href="/demonstracao" className="button hero-cta">
              Explorar o piloto <ArrowRight size={17} />
            </Link>
          )}
        </div>
      </footer>
    </main>
  );
}
