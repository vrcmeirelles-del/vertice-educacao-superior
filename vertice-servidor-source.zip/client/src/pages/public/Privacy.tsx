import React from "react";
import { PublicHeading } from "@/components/PublicLayout";
export default function Privacy() {
  return (
    <>
      <PublicHeading
        eyebrow="PRIVACIDADE E LIMITES"
        title="Informação protegida começa por limites claros."
        text="Esta página descreve o funcionamento desta versão do site público e da demonstração Vértice. Atualizada em 26 de outubro de 2026."
      />
      <article className="corp-container corp-section legal-copy">
        <section>
          <h2>Criação de conta e acesso autenticado</h2>
          <p>Quando habilitado, o acesso utiliza um provedor externo de autenticação. A aplicação recebe nome, e-mail, identificador do provedor, método de login e datas de criação e último acesso. A senha é fornecida ao provedor, não a este formulário. O cadastro próprio ainda não está disponível.</p>
          <p>Esses dados são usados para identificar a conta, manter a sessão e verificar as permissões. O tratamento necessário à prestação do serviço deve ser delimitado no contrato; obrigações legais e medidas de segurança possuem finalidades próprias. A ciência deste aviso não constitui consentimento genérico. Não há autorização de marketing nesta etapa.</p>
          <h2>Cookies, fornecedores e conservação</h2>
          <p>O acesso utiliza cookies técnicos de sessão e de validação da autenticação. No código desta versão, a sessão emitida no login dura até oito horas. O provedor de autenticação e a hospedagem podem tratar dados técnicos conforme suas políticas. A localização dos servidores, os fornecedores efetivamente contratados, os prazos de conservação e eventuais transferências internacionais ainda precisam ser identificados pelo responsável antes da abertura do serviço a dados reais.</p>
          <h2>Seus direitos</h2>
          <p>Nos termos da LGPD, o titular pode solicitar confirmação do tratamento, acesso, correção, informação sobre compartilhamento e, nas hipóteses aplicáveis, anonimização, bloqueio, eliminação, portabilidade e revogação de consentimento. Pode também peticionar à ANPD. A exclusão pode estar sujeita às hipóteses legais de conservação.</p>
          <p>A identificação jurídica do controlador e o canal oficial para exercício desses direitos ainda estão pendentes de confirmação. O serviço não deve abrir cadastro real enquanto essas informações não estiverem publicadas.</p>
          <h2>Medidas e limites de proteção</h2>
          <p>O código inclui validação da identidade do proprietário, cookies de sessão HttpOnly e Secure, limitação de requisições por processo, restrição de origem nas operações de escrita e cabeçalhos de segurança. Sua eficácia em produção depende de implantação e testes. Autenticação multifator, backups, restauração, auditoria e segregação completa entre instituições não estão atestados por este aviso. A demonstração usa dados fictícios e não deve receber dados pessoais reais.</p>
        </section>
        <section>
          <h2>Site público e briefing</h2>
          <p>
            As páginas apresentam a proposta e os serviços da consultoria. O
            formulário de contato apenas prepara texto na memória da página,
            para cópia manual. Não existe envio de mensagem ao servidor,
            cadastro de leads ou armazenamento do briefing pelo aplicativo. Os
            campos desaparecem ao sair ou recarregar a página.
          </p>
          <p>
            O canal comercial ainda está em configuração. Não há garantia de
            recebimento de solicitações a partir do formulário desta versão.
          </p>
        </section>
        <section>
          <h2>Armazenamento da demonstração</h2>
          <p>
            O demonstrador utiliza o armazenamento local do navegador, chamado
            localStorage, para manter critérios, metas, planos de ação e
            pendências fictícios que você edita. A chave é “vertice-piloto-v1”. Na primeira atualização de um cenário antigo, pode ser preservada uma cópia de histórico na chave “vertice-piloto-v1-antes-empresarial”. Remover os dados do site nas configurações do navegador apaga também esse histórico local.
            As alterações ficam no navegador e na origem do site em que foram
            feitas; não são sincronizadas entre pessoas, dispositivos ou
            domínios.
          </p>
          <p>
            Você pode exportar uma cópia JSON. A reimportação ainda não está
            disponível. Para restaurar os exemplos, utilize o comando da página
            de premissas, que pede confirmação. Também é possível remover o
            armazenamento local pelas configurações do navegador.
          </p>
        </section>
        <section>
          <h2>Dados que não devem ser inseridos</h2>
          <p>
            Não insira nomes de estudantes, documentos de identificação, dados
            de saúde, informações financeiras pessoais, avaliações individuais
            de funcionários ou documentos institucionais confidenciais. As
            referências de evidência são apenas texto; não há upload de anexos,
            proteção por conta ou ambiente multiusuário nesta demonstração.
          </p>
        </section>
        <section>
          <h2>Infraestrutura e fontes</h2>
          <p>
            A fonte Inter e a marca são servidas com o site. O aplicativo não
            instala analytics, publicidade ou rastreamento de visitantes nesta
            versão. A infraestrutura de hospedagem pode processar dados técnicos
            necessários ao acesso, segurança e operação; essa descrição não
            afirma que o provedor não mantém registros técnicos ou mecanismos
            próprios.
          </p>
          <p>
            Links externos levam a serviços com políticas próprias. A Vértice
            não representa nem integra plataformas externas de gestão.
            de outras instituições não são disponibilizados pelo site.
          </p>
        </section>
        <section>
          <h2>Uso real e contratação</h2>
          <p>
            Uma aplicação real com dados de instituições exige escopo
            contratado, definição de responsabilidades, finalidade, base legal,
            controle de acesso, retenção e medidas de segurança. Esses elementos
            não estão implementados no demonstrador. O site não oferece
            certificação, decisão regulatória nem promessa de resultado.
          </p>
        </section>
        <section>
          <h2>Contato sobre privacidade</h2>
          <p>
            O canal oficial será acrescentado após confirmação pelo responsável
            pela Vértice. Enquanto estiver pendente, não use o demonstrador como
            repositório de informação sensível ou como canal de atendimento.
          </p>
        </section>
      </article>
    </>
  );
}
