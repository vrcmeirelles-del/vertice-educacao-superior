import React from "react";
import { Link } from "wouter";
import { ArrowUpRight, Compass, ShieldCheck, Users } from "lucide-react";
import { PublicHeading, ConsultCTA } from "@/components/PublicLayout";
export default function About() {
  return (
    <>
      <PublicHeading
        eyebrow="A VÉRTICE"
        title="Gestão com clareza. Educação com responsabilidade."
        text="Vértice Educação Superior é uma proposta de consultoria estratégica e regulatória que aproxima experiência de gestão, evidências e execução."
      />
      <section className="corp-container corp-section about-composition">
        <div className="about-brand-panel">
          <img
            src="/brand/vertice-identidade-original.webp"
            alt="Identidade Vértice Educação Superior — Consultoria Estratégica e Regulatória. Clareza regulatória, solidez institucional."
            width="2048"
            height="1365"
          />
        </div>
        <div className="about-copy">
          <span className="corp-eyebrow">
            UMA PROPOSTA DO PROFESSOR VIRGÍLIO MEIRELLES
          </span>
          <h2>
            Apoiar quem decide.
            <br />
            Fortalecer quem executa.
          </h2>
          <p>
            A proposta parte de uma questão prática: como transformar a
            experiência de gestão acadêmica em um método compreensível,
            rastreável e útil para diferentes instituições?
          </p>
          <p>
            A Vértice organiza esse trabalho em diagnóstico, prioridades,
            indicadores e acompanhamento. A tecnologia apoia a leitura e o
            registro; a análise depende de contexto, escuta e responsabilidade.
          </p>
          <p>
            O foco é trabalhar com a gestão, não substituir suas instâncias de
            decisão. Cada instituição conserva sua autonomia, seus processos e a
            titularidade de seus dados.
          </p>
          <Link href="/metodo.html" className="corp-text-link">
            Conheça o ciclo de trabalho <ArrowUpRight size={17} />
          </Link>
        </div>
      </section>
      <section className="scope-band">
        <div className="corp-container">
          <span className="corp-eyebrow">
            COMPROMISSOS QUE ORIENTAM A PROPOSTA
          </span>
          <h2>Uma consultoria que explica o seu raciocínio.</h2>
          <div className="about-values">
            <article>
              <Compass size={26} />
              <h3>Clareza</h3>
              <p>
                Termos, fontes, unidades e limites explicados. A gestão precisa
                entender como a conclusão foi construída.
              </p>
            </article>
            <article>
              <ShieldCheck size={26} />
              <h3>Rigor</h3>
              <p>
                Estimativas não se tornam resultados. Intenções não se tornam
                aprovações. Evidências ficam próximas das decisões.
              </p>
            </article>
            <article>
              <Users size={26} />
              <h3>Cooperação</h3>
              <p>
                Prioridades pactuadas com as pessoas responsáveis pela execução
                e desenvolvimento das competências necessárias.
              </p>
            </article>
          </div>
        </div>
      </section>
      <ConsultCTA />
    </>
  );
}
