import { useEffect, useState, type FormEvent } from 'react';
import { Link } from 'wouter';
import { LockKeyhole } from 'lucide-react';
import { callbackToken, passwordCallback, supabase } from '@/lib/supabase';

function describeError(error: { code?: string; message?: string; status?: number }) {
  const code = error.code || '';
  const msg = (error.message || '').toLowerCase();
  if (code === 'same_password' || msg.includes('different from the old')) return 'A nova senha precisa ser diferente da anterior.';
  if (code === 'weak_password' || msg.includes('weak') || msg.includes('should contain')) return 'Senha fraca para a política de segurança. Combine letras maiúsculas, minúsculas, números e símbolos.';
  if (code === 'session_not_found' || code === 'session_expired' || msg.includes('session')) return 'Sua sessão de recuperação expirou. Solicite um novo link na página de acesso.';
  if (code === 'reauthentication_needed') return 'Por segurança, solicite um novo link e tente novamente.';
  if (error.status === 429) return 'Muitas tentativas em pouco tempo. Aguarde alguns minutos e tente novamente.';
  return 'Não foi possível salvar a senha. Solicite um novo link e tente novamente.';
}

export default function ResetPassword() {
  const [status, setStatus] = useState<'checking' | 'ready' | 'invalid' | 'done'>('checking');
  const [password, setPassword] = useState('');
  const [confirmation, setConfirmation] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  useEffect(() => {
    let active = true;
    // Aceita a sessão criada pelo link (recovery/invite) mesmo que o SDK a renove antes da checagem.
    const accept = (ok: boolean) => { if (active) setStatus(ok ? 'ready' : 'invalid'); };
    const { data: sub } = supabase.auth.onAuthStateChange((event, current) => {
      if (event === 'PASSWORD_RECOVERY' && current) accept(true);
    });
    supabase.auth.getSession().then(({ data, error }) => {
      if (error) { accept(false); return; }
      accept(Boolean(data.session && (passwordCallback || callbackToken)));
    }).catch(() => accept(false));
    return () => { active = false; sub.subscription.unsubscribe(); };
  }, []);
  async function submit(event: FormEvent) {
    event.preventDefault();
    if (password.length < 12) { setMessage('A senha precisa ter pelo menos 12 caracteres.'); return; }
    if (password !== confirmation) { setMessage('As senhas não coincidem.'); return; }
    setBusy(true); setMessage('');
    const { error } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (error) { setMessage(describeError(error)); return; }
    setPassword(''); setConfirmation('');
    await supabase.auth.signOut();
    setStatus('done');
  }
  return <section className="corp-section corp-login-section"><div className="corp-container corp-login-grid">
    <div className="corp-login-intro"><span className="corp-eyebrow">ÁREA RESTRITA</span><h1>Defina sua senha.</h1><p>Use o link recebido por e-mail para criar uma senha pessoal.</p></div>
    <div className="corp-login-card"><LockKeyhole size={30}/><h2>Definir nova senha</h2>
      {status === 'checking' && <p role="status">Validando seu link…</p>}
      {status === 'invalid' && <><p role="alert">O link é inválido, já foi usado ou expirou. Solicite um novo link na página de acesso.</p><Link href="/entrar" className="corp-button">Ir para o acesso</Link></>}
      {status === 'done' && <><p role="status">Senha atualizada. Entre com seu e-mail e sua nova senha.</p><a href="/entrar" className="corp-button">Ir para o acesso</a></>}
      {status === 'ready' && <form className="access-form" onSubmit={submit}>
        <label>Nova senha<input type="password" autoComplete="new-password" maxLength={256} required value={password} onChange={e => setPassword(e.target.value)}/></label>
        <label>Confirme a nova senha<input type="password" autoComplete="new-password" maxLength={256} required value={confirmation} onChange={e => setConfirmation(e.target.value)}/></label>
        <p>Use pelo menos 12 caracteres.</p><button className="corp-button corp-login-submit" disabled={busy}>{busy ? 'Salvando…' : 'Salvar nova senha'}</button>
        {message && <p role="alert">{message}</p>}
      </form>}
    </div></div></section>;
}
