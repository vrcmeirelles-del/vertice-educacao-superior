import { useEffect, useState, type FormEvent } from 'react';
import { Link } from 'wouter';
import { LockKeyhole } from 'lucide-react';
import { callbackToken, supabase } from '@/lib/supabase';

export default function ResetPassword() {
  const [status, setStatus] = useState<'checking' | 'ready' | 'invalid' | 'done'>('checking');
  const [password, setPassword] = useState('');
  const [confirmation, setConfirmation] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  useEffect(() => {
    let active = true;
    supabase.auth.getSession().then(({ data, error }) => {
      if (active) setStatus(!error && callbackToken && data.session?.access_token === callbackToken ? 'ready' : 'invalid');
    }).catch(() => { if (active) setStatus('invalid'); });
    return () => { active = false; };
  }, []);
  async function submit(event: FormEvent) {
    event.preventDefault();
    if (password !== confirmation) { setMessage('As senhas não coincidem.'); return; }
    setBusy(true); setMessage('');
    const { error } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (error) { setMessage('Não foi possível salvar a senha. Solicite um novo link e tente novamente.'); return; }
    setPassword(''); setConfirmation('');
    await supabase.auth.signOut();
    setStatus('done');
  }
  return <section className="corp-section corp-login-section"><div className="corp-container corp-login-grid">
    <div className="corp-login-intro"><span className="corp-eyebrow">ÁREA RESTRITA</span><h1>Defina sua senha.</h1><p>Use o link recebido por e-mail para criar uma senha pessoal.</p></div>
    <div className="corp-login-card"><LockKeyhole size={30}/><h2>Definir nova senha</h2>
      {status === 'checking' && <p role="status">Validando seu link…</p>}
      {status === 'invalid' && <><p role="alert">O link é inválido, já foi usado ou expirou. Solicite um novo link na página de acesso.</p><Link href="/entrar" className="corp-button">Ir para o acesso</Link></>}
      {status === 'done' && <><p role="status">Senha atualizada. Entre com seu e-mail e sua nova senha.</p><a href="/entrar" className="corp-button">Ir para o acesso</a></>}
      {status === 'ready' && <form className="access-form" onSubmit={submit}>
        <label>Nova senha<input type="password" autoComplete="new-password" minLength={12} maxLength={256} required value={password} onChange={e => setPassword(e.target.value)}/></label>
        <label>Confirme a nova senha<input type="password" autoComplete="new-password" minLength={12} maxLength={256} required value={confirmation} onChange={e => setConfirmation(e.target.value)}/></label>
        <p>Use pelo menos 12 caracteres.</p><button className="corp-button corp-login-submit" disabled={busy}>{busy ? 'Salvando…' : 'Salvar nova senha'}</button>
        {message && <p role="alert">{message}</p>}
      </form>}
    </div></div></section>;
}
