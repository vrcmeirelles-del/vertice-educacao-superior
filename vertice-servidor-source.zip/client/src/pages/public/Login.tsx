import { useEffect, useState } from "react";
import { Link } from "wouter";
import { ArrowUpRight, LockKeyhole, ShieldCheck } from "lucide-react";
import { startLogin } from "@/const";

type LoginStatus = { configured: boolean; authenticated: boolean; isOwner: boolean; email?: string | null };

export default function Login() {
  const [status, setStatus] = useState<LoginStatus | null>(null);
  const [checking, setChecking] = useState(true);
  const [message, setMessage] = useState("");
  const [recovery, setRecovery] = useState(false);
  useEffect(() => {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);
    fetch("/api/auth/status", { signal: controller.signal, credentials: "same-origin", cache: "no-store" })
      .then(async response => {
        if (!response.ok || !response.headers.get("content-type")?.includes("application/json")) throw new Error("unavailable");
        const value = await response.json();
        if (typeof value.configured !== "boolean" || typeof value.authenticated !== "boolean" || typeof value.isOwner !== "boolean") throw new Error("invalid response");
        setStatus(value);
      }).catch(() => setStatus(null)).finally(() => { clearTimeout(timeout); setChecking(false); });
    return () => { clearTimeout(timeout); controller.abort(); };
  }, []);
  const login = () => {
    setMessage("");
    try { startLogin(); } catch { setMessage("O serviço de login ainda não está disponível. Nenhuma sessão foi iniciada."); }
  };
  const logout = async () => {
    try {
      const response = await fetch("/api/auth/logout", { method: "POST", credentials: "same-origin" });
      if (!response.ok) throw new Error("logout failed");
      setStatus(previous => previous && { ...previous, authenticated: false, isOwner: false, email: null });
      setMessage("Você saiu da sua conta.");
    } catch { setMessage("Não foi possível encerrar a sessão. Tente novamente."); }
  };
  return <section className="corp-section corp-login-section">
    <div className="corp-container corp-login-grid">
      <div className="corp-login-intro"><span className="corp-eyebrow">ÁREA RESTRITA</span><h1>Seu espaço<br />de gestão.</h1><p>Acesse sua conta para acompanhar as instituições e atividades autorizadas para o seu perfil.</p><div className="corp-login-trust"><ShieldCheck size={22} /><p>O perfil de proprietário é validado no servidor. Cada conta acessa apenas os dados autorizados.</p></div><Link href="/demonstracao">Conhecer a demonstração <ArrowUpRight size={16} /></Link></div>
      <div className="corp-login-card"><LockKeyhole size={30} aria-hidden="true" /><h2>Entrar no Vértice</h2><p>Use sua conta no provedor de autenticação. Sua senha é informada diretamente no provedor.</p>
        {checking ? <p role="status">Verificando a disponibilidade do acesso…</p> : status?.authenticated ? <div><p>Sessão ativa: <strong>{status.email ?? "Conta autenticada"}</strong></p>{status.isOwner ? <Link href="/master" className="corp-button">Abrir painel do proprietário <ArrowUpRight size={16} /></Link> : <p>Sua conta está autenticada. O painel institucional compartilhado ainda está em implantação.</p>}<button className="corp-login-text-button" onClick={logout}>Sair da conta</button></div> : <>
          {status?.configured ? <button className="corp-button corp-login-submit" onClick={login}>Entrar com minha conta <ArrowUpRight size={16} /></button> : <div className="corp-login-notice" role="status"><strong>Acesso em implantação</strong><p>A área de login está pronta para receber a autenticação. O servidor de acesso ainda não está ativo neste endereço.</p><button className="corp-button corp-login-submit" disabled>Login indisponível no momento</button></div>}
          <button className="corp-login-text-button" onClick={() => setRecovery(value => !value)} aria-expanded={recovery}>Preciso recuperar meu acesso</button>
          {recovery && <div className="corp-login-help"><p>A recuperação de senha será feita pelo provedor de autenticação. Quando o login estiver disponível, entre pelo botão acima e use a opção de recuperação do provedor.</p><p>Não envie sua senha por e-mail ou mensagem.</p></div>}
        </>}
        {message && <p role="status">{message}</p>}
        <p className="corp-login-privacy">A demonstração continua disponível sem login. <Link href="/privacidade.html">Privacidade e uso dos dados</Link></p>
      </div>
    </div>
  </section>;
}
