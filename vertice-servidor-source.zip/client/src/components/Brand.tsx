import React from "react";
export function Brand({ compact = false }: { compact?: boolean }) {
  return compact ? (
    <img
      className="vertex-symbol"
      src="/brand/vertice-simbolo.webp"
      alt="Vértice"
      width="438"
      height="390"
    />
  ) : (
    <img
      className="vertex-brand"
      src="/brand/vertice-logo.webp"
      alt="Vértice Educação Superior"
      width="1703"
      height="390"
    />
  );
}
