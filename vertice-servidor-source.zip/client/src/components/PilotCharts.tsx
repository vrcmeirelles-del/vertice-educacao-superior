import { Link } from "wouter";
import {
  ArrowUpRight,
  CircleAlert,
  ClipboardCheck,
  Layers3,
  Target,
} from "lucide-react";
import {
  PolarAngleAxis,
  PolarGrid,
  PolarRadiusAxis,
  Radar,
  RadarChart,
  ResponsiveContainer,
  Tooltip,
} from "recharts";
import { attentionLevel, calculateResults, dimensions } from "@/lib/pilot";
import { usePilot } from "@/contexts/PilotContext";

export function LevelBadge({ score }: { score: number | null }) {
  const label = attentionLevel(score === null ? null : (score / 4) * 100);
  const tone =
    label === "Crítico"
      ? "red"
      : label === "Atenção"
        ? "amber"
        : label === "Consolidado"
          ? "green"
          : "gray";
  return (
    <span className={`badge ${tone}`}>
      <span />
      {label}
    </span>
  );
}
export function Stats({ dimension = "all" }: { dimension?: string }) {
  const { state } = usePilot();
  const result = calculateResults(
    state.criteria,
    dimension === "all" ? undefined : dimension
  );
  const items = [
    {
      label: "Índice de estruturação",
      value: result.score === null ? "—" : `${result.score}`,
      suffix: result.score === null ? "" : "/100",
      icon: Target,
      note: "Escore do cenário ilustrativo",
      color: "jade",
    },
    {
      label: "Critérios avaliados",
      value: result.answered.toString(),
      suffix: `/${result.total}`,
      icon: ClipboardCheck,
      note: `${Math.round(result.coverage)}% de preenchimento`,
      color: "navy",
    },
    {
      label: "Pontos de atenção",
      value: result.attention.toString().padStart(2, "0"),
      suffix: "",
      icon: CircleAlert,
      note: "Respostas abaixo de 3 na escala",
      color: "amber",
    },
    {
      label: "Ações em aberto",
      value: state.actions
        .filter(
          a =>
            a.status !== "Concluída" &&
            (dimension === "all" || a.dimension === dimension)
        )
        .length.toString()
        .padStart(2, "0"),
      suffix: "",
      icon: Layers3,
      note: "Iniciativas do plano demonstrativo",
      color: "blue",
    },
  ];
  return (
    <div className="stats-row">
      {items.map(i => (
        <div className={`stat-card ${i.color}`} key={i.label}>
          <div className="stat-label">
            {i.label}
            <span className="stat-icon">
              <i.icon size={18} strokeWidth={1.6} />
            </span>
          </div>
          <div className="stat-value">
            {i.value}
            <span>{i.suffix}</span>
          </div>
          <p>{i.note}</p>
        </div>
      ))}
    </div>
  );
}
export function DimensionProgress() {
  const { state } = usePilot();
  const result = calculateResults(state.criteria);
  return (
    <div className="dimension-progress">
      {result.byDimension.map(d => (
        <Link
          href={`/diagnostico?dimensao=${d.id}`}
          key={d.id}
          className="dimension-row"
        >
          <div className="dimension-name">
            <span style={{ background: d.color }} />
            {d.name}
            <ArrowUpRight size={14} />
          </div>
          <div className="dimension-track">
            <span style={{ width: `${d.score ?? 0}%`, background: d.color }} />
          </div>
          <strong>
            {d.score ?? "—"}
            <small>{d.score !== null ? "/100" : ""}</small>
          </strong>
        </Link>
      ))}
    </div>
  );
}
export function MaturityRadar() {
  const { state } = usePilot();
  const results = calculateResults(state.criteria);
  const chartData = results.byDimension.map(d => ({
    ...d,
    score: d.score ?? 0,
  }));
  return (
    <div className="radar-wrapper">
      <ResponsiveContainer width="100%" height={255}>
        <RadarChart data={chartData} outerRadius="72%">
          <PolarGrid stroke="#e0e7e4" />
          <PolarAngleAxis
            dataKey="short"
            tick={{
              fontSize: 11,
              fill: "#677774",
              fontFamily: "DM Sans, sans-serif",
            }}
          />
          <PolarRadiusAxis
            domain={[0, 100]}
            tick={false}
            axisLine={false}
            tickCount={5}
          />
          <Radar
            name="Índice ilustrativo"
            dataKey="score"
            stroke="#20856f"
            fill="#20856f"
            fillOpacity={0.14}
            strokeWidth={2}
            dot={{ r: 3, fill: "#20856f" }}
          />
          <Tooltip
            formatter={value => [`${value}/100`, "Índice ilustrativo"]}
            contentStyle={{
              borderRadius: 10,
              borderColor: "#e5e8e4",
              fontSize: 12,
            }}
          />
        </RadarChart>
      </ResponsiveContainer>
      <p>
        <span className="legend-dot" />
        Cenário demonstrativo • escala 0–100
      </p>
      {results.byDimension.some(d => d.score === null) && (
        <small>
          Dimensões sem respostas aparecem como zero apenas no desenho.
        </small>
      )}
    </div>
  );
}
export function ActionSummary() {
  const { state } = usePilot();
  return (
    <div className="action-summary">
      {state.actions
        .filter(a => a.status !== "Concluída")
        .slice(0, 3)
        .map((a, i) => (
          <Link href="/plano" className="action-summary-row" key={a.id}>
            <span className="action-number">0{i + 1}</span>
            <div>
              <strong>{a.title}</strong>
              <small>
                {dimensions.find(d => d.id === a.dimension)?.name}{" "}
                <span>•</span> {a.deadline}
              </small>
            </div>
            <span
              className={`badge ${a.priority === "Alta" ? "amber" : "gray"}`}
            >
              {a.priority}
            </span>
            <ArrowUpRight size={15} />
          </Link>
        ))}
      {!state.actions.some(a => a.status !== "Concluída") && (
        <p className="empty-state">
          Todas as ações do cenário foram concluídas.
        </p>
      )}
    </div>
  );
}
