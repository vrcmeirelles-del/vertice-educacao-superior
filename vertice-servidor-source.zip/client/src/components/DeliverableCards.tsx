import React from "react";
import { FileCheck2, BarChart3, Flag, ArrowUpRight } from "lucide-react";

export function DeliverableCards() {
  return (
    <div className="deliverable-grid">
      {/* Card 1: Matriz de Achados */}
      <article className="deliverable-card">
        <div className="card-header">
          <FileCheck2 size={24} />
          <span>Matriz de Achados</span>
        </div>
        <div className="card-preview">
          <div className="mock-table">
            <div className="mock-row header">
              <span>Critério</span>
              <span>Nível</span>
              <span>Ação</span>
            </div>
            <div className="mock-row">
              <span>Governança Acadêmica</span>
              <span className="badge warning">Atenção</span>
              <span>Revisar fluxos</span>
            </div>
            <div className="mock-row">
              <span>Captação de Alunos</span>
              <span className="badge success">Consolidado</span>
              <span>Manter ritmo</span>
            </div>
          </div>
        </div>
        <p className="card-desc">Mapeamento completo de requisitos, evidências e lacunas institucionais.</p>
      </article>

      {/* Card 2: Painel de Metas */}
      <article className="deliverable-card">
        <div className="card-header">
          <BarChart3 size={24} />
          <span>Painel de Metas</span>
        </div>
        <div className="card-preview">
          <div className="mock-chart">
            <div className="bar" style={{ height: '60%' }}></div>
            <div className="bar" style={{ height: '85%' }}></div>
            <div className="bar" style={{ height: '40%' }}></div>
            <div className="bar target" style={{ height: '90%' }}></div>
          </div>
          <div className="mock-stats">
            <span>Avanço: 62%</span>
            <span>Meta: 90%</span>
          </div>
        </div>
        <p className="card-desc">Acompanhamento visual de indicadores com cálculo auditável de avanço.</p>
      </article>

      {/* Card 3: Plano 5W2H */}
      <article className="deliverable-card">
        <div className="card-header">
          <Flag size={24} />
          <span>Plano de Ação</span>
        </div>
        <div className="card-preview">
          <div className="mock-list">
            <div className="mock-item">
              <span className="check-icon">✓</span>
              <span>Definir rito de priorização</span>
            </div>
            <div className="mock-item">
              <span className="check-icon">✓</span>
              <span>Mapear capacidade docente</span>
            </div>
            <div className="mock-item pending">
              <span className="circle-icon">○</span>
              <span>Implementar triagem de evasão</span>
            </div>
          </div>
        </div>
        <p className="card-desc">Execução organizada com responsáveis, prazos e recursos definidos.</p>
      </article>
    </div>
  );
}