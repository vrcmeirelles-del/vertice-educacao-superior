import { createClient } from '@supabase/supabase-js';
// Only the publishable key belongs in a browser. RLS controls data access.
export const supabase = createClient(
  'https://qvetbbmviatxxatzzuzc.supabase.co',
  'sb_publishable_id8AJN7W1v1TyYIp4R7yTg_gclHJ0T1',
  { auth: { persistSession: typeof window !== 'undefined', storage: typeof window !== 'undefined' ? window.sessionStorage : undefined, autoRefreshToken: true, detectSessionInUrl: true, flowType: 'pkce' } }
);
