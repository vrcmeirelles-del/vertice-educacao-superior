import type { Action } from "@/lib/pilot";

export type Goal = {
  id: string;
  title: string;
  axis: string;
  objective: string;
  unit: string;
  baseline: number | null;
  target: number | null;
  current: number | null;
  direction: "up" | "down";
  weight: number | null;
  period: string;
  owner: string;
  source: string;
  frequency: string;
};

/**
 * Indicadores totalmente fictícios para demonstrar o ciclo objetivos →
 * indicadores → ações → evidências → revisão. Nenhum valor representa uma
 * organização real ou deve ser tratado como dado institucional.
 */
export const initialGoals: Goal[] = [
  {
    id: "meta-captacao-alunos",
    title: "Captação de novos alunos",
    axis: "captacao",
    objective:
      "Aumentar a entrada sustentável de estudantes nas ofertas prioritárias.",
    unit: "alunos",
    baseline: 620,
    target: 760,
    current: 688,
    direction: "up",
    weight: 1.2,
    period: "Ano letivo demonstrativo",
    owner: "Liderança comercial (exemplo)",
    source: "Simulação local; validar com registros de captação.",
    frequency: "Mensal",
  },
  {
    id: "meta-permanencia-evasao",
    title: "Reduzir evasão e proteger a permanência",
    axis: "permanencia",
    objective:
      "Reduzir a evasão com sinais de alerta e acompanhamento de jornada.",
    unit: "%",
    baseline: 12.8,
    target: 8.5,
    current: null,
    direction: "down",
    weight: 1.4,
    period: "Ciclo acadêmico demonstrativo",
    owner: "Núcleo de permanência (exemplo)",
    source: "Simulação local; fonte ainda não aferida.",
    frequency: "Mensal",
  },
  {
    id: "meta-ocupacao-turma",
    title: "Ocupação média por turma",
    axis: "ocupacao",
    objective:
      "Equilibrar ocupação e capacidade para sustentar a experiência formativa.",
    unit: "alunos/turma",
    baseline: 28,
    target: 34,
    current: 31.5,
    direction: "up",
    weight: 1,
    period: "Semestre demonstrativo",
    owner: "Planejamento de oferta (exemplo)",
    source: "Simulação local; validar capacidade por turma.",
    frequency: "Quinzenal",
  },
  {
    id: "meta-margem-contribuicao",
    title: "Margem de contribuição",
    axis: "sustentabilidade",
    objective:
      "Ampliar a margem de contribuição sem perder qualidade ou acesso.",
    unit: "%",
    baseline: 21.4,
    target: 28,
    current: 25.2,
    direction: "up",
    weight: 1.1,
    period: "Ano fiscal demonstrativo",
    owner: "Gestão financeira (exemplo)",
    source: "Simulação local; validar premissas de custos e receitas.",
    frequency: "Mensal",
  },
  {
    id: "meta-auditoria-evidencias",
    title: "Conferência de evidências acadêmicas",
    axis: "governanca",
    objective:
      "Ampliar o atendimento aos itens de um checklist acadêmico fictício, sem certificar conformidade.",
    unit: "%",
    baseline: 48,
    target: 90,
    current: null,
    direction: "up",
    weight: 1,
    period: "Ciclo de gestão demonstrativo",
    owner: "Escritório de gestão (exemplo)",
    source: "Simulação local; amostra de evidências a definir.",
    frequency: "Trimestral",
  },
  {
    id: "meta-avaliacao-institucional",
    title: "Avaliação institucional",
    axis: "qualidade",
    objective:
      "Melhorar a percepção integrada de qualidade entre os públicos envolvidos.",
    unit: "0–5",
    baseline: 3.1,
    target: 4.2,
    current: 3.6,
    direction: "up",
    weight: 0.9,
    period: "Ciclo anual demonstrativo",
    owner: "Comitê de qualidade (exemplo)",
    source: "Simulação local; instrumento ainda em validação.",
    frequency: "Semestral",
  },
  {
    id: "meta-desempenho-academico",
    title: "Desempenho acadêmico: avaliação de aprendizagem",
    axis: "academico",
    objective:
      "Acompanhar acertos em avaliação interna fictícia; ENADE e exames profissionais exigem indicadores próprios.",
    unit: "%",
    baseline: 61,
    target: 74,
    current: 66,
    direction: "up",
    weight: 1.3,
    period: "Ciclo avaliativo demonstrativo",
    owner: "Coordenação acadêmica (exemplo)",
    source:
      "Percentual de acertos em uma avaliação interna fictícia; população e fonte a validar.",
    frequency: "Anual",
  },
];

type ProgressResult = {
  progress: number | null;
  reason: string;
  delta: number | null;
};

function finite(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}

function invalidConfiguration(goal: Goal): string | null {
  if (!finite(goal.weight) || goal.weight <= 0) {
    return "peso inválido: informe um número finito maior que zero";
  }
  if (!finite(goal.baseline) || !finite(goal.target)) {
    return "meta inválida: linha de base e meta precisam ser números finitos";
  }
  if (goal.direction === "up" && !(goal.target > goal.baseline)) {
    return "meta inválida: na direção de alta, a meta deve ser maior que a linha de base";
  }
  if (goal.direction === "down" && !(goal.target < goal.baseline)) {
    return "meta inválida: na direção de baixa, a meta deve ser menor que a linha de base";
  }
  if (goal.direction !== "up" && goal.direction !== "down") {
    return "meta inválida: direção desconhecida";
  }
  return null;
}

/**
 * Calcula avanço relativo à linha de base. O resultado é um avanço limitado a
 * 0–100 e não um indicador de aprovação ou de qualidade por si só.
 */
export function goalProgress(goal: Goal): ProgressResult {
  const configurationError = invalidConfiguration(goal);
  if (configurationError) {
    return { progress: null, reason: configurationError, delta: null };
  }
  if (goal.current === null) {
    return {
      progress: null,
      reason: "sem medição atual: progresso desconhecido",
      delta: null,
    };
  }
  if (!finite(goal.current)) {
    return {
      progress: null,
      reason: "medição atual inválida: informe um número finito",
      delta: null,
    };
  }

  const rawProgress =
    (100 * (goal.current - (goal.baseline as number))) /
    ((goal.target as number) - (goal.baseline as number));
  if (!finite(rawProgress)) {
    return {
      progress: null,
      reason: "progresso indefinido: divisão inválida",
      delta: null,
    };
  }

  const progress = Math.min(100, Math.max(0, rawProgress));
  const delta = goal.current - (goal.baseline as number);
  const reason =
    progress === rawProgress
      ? "avanço calculado entre linha de base e meta; não é indicador de aprovação"
      : "avanço limitado ao intervalo 0–100; não é indicador de aprovação";
  return { progress, reason, delta };
}

export function goalSummary(goals: Goal[]): {
  progress: number | null;
  measured: number;
  total: number;
  validWeight: number;
} {
  let measured = 0;
  let validWeight = 0;
  let weightedProgress = 0;

  for (const goal of goals) {
    const result = goalProgress(goal);
    if (result.progress === null || !finite(goal.weight) || goal.weight <= 0) {
      continue;
    }
    measured += 1;
    validWeight += goal.weight;
    weightedProgress += result.progress * goal.weight;
  }

  return {
    progress: validWeight > 0 ? weightedProgress / validWeight : null,
    measured,
    total: goals.length,
    validWeight,
  };
}

type EnrichedActionFields = {
  relatedGoal: string;
  why: string;
  how: string;
  where: string;
  information: string;
  plannedStart: string;
  plannedEnd: string;
  actualStart: string;
  actualEnd: string;
  budget: number | null;
  expectedReturn: number | null;
  tags: string[];
  observation: string;
  evidence: string;
  review: string;
};

/**
 * Preenche apenas campos de gestão ausentes em ações antigas. Datas de
 * execução e valores financeiros permanecem vazios/nulos até serem informados.
 */
export function enrichAction(action: Action): Action {
  const defaults: EnrichedActionFields = {
    relatedGoal: "",
    why: "",
    how: "",
    where: "",
    information: "",
    plannedStart: "",
    plannedEnd: "",
    actualStart: "",
    actualEnd: "",
    budget: null,
    expectedReturn: null,
    tags: [],
    observation: "",
    evidence: "",
    review: "",
  };
  const enriched = { ...defaults, ...action } as EnrichedActionFields & Action;
  if (!Array.isArray(enriched.tags)) enriched.tags = [];
  return enriched as Action;
}
