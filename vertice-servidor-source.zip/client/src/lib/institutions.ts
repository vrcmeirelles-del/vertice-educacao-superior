export type SectorRole =
  | "gestor"
  | "diagnostico"
  | "academico"
  | "academico-colegiado"
  | "evidencia"
  | "regulacao";

export type SectorAccess = {
  sectorId: string;
  label: string;
  role: SectorRole;
  canAnswer: boolean;
  canReview: boolean;
};

export type InstitutionCourse = {
  id: string;
  code: string;
  name: string;
  active: boolean;
};

export type Institution = {
  id: string;
  name: string;
  courses: InstitutionCourse[];
  sectors: SectorAccess[];
};

export type DiagnosticDraft = {
  institutionId: string;
  courseId?: string;
  dimension: string;
  criterionId: string;
  score: number | null;
  observation: string;
  evidence: string;
  recommendation: string;
};

export type DiagnosticResult = {
  institutionId: string;
  courseId: string;
  dimension: string;
  score: number | null;
  answered: number;
  total: number;
  attention: number;
  coverage: number;
};

export const emptyInstitution: Institution = {
  id: "",
  name: "",
  courses: [],
  sectors: [],
};
