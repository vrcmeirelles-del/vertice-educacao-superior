export type TrajectoryEntry = {
  period: string;
  role: string;
  institution: string;
  summary?: string;
};

export type PublicationEntry = {
  year: string;
  title: string;
  venue: string;
  href?: string;
};

export type TypicalSituation = {
  number: string;
  situation: string;
  reading: string;
  delivery: string;
  serviceId: string;
};

export const founder = {
  name: "Virgílio Meirelles",
  shortName: "Virgílio Meirelles",
  role: "Consultoria estratégica e regulatória para o ensino superior",
  headline: "Quem conduz o trabalho.",
  intro:
    "A Vértice é conduzida por Virgílio Meirelles. Cada trabalho parte da leitura de documentos, da escuta da gestão e de uma análise orientada à decisão institucional.",
  formation: [] as string[],
  areas: [
    "Governança Acadêmica",
    "Processos Avaliativos e Regulação",
    "Sustentabilidade Operacional",
    "Gestão de Dados Institucionais",
  ],
  credentials: [] as { label: string; detail: string }[],
  trajectory: [] as TrajectoryEntry[],
  publications: [] as PublicationEntry[],
  links: [] as { label: string; href: string }[],
};

export const typicalSituations: TypicalSituation[] = [
  {
    number: "01",
    situation: "O curso cresceu, mas a evasão também.",
    reading:
      "Antes de agir sobre a saída, é preciso distinguir trancamento, transferência e abandono, e identificar em que período e em que grupo o percurso perde força.",
    delivery:
      "Mapa da jornada por etapa, critérios de triagem e um plano de acolhimento pactuado com a coordenação.",
    serviceId: "permanencia",
  },
  {
    number: "02",
    situation:
      "A avaliação se aproxima e as evidências estão dispersas em pastas diferentes.",
    reading:
      "A questão raramente é a ausência de documentos, e sim a ausência de correspondência entre o que a instituição declara e o que consegue demonstrar.",
    delivery:
      "Matriz de requisitos, evidências e lacunas, com responsáveis e prazos de atualização documental.",
    serviceId: "academico",
  },
  {
    number: "03",
    situation: "Há oferta de turmas que não se sustenta.",
    reading:
      "Ocupação, carga horária e qualidade da formação precisam ser lidas juntas. Reduzir a decisão a uma razão numérica costuma transferir o problema adiante.",
    delivery:
      "Cenários operacionais com premissas explícitas, ligando demanda, ocupação, receita e custo.",
    serviceId: "sustentabilidade",
  },
  {
    number: "04",
    situation: "Todos medem, mas cada área apresenta um número diferente.",
    reading:
      "Indicadores divergentes geralmente vêm de definições divergentes: fonte, período, unidade e regra de cálculo não foram acordados antes da coleta.",
    delivery:
      "Dicionário de indicadores com regra de cálculo auditável e uma agenda de revisão com decisões registradas.",
    serviceId: "lideranca",
  },
];
