type MfaAuth={mfa:{
 getAuthenticatorAssuranceLevel:()=>Promise<{data:{currentLevel:string|null}|null;error:unknown}>;
 listFactors:()=>Promise<{data:{totp:{id:string;status:string}[]}|null;error:unknown}>;
}};

export async function passwordMfaFactor(auth:MfaAuth):Promise<string|null>{
 const assurance=await auth.mfa.getAuthenticatorAssuranceLevel();
 if(assurance.error)throw assurance.error;
 if(assurance.data?.currentLevel==='aal2')return null;
 const factors=await auth.mfa.listFactors();
 if(factors.error)throw factors.error;
 return factors.data?.totp.find(f=>f.status==='verified')?.id??null;
}

export function passwordChangeError(error:{code?:string;message?:string;status?:number}){
 const msg=(error.message||'').toLowerCase();
 if(error.code==='insufficient_aal'||msg.includes('aal2'))return 'Confirme o código do seu aplicativo autenticador antes de alterar a senha.';
 if(error.code==='same_password'||msg.includes('different from the old'))return 'A nova senha precisa ser diferente da anterior.';
 if(error.code==='weak_password'||msg.includes('weak')||msg.includes('should contain'))return 'Senha fraca. Combine letras maiúsculas, minúsculas, números e símbolos.';
 if(error.status===429)return 'Muitas tentativas. Aguarde alguns minutos e tente novamente.';
 if(error.code==='session_not_found'||error.code==='session_expired'||msg.includes('session'))return 'Sua sessão de recuperação expirou. Solicite um novo link na página de acesso.';
 return 'Não foi possível salvar a senha. Solicite um novo link e tente novamente.';
}
