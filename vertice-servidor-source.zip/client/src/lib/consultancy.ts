export const company = {
  name: "Vértice Educação Superior",
  descriptor: "Consultoria Estratégica e Regulatória",
  slogan: "Clareza regulatória, solidez institucional.",
  founder: "Professor Virgílio Meirelles",
  email: "",
  whatsapp: "",
  requestedDomain: "www.verticesuperior.com.br",
};

export const services = [
  {
    id: "estrategia",
    number: "01",
    title: "Estratégia e governança",
    description:
      "Conectar a direção institucional à rotina de gestão, com prioridades, responsabilidades e critérios para decidir.",
    deliverables: [
      "Diagnóstico estratégico e mapa de prioridades",
      "Objetivos, indicadores e agenda de decisões",
      "Plano de ação e ritos de acompanhamento",
    ],
    question: "O que precisa mudar — e quem conduz essa mudança?",
  },
  {
    id: "academico",
    number: "02",
    title: "Qualidade e conformidade acadêmica",
    description:
      "Organizar documentos, processos e evidências para uma leitura consistente da realidade acadêmica e dos requisitos aplicáveis.",
    deliverables: [
      "Matriz de requisitos, evidências e lacunas",
      "Preparação para avaliações e revisão documental",
      "Plano de melhoria ligado à avaliação institucional",
    ],
    question: "Que evidências sustentam a qualidade que a instituição declara?",
  },
  {
    id: "permanencia",
    number: "03",
    title: "Captação e permanência",
    description:
      "Acompanhar o ingresso e a trajetória dos estudantes, investigando causas e organizando ações de acolhimento e continuidade.",
    deliverables: [
      "Mapa da jornada e indicadores por etapa",
      "Triagem preventiva com critérios e proteção de dados",
      "Plano integrado de captação, apoio e permanência",
    ],
    question: "Onde a jornada perde força — e como agir antes da saída?",
  },
  {
    id: "sustentabilidade",
    number: "04",
    title: "Sustentabilidade e capacidade",
    description:
      "Relacionar demanda, ocupação de turmas, recursos e sustentabilidade operacional sem separar eficiência da qualidade da formação.",
    deliverables: [
      "Análise de ocupação e capacidade de oferta",
      "Premissas e cenários operacionais auditáveis",
      "Indicadores de receita, custos e margem definidos com a gestão",
    ],
    question: "A oferta faz sentido para os estudantes e para a instituição?",
  },
  {
    id: "pesquisa",
    number: "05",
    title: "Pesquisa e pós-graduação",
    description:
      "Mapear vocação, capacidade e requisitos para decisões responsáveis sobre pesquisa, pós-graduação e possibilidades de expansão.",
    deliverables: [
      "Mapa de capacidade e lacunas de pesquisa",
      "Estudo de viabilidade e caminhos de desenvolvimento",
      "Marcos de decisão e preparação documental",
    ],
    question: "Que condições precisam existir antes de avançar?",
  },
  {
    id: "lideranca",
    number: "06",
    title: "Dados, liderança e desenvolvimento",
    description:
      "Tornar os indicadores compreensíveis e desenvolver as pessoas que transformam informação em decisão e execução.",
    deliverables: [
      "Dicionário de indicadores e regras de cálculo",
      "Planos de desenvolvimento individual e feedback",
      "Painéis, reuniões de revisão e memória das decisões",
    ],
    question: "A equipe consegue interpretar, agir e aprender com os dados?",
  },
];

export const managementAxes = [
  {
    title: "Captação",
    text: "Do interesse à matrícula: acompanhar volume, conversão e canais com definições consistentes.",
  },
  {
    title: "Permanência",
    text: "Investigar evasão e sinais de risco por período e grupo, sem confundir intenção com saída efetiva.",
  },
  {
    title: "Ocupação de turmas",
    text: "Relacionar alunos, capacidade, carga horária e qualidade — sem reduzir a formação a uma razão numérica.",
  },
  {
    title: "Sustentabilidade",
    text: "Definir receitas, custos e margem com fontes e critérios comparáveis, explicitando estimativas.",
  },
  {
    title: "Auditoria acadêmica",
    text: "Verificar evidências contra requisitos, com escopo, registros e responsáveis claros.",
  },
  {
    title: "Avaliação institucional",
    text: "Traduzir a escuta da comunidade em prioridades e acompanhar a execução das melhorias.",
  },
  {
    title: "Desempenho acadêmico",
    text: "Examinar aprendizagem, conclusão e avaliações externas, inclusive exames profissionais quando aplicáveis.",
  },
];

export const cycle = [
  {
    number: "01",
    title: "Diagnosticar",
    text: "Definir o escopo, ouvir a gestão e conferir documentos, fontes e lacunas.",
    output: "Diagnóstico e mapa de evidências",
  },
  {
    number: "02",
    title: "Alinhar",
    text: "Escolher objetivos e indicadores com linha de base, meta, unidade e prazo.",
    output: "Prioridades e metas pactuadas",
  },
  {
    number: "03",
    title: "Executar",
    text: "Transformar cada prioridade em ações com responsável, recursos e evidências.",
    output: "Plano 5W2H conectado às metas",
  },
  {
    number: "04",
    title: "Desenvolver",
    text: "Apoiar lideranças com feedback e planos de desenvolvimento das competências necessárias.",
    output: "Agenda de desenvolvimento e apoio",
  },
  {
    number: "05",
    title: "Revisar",
    text: "Comparar o observado com o planejado, investigar causas e registrar a decisão seguinte.",
    output: "Revisão do ciclo e memória de decisões",
  },
];

export const faqs = [
  {
    question: "A Vértice substitui o sistema acadêmico da instituição?",
    answer:
      "Não. A consultoria organiza diagnóstico, prioridades e acompanhamento. Sistemas acadêmicos e comerciais continuam com suas funções; qualquer integração deve ser avaliada tecnicamente e contratada em escopo próprio.",
  },
  {
    question: "O trabalho começa pela instituição inteira?",
    answer:
      "Não necessariamente. O primeiro ciclo pode abranger um curso, um processo ou uma frente de gestão. O escopo e as fontes são definidos em conjunto antes da coleta de informações.",
  },
  {
    question: "Há garantia de aprovação regulatória ou crescimento?",
    answer:
      "Não. A proposta é apoiar decisões e preparação com evidências. Resultados dependem da realidade institucional, da execução e dos requisitos e processos das instâncias competentes.",
  },
  {
    question: "O que posso testar na demonstração?",
    answer:
      "Você pode editar critérios, metas e ações fictícias. As alterações ficam somente no seu navegador e podem ser exportadas. Não há conta, colaboração entre pessoas, anexos nem integração com sistemas nesta versão.",
  },
];

export const publicPages = [
  {
    path: "/",
    title: "Vértice Educação Superior | Estratégia e Regulação",
    description:
      "Consultoria estratégica e regulatória para instituições de ensino superior. Diagnóstico, metas e acompanhamento com clareza e evidências.",
  },
  {
    path: "/servicos",
    title: "Serviços de consultoria | Vértice Educação Superior",
    description:
      "Conheça as frentes de estratégia, qualidade acadêmica, captação, permanência, sustentabilidade, pesquisa e desenvolvimento de lideranças.",
  },
  {
    path: "/metodo",
    title: "Nosso método de gestão | Vértice Educação Superior",
    description:
      "Um ciclo que conecta diagnóstico, objetivos, indicadores, planos de ação, desenvolvimento e revisão para apoiar a gestão do ensino superior.",
  },
  {
    path: "/sobre",
    title: "Sobre a consultoria | Vértice Educação Superior",
    description:
      "Vértice Educação Superior: consultoria estratégica e regulatória proposta pelo Professor Virgílio Meirelles, com foco em decisões fundamentadas.",
  },
  {
    path: "/fundador",
    title: "Quem conduz o trabalho | Vértice Educação Superior",
    description:
      "Professor Virgílio Meirelles: como o trabalho de consultoria é conduzido, situações típicas do ensino superior e produção acadêmica e técnica.",
  },
  {
    path: "/contato",
    title: "Prepare seu briefing | Vértice Educação Superior",
    description:
      "Organize o desafio da sua instituição para uma conversa sobre diagnóstico e acompanhamento. Prepare um briefing sem enviar dados sensíveis.",
  },
  {
    path: "/privacidade",
    title: "Privacidade e limites | Vértice Educação Superior",
    description:
      "Entenda os dados utilizados pelo site e pelo demonstrador local da Vértice, os limites de armazenamento e os cuidados com informações institucionais.",
  },
];
