import { initialGoals, type Goal } from "./management";

export type Dimension = {
  id: string;
  name: string;
  short: string;
  description: string;
  color: string;
};

export type Criterion = {
  id: string;
  dimension: string;
  question: string;
  score: number | null;
  observation: string;
  evidence: string;
  recommendation: string;
};

export type Action = {
  id: string;
  title: string;
  dimension: string;
  owner: string;
  deadline: string;
  priority: "Alta" | "Média" | "Baixa";
  status: "A fazer" | "Em andamento" | "Concluída";
  relatedGoal?: string;
  why?: string;
  how?: string;
  where?: string;
  information?: string;
  plannedStart?: string;
  plannedEnd?: string;
  actualStart?: string;
  actualEnd?: string;
  budget?: number | null;
  expectedReturn?: number | null;
  tags?: string[];
  observation?: string;
  evidence?: string;
  review?: string;
};

export type Pending = {
  id: string;
  title: string;
  detail: string;
  done: boolean;
};

export type PilotState = {
  criteria: Criterion[];
  actions: Action[];
  pending: Pending[];
  goals: Goal[];
};

/**
 * Catálogo fixo do piloto. Os IDs não têm acentos para permanecerem estáveis
 * em filtros, URLs e integrações futuras. Todos os dados abaixo são fictícios.
 */
export const dimensions: Dimension[] = [
  {
    id: "governanca",
    name: "Governança",
    short: "GOV",
    description:
      "Direção, prioridades, papéis e cadência para orientar o crescimento.",
    color: "#328ea8",
  },
  {
    id: "academico",
    name: "Acadêmico",
    short: "ACA",
    description:
      "Qualidade da proposta formativa, aprendizagem e desenvolvimento docente.",
    color: "#61758a",
  },
  {
    id: "permanencia",
    name: "Permanência",
    short: "PER",
    description:
      "Acolhimento, acompanhamento da jornada e apoio à continuidade dos estudantes.",
    color: "#427f9a",
  },
  {
    id: "expansao",
    name: "Expansão",
    short: "EXP",
    description:
      "Crescimento responsável de ofertas, canais e parcerias institucionais.",
    color: "#8c9baa",
  },
  {
    id: "pesquisa_stricto_sensu",
    name: "Pesquisa / Stricto sensu",
    short: "PES",
    description:
      "Capacidade de pesquisa e estudo cuidadoso de possíveis caminhos de pós-graduação.",
    color: "#516581",
  },
  {
    id: "dados",
    name: "Dados",
    short: "DAT",
    description:
      "Definições, qualidade, proteção e uso responsável de informações educacionais.",
    color: "#7799ad",
  },
];

const fictitiousEvidence =
  "[FICTÍCIO] Exemplo demonstrativo; validar com fontes institucionais.";

export const initialState: PilotState = {
  goals: initialGoals,
  criteria: [
    {
      id: "governanca_01",
      dimension: "governanca",
      question:
        "A instituição possui objetivos de crescimento educacional formalizados e compartilhados?",
      score: 3,
      observation:
        "[FICTÍCIO] Há uma direção geral, mas a comunicação entre áreas pode ser mais regular.",
      evidence: fictitiousEvidence,
      recommendation:
        "Como próximo passo, registrar objetivos, premissas e responsáveis em um plano revisável.",
    },
    {
      id: "governanca_02",
      dimension: "governanca",
      question:
        "Há papéis e ritos de decisão definidos para priorizar iniciativas de crescimento?",
      score: 2,
      observation:
        "[FICTÍCIO] Algumas decisões têm responsáveis conhecidos, sem um rito único entre áreas.",
      evidence: fictitiousEvidence,
      recommendation:
        "Testar uma cadência simples de priorização, com critérios explícitos e ata de decisões.",
    },
    {
      id: "governanca_03",
      dimension: "governanca",
      question:
        "O acompanhamento do plano inclui revisão periódica, responsáveis e próximos passos?",
      score: null,
      observation:
        "[FICTÍCIO] Não há registro suficiente para avaliar a rotina de revisão.",
      evidence: fictitiousEvidence,
      recommendation:
        "Definir uma primeira revisão em D+30, sem presumir resultados antes de reunir evidências.",
    },
    {
      id: "academico_01",
      dimension: "academico",
      question:
        "As trilhas formativas têm resultados de aprendizagem e critérios de qualidade explicitados?",
      score: 3,
      observation:
        "[FICTÍCIO] Os resultados estão descritos em parte das trilhas demonstrativas.",
      evidence: fictitiousEvidence,
      recommendation:
        "Revisar a matriz de resultados e testar sua compreensão com docentes e estudantes.",
    },
    {
      id: "academico_02",
      dimension: "academico",
      question:
        "A formação docente recebe apoio para inovação pedagógica e avaliação de aprendizagem?",
      score: 3,
      observation:
        "[FICTÍCIO] Existe apoio pontual, ainda sem uma agenda comum de desenvolvimento.",
      evidence: fictitiousEvidence,
      recommendation:
        "Propor uma oficina-piloto e avaliar sua utilidade antes de ampliar a iniciativa.",
    },
    {
      id: "academico_03",
      dimension: "academico",
      question:
        "A oferta acadêmica é revisada com base em evidências de demanda e capacidade?",
      score: 2,
      observation:
        "[FICTÍCIO] A revisão combina percepções e registros parciais de capacidade.",
      evidence: fictitiousEvidence,
      recommendation:
        "Consolidar fontes e critérios de revisão, tratando os sinais como hipóteses até validação.",
    },
    {
      id: "permanencia_01",
      dimension: "permanencia",
      question:
        "Existem sinais de alerta e rotinas de acolhimento para reduzir evasão?",
      score: 2,
      observation:
        "[FICTÍCIO] Há iniciativas de acolhimento, mas os sinais e encaminhamentos variam.",
      evidence: fictitiousEvidence,
      recommendation:
        "Desenhar um fluxo mínimo de acolhimento e acompanhar sua execução em pequena escala.",
    },
    {
      id: "permanencia_02",
      dimension: "permanencia",
      question:
        "A instituição acompanha jornada e conclusão por coortes de forma ética?",
      score: 3,
      observation:
        "[FICTÍCIO] O acompanhamento por turma é possível em alguns registros de demonstração.",
      evidence: fictitiousEvidence,
      recommendation:
        "Validar definições, permissões e limites de uso antes de comparar coortes.",
    },
    {
      id: "permanencia_03",
      dimension: "permanencia",
      question:
        "As ações de apoio têm responsáveis, prazos e critérios de reavaliação?",
      score: null,
      observation:
        "[FICTÍCIO] Não foi apresentada evidência demonstrativa suficiente sobre reavaliação.",
      evidence: fictitiousEvidence,
      recommendation:
        "Registrar responsável, prazo e critério de reavaliação para cada ação de apoio.",
    },
    {
      id: "expansao_01",
      dimension: "expansao",
      question:
        "A expansão de cursos ou polos considera capacidade, demanda e sustentabilidade?",
      score: 3,
      observation:
        "[FICTÍCIO] O planejamento considera esses fatores, porém ainda em nível preliminar.",
      evidence: fictitiousEvidence,
      recommendation:
        "Montar uma matriz de cenários e explicitar as premissas antes de qualquer decisão.",
    },
    {
      id: "expansao_02",
      dimension: "expansao",
      question:
        "Parcerias e novos canais passam por critérios de alinhamento pedagógico e institucional?",
      score: 2,
      observation:
        "[FICTÍCIO] Há avaliação caso a caso, sem checklist compartilhado.",
      evidence: fictitiousEvidence,
      recommendation:
        "Criar um checklist de alinhamento e submetê-lo à revisão das áreas envolvidas.",
    },
    {
      id: "expansao_03",
      dimension: "expansao",
      question:
        "Existe plano de implantação gradual com riscos e pontos de decisão?",
      score: 3,
      observation:
        "[FICTÍCIO] O plano demonstrativo tem fases, mas os pontos de pausa ainda são genéricos.",
      evidence: fictitiousEvidence,
      recommendation:
        "Definir critérios de pausa e aprendizado para um piloto antes de considerar escala.",
    },
    {
      id: "pesquisa_stricto_sensu_01",
      dimension: "pesquisa_stricto_sensu",
      question:
        "Há agenda de pesquisa aplicada conectada aos desafios da formação?",
      score: 1,
      observation:
        "[FICTÍCIO] Existem interesses iniciais, sem agenda priorizada e compartilhada.",
      evidence: fictitiousEvidence,
      recommendation:
        "Mapear temas e capacidade disponível, mantendo a agenda como hipótese de trabalho.",
    },
    {
      id: "pesquisa_stricto_sensu_02",
      dimension: "pesquisa_stricto_sensu",
      question:
        "A capacidade para stricto sensu está em estudo com requisitos e lacunas explicitados?",
      score: null,
      observation:
        "[FICTÍCIO] A capacidade e as lacunas ainda não foram documentadas para este piloto.",
      evidence: fictitiousEvidence,
      recommendation:
        "Fazer um estudo de viabilidade com requisitos aplicáveis; não presumir autorização ou cronograma.",
    },
    {
      id: "pesquisa_stricto_sensu_03",
      dimension: "pesquisa_stricto_sensu",
      question:
        "Decisões sobre eventual oferta futura dependem de validação regulatória e institucional?",
      score: 2,
      observation:
        "[FICTÍCIO] A intenção de validação foi registrada, mas o fluxo ainda não está definido.",
      evidence: fictitiousEvidence,
      recommendation:
        "Identificar instâncias competentes e validar requisitos antes de comunicar qualquer possibilidade futura.",
    },
    {
      id: "dados_01",
      dimension: "dados",
      question: "As definições de indicadores e fontes estão documentadas?",
      score: 2,
      observation:
        "[FICTÍCIO] Há indicadores sugeridos, com definições e fontes ainda incompletas.",
      evidence: fictitiousEvidence,
      recommendation:
        "Construir um dicionário mínimo de indicadores e marcar campos sem fonte oficial.",
    },
    {
      id: "dados_02",
      dimension: "dados",
      question:
        "Há governança de acesso, qualidade e proteção para dados educacionais?",
      score: 3,
      observation:
        "[FICTÍCIO] Alguns controles são conhecidos, mas a governança completa não foi verificada.",
      evidence: fictitiousEvidence,
      recommendation:
        "Validar acessos, responsabilidades e critérios de qualidade com as áreas competentes.",
    },
    {
      id: "dados_03",
      dimension: "dados",
      question:
        "Painéis e relatórios permitem acompanhar tendências sem substituir análise contextual?",
      score: 2,
      observation:
        "[FICTÍCIO] O painel conceitual mostra tendências, ainda sem contexto e notas metodológicas.",
      evidence: fictitiousEvidence,
      recommendation:
        "Adicionar contexto, limitações e notas de interpretação antes de usar o painel em decisões.",
    },
  ],
  actions: [
    {
      id: "acao_governanca_30",
      title: "Formalizar objetivos e rito de priorização do piloto",
      dimension: "governanca",
      owner: "Direção acadêmica (exemplo)",
      deadline: "D+30",
      priority: "Alta",
      status: "A fazer",
    },
    {
      id: "acao_academico_45",
      title: "Revisar resultados de aprendizagem de uma trilha",
      dimension: "academico",
      owner: "Coordenação pedagógica (exemplo)",
      deadline: "D+45",
      priority: "Média",
      status: "A fazer",
    },
    {
      id: "acao_permanencia_30",
      title: "Desenhar fluxo-piloto de acolhimento e acompanhamento",
      dimension: "permanencia",
      owner: "Núcleo de apoio ao estudante (exemplo)",
      deadline: "D+30",
      priority: "Alta",
      status: "Em andamento",
    },
    {
      id: "acao_expansao_60",
      title: "Testar matriz de cenários para uma iniciativa de expansão",
      dimension: "expansao",
      owner: "Planejamento institucional (exemplo)",
      deadline: "D+60",
      priority: "Média",
      status: "A fazer",
    },
    {
      id: "acao_pesquisa_90",
      title: "Preparar estudo de viabilidade para pesquisa e pós-graduação",
      dimension: "pesquisa_stricto_sensu",
      owner: "Coordenação de pesquisa (exemplo)",
      deadline: "D+90",
      priority: "Baixa",
      status: "A fazer",
    },
    {
      id: "acao_dados_60",
      title: "Definir dicionário mínimo e responsabilidades dos indicadores",
      dimension: "dados",
      owner: "Tecnologia e dados (exemplo)",
      deadline: "D+60",
      priority: "Alta",
      status: "A fazer",
    },
  ],
  pending: [
    {
      id: "pendente_mereu_link",
      title: "Referência de gestão identificada",
      detail:
        "Utilizamos princípios gerais de gestão educacional, sem cópia de dados, interface ou integração técnica com plataformas externas.",
      done: true,
    },
    {
      id: "pendente_questoes",
      title: "Questões do diagnóstico",
      detail:
        "Validar a redação e a ordem das questões com as áreas responsáveis; conteúdo atual é demonstrativo.",
      done: false,
    },
    {
      id: "pendente_metricas_oficiais",
      title: "Métricas oficiais",
      detail:
        "Substituir exemplos por definições e fontes oficiais somente após validação institucional.",
      done: false,
    },
    {
      id: "pendente_identidade",
      title: "Identidade visual",
      detail:
        "Identidade Vértice Educação Superior aprovada pelo proponente: marinho, cinza e ciano. Site empresarial separado dos materiais institucionais.",
      done: true,
    },
    {
      id: "pendente_autorizacao",
      title: "Autorização",
      detail:
        "Obter autorização institucional para uso, circulação e eventual coleta de informações.",
      done: false,
    },
    {
      id: "pendente_validacao_regulatoria",
      title: "Validação regulatória",
      detail:
        "Consultar as instâncias competentes para qualquer hipótese de oferta futura; não há autorização presumida.",
      done: false,
    },
  ],
};

function isValidScore(score: number | null): score is number {
  return score !== null && Number.isInteger(score) && score >= 0 && score <= 4;
}

function summarize(criteria: Criterion[]): {
  score: number | null;
  answered: number;
  total: number;
  attention: number;
} {
  const total = criteria.length;
  const answeredScores = criteria
    .map(criterion => criterion.score)
    .filter(isValidScore);
  const answered = answeredScores.length;
  const attention = answeredScores.filter(score => score < 3).length;

  if (answered === 0) {
    return { score: null, answered, total, attention };
  }

  const mean = answeredScores.reduce((sum, score) => sum + score, 0) / answered;
  return {
    score: Math.round((mean / 4) * 100),
    answered,
    total,
    attention,
  };
}

export function calculateResults(
  criteria: Criterion[],
  dimensionId?: string
): {
  score: number | null;
  answered: number;
  total: number;
  attention: number;
  coverage: number;
  byDimension: {
    id: string;
    name: string;
    short: string;
    color: string;
    score: number | null;
    answered: number;
    total: number;
  }[];
} {
  const selectedCriteria =
    dimensionId === undefined
      ? criteria
      : criteria.filter(criterion => criterion.dimension === dimensionId);
  const overall = summarize(selectedCriteria);

  return {
    ...overall,
    coverage:
      overall.total === 0 ? 0 : (overall.answered / overall.total) * 100,
    byDimension: dimensions.map(dimension => {
      const summary = summarize(
        criteria.filter(criterion => criterion.dimension === dimension.id)
      );
      return {
        id: dimension.id,
        name: dimension.name,
        short: dimension.short,
        color: dimension.color,
        score: summary.score,
        answered: summary.answered,
        total: summary.total,
      };
    }),
  };
}

export function attentionLevel(
  score: number | null
): "Sem avaliação" | "Crítico" | "Atenção" | "Consolidado" {
  if (score === null || !Number.isFinite(score)) {
    return "Sem avaliação";
  }
  if (score < 50) {
    return "Crítico";
  }
  if (score < 75) {
    return "Atenção";
  }
  return "Consolidado";
}

function csvCell(value: unknown): string {
  const text = value === null || value === undefined ? "" : String(value);
  const safeText = /^[\t\r\n ]*[=+\-@]/.test(text) ? `'${text}` : text;
  const escaped = safeText.replaceAll('"', '""');
  return /[",\r\n]/.test(safeText) ? `"${escaped}"` : safeText;
}

export function toCsv(criteria: Criterion[]): string {
  const header = [
    "id",
    "dimension",
    "question",
    "score",
    "observation",
    "evidence",
    "recommendation",
  ];
  const rows = criteria.map(criterion => [
    criterion.id,
    criterion.dimension,
    criterion.question,
    criterion.score,
    criterion.observation,
    criterion.evidence,
    criterion.recommendation,
  ]);

  return (
    [header, ...rows].map(row => row.map(csvCell).join(",")).join("\n") + "\n"
  );
}
