import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Tabela de Instituições de Ensino Superior (IES)
 */
export const institutions = mysqlTable("institutions", {
  id: varchar("id", { length: 64 }).primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  cnpj: varchar("cnpj", { length: 18 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/**
 * Tabela de Cursos vinculados a uma IES
 */
export const courses = mysqlTable("courses", {
  id: varchar("id", { length: 64 }).primaryKey(),
  institutionId: varchar("institutionId", { length: 64 }).notNull().references(() => institutions.id),
  code: varchar("code", { length: 32 }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  active: mysqlEnum("active", ["true", "false"]).default("true").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/**
 * Tabela de Usuários do sistema (expansão da tabela users existente ou nova se necessário)
 * Nota: A tabela 'users' já existe para auth. Vamos adicionar um vínculo com a IES.
 */
export const userInstitutionRoles = mysqlTable("user_institution_roles", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  institutionId: varchar("institutionId", { length: 64 }).notNull().references(() => institutions.id),
  role: mysqlEnum("role", ["admin", "gestor", "analista", "revisor"]).notNull(),
  sector: varchar("sector", { length: 128 }), // Ex: 'academico', 'financeiro'
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Institution = typeof institutions.$inferSelect;
export type InsertInstitution = typeof institutions.$inferInsert;
export type Course = typeof courses.$inferSelect;
export type InsertCourse = typeof courses.$inferInsert;
export type UserInstitutionRole = typeof userInstitutionRoles.$inferSelect;
export type InsertUserInstitutionRole = typeof userInstitutionRoles.$inferInsert;