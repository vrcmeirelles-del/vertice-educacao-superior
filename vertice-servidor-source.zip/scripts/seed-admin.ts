import { eq } from "drizzle-orm";
import { pathToFileURL } from "node:url";
import { getDb } from "../server/db";
import { users, type InsertUser } from "../drizzle/schema";

async function seedAdmin() {
  const db = await getDb();
  if (!db) {
    console.log("[Seed] Banco de dados não disponível. Pulei o seed.");
    return;
  }

  const adminOpenId = process.env.ADMIN_OPEN_ID?.trim();

  if (!adminOpenId) {
    console.log("[Seed] ADMIN_OPEN_ID não configurado; nenhum administrador criado.");
    return;
  }

  // Verifica se o admin já existe
  const existing = await db.select().from(users).where(eq(users.openId, adminOpenId)).limit(1);

  if (existing.length > 0) {
    console.log("[Seed] Usuário administrador já existe.");
    return;
  }

  const newUser: InsertUser = {
    openId: adminOpenId,
    name: "Administrador Mestre",
    email: "admin@vertice.edu.br",
    role: "admin",
    loginMethod: "local",
  };

  await db.insert(users).values(newUser);
  console.log(`[Seed] Usuário administrador criado com OpenID: ${adminOpenId}`);
}

// Executa apenas se chamado diretamente ou importado
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  seedAdmin().catch(console.error);
}

export { seedAdmin };