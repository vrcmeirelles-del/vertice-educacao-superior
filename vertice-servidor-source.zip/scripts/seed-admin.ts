import { eq } from "drizzle-orm";
import { pathToFileURL } from "node:url";
import { getDb } from "../server/db";
import { users } from "../drizzle/schema";
import { matchesOwnerIdentity } from "../server/_core/owner";

export async function seedAdmin() {
  const id = process.env.OWNER_OPEN_ID?.trim();
  if (!id || !process.env.OWNER_EMAIL?.trim()) return;
  const db = await getDb();
  if (!db) return;
  const [existing] = await db.select().from(users).where(eq(users.openId, id)).limit(1);
  // Promote only an existing, authenticated identity. Never fabricate an account.
  if (!existing || !matchesOwnerIdentity(existing)) return;
  if (existing.role !== "admin") await db.update(users).set({ role: "admin" }).where(eq(users.id, existing.id));
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  seedAdmin().catch(() => { console.error("Falha ao preparar proprietário."); process.exitCode = 1; });
}
