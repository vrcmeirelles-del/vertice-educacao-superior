#!/usr/bin/env python3
"""Empacota somente o conteúdo empresarial autorizado da Vértice."""
from pathlib import Path
import subprocess, zipfile, shutil, json

ROOT = Path(__file__).resolve().parent.parent
OUT = Path('/home/ubuntu/entrega-vertice-empresa')
OUT.mkdir(exist_ok=True)
files = subprocess.check_output(['git', 'ls-files'], cwd=ROOT, text=True).splitlines()
excluded_parts = {'.git', 'node_modules', '.manus', 'upload', 'logs'}
excluded_names = {'.env', '.env.local', '.env.production', '.env.development'}
zip_path = OUT / 'Vertice_Educacao_Superior_Site_Completo.zip'
with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for name in files:
        path = ROOT / name
        if not path.is_file() or any(p in excluded_parts for p in path.parts):
            continue
        if path.name in excluded_names or path.name.startswith('.env.') and path.name != '.env.example':
            continue
        archive.write(path, 'codigo/' + name)
    for path in sorted((ROOT/'dist/public').rglob('*')):
        if path.is_file():
            archive.write(path, 'site-compilado/' + path.relative_to(ROOT/'dist/public').as_posix())
    for path in sorted(OUT.iterdir()):
        if path.is_file() and path.suffix != '.zip':
            archive.write(path, 'entrega/' + path.name)
with zipfile.ZipFile(zip_path) as archive:
    assert archive.testzip() is None
    names=archive.namelist()
    assert 'site-compilado/index.html' in names
    assert 'codigo/client/src/pages/Goals.tsx' in names
    assert not any(n.endswith('.docx') or n.endswith('.pdf') for n in names)
    assert not any('/node_modules/' in n or '/.git/' in n for n in names)
print(f'Pacote íntegro: {zip_path} | {len(names)} arquivos | {zip_path.stat().st_size} bytes')
